package com.onehub.floatgauge;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.PixelFormat;
import android.os.Build;
import android.os.IBinder;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.MotionEvent;
import android.view.View;
import android.view.WindowManager;
import android.widget.FrameLayout;
import android.widget.Toast;

import androidx.core.app.NotificationCompat;

public class FloatService extends Service implements CarDataReader.Listener {

    public static final String ACTION_START = "START";
    public static final String ACTION_STOP = "STOP";
    private static final String CH = "float_gauge";
    private static final int NID = 42;
    private static final String PREFS = "onehub_float";

    private WindowManager wm;
    private View root;
    private WindowManager.LayoutParams params;
    private SpeedoView speedo;
    private CarDataReader reader;
    private int sizeDp = 220;
    private int ix, iy;
    private float itx, ity;

    @Override
    public IBinder onBind(Intent i) { return null; }

    @Override
    public void onCreate() {
        super.onCreate();
        wm = (WindowManager) getSystemService(WINDOW_SERVICE);
        if (Build.VERSION.SDK_INT >= 26) {
            NotificationChannel c = new NotificationChannel(CH, "Float Gauge", NotificationManager.IMPORTANCE_LOW);
            NotificationManager nm = getSystemService(NotificationManager.class);
            if (nm != null) nm.createNotificationChannel(c);
        }
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        SharedPreferences p = getSharedPreferences(PREFS, MODE_PRIVATE);
        if (intent != null && ACTION_STOP.equals(intent.getAction())) {
            stopAll();
            return START_NOT_STICKY;
        }
        if (root == null) {
            sizeDp = p.getInt("size", 220);
            show();
            reader = new CarDataReader(this, this);
            reader.start();
        }
        startForeground(NID, notif());
        return START_STICKY;
    }

    private void show() {
        root = LayoutInflater.from(this).inflate(R.layout.float_root, null);
        FrameLayout content = root.findViewById(R.id.content);
        speedo = new SpeedoView(this);
        SharedPreferences p = getSharedPreferences(PREFS, MODE_PRIVATE);
        speedo.setStyle(p.getInt("style", 0));
        speedo.setThemeIndex(p.getInt("theme", 0));
        content.addView(speedo, new FrameLayout.LayoutParams(
                FrameLayout.LayoutParams.MATCH_PARENT, FrameLayout.LayoutParams.MATCH_PARENT));

        int type = Build.VERSION.SDK_INT >= 26
                ? WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
                : WindowManager.LayoutParams.TYPE_PHONE;

        params = new WindowManager.LayoutParams(
                dp(sizeDp), dp(sizeDp + 48),
                type,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE | WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
                PixelFormat.TRANSLUCENT);
        params.gravity = Gravity.TOP | Gravity.START;
        params.x = 80;
        params.y = 160;

        root.setOnTouchListener((v, e) -> {
            switch (e.getAction()) {
                case MotionEvent.ACTION_DOWN:
                    ix = params.x; iy = params.y;
                    itx = e.getRawX(); ity = e.getRawY();
                    return true;
                case MotionEvent.ACTION_MOVE:
                    params.x = ix + (int) (e.getRawX() - itx);
                    params.y = iy + (int) (e.getRawY() - ity);
                    try { wm.updateViewLayout(root, params); } catch (Exception ignored) {}
                    return true;
            }
            return false;
        });

        root.findViewById(R.id.btn_theme).setOnClickListener(v -> {
            // cycle style then theme for variety like OneHub
            if (speedo.getStyle() == SpeedoView.STYLE_COUNT - 1) {
                speedo.setStyle(0);
                speedo.nextTheme();
            } else {
                speedo.nextStyle();
            }
            p.edit().putInt("style", speedo.getStyle()).putInt("theme", speedo.getThemeIndex()).apply();
        });

        root.findViewById(R.id.btn_bigger).setOnClickListener(v -> resize(+30));
        root.findViewById(R.id.btn_smaller).setOnClickListener(v -> resize(-30));
        root.findViewById(R.id.btn_close).setOnClickListener(v -> {
            getSharedPreferences(PREFS, MODE_PRIVATE).edit().putBoolean("on", false).apply();
            stopAll();
        });

        try {
            wm.addView(root, params);
        } catch (Exception e) {
            Toast.makeText(this, "امنح إذن الظهور فوق التطبيقات", Toast.LENGTH_LONG).show();
            stopSelf();
        }
    }

    private void resize(int delta) {
        sizeDp = Math.max(140, Math.min(340, sizeDp + delta));
        getSharedPreferences(PREFS, MODE_PRIVATE).edit().putInt("size", sizeDp).apply();
        params.width = dp(sizeDp);
        params.height = dp(sizeDp + 48);
        FrameLayout content = root.findViewById(R.id.content);
        content.getLayoutParams().width = dp(sizeDp);
        content.getLayoutParams().height = dp(sizeDp);
        content.requestLayout();
        try { wm.updateViewLayout(root, params); } catch (Exception ignored) {}
    }

    @Override
    public void onData(CarDataReader.Snapshot s) {
        if (speedo != null) {
            speedo.setData(s.speed, s.gear, s.fuelPct, s.powerKw);
        }
    }

    private void stopAll() {
        if (reader != null) { reader.stop(); reader = null; }
        if (root != null) {
            try { wm.removeView(root); } catch (Exception ignored) {}
            root = null;
        }
        stopForeground(true);
        stopSelf();
    }

    private Notification notif() {
        Intent stop = new Intent(this, FloatService.class).setAction(ACTION_STOP);
        PendingIntent pi = PendingIntent.getService(this, 0, stop,
                PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
        Intent open = new Intent(this, MainActivity.class);
        PendingIntent oi = PendingIntent.getActivity(this, 1, open,
                PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
        return new NotificationCompat.Builder(this, CH)
                .setContentTitle("OneHub Float")
                .setContentText("العداد العائم يعمل")
                .setSmallIcon(android.R.drawable.ic_menu_compass)
                .setContentIntent(oi)
                .addAction(0, "إيقاف", pi)
                .setOngoing(true)
                .setPriority(NotificationCompat.PRIORITY_LOW)
                .build();
    }

    private int dp(int v) {
        return Math.round(v * getResources().getDisplayMetrics().density);
    }

    @Override
    public void onDestroy() {
        if (reader != null) reader.stop();
        if (root != null) {
            try { wm.removeView(root); } catch (Exception ignored) {}
        }
        super.onDestroy();
    }
}
