package com.onehub.floatgauge;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.RectF;
import android.graphics.Typeface;
import android.util.AttributeSet;
import android.view.View;

/**
 * Draws floating speedometer styles inspired by OneHub video:
 * 0 = full circular digital (PRND + km/h)
 * 1 = compact horizontal bar
 * 2 = analog-style arc
 * 3 = rings / concentric
 */
public class SpeedoView extends View {

    public static final int STYLE_CIRCLE = 0;
    public static final int STYLE_BAR = 1;
    public static final int STYLE_ARC = 2;
    public static final int STYLE_RINGS = 3;
    public static final int STYLE_COUNT = 4;

    // Themes (accent colors) matching video: green, purple, white, red/pink, cyan
    public static final int[] THEMES = {
            0xFF00E676, // green
            0xFFB388FF, // purple
            0xFFFFFFFF, // white
            0xFFFF5252, // red/pink
            0xFF00E5FF  // cyan
    };

    private int style = STYLE_CIRCLE;
    private int themeIndex = 0;
    private float speed = 0f;
    private String gear = "P";
    private int fuelPct = -1;
    private float powerKw = Float.NaN;

    private final Paint paint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint textPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final RectF oval = new RectF();

    public SpeedoView(Context c) { super(c); init(); }
    public SpeedoView(Context c, AttributeSet a) { super(c, a); init(); }

    private void init() {
        textPaint.setTypeface(Typeface.DEFAULT_BOLD);
        textPaint.setTextAlign(Paint.Align.CENTER);
    }

    public void setStyle(int s) {
        style = ((s % STYLE_COUNT) + STYLE_COUNT) % STYLE_COUNT;
        invalidate();
    }

    public int getStyle() { return style; }

    public void nextStyle() {
        setStyle(style + 1);
    }

    public void setThemeIndex(int i) {
        themeIndex = ((i % THEMES.length) + THEMES.length) % THEMES.length;
        invalidate();
    }

    public void nextTheme() {
        setThemeIndex(themeIndex + 1);
    }

    public int getThemeIndex() { return themeIndex; }

    public void setData(float speedKmh, String gear, int fuelPct, float powerKw) {
        this.speed = Math.max(0, speedKmh);
        this.gear = gear != null ? gear : "-";
        this.fuelPct = fuelPct;
        this.powerKw = powerKw;
        invalidate();
    }

    private int accent() { return THEMES[themeIndex]; }

    @Override
    protected void onDraw(Canvas c) {
        super.onDraw(c);
        int w = getWidth();
        int h = getHeight();
        if (w <= 0 || h <= 0) return;

        switch (style) {
            case STYLE_BAR: drawBar(c, w, h); break;
            case STYLE_ARC: drawArc(c, w, h); break;
            case STYLE_RINGS: drawRings(c, w, h); break;
            default: drawCircle(c, w, h); break;
        }
    }

    private void drawCircle(Canvas c, int w, int h) {
        float cx = w / 2f, cy = h / 2f;
        float r = Math.min(w, h) * 0.42f;
        int acc = accent();

        // outer ring
        paint.setStyle(Paint.Style.STROKE);
        paint.setStrokeWidth(r * 0.08f);
        paint.setColor(Color.argb(40, 255, 255, 255));
        c.drawCircle(cx, cy, r, paint);

        // progress arc (speed 0-240)
        float sweep = Math.min(1f, speed / 240f) * 270f;
        oval.set(cx - r, cy - r, cx + r, cy + r);
        paint.setColor(acc);
        paint.setStrokeCap(Paint.Cap.ROUND);
        c.drawArc(oval, 135f, sweep, false, paint);

        // tick marks
        paint.setStrokeWidth(2f);
        paint.setColor(Color.argb(120, 255, 255, 255));
        for (int i = 0; i <= 12; i++) {
            float a = (float) Math.toRadians(135 + i * 22.5);
            float r1 = r * 0.88f, r2 = r * 0.96f;
            c.drawLine(cx + r1 * (float) Math.cos(a), cy + r1 * (float) Math.sin(a),
                    cx + r2 * (float) Math.cos(a), cy + r2 * (float) Math.sin(a), paint);
        }

        // speed number
        textPaint.setColor(Color.WHITE);
        textPaint.setTextSize(r * 0.55f);
        c.drawText(String.valueOf(Math.round(speed)), cx, cy + r * 0.08f, textPaint);

        textPaint.setTextSize(r * 0.18f);
        textPaint.setColor(Color.argb(200, 255, 255, 255));
        c.drawText("km/h", cx, cy + r * 0.32f, textPaint);

        // PRND
        textPaint.setTextSize(r * 0.16f);
        String[] gears = {"P", "R", "N", "D"};
        float gx = cx - r * 0.35f;
        for (String g : gears) {
            textPaint.setColor(g.equals(gear) ? acc : Color.argb(100, 255, 255, 255));
            c.drawText(g, gx, cy + r * 0.55f, textPaint);
            gx += r * 0.23f;
        }
    }

    private void drawBar(Canvas c, int w, int h) {
        float pad = 8f;
        RectF bg = new RectF(pad, pad, w - pad, h - pad);
        paint.setStyle(Paint.Style.FILL);
        paint.setColor(Color.argb(200, 20, 20, 20));
        c.drawRoundRect(bg, 24f, 24f, paint);

        paint.setStyle(Paint.Style.STROKE);
        paint.setStrokeWidth(3f);
        paint.setColor(accent());
        c.drawRoundRect(bg, 24f, 24f, paint);

        // mini arc left
        float cx = h * 0.45f, cy = h / 2f, r = h * 0.32f;
        paint.setStrokeWidth(r * 0.15f);
        paint.setColor(Color.argb(50, 255, 255, 255));
        oval.set(cx - r, cy - r, cx + r, cy + r);
        c.drawArc(oval, 135f, 270f, false, paint);
        float sweep = Math.min(1f, speed / 240f) * 270f;
        paint.setColor(accent());
        c.drawArc(oval, 135f, sweep, false, paint);

        // speed
        textPaint.setColor(Color.WHITE);
        textPaint.setTextSize(h * 0.28f);
        textPaint.setTextAlign(Paint.Align.LEFT);
        c.drawText(String.valueOf(Math.round(speed)), cx + r * 1.3f, cy + h * 0.02f, textPaint);
        textPaint.setTextSize(h * 0.12f);
        textPaint.setColor(Color.argb(180, 255, 255, 255));
        c.drawText("km/h", cx + r * 1.3f, cy + h * 0.22f, textPaint);

        // fuel / power right side
        textPaint.setTextAlign(Paint.Align.RIGHT);
        textPaint.setTextSize(h * 0.14f);
        textPaint.setColor(accent());
        String right = fuelPct >= 0 ? (fuelPct + "%") : (Float.isNaN(powerKw) ? "--" : (Math.round(powerKw) + " kW"));
        c.drawText(right, w - pad * 3, cy + h * 0.05f, textPaint);
        textPaint.setTextAlign(Paint.Align.CENTER);
    }

    private void drawArc(Canvas c, int w, int h) {
        float cx = w / 2f, cy = h * 0.58f;
        float r = Math.min(w, h) * 0.48f;
        int acc = accent();

        paint.setStyle(Paint.Style.STROKE);
        paint.setStrokeWidth(r * 0.12f);
        paint.setColor(Color.argb(40, 255, 255, 255));
        oval.set(cx - r, cy - r, cx + r, cy + r);
        c.drawArc(oval, 180f, 180f, false, paint);

        float sweep = Math.min(1f, speed / 240f) * 180f;
        paint.setColor(acc);
        paint.setStrokeCap(Paint.Cap.ROUND);
        c.drawArc(oval, 180f, sweep, false, paint);

        textPaint.setColor(Color.WHITE);
        textPaint.setTextSize(r * 0.4f);
        c.drawText(String.valueOf(Math.round(speed)), cx, cy - r * 0.05f, textPaint);
        textPaint.setTextSize(r * 0.15f);
        textPaint.setColor(Color.argb(180, 255, 255, 255));
        c.drawText("km/h", cx, cy + r * 0.18f, textPaint);

        // power badge
        if (!Float.isNaN(powerKw)) {
            textPaint.setTextSize(r * 0.14f);
            textPaint.setColor(acc);
            c.drawText(Math.round(powerKw) + " kW", cx, cy + r * 0.4f, textPaint);
        }
    }

    private void drawRings(Canvas c, int w, int h) {
        float cx = w / 2f, cy = h / 2f;
        float maxR = Math.min(w, h) * 0.42f;
        int acc = accent();

        paint.setStyle(Paint.Style.STROKE);
        for (int i = 4; i >= 1; i--) {
            float rr = maxR * (i / 4f);
            paint.setStrokeWidth(maxR * 0.04f);
            int alpha = 30 + i * 30;
            paint.setColor(Color.argb(alpha, Color.red(acc), Color.green(acc), Color.blue(acc)));
            c.drawCircle(cx, cy, rr, paint);
        }

        // speed progress on outer
        paint.setStrokeWidth(maxR * 0.06f);
        paint.setColor(acc);
        oval.set(cx - maxR, cy - maxR, cx + maxR, cy + maxR);
        float sweep = Math.min(1f, speed / 240f) * 360f;
        c.drawArc(oval, -90f, sweep, false, paint);

        textPaint.setColor(Color.WHITE);
        textPaint.setTextSize(maxR * 0.45f);
        c.drawText(String.valueOf(Math.round(speed)), cx, cy + maxR * 0.05f, textPaint);
        textPaint.setTextSize(maxR * 0.16f);
        textPaint.setColor(Color.argb(180, 255, 255, 255));
        c.drawText("km/h", cx, cy + maxR * 0.28f, textPaint);
    }
}
