package com.onehub.floatgauge;

import android.content.Context;
import android.os.Handler;
import android.os.Looper;
import android.util.Log;

import java.lang.reflect.Method;
import java.util.concurrent.Executors;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.atomic.AtomicBoolean;

public class CarDataReader {
    private static final String TAG = "CarDataReader";
    public static final int PROP_SPEED = 0x11600207;
    public static final int PROP_FUEL = 0x2140a569;

    public static class Snapshot {
        public float speed = 0f;
        public String gear = "P";
        public int fuelPct = -1;
        public float powerKw = Float.NaN;
        public boolean fromCar = false;
    }

    public interface Listener { void onData(Snapshot s); }

    private final Context ctx;
    private final Listener listener;
    private final Handler main = new Handler(Looper.getMainLooper());
    private ScheduledExecutorService exec;
    private final AtomicBoolean running = new AtomicBoolean(false);
    private Object car, pm;
    private Method getFloat, getInt;
    private boolean carOk = false;
    private float demoSpeed = 0f;
    private boolean demoUp = true;

    public CarDataReader(Context c, Listener l) {
        ctx = c.getApplicationContext();
        listener = l;
        initCar();
    }

    private void initCar() {
        try {
            Class<?> carCl = Class.forName("android.car.Car");
            car = carCl.getMethod("createCar", Context.class).invoke(null, ctx);
            if (car == null) return;
            pm = carCl.getMethod("getCarManager", String.class).invoke(car, "property");
            if (pm == null) return;
            getFloat = pm.getClass().getMethod("getFloatProperty", int.class, int.class);
            getInt = pm.getClass().getMethod("getIntProperty", int.class, int.class);
            carOk = true;
        } catch (Throwable t) {
            Log.w(TAG, "No Car API: " + t.getMessage());
            carOk = false;
        }
    }

    public void start() {
        if (running.getAndSet(true)) return;
        exec = Executors.newSingleThreadScheduledExecutor();
        exec.scheduleAtFixedRate(this::poll, 0, 150, TimeUnit.MILLISECONDS);
    }

    public void stop() {
        running.set(false);
        if (exec != null) { exec.shutdownNow(); exec = null; }
    }

    private void poll() {
        if (!running.get()) return;
        Snapshot s = new Snapshot();
        if (carOk && pm != null) {
            try {
                Object f = getFloat.invoke(pm, PROP_SPEED, 0);
                if (f instanceof Float) s.speed = (Float) f;
                Object i = getInt.invoke(pm, PROP_FUEL, 0);
                if (i instanceof Integer) {
                    int v = (Integer) i;
                    if (v >= 0 && v <= 100) s.fuelPct = v;
                }
                s.fromCar = true;
            } catch (Throwable ignored) { carOk = false; }
        }
        if (!s.fromCar) {
            if (demoUp) { demoSpeed += 1.5f; if (demoSpeed >= 160) demoUp = false; }
            else { demoSpeed -= 1.2f; if (demoSpeed <= 0) { demoSpeed = 0; demoUp = true; } }
            s.speed = demoSpeed;
            s.fuelPct = 68;
            s.powerKw = demoSpeed > 5 ? -1f : 0f;
            s.gear = demoSpeed > 1 ? "D" : "P";
        }
        final Snapshot out = s;
        main.post(() -> { if (listener != null) listener.onData(out); });
    }
}
