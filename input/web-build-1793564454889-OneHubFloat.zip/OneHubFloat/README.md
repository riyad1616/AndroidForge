# OneHub Float v4

عداد عائم بأسلوب OneHub:
- 4 أشكال: دائري · شريط · قوس · حلقات
- 5 ثيمات ألوان (أخضر / بنفسجي / أبيض / أحمر / سماوي)
- تكبير وتصغير
- سحب حر
- بيانات حية عبر CarProperty عند التوفر، وإلا وضع تجريبي

## البناء
افتح في Android Studio → Build → Build APK(s)
أو: ./gradlew assembleDebug

minSdk 24 · targetSdk 34 · لا تبعيات معقدة
