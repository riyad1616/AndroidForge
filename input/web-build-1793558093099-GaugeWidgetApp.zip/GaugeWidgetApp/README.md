# Gauge Widget - Digital Speedometer

تطبيق ودجت عداد سرعة رقمي مستخرج من OneHub Car.

## المميزات
- 13 تصميم مختلف للعدادات (مستخرجة من التطبيق الأصلي)
- يمكن إضافته كـ Widget على الشاشة الرئيسية
- اختيار التصميم عند الإضافة

## طريقة البناء (Build)

1. افتح المشروع في **Android Studio** (Arctic Fox أو أحدث)
2. انتظر حتى ينتهي Gradle Sync
3. Connect جهاز أو استخدم Emulator
4. اضغط Run أو Build → Build Bundle(s) / APK(s) → Build APK(s)

أو من الطرفية:
```bash
./gradlew assembleDebug
```
الـ APK سيكون في: `app/build/outputs/apk/debug/app-debug.apk`

## طريقة الاستخدام
1. ثبت الـ APK
2. اضغط مطولاً على الشاشة الرئيسية → Widgets
3. ابحث عن **Digital Speedometer**
4. اسحبه واختر التصميم الذي تريده

## ملاحظات
- الودجت حالياً ثابت (لا يعرض سرعة حقيقية)
- يمكن تطويره لاحقاً لربطه بـ OBD-II أو بيانات السيارة
- يعمل على Android 7.0+ (API 24)

تم استخراج الأصول من: onehub-car-2.9.apk
