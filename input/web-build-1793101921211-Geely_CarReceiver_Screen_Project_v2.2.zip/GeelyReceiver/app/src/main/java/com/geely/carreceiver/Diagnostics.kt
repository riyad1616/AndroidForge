package com.geely.carreceiver

import android.content.Context
import android.os.Build
import java.io.File
import java.io.IOException
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/**
 * Read-only report about this head unit: what Android it runs, whether this app can really become root,
 * and (only when it can) what the Vehicle HAL / car service expose. Send it to whoever adapts the
 * command table. Nothing here changes anything on the car.
 */
object Diagnostics {

    private class Check(val title: String, val command: String)

    /** Checks that need no special rights. */
    private val BASIC = listOf(
        Check("user id", "id"),
        Check("kernel", "uname -a"),
        Check("su binary", "ls -l /system/bin/su /system/xbin/su /sbin/su /su/bin/su /vendor/bin/su 2>&1; ls -Z /system/xbin/su 2>&1"),
        Check(
            "selinux and build flags",
            "getenforce 2>&1; getprop ro.build.type; getprop ro.build.tags; getprop ro.debuggable; getprop ro.secure; " +
                "getprop service.adb.tcp.port; getprop persist.adb.tcp.port; getprop persist.sys.usb.config"
        ),
        Check("listening ports", "netstat -tln 2>&1 | head -n 30"),
        Check(
            "car related properties",
            "getprop | grep -iE 'geely|ecarx|vehicle|flyme|hvac|\\.car\\.|mcu' | grep -v 'log.tag' | head -n 100"
        ),
        Check("all service names", "service list 2>&1 | cut -f2 | cut -d: -f1 | head -n 400"),
        Check(
            "car related permissions (name + protection level)",
            "pm list permissions -f 2>&1 | grep -iE -A4 'permission:.*(\\.car\\.|ecarx|geely|vehicle|hvac)' | " +
                "grep -E 'permission:|protectionLevel' | head -n 120"
        ),
        Check("network", "ip -4 addr 2>&1 | grep -E 'inet |^[0-9]+:' | head -n 20")
    )

    /** Read-only checks that are run as root, and only when su really gives root to this app. */
    private val ROOT_CHECKS = listOf(
        Check("hal services", "lshal 2>&1 | grep -iE 'vehicle|ecarx|geely|car' | head -n 30"),
        Check("vehicle hal help", "lshal debug android.hardware.automotive.vehicle@2.0::IVehicle/default --help 2>&1 | head -n 40"),
        Check("vehicle hal property list", "lshal debug android.hardware.automotive.vehicle@2.0::IVehicle/default --list 2>&1 | head -n 250"),
        Check("car_service dump", "dumpsys car_service 2>&1 | head -n 250")
    )

    private const val CHECK_TIMEOUT_MS = 6000L
    private const val MAX_CHARS = 9000

    /** Blocking (up to a minute on a slow unit): call from a background thread. */
    fun run(context: Context): String {
        val sb = StringBuilder()
        sb.append("Geely Receiver diagnostics ").append(SimpleDateFormat("yyyy-MM-dd HH:mm", Locale.US).format(Date())).append("\n\n")
        sb.append("manufacturer: ").append(Build.MANUFACTURER).append('\n')
        sb.append("model: ").append(Build.MODEL).append('\n')
        sb.append("device: ").append(Build.DEVICE).append('\n')
        sb.append("android: ").append(Build.VERSION.RELEASE).append(" (sdk ").append(Build.VERSION.SDK_INT).append(")\n")
        sb.append("build: ").append(Build.DISPLAY).append('\n')
        sb.append("fingerprint: ").append(Build.FINGERPRINT).append("\n\n")

        for (check in BASIC) section(sb, check.title, check.command)

        // Does su really give root to THIS app? (a su binary can exist and still refuse every app)
        val suPath = CommandBackend.SU_PATHS.firstOrNull { File(it).exists() }
        var wrap: ((String) -> String)? = null
        if (suPath == null) {
            sb.append("## su test\n(no su binary found)\n\n")
        } else {
            val dashC = section(sb, "su -c id", "$suPath -c id 2>&1")
            if (dashC.contains("uid=0")) {
                wrap = { inner -> "$suPath -c '$inner' 2>&1" }
            } else {
                val zero = section(sb, "su 0 id", "$suPath 0 id 2>&1")
                if (zero.contains("uid=0")) wrap = { inner -> "$suPath 0 sh -c '$inner' 2>&1" }
            }
        }

        val rootWrap = wrap
        if (rootWrap == null) {
            sb.append("## root-only checks\nskipped: su does not give root to this app (see the su test above)\n\n")
        } else {
            for (check in ROOT_CHECKS) section(sb, "root: " + check.title, rootWrap(check.command))
        }

        sb.append("command table: ").append(File(context.filesDir, CommandBackend.FILE_NAME).absolutePath).append('\n')
        return sb.toString()
    }

    /** Runs one check, appends it to the report and returns its raw output (for decisions). */
    private fun section(sb: StringBuilder, title: String, command: String): String {
        sb.append("## ").append(title).append("\n$ ").append(command).append('\n')
        val out = Shell.run(arrayOf("sh", "-c", command), CHECK_TIMEOUT_MS, MAX_CHARS)
        val failure = out.failure
        when {
            failure != null -> {
                sb.append("[").append(failure).append("]\n")
                if (out.text.isNotEmpty()) sb.append(out.text).append('\n')
            }
            out.text.isEmpty() -> sb.append("(no output, exit=").append(out.exit).append(")\n")
            else -> sb.append(out.text).append('\n')
        }
        sb.append('\n')
        return out.text
    }

    /** @return the path of the saved report, or null when it could not be written. */
    fun save(context: Context, report: String): String? = try {
        val dir = context.getExternalFilesDir(null) ?: context.filesDir
        val file = File(dir, "diagnostics.txt")
        file.writeText(report, Charsets.UTF_8)
        file.absolutePath
    } catch (e: IOException) {
        null
    }
}
