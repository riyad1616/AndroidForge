package com.geely.carreceiver

import android.content.Context
import android.content.Intent
import java.io.File
import java.io.IOException

/**
 * Turns a command name received from the phone into something that actually runs on this head unit.
 *
 * The table lives in an editable text file (see [defaultText]) so it can be changed on the car screen
 * ("أوامر السيارة" button) without rebuilding the app. Most commands still write a token to
 * /dev/car_control, exactly like the original project; that device does not exist on a real head unit,
 * so those lines must still be replaced with commands that really work on the car (see the "فحص النظام"
 * report). The windows and sunroof already use a real mechanism: this car's launcher app
 * (com.flyme.auto.launcher) ships two exported, unprotected broadcast receivers — the same ones its own
 * widget buttons use — that call the real android.car.hardware.property.CarPropertyManager for us, with
 * no root needed. A line of the form `COMMAND=BROADCAST <action> <package>/<Class>` sends that broadcast
 * instead of running a shell command; see [execute].
 */
class CommandBackend(
    private val context: Context,
    private val suPaths: List<String> = SU_PATHS
) {

    data class ExecResult(val ok: Boolean, val message: String)

    /** Can this app really become root through su? [message] is "ok" or the reason su refused. */
    class SuStatus(val path: String?, val works: Boolean, val message: String)

    private class Config(val options: Map<String, String>, val commands: Map<String, String>)

    private val file: File get() = File(context.filesDir, FILE_NAME)
    private val execLock = Any()
    private val suLock = Any()
    private var suCache: SuStatus? = null
    private var suCacheAt = 0L

    fun isKnown(cmd: String) = cmd in KNOWN

    fun ensureConfig() {
        if (!file.exists()) {
            try {
                writeText(defaultText())
            } catch (e: IOException) {
                // execute() falls back to the built-in defaults when the file cannot be read
            }
        }
    }

    fun readText(): String = try {
        if (file.exists()) file.readText(Charsets.UTF_8) else defaultText()
    } catch (e: IOException) {
        defaultText()
    }

    @Throws(IOException::class)
    fun writeText(text: String) {
        file.writeText(text, Charsets.UTF_8)
    }

    @Throws(IOException::class)
    fun resetToDefault() = writeText(defaultText())

    /** True while at least one command still points at the placeholder device and that device is missing. */
    fun usesPlaceholder(): Boolean =
        parse(readText()).commands.values.any { it.contains(PLACEHOLDER_DEVICE) } && !File(PLACEHOLDER_DEVICE).exists()

    fun execute(cmd: String): ExecResult = synchronized(execLock) {
        val config = parse(readText())
        val line = config.commands[cmd] ?: return ExecResult(false, "no command configured for $cmd")
        if (line.isBlank()) return ExecResult(false, "empty command for $cmd")

        if (line.startsWith("BROADCAST ", ignoreCase = true)) {
            return sendVehicleBroadcast(line.substring("BROADCAST ".length).trim())
        }

        val timeoutMs = (config.options["timeout_ms"]?.toLongOrNull() ?: 4000L).coerceIn(500L, 20000L)
        val mode = (config.options["run_as_root"] ?: "auto").lowercase()
        val su = suStatus()
        val useRoot = when (mode) {
            "true" -> true
            "false" -> false
            else -> su.works // auto: only when su really gives root to this app
        }
        val suPath = su.path
        if (useRoot && suPath == null) return ExecResult(false, "run_as_root=true but no su binary was found")

        // The command runs exactly once: no silent retry without su (it hid the real reason and could repeat side effects).
        val out = if (useRoot && suPath != null) {
            Shell.run(arrayOf(suPath, "-c", line), timeoutMs)
        } else {
            Shell.run(arrayOf("sh", "-c", line), timeoutMs)
        }
        if (out.ok) return ExecResult(true, out.text)

        var detail = out.failure ?: ("exit=" + out.exit + (if (out.text.isNotEmpty()) ": " + out.text else ""))
        if (!useRoot && mode != "false" && suPath != null) detail += "  [su unusable: " + su.message + "]"
        ExecResult(false, detail)
    }

    /**
     * `BROADCAST <action> <package>/<Class>`: sends an explicit broadcast Intent to a component in another
     * app, exactly like tapping that app's own widget button would. Works without root, because Android lets
     * any app send a broadcast to a component that the target declares `exported` with no `android:permission`
     * — the vehicle operation itself then runs inside the TARGET app's process, using its own permissions,
     * not ours. This is fire-and-forget: a successful send only means the broadcast was dispatched, not that
     * the window (or whatever it controls) actually moved — there is no reply to confirm that.
     */
    private fun sendVehicleBroadcast(spec: String): ExecResult {
        val parts = spec.split(Regex("\\s+")).filter { it.isNotEmpty() }
        if (parts.size != 2) return ExecResult(false, "BROADCAST needs exactly: <action> <package>/<Class>, got '$spec'")
        val (action, target) = parts
        val slash = target.indexOf('/')
        if (slash <= 0 || slash == target.length - 1) return ExecResult(false, "bad BROADCAST target '$target' (expected package/Class)")
        val pkg = target.substring(0, slash)
        val cls = target.substring(slash + 1)
        val className = if (cls.startsWith(".")) pkg + cls else cls
        return try {
            context.applicationContext.sendBroadcast(Intent(action).setClassName(pkg, className))
            ExecResult(true, "broadcast '$action' sent to $pkg/$className (fire-and-forget, not confirmed)")
        } catch (e: Exception) {
            ExecResult(false, "broadcast failed: " + (e.message ?: e.javaClass.simpleName))
        }
    }

    /** Result of a real `su -c id` test, cached for a minute (running su before every command would be slow). */
    fun suStatus(): SuStatus = synchronized(suLock) {
        val now = System.currentTimeMillis()
        val cached = suCache
        if (cached != null && now - suCacheAt < SU_CACHE_MS) return cached
        val fresh = probeSu()
        suCache = fresh
        suCacheAt = now
        fresh
    }

    private fun probeSu(): SuStatus {
        val path = findSu() ?: return SuStatus(null, false, "no su binary found")
        val out = Shell.run(arrayOf(path, "-c", "id"), SU_PROBE_TIMEOUT_MS)
        val works = out.ok && out.text.contains("uid=0")
        val failure = out.failure
        val message = when {
            works -> "ok"
            failure != null -> failure
            out.text.isNotEmpty() -> out.text.replace(Regex("\\s+"), " ").take(120)
            else -> "exit=" + out.exit
        }
        return SuStatus(path, works, message)
    }

    private fun findSu(): String? =
        suPaths.firstOrNull { File(it).exists() }

    private fun parse(text: String): Config {
        val options = HashMap<String, String>()
        val commands = HashMap<String, String>()
        for (raw in text.lineSequence()) {
            val line = raw.trim()
            if (line.isEmpty() || line.startsWith("#")) continue
            val eq = line.indexOf('=')
            if (eq <= 0) continue
            val key = line.substring(0, eq).trim()
            val value = line.substring(eq + 1).trim()
            if (key in KNOWN) commands[key] = value else options[key.lowercase()] = value
        }
        return Config(options, commands)
    }

    companion object {
        const val FILE_NAME = "car_commands.txt"
        const val PLACEHOLDER_DEVICE = "/dev/car_control"
        private const val SU_CACHE_MS = 60_000L
        private const val SU_PROBE_TIMEOUT_MS = 5000L

        val SU_PATHS: List<String> = listOf(
            "/system/bin/su", "/system/xbin/su", "/sbin/su", "/su/bin/su", "/vendor/bin/su", "/system/sbin/su"
        )

        /** Found by reading this car's own launcher app (com.flyme.auto.launcher): its two exported,
         *  unprotected widget receivers, and the action string each one of its buttons sends. */
        private const val LAUNCHER_PKG = "com.flyme.auto.launcher"
        private const val WINDOWS_WIDGET = "com.coolray.vehicle.WindowsWidgetV2"
        private const val ROOF_WIDGET = "com.coolray.vehicle.RoofWidgetV2"

        /** command name -> BROADCAST line, for the commands wired to that real mechanism. */
        private val BROADCAST_DEFAULTS: Map<String, String> = linkedMapOf(
            "CMD_WINDOW_OPEN" to "BROADCAST com.coolray.vehicle.ALL_OPEN $LAUNCHER_PKG/$WINDOWS_WIDGET",
            "CMD_WINDOW_CLOSE" to "BROADCAST com.coolray.vehicle.ALL_CLOSE $LAUNCHER_PKG/$WINDOWS_WIDGET",
            "CMD_SUNROOF_OPEN" to "BROADCAST com.coolray.vehicle.ROOF_OPEN $LAUNCHER_PKG/$ROOF_WIDGET",
            "CMD_SUNROOF_CLOSE" to "BROADCAST com.coolray.vehicle.ROOF_CLOSE $LAUNCHER_PKG/$ROOF_WIDGET"
        )

        /** command name -> token written to the placeholder device (same table as the original project).
         *  The 4 commands above are overridden with [BROADCAST_DEFAULTS] in [defaultText]; their entries
         *  below only matter if someone deletes the BROADCAST line and wants the old placeholder back. */
        private val DEFAULTS: LinkedHashMap<String, String> = linkedMapOf(
            "CMD_WINDOW_OPEN" to "OPEN_WINDOWS",
            "CMD_WINDOW_CLOSE" to "CLOSE_WINDOWS",
            "CMD_SUNROOF_OPEN" to "OPEN_SUNROOF",
            "CMD_SUNROOF_CLOSE" to "CLOSE_SUNROOF",
            "CMD_AC_ON" to "AC_ON",
            "CMD_AC_OFF" to "AC_OFF",
            "CMD_MIRROR_UNFOLD" to "UNFOLD_MIRRORS",
            "CMD_MIRROR_FOLD" to "FOLD_MIRRORS",
            "CMD_HEADLIGHTS_ON" to "HEADLIGHTS_ON",
            "CMD_HEADLIGHTS_OFF" to "HEADLIGHTS_OFF",
            "CMD_HIGHBEAM_ON" to "HIGHBEAM_ON",
            "CMD_HIGHBEAM_OFF" to "HIGHBEAM_OFF",
            "CMD_INTERIOR_ON" to "INTERIOR_ON",
            "CMD_INTERIOR_OFF" to "INTERIOR_OFF",
            "CMD_FOG_ON" to "FOG_ON",
            "CMD_FOG_OFF" to "FOG_OFF",
            "CMD_DOOR_UNLOCK" to "DOOR_UNLOCK",
            "CMD_DOOR_LOCK" to "DOOR_LOCK",
            "CMD_TRUNK_OPEN" to "TRUNK_OPEN",
            "CMD_TRUNK_CLOSE" to "TRUNK_CLOSE",
            "CMD_HORN" to "HORN",
            "CMD_RADIO_ON" to "RADIO_ON",
            "CMD_RADIO_OFF" to "RADIO_OFF",
            "CMD_SEAT_HEAT_ON" to "SEAT_HEAT_ON",
            "CMD_SEAT_HEAT_OFF" to "SEAT_HEAT_OFF",
            "CMD_HAZARD_ON" to "HAZARD_ON",
            "CMD_HAZARD_OFF" to "HAZARD_OFF"
        )

        /** Every command the phone may send (the table above plus the reboot command). */
        val KNOWN: Set<String> = DEFAULTS.keys + "CMD_REBOOT"

        fun defaultText(): String {
            val sb = StringBuilder()
            sb.append("# Geely Receiver - command table\n")
            sb.append("# Two kinds of line are understood:\n")
            sb.append("#   COMMAND_NAME=shell command                         (run with: sh -c ...)\n")
            sb.append("#   COMMAND_NAME=BROADCAST <action> <package>/<Class>  (sends a broadcast, no shell)\n")
            sb.append("# The /dev/car_control lines below are placeholders from the original project.\n")
            sb.append("# Replace them with commands that really work on this head unit.\n")
            sb.append("# The 4 BROADCAST lines below are real: this car's own launcher app exposes the\n")
            sb.append("# exact same window/sunroof buttons its widgets use, with no permission needed to call them.\n")
            sb.append("# Avoid backslashes. Lines starting with # are ignored.\n")
            sb.append("#\n")
            sb.append("# run_as_root: auto = use su when it exists | true | false (BROADCAST lines ignore this)\n")
            sb.append("run_as_root=auto\n")
            sb.append("timeout_ms=4000\n\n")
            for ((name, token) in DEFAULTS) {
                val broadcast = BROADCAST_DEFAULTS[name]
                if (broadcast != null) {
                    sb.append(name).append('=').append(broadcast).append('\n')
                } else {
                    sb.append(name).append("=echo '").append(token).append("' > ").append(PLACEHOLDER_DEVICE).append('\n')
                }
            }
            sb.append("CMD_REBOOT=reboot\n")
            return sb.toString()
        }
    }
}
