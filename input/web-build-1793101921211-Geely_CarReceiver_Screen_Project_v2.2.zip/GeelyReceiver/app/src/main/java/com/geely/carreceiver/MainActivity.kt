package com.geely.carreceiver

import android.content.ActivityNotFoundException
import android.content.DialogInterface
import android.content.Intent
import android.content.res.ColorStateList
import android.graphics.Typeface
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.text.InputType
import android.text.Spannable
import android.text.SpannableStringBuilder
import android.text.style.ForegroundColorSpan
import android.view.Gravity
import android.view.View
import android.widget.EditText
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import com.google.android.material.button.MaterialButton
import com.google.android.material.dialog.MaterialAlertDialogBuilder
import java.io.IOException
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import kotlin.concurrent.thread

class MainActivity : AppCompatActivity() {

    private val ui = Handler(Looper.getMainLooper())
    private lateinit var backend: CommandBackend

    private lateinit var dotService: View
    private lateinit var tvServiceState: TextView
    private lateinit var tvBackendWarn: TextView
    private lateinit var tvIp: TextView
    private lateinit var tvPin: TextView
    private lateinit var tvNoNetwork: TextView
    private lateinit var ivQr: ImageView
    private lateinit var tvLog: TextView

    private var lastPayload: String? = null

    /** Re-reads the IP addresses every few seconds: hotspot / Wi-Fi can change while the screen is open. */
    private val ticker = object : Runnable {
        override fun run() {
            refresh()
            ui.postDelayed(this, REFRESH_MS)
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        backend = CommandBackend(this)
        backend.ensureConfig()

        dotService = findViewById(R.id.dotService)
        tvServiceState = findViewById(R.id.tvServiceState)
        tvBackendWarn = findViewById(R.id.tvBackendWarn)
        tvIp = findViewById(R.id.tvIp)
        tvPin = findViewById(R.id.tvPin)
        tvNoNetwork = findViewById(R.id.tvNoNetwork)
        ivQr = findViewById(R.id.ivQr)
        tvLog = findViewById(R.id.tvLog)

        findViewById<MaterialButton>(R.id.btnStart).setOnClickListener { startServer() }
        findViewById<MaterialButton>(R.id.btnStop).setOnClickListener {
            stopService(Intent(this, CarSocketService::class.java))
        }
        findViewById<MaterialButton>(R.id.btnNewPin).setOnClickListener { confirmNewPin() }
        findViewById<MaterialButton>(R.id.btnDiag).setOnClickListener { runDiagnostics() }
        findViewById<MaterialButton>(R.id.btnEdit).setOnClickListener { editCommands() }

        // like the original: opening the app makes sure the server is running
        startServer()
    }

    override fun onStart() {
        super.onStart()
        ReceiverState.listener = { refresh() }
        ui.post(ticker)
    }

    override fun onStop() {
        ReceiverState.listener = null
        ui.removeCallbacks(ticker)
        super.onStop()
    }

    private fun startServer() {
        val intent = Intent(this, CarSocketService::class.java)
        try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) startForegroundService(intent) else startService(intent)
        } catch (e: Exception) {
            Toast.makeText(this, getString(R.string.state_error, e.message ?: e.javaClass.simpleName), Toast.LENGTH_LONG).show()
        }
    }

    // ------------------------------------------------------------------ screen state

    private fun color(res: Int) = ContextCompat.getColor(this, res)

    private fun refresh() {
        // service
        val running = ReceiverState.running
        val error = ReceiverState.lastError
        tvServiceState.text = when {
            running -> getString(R.string.state_running)
            error != null -> getString(R.string.state_error, error)
            else -> getString(R.string.state_stopped)
        }
        val dot = when {
            running -> R.color.success
            error != null -> R.color.danger
            else -> R.color.idle
        }
        dotService.backgroundTintList = ColorStateList.valueOf(color(dot))
        tvBackendWarn.visibility = if (backend.usesPlaceholder()) View.VISIBLE else View.GONE

        // pairing: IP addresses, PIN and the QR code that contains both
        val pin = Prefs.pin(this)
        val ips = NetUtils.localIpv4().map { it.ip }.distinct()
        tvPin.text = pin
        if (ips.isEmpty()) {
            tvIp.text = "-"
            tvNoNetwork.visibility = View.VISIBLE
            ivQr.setImageDrawable(null)
            lastPayload = null
        } else {
            tvIp.text = ips.joinToString("\n")
            tvNoNetwork.visibility = View.GONE
            val payload = PairingLink.build(ips.take(MAX_QR_IPS), pin)
            if (payload != lastPayload) {
                val px = (QR_DP * resources.displayMetrics.density).toInt()
                ivQr.setImageBitmap(QrCode.render(payload, px))
                lastPayload = payload
            }
        }

        renderLog()
    }

    private fun renderLog() {
        val entries = ReceiverState.snapshot().take(LOG_LINES)
        if (entries.isEmpty()) {
            tvLog.setText(R.string.log_empty)
            return
        }
        val time = SimpleDateFormat("HH:mm:ss", Locale.US)
        val sb = SpannableStringBuilder()
        for (e in entries) {
            if (sb.isNotEmpty()) sb.append('\n')
            sb.append(time.format(Date(e.time))).append("  ").append(e.command).append("  ")
            val start = sb.length
            sb.append(if (e.ok) "OK" else "FAIL")
            sb.setSpan(
                ForegroundColorSpan(color(if (e.ok) R.color.success else R.color.danger)),
                start, sb.length, Spannable.SPAN_EXCLUSIVE_EXCLUSIVE
            )
            if (!e.ok && e.detail.isNotEmpty()) sb.append("  ").append(e.detail.take(70))
        }
        tvLog.text = sb
    }

    // ------------------------------------------------------------------ actions

    private fun confirmNewPin() {
        MaterialAlertDialogBuilder(this)
            .setTitle(R.string.new_pin_title)
            .setMessage(R.string.new_pin_msg)
            .setPositiveButton(R.string.yes) { _, _ ->
                Prefs.regenerate(this)
                refresh()
            }
            .setNegativeButton(R.string.cancel, null)
            .show()
    }

    private fun dp(value: Int) = (value * resources.displayMetrics.density).toInt()

    private fun monoText(text: String): TextView = TextView(this).apply {
        this.text = text
        typeface = Typeface.MONOSPACE
        textSize = 12f
        setTextColor(color(R.color.text_primary))
        layoutDirection = View.LAYOUT_DIRECTION_LTR
        textDirection = View.TEXT_DIRECTION_LTR
        setTextIsSelectable(true)
    }

    private fun scrollOf(content: View): ScrollView = ScrollView(this).apply {
        val pad = dp(20)
        setPadding(pad, dp(8), pad, 0)
        addView(content)
    }

    /** Edit the command table: the part that must be adapted to the real car. */
    private fun editCommands() {
        val help = TextView(this).apply {
            setText(R.string.edit_help)
            textSize = 12f
            setTextColor(color(R.color.text_secondary))
            setPadding(0, 0, 0, dp(8))
        }
        val editor = EditText(this).apply {
            setText(backend.readText())
            typeface = Typeface.MONOSPACE
            textSize = 12f
            setTextColor(color(R.color.text_primary))
            gravity = Gravity.TOP or Gravity.START
            inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_FLAG_MULTI_LINE or
                InputType.TYPE_TEXT_FLAG_NO_SUGGESTIONS
            minLines = 12
            layoutDirection = View.LAYOUT_DIRECTION_LTR
            textDirection = View.TEXT_DIRECTION_LTR
        }
        val column = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            addView(help)
            addView(editor)
        }
        MaterialAlertDialogBuilder(this)
            .setTitle(R.string.edit_title)
            .setView(scrollOf(column))
            .setPositiveButton(R.string.save) { _, _ -> saveCommands(editor.text.toString()) }
            .setNeutralButton(R.string.reset) { _, _ -> saveCommands(CommandBackend.defaultText()) }
            .setNegativeButton(R.string.cancel, null)
            .show()
    }

    private fun saveCommands(text: String) {
        try {
            backend.writeText(text)
            Toast.makeText(this, R.string.edit_saved, Toast.LENGTH_SHORT).show()
            refresh()
        } catch (e: IOException) {
            Toast.makeText(this, getString(R.string.edit_error, e.message ?: ""), Toast.LENGTH_LONG).show()
        }
    }

    /** Collects facts about this head unit; the report is what is needed to wire the commands. */
    private fun runDiagnostics() {
        val body = monoText(getString(R.string.diag_running))
        val dialog = MaterialAlertDialogBuilder(this)
            .setTitle(R.string.diag_title)
            .setView(scrollOf(body))
            .setPositiveButton(R.string.share, null)
            .setNegativeButton(R.string.close, null)
            .create()
        dialog.show()

        thread(name = "diagnostics") {
            val report = Diagnostics.run(this)
            val path = Diagnostics.save(this, report)
            runOnUiThread {
                if (isFinishing || isDestroyed) return@runOnUiThread
                body.text = report + "\n" + getString(R.string.diag_saved, path ?: "-")
                // set after show() so the dialog stays open when the button is pressed
                dialog.getButton(DialogInterface.BUTTON_POSITIVE)?.setOnClickListener { shareText(report) }
            }
        }
    }

    private fun shareText(text: String) {
        val send = Intent(Intent.ACTION_SEND).apply {
            type = "text/plain"
            putExtra(Intent.EXTRA_TEXT, text)
        }
        try {
            startActivity(Intent.createChooser(send, getString(R.string.share)))
        } catch (e: ActivityNotFoundException) {
            Toast.makeText(this, getString(R.string.diag_saved, "diagnostics.txt"), Toast.LENGTH_LONG).show()
        }
    }

    companion object {
        private const val REFRESH_MS = 5000L
        private const val MAX_QR_IPS = 3
        private const val QR_DP = 144
        private const val LOG_LINES = 6
    }
}
