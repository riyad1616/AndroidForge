package com.geely.dashboard;

import android.app.*;
import android.content.*;
import android.graphics.*;
import android.os.*;
import android.view.*;
import android.widget.Toast;

public class FloatingWidgetService extends Service {
 private WindowManager wm; private DashboardView view; private WindowManager.LayoutParams lp;
 @Override public void onCreate(){super.onCreate(); wm=(WindowManager)getSystemService(WINDOW_SERVICE); createNotification();
  int type=Build.VERSION.SDK_INT>=26?WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY:WindowManager.LayoutParams.TYPE_PHONE;
  lp=new WindowManager.LayoutParams(760,420,type,WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE|WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,PixelFormat.TRANSLUCENT);
  lp.gravity=Gravity.TOP|Gravity.START; lp.x=80; lp.y=80; view=new DashboardView(this); wm.addView(view,lp);
 }
 private void createNotification(){ if(Build.VERSION.SDK_INT>=26){NotificationChannel c=new NotificationChannel("dashboard","Floating dashboard",NotificationManager.IMPORTANCE_LOW); ((NotificationManager)getSystemService(NOTIFICATION_SERVICE)).createNotificationChannel(c);} Notification n=new Notification.Builder(this,Build.VERSION.SDK_INT>=26?"dashboard":"").setContentTitle("Geely Dashboard").setContentText("Floating panel is active").setSmallIcon(android.R.drawable.ic_menu_view).build(); startForeground(7,n); }
 @Override public int onStartCommand(Intent i,int f,int id){return START_STICKY;}
 @Override public void onDestroy(){if(view!=null)wm.removeView(view);super.onDestroy();}
 @Override public IBinder onBind(Intent i){return null;}
 private class DashboardView extends View {
  Paint p=new Paint(3); float sx,sy,baseX,baseY,scale=1,baseScale=1; float minScale=.65f,maxScale=1.65f; ScaleGestureDetector pinch;
  DashboardView(Context c){super(c);setLayerType(View.LAYER_TYPE_SOFTWARE,null);pinch=new ScaleGestureDetector(c,new ScaleGestureDetector.SimpleOnScaleGestureListener(){public boolean onScale(ScaleGestureDetector d){scale=Math.max(minScale,Math.min(maxScale,baseScale*d.getScaleFactor())); lp.width=(int)(760*scale);lp.height=(int)(420*scale);wm.updateViewLayout(DashboardView.this,lp);invalidate();return true;} public boolean onScaleBegin(ScaleGestureDetector d){baseScale=scale;return true;}});}
  protected void onDraw(Canvas c){super.onDraw(c); c.save(); c.scale(getWidth()/760f,getHeight()/420f);
   p.setColor(0xee090e18);p.setStyle(Paint.Style.FILL);c.drawRoundRect(0,0,760,420,28,28,p);
   p.setShader(new LinearGradient(0,0,760,420,new int[]{0xff27345b,0xff101a2c,0xff102b28},null,Shader.TileMode.CLAMP)); c.drawRoundRect(2,2,758,418,27,27,p);p.setShader(null);
   p.setColor(0xff111a27); c.drawRoundRect(8,8,752,412,22,22,p);
   // left clock
   p.setStyle(Paint.Style.STROKE);p.setStrokeWidth(5);p.setColor(0xff8d68ff);c.drawRoundRect(18,18,245,402,25,25,p);p.setStyle(Paint.Style.FILL);
   p.setColor(0xffeafff0);p.setTextSize(48);c.drawText("10:08",55,112,p);p.setTextSize(17);p.setColor(0xff9daec0);c.drawText("TUESDAY  ·  NOV 24",45,145,p);
   p.setColor(0xffb6ff43);p.setTextSize(15);c.drawText("WEATHER",48,205,p);p.setTextSize(42);p.setColor(0xfff4f7ff);c.drawText("22°",48,258,p);p.setTextSize(15);p.setColor(0xff9daec0);c.drawText("Partly cloudy",48,286,p);
   // right modules
   card(c,265,18,485,112,"CONNECTION","Wi-Fi     Bluetooth     Hotspot",0xff4c91ff);
   card(c,265,130,485,224,"CAR CONTROLS","Windows       Volume       Fan",0xff9d74ff);
   card(c,265,242,485,336,"CALENDAR","Today  ·  Add your schedule",0xff54d69a);
   card(c,265,354,485,402,"STATUS","Vehicle link: not connected",0xffffc45a);
   c.restore();
  }
  void card(Canvas c,float l,float t,float r,float b,String title,String body,int color){p.setStyle(Paint.Style.STROKE);p.setStrokeWidth(2);p.setColor(color);c.drawRoundRect(l,t,r,b,18,18,p);p.setStyle(Paint.Style.FILL);p.setColor(0xffe9f2ff);p.setTextSize(17);c.drawText(title,l+18,t+29,p);p.setColor(0xffaebccc);p.setTextSize(14);c.drawText(body,l+18,t+58,p);}
  public boolean onTouchEvent(android.view.MotionEvent e){pinch.onTouchEvent(e); if(e.getPointerCount()>1)return true; switch(e.getAction()){case MotionEvent.ACTION_DOWN:sx=e.getRawX();sy=e.getRawY();baseX=lp.x;baseY=lp.y;return true;case MotionEvent.ACTION_MOVE:if(!pinch.isInProgress()){lp.x=(int)(baseX+e.getRawX()-sx);lp.y=(int)(baseY+e.getRawY()-sy);wm.updateViewLayout(this,lp);}return true;case MotionEvent.ACTION_UP:return true;}return true;}
 }
}
