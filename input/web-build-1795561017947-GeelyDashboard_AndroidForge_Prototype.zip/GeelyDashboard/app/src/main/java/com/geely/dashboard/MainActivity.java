package com.geely.dashboard;

import android.app.Activity;
import android.content.Intent;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.provider.Settings;
import android.view.Gravity;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;

public class MainActivity extends Activity {
 @Override public void onCreate(Bundle b) { super.onCreate(b);
  LinearLayout root=new LinearLayout(this); root.setOrientation(1); root.setPadding(32,40,32,24); root.setBackgroundColor(0xff080b10); root.setGravity(Gravity.CENTER);
  TextView title=new TextView(this); title.setText("GEELY DASHBOARD\n\nPrototype 0.1"); title.setTextColor(0xffe9f2ff); title.setTextSize(25); title.setGravity(Gravity.CENTER); root.addView(title);
  TextView info=new TextView(this); info.setText("Allow overlay permission, then start the floating dashboard. Drag with one finger; pinch with two fingers to resize."); info.setTextColor(0xffaab6c7); info.setTextSize(16); info.setGravity(Gravity.CENTER); info.setPadding(0,28,0,28); root.addView(info);
  Button permission=new Button(this); permission.setText("Grant overlay permission"); root.addView(permission);
  Button start=new Button(this); start.setText("Start floating dashboard"); root.addView(start);
  Button stop=new Button(this); stop.setText("Stop dashboard"); root.addView(stop);
  permission.setOnClickListener(v->{ if(!Settings.canDrawOverlays(this)) startActivity(new Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:"+getPackageName()))); });
  start.setOnClickListener(v->{ if(Settings.canDrawOverlays(this)) { Intent i=new Intent(this,FloatingWidgetService.class); if(Build.VERSION.SDK_INT>=26) startForegroundService(i); else startService(i); } else { startActivity(new Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:"+getPackageName()))); } });
  stop.setOnClickListener(v->stopService(new Intent(this,FloatingWidgetService.class)));
  setContentView(root);
 }
}
