package com.geely.musicwidget

import android.content.Intent
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.widget.Button
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity

class MainActivity : AppCompatActivity() {

    private lateinit var tvStatus: TextView
    private lateinit var btnOverlay: Button
    private lateinit var btnStart: Button
    private lateinit var btnStop: Button

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        tvStatus = findViewById(R.id.tvStatus)
        btnOverlay = findViewById(R.id.btnOverlayPermission)
        btnStart = findViewById(R.id.btnStart)
        btnStop = findViewById(R.id.btnStop)

        btnOverlay.setOnClickListener { requestOverlayPermission() }
        btnStart.setOnClickListener { startWidget() }
        btnStop.setOnClickListener { stopWidget() }

        updateStatus()
    }

    override fun onResume() {
        super.onResume()
        updateStatus()
    }

    private fun hasOverlayPermission(): Boolean {
        return if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            Settings.canDrawOverlays(this)
        } else {
            true
        }
    }

    private fun requestOverlayPermission() {
        if (hasOverlayPermission()) {
            Toast.makeText(this, "الإذن ممنوح مسبقاً", Toast.LENGTH_SHORT).show()
            return
        }
        try {
            val intent = Intent(
                Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                Uri.parse("package:$packageName")
            )
            startActivity(intent)
        } catch (e: Exception) {
            // بعض أنظمة السيارات لا تدعم هذه الشاشة — جرّب الإعدادات العامة
            try {
                startActivity(Intent(Settings.ACTION_SETTINGS))
                Toast.makeText(
                    this,
                    "ابحث عن «العرض فوق التطبيقات» أو «النوافذ العائمة»",
                    Toast.LENGTH_LONG
                ).show()
            } catch (_: Exception) {
                Toast.makeText(this, "تعذر فتح الإعدادات", Toast.LENGTH_SHORT).show()
            }
        }
    }

    private fun startWidget() {
        if (!hasOverlayPermission()) {
            Toast.makeText(this, getString(R.string.overlay_permission_needed), Toast.LENGTH_LONG)
                .show()
            requestOverlayPermission()
            return
        }
        val intent = Intent(this, FloatingMusicService::class.java)
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            startForegroundService(intent)
        } else {
            startService(intent)
        }
        Toast.makeText(this, "تم تشغيل الويدجت", Toast.LENGTH_SHORT).show()
        updateStatus()
    }

    private fun stopWidget() {
        stopService(Intent(this, FloatingMusicService::class.java))
        Toast.makeText(this, "تم إيقاف الويدجت", Toast.LENGTH_SHORT).show()
        updateStatus()
    }

    private fun updateStatus() {
        val running = FloatingMusicService.isRunning
        tvStatus.text = if (running) {
            getString(R.string.status_running)
        } else {
            getString(R.string.status_stopped)
        }
        val overlayOk = hasOverlayPermission()
        btnOverlay.text = if (overlayOk) {
            "✓ إذن العرض فوق التطبيقات"
        } else {
            "1) السماح بالعرض فوق التطبيقات"
        }
    }
}
