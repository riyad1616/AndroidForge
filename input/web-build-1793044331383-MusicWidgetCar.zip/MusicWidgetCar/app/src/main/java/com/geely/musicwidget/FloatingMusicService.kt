package com.geely.musicwidget

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.graphics.PixelFormat
import android.media.MediaMetadata
import android.media.session.MediaController
import android.media.session.MediaSessionManager
import android.media.session.PlaybackState
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.view.Gravity
import android.view.LayoutInflater
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.widget.ImageView
import android.widget.TextView
import androidx.core.app.NotificationCompat

class FloatingMusicService : Service() {

    companion object {
        @Volatile
        var isRunning = false
        private const val CHANNEL_ID = "music_widget_channel"
        private const val NOTIFICATION_ID = 1001
        private const val POLL_MS = 1000L
    }

    private lateinit var windowManager: WindowManager
    private var floatingView: View? = null
    private var layoutParams: WindowManager.LayoutParams? = null

    private lateinit var tvTitle: TextView
    private lateinit var tvArtist: TextView
    private lateinit var btnPlayPause: ImageView

    private var mediaController: MediaController? = null
    private val handler = Handler(Looper.getMainLooper())
    private val pollRunnable = object : Runnable {
        override fun run() {
            refreshMedia()
            handler.postDelayed(this, POLL_MS)
        }
    }

    override fun onCreate() {
        super.onCreate()
        isRunning = true
        startForegroundNotification()
        showFloatingWidget()
        handler.post(pollRunnable)
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        return START_STICKY
    }

    override fun onDestroy() {
        super.onDestroy()
        isRunning = false
        handler.removeCallbacks(pollRunnable)
        removeFloatingWidget()
    }

    override fun onBind(intent: Intent?): IBinder? = null

    private fun startForegroundNotification() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                CHANNEL_ID,
                "Music Widget",
                NotificationManager.IMPORTANCE_LOW
            )
            val nm = getSystemService(NotificationManager::class.java)
            nm?.createNotificationChannel(channel)
        }

        val openIntent = Intent(this, MainActivity::class.java)
        val pending = PendingIntent.getActivity(
            this, 0, openIntent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        val notification: Notification = NotificationCompat.Builder(this, CHANNEL_ID)
            .setContentTitle("Music Widget Car")
            .setContentText("الويدجت يعمل — اضغط للعودة للإعدادات")
            .setSmallIcon(android.R.drawable.ic_media_play)
            .setContentIntent(pending)
            .setOngoing(true)
            .build()

        startForeground(NOTIFICATION_ID, notification)
    }

    private fun showFloatingWidget() {
        windowManager = getSystemService(WINDOW_SERVICE) as WindowManager
        floatingView = LayoutInflater.from(this).inflate(R.layout.layout_floating_widget, null)

        val type = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
        } else {
            @Suppress("DEPRECATION")
            WindowManager.LayoutParams.TYPE_PHONE
        }

        layoutParams = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            type,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                    WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            x = 40
            y = 200
        }

        tvTitle = floatingView!!.findViewById(R.id.tvTitle)
        tvArtist = floatingView!!.findViewById(R.id.tvArtist)
        btnPlayPause = floatingView!!.findViewById(R.id.btnPlayPause)

        floatingView!!.findViewById<ImageView>(R.id.btnClose).setOnClickListener {
            stopSelf()
        }
        floatingView!!.findViewById<ImageView>(R.id.btnPrev).setOnClickListener {
            mediaController?.transportControls?.skipToPrevious()
        }
        floatingView!!.findViewById<ImageView>(R.id.btnNext).setOnClickListener {
            mediaController?.transportControls?.skipToNext()
        }
        btnPlayPause.setOnClickListener {
            val state = mediaController?.playbackState?.state
            if (state == PlaybackState.STATE_PLAYING) {
                mediaController?.transportControls?.pause()
            } else {
                mediaController?.transportControls?.play()
            }
        }

        setupDrag(floatingView!!.findViewById(R.id.headerBar))
        setupDrag(floatingView!!.findViewById(R.id.rootWidget))

        try {
            windowManager.addView(floatingView, layoutParams)
        } catch (e: Exception) {
            e.printStackTrace()
            stopSelf()
        }
    }

    private fun setupDrag(view: View) {
        var initialX = 0
        var initialY = 0
        var initialTouchX = 0f
        var initialTouchY = 0f

        view.setOnTouchListener { _, event ->
            val params = layoutParams ?: return@setOnTouchListener false
            when (event.action) {
                MotionEvent.ACTION_DOWN -> {
                    initialX = params.x
                    initialY = params.y
                    initialTouchX = event.rawX
                    initialTouchY = event.rawY
                    true
                }
                MotionEvent.ACTION_MOVE -> {
                    params.x = initialX + (event.rawX - initialTouchX).toInt()
                    params.y = initialY + (event.rawY - initialTouchY).toInt()
                    try {
                        windowManager.updateViewLayout(floatingView, params)
                    } catch (_: Exception) {
                    }
                    true
                }
                else -> false
            }
        }
    }

    private fun removeFloatingWidget() {
        floatingView?.let {
            try {
                windowManager.removeView(it)
            } catch (_: Exception) {
            }
        }
        floatingView = null
    }

    private fun refreshMedia() {
        try {
            val msm = getSystemService(Context.MEDIA_SESSION_SERVICE) as MediaSessionManager
            val controllers = try {
                msm.getActiveSessions(null)
            } catch (se: SecurityException) {
                // بدون إشعار Notification Listener قد يفشل — نحاول بصمت
                emptyList()
            }

            if (controllers.isEmpty()) {
                mediaController = null
                tvTitle.text = getString(R.string.no_media)
                tvArtist.text = ""
                btnPlayPause.setImageResource(R.drawable.ic_play)
                return
            }

            // اختر أول جلسة نشطة تبدو كمشغّل موسيقى
            val controller = controllers.firstOrNull { c ->
                val st = c.playbackState?.state
                st == PlaybackState.STATE_PLAYING || st == PlaybackState.STATE_PAUSED ||
                        st == PlaybackState.STATE_BUFFERING
            } ?: controllers[0]

            mediaController = controller
            val meta = controller.metadata
            val title = meta?.getString(MediaMetadata.METADATA_KEY_TITLE)
                ?: getString(R.string.unknown_track)
            val artist = meta?.getString(MediaMetadata.METADATA_KEY_ARTIST)
                ?: meta?.getString(MediaMetadata.METADATA_KEY_ALBUM_ARTIST)
                ?: ""

            tvTitle.text = title
            tvArtist.text = artist

            val playing = controller.playbackState?.state == PlaybackState.STATE_PLAYING
            btnPlayPause.setImageResource(
                if (playing) R.drawable.ic_pause else R.drawable.ic_play
            )
        } catch (e: Exception) {
            e.printStackTrace()
        }
    }
}
