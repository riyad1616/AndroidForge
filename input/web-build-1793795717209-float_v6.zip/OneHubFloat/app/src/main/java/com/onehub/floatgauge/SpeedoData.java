package com.onehub.floatgauge;

/** Port of OneHub C0018b2 + Coolray gear/mode fields */
public final class SpeedoData {
    public float f1011a;
    public boolean b = true;
    public int f1012c = -1;
    public final int[] f1013d;
    public int f1014e;

    public String driveMode = "-";
    public String gearLetter = "P";
    public int gearStep;

    public SpeedoData() {
        f1013d = new int[7];
        for (int i = 0; i < 7; i++) f1013d[i] = Integer.MIN_VALUE;
    }

    public void set(float speed, int gearIdx, int gearStep, String gearLetter,
                    String driveMode, int battOrGear, int fuel, int powerKw,
                    int tempOut, int tempBatt) {
        this.f1011a = Math.max(0f, speed);
        this.f1012c = gearIdx;
        this.b = true;
        this.gearStep = gearStep;
        this.gearLetter = gearLetter != null ? gearLetter : "P";
        this.driveMode = driveMode != null ? driveMode : "-";

        // Slot 0 = gear step for battery-hole styles
        f1013d[0] = (gearStep > 0) ? gearStep : Integer.MIN_VALUE;
        f1013d[1] = fuel;
        // No fake autonomy range (was wrong 451 km)
        f1013d[2] = Integer.MIN_VALUE;
        f1013d[3] = Integer.MIN_VALUE;
        f1013d[4] = Integer.MIN_VALUE;
        // tempOut = engine coolant °C (only if real)
        f1013d[5] = (tempOut > 0 && tempOut < 150) ? tempOut : Integer.MIN_VALUE;
        // tempBatt = voltage decidegrees 90..160 (9.0V..16.0V) OR unused
        f1013d[6] = tempBatt;
    }
}
