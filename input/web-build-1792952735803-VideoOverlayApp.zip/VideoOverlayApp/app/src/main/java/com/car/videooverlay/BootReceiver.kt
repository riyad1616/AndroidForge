package com.car.videooverlay

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.preference.PreferenceManager
import androidx.core.content.ContextCompat

class BootReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        if (intent.action == Intent.ACTION_BOOT_COMPLETED) {
            val prefs = PreferenceManager.getDefaultSharedPreferences(context)
            val lastUri = prefs.getString("last_video_uri", null)
            val autoStart = prefs.getBoolean("auto_start", false)

            if (autoStart && !lastUri.isNullOrEmpty()) {
                val serviceIntent = Intent(context, VideoOverlayService::class.java).apply {
                    putExtra("video_uri", lastUri)
                    putExtra("opacity", prefs.getFloat("opacity", 1.0f))
                    putExtra("muted", prefs.getBoolean("muted", true))
                }
                ContextCompat.startForegroundService(context, serviceIntent)
            }
        }
    }
}
