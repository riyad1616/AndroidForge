package com.car.videooverlay

import android.app.*
import android.content.Intent
import android.graphics.PixelFormat
import android.net.Uri
import android.os.Build
import android.os.IBinder
import android.view.Gravity
import android.view.WindowManager
import android.widget.VideoView
import androidx.core.app.NotificationCompat

class VideoOverlayService : Service() {

    private var windowManager: WindowManager? = null
    private var videoView: VideoView? = null
    private var layoutParams: WindowManager.LayoutParams? = null

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        val videoUriString = intent?.getStringExtra("video_uri") ?: return START_NOT_STICKY
        val opacity = intent.getFloatExtra("opacity", 1.0f)
        val muted = intent.getBooleanExtra("muted", true)

        startForeground(1, createNotification())
        showVideoOverlay(Uri.parse(videoUriString), opacity, muted)

        return START_STICKY
    }

    private fun showVideoOverlay(uri: Uri, opacity: Float, muted: Boolean) {
        windowManager = getSystemService(WINDOW_SERVICE) as WindowManager

        videoView = VideoView(this).apply {
            setVideoURI(uri)
            setOnPreparedListener { mp ->
                mp.isLooping = true
                if (muted) {
                    mp.setVolume(0f, 0f)
                } else {
                    mp.setVolume(1f, 1f)
                }
                start()
            }
            alpha = opacity
        }

        // متوافق مع Android 9
        val type = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
        } else {
            WindowManager.LayoutParams.TYPE_PHONE
        }

        layoutParams = WindowManager.LayoutParams(
            WindowManager.LayoutParams.MATCH_PARENT,
            WindowManager.LayoutParams.MATCH_PARENT,
            type,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                    WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE or
                    WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or
                    WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START
        }

        try {
            windowManager?.addView(videoView, layoutParams)
        } catch (e: Exception) {
            e.printStackTrace()
            try {
                // محاولة بديلة لـ Android 9
                layoutParams?.type = WindowManager.LayoutParams.TYPE_SYSTEM_ALERT
                windowManager?.addView(videoView, layoutParams)
            } catch (e2: Exception) {
                e2.printStackTrace()
                stopSelf()
            }
        }
    }

    private fun createNotification(): Notification {
        val channelId = "video_overlay_channel"

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                channelId,
                "Video Overlay",
                NotificationManager.IMPORTANCE_MIN
            )
            channel.setShowBadge(false)
            getSystemService(NotificationManager::class.java)?.createNotificationChannel(channel)
        }

        return NotificationCompat.Builder(this, channelId)
            .setContentTitle("Video Overlay")
            .setContentText("يعمل في الخلفية")
            .setSmallIcon(android.R.drawable.ic_media_play)
            .setOngoing(true)
            .setPriority(NotificationCompat.PRIORITY_MIN)
            .build()
    }

    override fun onDestroy() {
        super.onDestroy()
        try {
            videoView?.stopPlayback()
            if (videoView != null && windowManager != null) {
                windowManager?.removeView(videoView)
            }
        } catch (e: Exception) {
            e.printStackTrace()
        }
    }
}
