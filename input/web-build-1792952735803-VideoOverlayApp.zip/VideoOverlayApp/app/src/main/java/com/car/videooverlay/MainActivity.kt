package com.car.videooverlay

import android.content.Intent
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.widget.*
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import android.preference.PreferenceManager

class MainActivity : AppCompatActivity() {

    private var selectedVideoUri: Uri? = null
    private lateinit var statusText: TextView
    private lateinit var opacitySeekBar: SeekBar
    private lateinit var muteCheckBox: CheckBox
    private lateinit var autoStartCheckBox: CheckBox

    private val pickVideo = registerForActivityResult(ActivityResultContracts.GetContent()) { uri ->
        if (uri != null) {
            selectedVideoUri = uri
            statusText.text = "تم اختيار الفيديو"
            try {
                contentResolver.takePersistableUriPermission(
                    uri,
                    Intent.FLAG_GRANT_READ_URI_PERMISSION
                )
            } catch (e: Exception) {
                e.printStackTrace()
            }

            // حفظ آخر فيديو
            val prefs = PreferenceManager.getDefaultSharedPreferences(this)
            prefs.edit().putString("last_video_uri", uri.toString()).apply()
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        statusText = findViewById(R.id.statusText)
        opacitySeekBar = findViewById(R.id.opacitySeekBar)
        muteCheckBox = findViewById(R.id.muteCheckBox)
        autoStartCheckBox = findViewById(R.id.autoStartCheckBox)

        val btnSelect = findViewById<Button>(R.id.btnSelectVideo)
        val btnStart = findViewById<Button>(R.id.btnStart)
        val btnStop = findViewById<Button>(R.id.btnStop)

        val prefs = PreferenceManager.getDefaultSharedPreferences(this)

        // استرجاع الإعدادات المحفوظة
        opacitySeekBar.progress = (prefs.getFloat("opacity", 1.0f) * 100).toInt()
        muteCheckBox.isChecked = prefs.getBoolean("muted", true)
        autoStartCheckBox.isChecked = prefs.getBoolean("auto_start", false)

        val lastUri = prefs.getString("last_video_uri", null)
        if (lastUri != null) {
            selectedVideoUri = Uri.parse(lastUri)
            statusText.text = "آخر فيديو محفوظ جاهز"
        }

        btnSelect.setOnClickListener {
            pickVideo.launch("video/*")
        }

        btnStart.setOnClickListener {
            if (selectedVideoUri == null) {
                Toast.makeText(this, "اختر فيديو أولاً", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }
            checkPermissionsAndStart()
        }

        btnStop.setOnClickListener {
            stopService(Intent(this, VideoOverlayService::class.java))
            statusText.text = "تم الإيقاف"
        }

        // حفظ الإعدادات عند التغيير
        opacitySeekBar.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(seekBar: SeekBar?, progress: Int, fromUser: Boolean) {}
            override fun onStartTrackingTouch(seekBar: SeekBar?) {}
            override fun onStopTrackingTouch(seekBar: SeekBar?) {
                prefs.edit().putFloat("opacity", opacitySeekBar.progress / 100f).apply()
            }
        })

        muteCheckBox.setOnCheckedChangeListener { _, isChecked ->
            prefs.edit().putBoolean("muted", isChecked).apply()
        }

        autoStartCheckBox.setOnCheckedChangeListener { _, isChecked ->
            prefs.edit().putBoolean("auto_start", isChecked).apply()
        }
    }

    private fun checkPermissionsAndStart() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            if (!Settings.canDrawOverlays(this)) {
                val intent = Intent(
                    Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                    Uri.parse("package:$packageName")
                )
                startActivity(intent)
                Toast.makeText(this, "أعطِ صلاحية الظهور فوق التطبيقات ثم اضغط تشغيل مرة أخرى", Toast.LENGTH_LONG).show()
                return
            }
        }

        val intent = Intent(this, VideoOverlayService::class.java).apply {
            putExtra("video_uri", selectedVideoUri.toString())
            putExtra("opacity", opacitySeekBar.progress / 100f)
            putExtra("muted", muteCheckBox.isChecked)
        }
        ContextCompat.startForegroundService(this, intent)
        statusText.text = "يعمل الآن..."
    }
}
