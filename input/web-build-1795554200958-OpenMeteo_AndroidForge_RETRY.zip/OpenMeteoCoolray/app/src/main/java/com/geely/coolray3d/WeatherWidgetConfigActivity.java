package com.geely.coolray3d;

import android.app.Activity;
import android.appwidget.AppWidgetManager;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.View;
import android.widget.*;

public class WeatherWidgetConfigActivity extends Activity {

    private int appWidgetId = AppWidgetManager.INVALID_APPWIDGET_ID;
    private EditText editCity;
    private RadioButton rbCelsius;
    private SeekBar seekAlpha, seekScale;
    private TextView txtAlphaPercent, txtScalePercent;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setResult(RESULT_CANCELED);
        setContentView(R.layout.activity_widget_config);

        Intent intent = getIntent();
        Bundle extras = intent.getExtras();
        if (extras != null) {
            appWidgetId = extras.getInt(AppWidgetManager.EXTRA_APPWIDGET_ID, AppWidgetManager.INVALID_APPWIDGET_ID);
        }

        editCity = findViewById(R.id.edit_city);
        rbCelsius = findViewById(R.id.rb_celsius);
        seekAlpha = findViewById(R.id.seek_alpha);
        txtAlphaPercent = findViewById(R.id.txt_alpha_percent);
        seekScale = findViewById(R.id.seek_scale);
        txtScalePercent = findViewById(R.id.txt_scale_percent);

        SharedPreferences prefs = getSharedPreferences("WeatherWidgetPrefs", MODE_PRIVATE);
        int savedAlpha = prefs.getInt("alpha_" + appWidgetId, 80);
        int savedScale = prefs.getInt("scale_" + appWidgetId, 100);

        seekAlpha.setProgress(savedAlpha);
        txtAlphaPercent.setText(savedAlpha + "%");

        seekScale.setProgress(savedScale - 50);
        txtScalePercent.setText(savedScale + "%");

        editCity.setText(prefs.getString("city_" + appWidgetId, "Oued Smar"));

        seekAlpha.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override
            public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {
                txtAlphaPercent.setText(progress + "%");
            }
            @Override public void onStartTrackingTouch(SeekBar seekBar) {}
            @Override public void onStopTrackingTouch(SeekBar seekBar) {}
        });

        findViewById(R.id.btn_alpha_minus).setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) { seekAlpha.setProgress(Math.max(0, seekAlpha.getProgress() - 5)); }
        });

        findViewById(R.id.btn_alpha_plus).setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) { seekAlpha.setProgress(Math.min(100, seekAlpha.getProgress() + 5)); }
        });

        seekScale.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override
            public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {
                txtScalePercent.setText((progress + 50) + "%");
            }
            @Override public void onStartTrackingTouch(SeekBar seekBar) {}
            @Override public void onStopTrackingTouch(SeekBar seekBar) {}
        });

        findViewById(R.id.btn_scale_minus).setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) { seekScale.setProgress(Math.max(0, seekScale.getProgress() - 5)); }
        });

        findViewById(R.id.btn_scale_plus).setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) { seekScale.setProgress(Math.min(100, seekScale.getProgress() + 5)); }
        });

        findViewById(R.id.btn_apply_widget).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                SharedPreferences.Editor editor = getSharedPreferences("WeatherWidgetPrefs", MODE_PRIVATE).edit();
                editor.putString("city_" + appWidgetId, editCity.getText().toString().trim());
                editor.putBoolean("isCelsius_" + appWidgetId, rbCelsius.isChecked());
                editor.putInt("alpha_" + appWidgetId, seekAlpha.getProgress());
                editor.putInt("scale_" + appWidgetId, seekScale.getProgress() + 50);
                editor.apply();

                AppWidgetManager appWidgetManager = AppWidgetManager.getInstance(WeatherWidgetConfigActivity.this);
                WeatherWidgetProvider.updateAppWidget(WeatherWidgetConfigActivity.this, appWidgetManager, appWidgetId);

                Intent resultValue = new Intent();
                resultValue.putExtra(AppWidgetManager.EXTRA_APPWIDGET_ID, appWidgetId);
                setResult(RESULT_OK, resultValue);
                finish();
            }
        });
    }
}
