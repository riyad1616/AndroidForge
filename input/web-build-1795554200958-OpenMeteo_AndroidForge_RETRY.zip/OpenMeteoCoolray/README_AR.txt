مشروع Open-Meteo لودجت طقس شاشة Geely Coolray - AndroidForge

طريقة البناء: ارفع هذا الملف ZIP إلى AndroidForge واختر Gradle / Android / Debug.

تم ترتيب ملفات المشروع وفق بنية Android Gradle القياسية، وإصلاح JavaVersion.VERSION_8 إلى VERSION_1_8، وتصحيح نطاقات API إلى geocoding-api.open-meteo.com و api.open-meteo.com، وإصلاح XML Android namespace.

ملاحظة: يلزم اختبار البناء الفعلي داخل AndroidForge؛ لم يتم إنتاج APK في هذه البيئة.
