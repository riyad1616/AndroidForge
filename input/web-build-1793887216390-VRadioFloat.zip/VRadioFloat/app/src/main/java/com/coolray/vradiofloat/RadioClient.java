package com.coolray.vradiofloat;

import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.media.MediaDescription;
import android.media.browse.MediaBrowser;
import android.media.session.MediaController;
import android.media.session.PlaybackState;
import android.os.Bundle;

import java.util.ArrayList;
import java.util.List;

final class RadioClient {
    static final ComponentName SERVICE =
            new ComponentName("com.ilv.vradio", "com.ilv.vradio.AutoBrowserService");
    static final int MAX = 10;

    private MediaBrowser browser;
    private MediaController controller;
    private Context appCtx;

    interface Callback {
        void favorites(List<MediaBrowser.MediaItem> list);
        void error(String msg);
    }

    interface StatusCallback {
        void status(String text, boolean playing);
    }

    static void startBackground(Context context) {
        try {
            Intent i = new Intent("android.media.browse.MediaBrowserService");
            i.setComponent(SERVICE);
            context.startService(i);
        } catch (Exception ignored) {}
    }

    static void open(Context context) {
        try {
            Intent i = context.getPackageManager().getLaunchIntentForPackage("com.ilv.vradio");
            if (i != null) {
                i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                context.startActivity(i);
            }
        } catch (Exception ignored) {}
    }

    void load(Context context, final Callback cb) {
        appCtx = context.getApplicationContext();
        startBackground(context);
        disconnect();
        browser = new MediaBrowser(context, SERVICE, new MediaBrowser.ConnectionCallback() {
            @Override public void onConnected() {
                try {
                    browser.subscribe("cFavorites", new MediaBrowser.SubscriptionCallback() {
                        @Override
                        public void onChildrenLoaded(String parentId, List<MediaBrowser.MediaItem> children) {
                            List<MediaBrowser.MediaItem> out = new ArrayList<>();
                            if (children != null) {
                                for (int i = 0; i < children.size() && out.size() < MAX; i++) {
                                    out.add(children.get(i));
                                }
                            }
                            cb.favorites(out);
                            try { browser.unsubscribe(parentId); } catch (Exception ignored) {}
                        }
                        @Override public void onError(String id) {
                            cb.error("Favoris indisponibles");
                        }
                    });
                } catch (Exception e) {
                    cb.error(e.getMessage() != null ? e.getMessage() : "error");
                }
            }
            @Override public void onConnectionFailed() {
                cb.error("VRadio non connecté");
            }
            @Override public void onConnectionSuspended() {}
        }, null);
        try { browser.connect(); } catch (Exception e) {
            cb.error("Connexion VRadio échouée");
        }
    }

    void play(Context context, MediaBrowser.MediaItem item) {
        if (item == null) return;
        appCtx = context.getApplicationContext();
        startBackground(context);
        final String mid = item.getMediaId();
        if (browser != null && browser.isConnected()) {
            tryPlay(mid);
            return;
        }
        browser = new MediaBrowser(context, SERVICE, new MediaBrowser.ConnectionCallback() {
            @Override public void onConnected() { tryPlay(mid); }
            @Override public void onConnectionFailed() {}
            @Override public void onConnectionSuspended() {}
        }, null);
        try { browser.connect(); } catch (Exception ignored) {}
    }

    private void tryPlay(String mediaId) {
        try {
            if (browser == null || !browser.isConnected()) return;
            Context ctx = appCtx;
            if (ctx == null) return;
            controller = new MediaController(ctx, browser.getSessionToken());
            Bundle extras = new Bundle();
            controller.getTransportControls().playFromMediaId(mediaId, extras);
        } catch (Exception ignored) {}
    }

    void stop(Context context) {
        try {
            appCtx = context.getApplicationContext();
            if (controller != null) {
                controller.getTransportControls().stop();
            } else if (browser != null && browser.isConnected()) {
                controller = new MediaController(appCtx, browser.getSessionToken());
                controller.getTransportControls().stop();
            }
        } catch (Exception ignored) {}
    }

    void listenStatus(Context context, final StatusCallback cb) {
        appCtx = context.getApplicationContext();
        startBackground(context);
        browser = new MediaBrowser(context, SERVICE, new MediaBrowser.ConnectionCallback() {
            @Override public void onConnected() {
                try {
                    controller = new MediaController(context, browser.getSessionToken());
                    controller.registerCallback(new MediaController.Callback() {
                        @Override public void onPlaybackStateChanged(PlaybackState state) {
                            push(cb);
                        }
                        @Override public void onMetadataChanged(android.media.MediaMetadata metadata) {
                            push(cb);
                        }
                    });
                    push(cb);
                } catch (Exception e) {
                    cb.status("ARRET", false);
                }
            }
            @Override public void onConnectionFailed() { cb.status("ARRET", false); }
            @Override public void onConnectionSuspended() {}
        }, null);
        try { browser.connect(); } catch (Exception e) {
            cb.status("ARRET", false);
        }
    }

    private void push(StatusCallback cb) {
        try {
            String title = "ARRET";
            boolean playing = false;
            if (controller != null) {
                PlaybackState st = controller.getPlaybackState();
                if (st != null) {
                    int s = st.getState();
                    playing = s == PlaybackState.STATE_PLAYING || s == PlaybackState.STATE_BUFFERING;
                }
                android.media.MediaMetadata md = controller.getMetadata();
                if (md != null) {
                    CharSequence t = md.getDescription().getTitle();
                    if (t != null && t.length() > 0) title = t.toString();
                }
            }
            if (!playing) title = "ARRET";
            else title = "LECTURE - " + title;
            cb.status(title, playing);
        } catch (Exception e) {
            cb.status("ARRET", false);
        }
    }

    void disconnect() {
        try {
            if (browser != null) {
                if (browser.isConnected()) browser.disconnect();
            }
        } catch (Exception ignored) {}
        browser = null;
        controller = null;
    }
}
