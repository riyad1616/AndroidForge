مشروع Open-Meteo Weather Widget لشاشة Geely Coolray

هذه حزمة مصدر Android Gradle بصيغة مناسبة للرفع إلى AndroidForge.
المشروع Java / Android ويحتوي على Widget قياسي قابل للإضافة من مشغّل الشاشة،
مع إعداد المدينة، وحدة الحرارة، الشفافية والحجم.

طريقة البناء:
1) ارفع ملف ZIP إلى واجهة AndroidForge.
2) اختر Android ثم Build variant = debug (أو auto).
3) ابدأ البناء وانتظر اكتمال GitHub Actions.
4) نزّل artifact باسم AndroidForge-APKs ثم استخرج ملف APK.

ملاحظات:
- هذه حزمة مصدر وليست APK جاهزاً.
- يتطلب AndroidForge اتصالاً بحساب GitHub ومستودعاً fork خاصاً بك وPersonal Access Token.
- لا ترسل GitHub token لأي شخص. أدخله فقط في الموقع الرسمي الذي فتحته بنفسك.
- لم يتم تنفيذ اختبار على جهاز Geely فعلي؛ توافق الودجت يعتمد على دعم مشغّل الشاشة للودجات القياسية.
- يعتمد جلب الطقس على اتصال الإنترنت وخدمات Open-Meteo.
