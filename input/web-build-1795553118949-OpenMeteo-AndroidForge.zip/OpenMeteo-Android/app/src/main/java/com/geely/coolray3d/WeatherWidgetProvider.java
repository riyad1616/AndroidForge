package com.geely.coolray3d;

import android.app.PendingIntent;
import android.appwidget.AppWidgetManager;
import android.appwidget.AppWidgetProvider;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Handler;
import android.os.Looper;
import android.util.TypedValue;
import android.widget.RemoteViews;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLEncoder;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

public class WeatherWidgetProvider extends AppWidgetProvider {

    @Override
    public void onUpdate(Context context, AppWidgetManager appWidgetManager, int[] appWidgetIds) {
        for (int appWidgetId : appWidgetIds) {
            updateAppWidget(context, appWidgetManager, appWidgetId);
        }
    }

    public static void updateAppWidget(final Context context, final AppWidgetManager appWidgetManager, final int appWidgetId) {
        SharedPreferences prefs = context.getSharedPreferences("WeatherWidgetPrefs", Context.MODE_PRIVATE);
        final String cityInput = prefs.getString("city_" + appWidgetId, "Oued Smar");
        final boolean isCelsius = prefs.getBoolean("isCelsius_" + appWidgetId, true);
        int alphaPercent = prefs.getInt("alpha_" + appWidgetId, 80);
        int scalePercent = prefs.getInt("scale_" + appWidgetId, 100);

        final float scale = scalePercent / 100.0f;
        final int imageAlpha = (int) ((alphaPercent / 100.0f) * 255);

        RemoteViews initialViews = buildBaseViews(context, appWidgetId, cityInput.toUpperCase(), imageAlpha, scale);
        appWidgetManager.updateAppWidget(appWidgetId, initialViews);

        new Thread(new Runnable() {
            @Override
            public void run() {
                try {
                    String geoUrl = "https://geocoding-api.open-meteo.com/v1/search?name="
                            + URLEncoder.encode(cityInput, "UTF-8") + "&count=1&language=en&format=json";
                    JSONObject geoJson = new JSONObject(httpGet(geoUrl));
                    JSONArray results = geoJson.optJSONArray("results");

                    double lat = 36.7025;
                    double lon = 3.1683;
                    if (results != null && results.length() > 0) {
                        JSONObject loc = results.getJSONObject(0);
                        lat = loc.getDouble("latitude");
                        lon = loc.getDouble("longitude");
                    }

                    String unitParam = isCelsius ? "celsius" : "fahrenheit";
                    String weatherUrl = "https://api.open-meteo.com/v1/forecast?latitude=" + lat
                            + "&longitude=" + lon
                            + "&current=temperature_2m,weather_code"
                            + "&daily=weather_code,temperature_2m_max,temperature_2m_min"
                            + "&temperature_unit=" + unitParam
                            + "&timezone=auto&forecast_days=4";

                    JSONObject wJson = new JSONObject(httpGet(weatherUrl));
                    JSONObject current = wJson.getJSONObject("current");
                    final int currentTemp = (int) Math.round(current.getDouble("temperature_2m"));
                    final int currentCode = current.getInt("weather_code");

                    JSONObject daily = wJson.getJSONObject("daily");
                    final JSONArray dates = daily.getJSONArray("time");
                    final JSONArray maxTemps = daily.getJSONArray("temperature_2m_max");
                    final JSONArray minTemps = daily.getJSONArray("temperature_2m_min");
                    final JSONArray codes = daily.getJSONArray("weather_code");

                    new Handler(Looper.getMainLooper()).post(new Runnable() {
                        @Override
                        public void run() {
                            try {
                                RemoteViews views = buildBaseViews(context, appWidgetId, cityInput.toUpperCase(), imageAlpha, scale);
                                views.setTextViewText(R.id.txt_current_temp, currentTemp + "°");
                                views.setTextViewText(R.id.txt_condition, getConditionText(currentCode));
                                views.setImageViewResource(R.id.img_current_icon, getIconRes(currentCode));

                                int[] dayNameIds = {R.id.day1_name, R.id.day2_name, R.id.day3_name, R.id.day4_name};
                                int[] dayTempIds = {R.id.day1_temp, R.id.day2_temp, R.id.day3_temp, R.id.day4_temp};
                                int[] dayIconIds = {R.id.day1_icon, R.id.day2_icon, R.id.day3_icon, R.id.day4_icon};

                                SimpleDateFormat inFmt = new SimpleDateFormat("yyyy-MM-dd", Locale.US);
                                SimpleDateFormat outFmt = new SimpleDateFormat("EEE.", Locale.FRENCH);

                                for (int i = 0; i < 4 && i < dates.length(); i++) {
                                    Date d = inFmt.parse(dates.getString(i));
                                    String dayShort = outFmt.format(d).toUpperCase();
                                    int maxT = (int) Math.round(maxTemps.getDouble(i));
                                    int minT = (int) Math.round(minTemps.getDouble(i));
                                    int code = codes.getInt(i);

                                    views.setTextViewText(dayNameIds[i], dayShort);
                                    views.setTextViewText(dayTempIds[i], maxT + "° / " + minT + "°");
                                    views.setImageViewResource(dayIconIds[i], getIconRes(code));
                                }

                                appWidgetManager.updateAppWidget(appWidgetId, views);
                            } catch (Exception ignored) {}
                        }
                    });
                } catch (Exception ignored) {}
            }
        }).start();
    }

    private static RemoteViews buildBaseViews(Context context, int appWidgetId, String city, int imageAlpha, float scale) {
        RemoteViews views = new RemoteViews(context.getPackageName(), R.layout.weather_widget);
        views.setTextViewText(R.id.txt_city_name, city);
        views.setInt(R.id.widget_bg_image, "setImageAlpha", imageAlpha);

        views.setTextViewTextSize(R.id.txt_current_temp, TypedValue.COMPLEX_UNIT_SP, 54f * scale);
        views.setTextViewTextSize(R.id.txt_city_name, TypedValue.COMPLEX_UNIT_SP, 18f * scale);
        views.setTextViewTextSize(R.id.txt_condition, TypedValue.COMPLEX_UNIT_SP, 14f * scale);

        int[] dayNameIds = {R.id.day1_name, R.id.day2_name, R.id.day3_name, R.id.day4_name};
        int[] dayTempIds = {R.id.day1_temp, R.id.day2_temp, R.id.day3_temp, R.id.day4_temp};
        for (int i = 0; i < 4; i++) {
            views.setTextViewTextSize(dayNameIds[i], TypedValue.COMPLEX_UNIT_SP, 15f * scale);
            views.setTextViewTextSize(dayTempIds[i], TypedValue.COMPLEX_UNIT_SP, 14f * scale);
        }

        Intent configIntent = new Intent(context, WeatherWidgetConfigActivity.class);
        configIntent.putExtra(AppWidgetManager.EXTRA_APPWIDGET_ID, appWidgetId);
        PendingIntent pendingIntent = PendingIntent.getActivity(
                context, appWidgetId, configIntent, PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
        views.setOnClickPendingIntent(R.id.widget_root, pendingIntent);

        return views;
    }

    private static String httpGet(String urlStr) throws Exception {
        URL url = new URL(urlStr);
        HttpURLConnection conn = (HttpURLConnection) url.openConnection();
        conn.setConnectTimeout(8000);
        conn.setReadTimeout(8000);
        try {
            BufferedReader reader = new BufferedReader(new InputStreamReader(conn.getInputStream(), "UTF-8"));
            StringBuilder sb = new StringBuilder();
            String line;
            while ((line = reader.readLine()) != null) sb.append(line);
            reader.close();
            return sb.toString();
        } finally { conn.disconnect(); }
    }

    private static String getConditionText(int code) {
        if (code == 0) return "CLEAR SKY";
        if (code <= 3) return "MAINLY CLEAR";
        if (code <= 48) return "FOGGY";
        if (code <= 67) return "RAINY";
        if (code <= 77) return "SNOWY";
        return "STORMY";
    }

    private static int getIconRes(int code) {
        if (code == 0) return R.drawable.ic_weather_sun;
        if (code <= 48) return R.drawable.ic_weather_cloud;
        return R.drawable.ic_weather_rain;
    }
}
