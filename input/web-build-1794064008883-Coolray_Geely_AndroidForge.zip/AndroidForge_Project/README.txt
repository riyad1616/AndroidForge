مشروع Coolray / Geely Receiver لـ AndroidForge
==============================================

1) apks/GeelyReceiver_mod_windows_climate.apk
   - النسخة المعدّلة من تطبيق السيارة (جاهزة للتثبيت)
   - تدعم التحكم الفردي بالنوافذ + السقف + المكيف الكامل

2) apks/base_original.apk
   - النسخة الأصلية قبل التعديل

3) apks/CoolrayRemote-Mobile-0.6.10.apk
   - تطبيق الهاتف

4) smali_base/
   - CommandBackend.smali          (تم تعديل isKnown)
   - CommandBackend$Companion.smali (تم إضافة الأوامر)

5) commands/new_commands.txt
   - قائمة الأوامر الجديدة جاهزة للنسخ

طريقة الاستخدام في AndroidForge:
- للتثبيت المباشر: استخدم GeelyReceiver_mod_windows_climate.apk
- للتعديل الإضافي: فك base_original.apk ثم استبدل ملفي smali ثم أعد البناء ووقّع

بروتوكول الاتصال (base.apk):
المنفذ 8888 | TCP نصي
AUTH <PIN>
ثم الأمر (مثال: window.driver.open)
