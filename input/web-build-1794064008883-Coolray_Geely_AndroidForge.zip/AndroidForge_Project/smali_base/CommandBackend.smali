.class public final Lcom/geely/carreceiver/CommandBackend;
.super Ljava/lang/Object;
.source "CommandBackend.kt"


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Lcom/geely/carreceiver/CommandBackend$Companion;,
        Lcom/geely/carreceiver/CommandBackend$Config;,
        Lcom/geely/carreceiver/CommandBackend$ExecResult;,
        Lcom/geely/carreceiver/CommandBackend$SuStatus;
    }
.end annotation

.annotation system Ldalvik/annotation/SourceDebugExtension;
    value = "SMAP\nCommandBackend.kt\nKotlin\n*S Kotlin\n*F\n+ 1 CommandBackend.kt\ncom/geely/carreceiver/CommandBackend\n+ 2 _Collections.kt\nkotlin/collections/CollectionsKt___CollectionsKt\n*L\n1#1,427:1\n1747#2,3:428\n766#2:431\n857#2,2:432\n766#2:434\n857#2,2:435\n1549#2:437\n1620#2,3:438\n766#2:441\n857#2,2:442\n1549#2:444\n1620#2,3:445\n1747#2,3:448\n766#2:451\n857#2,2:452\n288#2,2:454\n*S KotlinDebug\n*F\n+ 1 CommandBackend.kt\ncom/geely/carreceiver/CommandBackend\n*L\n87#1:428,3\n143#1:431\n143#1:432,2\n165#1:434\n165#1:435,2\n169#1:437\n169#1:438,3\n169#1:441\n169#1:442,2\n169#1:444\n169#1:445,3\n170#1:448,3\n203#1:451\n203#1:452,2\n252#1:454,2\n*E\n"
.end annotation

.annotation runtime Lkotlin/Metadata;
    d1 = {
        "\u0000X\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010 \n\u0002\u0010\u000e\n\u0002\u0008\u0003\n\u0002\u0018\u0002\n\u0002\u0008\u0003\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\t\n\u0002\u0008\u0002\n\u0002\u0010\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\u0008\u0002\n\u0002\u0010\u000b\n\u0002\u0008\u0006\n\u0002\u0018\u0002\n\u0002\u0008\u0002\n\u0002\u0010\u0008\n\u0002\u0008\u000e\u0018\u0000 ,2\u00020\u0001:\u0004,-./B\u001d\u0012\u0006\u0010\u0002\u001a\u00020\u0003\u0012\u000e\u0008\u0002\u0010\u0004\u001a\u0008\u0012\u0004\u0012\u00020\u00060\u0005\u00a2\u0006\u0002\u0010\u0007J\u0006\u0010\u0012\u001a\u00020\u0013J\u0018\u0010\u0014\u001a\u00020\u00152\u0006\u0010\u0016\u001a\u00020\u00062\u0006\u0010\u0017\u001a\u00020\u0018H\u0002J\u0018\u0010\u0019\u001a\u00020\u00152\u0006\u0010\u0016\u001a\u00020\u00062\u0006\u0010\u0017\u001a\u00020\u0018H\u0002J\u000e\u0010\u001a\u001a\u00020\u00152\u0006\u0010\u001b\u001a\u00020\u0006J\n\u0010\u001c\u001a\u0004\u0018\u00010\u0006H\u0002J\u000e\u0010\u001d\u001a\u00020\u00182\u0006\u0010\u001b\u001a\u00020\u0006J\u0010\u0010\u001e\u001a\u00020\u001f2\u0006\u0010 \u001a\u00020\u0006H\u0002J\u0017\u0010!\u001a\u0004\u0018\u00010\"2\u0006\u0010#\u001a\u00020\u0006H\u0002\u00a2\u0006\u0002\u0010$J\u0008\u0010%\u001a\u00020\u000eH\u0002J\u0006\u0010&\u001a\u00020\u0006J\u0006\u0010\'\u001a\u00020\u0013J\u0010\u0010(\u001a\u00020\u00152\u0006\u0010\u0016\u001a\u00020\u0006H\u0002J\u0006\u0010)\u001a\u00020\u000eJ\u0006\u0010*\u001a\u00020\u0018J\u000e\u0010+\u001a\u00020\u00132\u0006\u0010 \u001a\u00020\u0006R\u000e\u0010\u0002\u001a\u00020\u0003X\u0082\u0004\u00a2\u0006\u0002\n\u0000R\u000e\u0010\u0008\u001a\u00020\u0001X\u0082\u0004\u00a2\u0006\u0002\n\u0000R\u0014\u0010\t\u001a\u00020\n8BX\u0082\u0004\u00a2\u0006\u0006\u001a\u0004\u0008\u000b\u0010\u000cR\u0010\u0010\r\u001a\u0004\u0018\u00010\u000eX\u0082\u000e\u00a2\u0006\u0002\n\u0000R\u000e\u0010\u000f\u001a\u00020\u0010X\u0082\u000e\u00a2\u0006\u0002\n\u0000R\u000e\u0010\u0011\u001a\u00020\u0001X\u0082\u0004\u00a2\u0006\u0002\n\u0000R\u0014\u0010\u0004\u001a\u0008\u0012\u0004\u0012\u00020\u00060\u0005X\u0082\u0004\u00a2\u0006\u0002\n\u0000\u00a8\u00060"
    }
    d2 = {
        "Lcom/geely/carreceiver/CommandBackend;",
        "",
        "context",
        "Landroid/content/Context;",
        "suPaths",
        "",
        "",
        "(Landroid/content/Context;Ljava/util/List;)V",
        "execLock",
        "file",
        "Ljava/io/File;",
        "getFile",
        "()Ljava/io/File;",
        "suCache",
        "Lcom/geely/carreceiver/CommandBackend$SuStatus;",
        "suCacheAt",
        "",
        "suLock",
        "ensureConfig",
        "",
        "execVhalGet",
        "Lcom/geely/carreceiver/CommandBackend$ExecResult;",
        "spec",
        "isBool",
        "",
        "execVhalSet",
        "execute",
        "cmd",
        "findSu",
        "isKnown",
        "parse",
        "Lcom/geely/carreceiver/CommandBackend$Config;",
        "text",
        "parseFlexInt",
        "",
        "tok",
        "(Ljava/lang/String;)Ljava/lang/Integer;",
        "probeSu",
        "readText",
        "resetToDefault",
        "sendVehicleBroadcast",
        "suStatus",
        "usesPlaceholder",
        "writeText",
        "Companion",
        "Config",
        "ExecResult",
        "SuStatus",
        "app_debug"
    }
    k = 0x1
    mv = {
        0x1,
        0x9,
        0x0
    }
    xi = 0x30
.end annotation


# static fields
.field private static final BROADCAST_DEFAULTS:Ljava/util/Map;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/Map<",
            "Ljava/lang/String;",
            "Ljava/lang/String;",
            ">;"
        }
    .end annotation
.end field

.field public static final Companion:Lcom/geely/carreceiver/CommandBackend$Companion;

.field private static final DEFAULTS:Ljava/util/LinkedHashMap;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/LinkedHashMap<",
            "Ljava/lang/String;",
            "Ljava/lang/String;",
            ">;"
        }
    .end annotation
.end field

.field private static final DOME_LIGHT_PROP:I = 0x21402069

.field private static final DOOR_LOCK_AREAS:Ljava/lang/String; = "0x1,0x4,0x10,0x40"

.field private static final DOOR_LOCK_PROP:I = 0x264020aa

.field public static final FILE_NAME:Ljava/lang/String; = "car_commands.txt"

.field private static final FUEL_CAP_PROP:I = 0x11200308

.field private static final KNOWN:Ljava/util/Set;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/Set<",
            "Ljava/lang/String;",
            ">;"
        }
    .end annotation
.end field

.field private static final LAUNCHER_PKG:Ljava/lang/String; = "com.flyme.auto.launcher"

.field private static final MIRROR_FOLD_AREA:Ljava/lang/String; = "0x0"

.field private static final MIRROR_FOLD_PROP:I = 0x21402023

.field public static final PLACEHOLDER_DEVICE:Ljava/lang/String; = "/dev/car_control"

.field private static final ROOF_WIDGET:Ljava/lang/String; = "com.coolray.vehicle.RoofWidgetV2"

.field private static final SUNSHADE_STATE_PROP:I = 0x2140209e

.field private static final SU_CACHE_MS:J = 0xea60L

.field private static final SU_PATHS:Ljava/util/List;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/List<",
            "Ljava/lang/String;",
            ">;"
        }
    .end annotation
.end field

.field private static final SU_PROBE_TIMEOUT_MS:J = 0x1388L

.field private static final TRUNK_AREA:Ljava/lang/String; = "0x20000000"

.field private static final TRUNK_POS_PROP:I = 0x264020a9

.field private static final VHAL_DEFAULTS:Ljava/util/Map;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/Map<",
            "Ljava/lang/String;",
            "Ljava/lang/String;",
            ">;"
        }
    .end annotation
.end field

.field private static final WINDOWS_WIDGET:Ljava/lang/String; = "com.coolray.vehicle.WindowsWidgetV2"


# instance fields
.field private final context:Landroid/content/Context;

.field private final execLock:Ljava/lang/Object;

.field private suCache:Lcom/geely/carreceiver/CommandBackend$SuStatus;

.field private suCacheAt:J

.field private final suLock:Ljava/lang/Object;

.field private final suPaths:Ljava/util/List;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/List<",
            "Ljava/lang/String;",
            ">;"
        }
    .end annotation
.end field


# direct methods
.method static constructor <clinit>()V
    .registers 19

    new-instance v0, Lcom/geely/carreceiver/CommandBackend$Companion;

    const/4 v1, 0x0

    invoke-direct {v0, v1}, Lcom/geely/carreceiver/CommandBackend$Companion;-><init>(Lkotlin/jvm/internal/DefaultConstructorMarker;)V

    sput-object v0, Lcom/geely/carreceiver/CommandBackend;->Companion:Lcom/geely/carreceiver/CommandBackend$Companion;

    .line 275
    nop

    .line 276
    const-string v2, "/system/bin/su"

    const-string v3, "/system/xbin/su"

    const-string v4, "/sbin/su"

    const-string v5, "/su/bin/su"

    const-string v6, "/vendor/bin/su"

    const-string v7, "/system/sbin/su"

    filled-new-array/range {v2 .. v7}, [Ljava/lang/String;

    move-result-object v0

    .line 275
    invoke-static {v0}, Lkotlin/collections/CollectionsKt;->listOf([Ljava/lang/Object;)Ljava/util/List;

    move-result-object v0

    sput-object v0, Lcom/geely/carreceiver/CommandBackend;->SU_PATHS:Ljava/util/List;

    .line 286
    nop

    .line 287
    const/4 v0, 0x4

    new-array v1, v0, [Lkotlin/Pair;

    const-string v2, "BROADCAST com.coolray.vehicle.ALL_OPEN com.flyme.auto.launcher/com.coolray.vehicle.WindowsWidgetV2"

    const-string v3, "CMD_WINDOW_OPEN"

    invoke-static {v3, v2}, Lkotlin/TuplesKt;->to(Ljava/lang/Object;Ljava/lang/Object;)Lkotlin/Pair;

    move-result-object v2

    const/4 v4, 0x0

    aput-object v2, v1, v4

    .line 288
    const-string v2, "BROADCAST com.coolray.vehicle.ALL_CLOSE com.flyme.auto.launcher/com.coolray.vehicle.WindowsWidgetV2"

    const-string v5, "CMD_WINDOW_CLOSE"

    invoke-static {v5, v2}, Lkotlin/TuplesKt;->to(Ljava/lang/Object;Ljava/lang/Object;)Lkotlin/Pair;

    move-result-object v2

    const/4 v6, 0x1

    aput-object v2, v1, v6

    .line 287
    nop

    .line 289
    const-string v2, "BROADCAST com.coolray.vehicle.ROOF_OPEN com.flyme.auto.launcher/com.coolray.vehicle.RoofWidgetV2"

    const-string v7, "CMD_SUNROOF_OPEN"

    invoke-static {v7, v2}, Lkotlin/TuplesKt;->to(Ljava/lang/Object;Ljava/lang/Object;)Lkotlin/Pair;

    move-result-object v2

    const/4 v8, 0x2

    aput-object v2, v1, v8

    .line 287
    nop

    .line 290
    const-string v2, "BROADCAST com.coolray.vehicle.ROOF_CLOSE com.flyme.auto.launcher/com.coolray.vehicle.RoofWidgetV2"

    const-string v9, "CMD_SUNROOF_CLOSE"

    invoke-static {v9, v2}, Lkotlin/TuplesKt;->to(Ljava/lang/Object;Ljava/lang/Object;)Lkotlin/Pair;

    move-result-object v2

    const/4 v10, 0x3

    aput-object v2, v1, v10

    .line 287
    nop

    .line 286
    invoke-static {v1}, Lkotlin/collections/MapsKt;->linkedMapOf([Lkotlin/Pair;)Ljava/util/LinkedHashMap;

    move-result-object v1

    check-cast v1, Ljava/util/Map;

    sput-object v1, Lcom/geely/carreceiver/CommandBackend;->BROADCAST_DEFAULTS:Ljava/util/Map;

    .line 330
    nop

    .line 331
    const/16 v1, 0xc

    new-array v2, v1, [Lkotlin/Pair;

    const-string v11, "VHAL_BOOL 557850659 0x0 false"

    const-string v12, "CMD_MIRROR_UNFOLD"

    invoke-static {v12, v11}, Lkotlin/TuplesKt;->to(Ljava/lang/Object;Ljava/lang/Object;)Lkotlin/Pair;

    move-result-object v11

    aput-object v11, v2, v4

    .line 332
    const-string v11, "VHAL_BOOL 557850659 0x0 true"

    const-string v13, "CMD_MIRROR_FOLD"

    invoke-static {v13, v11}, Lkotlin/TuplesKt;->to(Ljava/lang/Object;Ljava/lang/Object;)Lkotlin/Pair;

    move-result-object v11

    aput-object v11, v2, v6

    .line 331
    nop

    .line 333
    const-string v11, "VHAL_BOOL 557850729 0x0 true"

    const-string v14, "CMD_INTERIOR_ON"

    invoke-static {v14, v11}, Lkotlin/TuplesKt;->to(Ljava/lang/Object;Ljava/lang/Object;)Lkotlin/Pair;

    move-result-object v11

    aput-object v11, v2, v8

    .line 331
    nop

    .line 334
    const-string v11, "VHAL_BOOL 557850729 0x0 false"

    const-string v15, "CMD_INTERIOR_OFF"

    invoke-static {v15, v11}, Lkotlin/TuplesKt;->to(Ljava/lang/Object;Ljava/lang/Object;)Lkotlin/Pair;

    move-result-object v11

    aput-object v11, v2, v10

    .line 331
    nop

    .line 335
    const-string v11, "VHAL_BOOL 287310600 0x0 true"

    const-string v1, "CMD_FUEL_CAP_OPEN"

    invoke-static {v1, v11}, Lkotlin/TuplesKt;->to(Ljava/lang/Object;Ljava/lang/Object;)Lkotlin/Pair;

    move-result-object v11

    aput-object v11, v2, v0

    .line 331
    nop

    .line 336
    const-string v11, "VHAL_BOOL 287310600 0x0 false"

    const-string v0, "CMD_FUEL_CAP_CLOSE"

    invoke-static {v0, v11}, Lkotlin/TuplesKt;->to(Ljava/lang/Object;Ljava/lang/Object;)Lkotlin/Pair;

    move-result-object v11

    const/16 v16, 0x5

    aput-object v11, v2, v16

    .line 331
    nop

    .line 337
    const-string v11, "VHAL_BOOL 641736874 0x1,0x4,0x10,0x40 true"

    const-string v10, "CMD_DOOR_LOCK"

    invoke-static {v10, v11}, Lkotlin/TuplesKt;->to(Ljava/lang/Object;Ljava/lang/Object;)Lkotlin/Pair;

    move-result-object v11

    const/16 v17, 0x6

    aput-object v11, v2, v17

    .line 331
    nop

    .line 338
    const-string v11, "VHAL_BOOL 641736874 0x1,0x4,0x10,0x40 false"

    const-string v8, "CMD_DOOR_UNLOCK"

    invoke-static {v8, v11}, Lkotlin/TuplesKt;->to(Ljava/lang/Object;Ljava/lang/Object;)Lkotlin/Pair;

    move-result-object v11

    const/16 v18, 0x7

    aput-object v11, v2, v18

    .line 331
    nop

    .line 339
    const-string v11, "CMD_TRUNK_OPEN"

    const-string v6, "VHAL_BOOL 641736873 0x20000000 true"

    invoke-static {v11, v6}, Lkotlin/TuplesKt;->to(Ljava/lang/Object;Ljava/lang/Object;)Lkotlin/Pair;

    move-result-object v6

    const/16 v11, 0x8

    aput-object v6, v2, v11

    .line 331
    nop

    .line 340
    const-string v6, "CMD_TRUNK_CLOSE"

    const-string v11, "VHAL_BOOL 641736873 0x20000000 false"

    invoke-static {v6, v11}, Lkotlin/TuplesKt;->to(Ljava/lang/Object;Ljava/lang/Object;)Lkotlin/Pair;

    move-result-object v6

    const/16 v11, 0x9

    aput-object v6, v2, v11

    .line 331
    nop

    .line 341
    const-string v6, "CMD_SUNSHADE_OPEN"

    const-string v11, "VHAL_BOOL 557850782 0x0 true"

    invoke-static {v6, v11}, Lkotlin/TuplesKt;->to(Ljava/lang/Object;Ljava/lang/Object;)Lkotlin/Pair;

    move-result-object v6

    const/16 v11, 0xa

    aput-object v6, v2, v11

    .line 331
    nop

    .line 342
    const-string v6, "CMD_SUNSHADE_CLOSE"

    const-string v11, "VHAL_BOOL 557850782 0x0 false"

    invoke-static {v6, v11}, Lkotlin/TuplesKt;->to(Ljava/lang/Object;Ljava/lang/Object;)Lkotlin/Pair;

    move-result-object v6

    const/16 v11, 0xb

    aput-object v6, v2, v11

    .line 331
    nop

    .line 330
    invoke-static {v2}, Lkotlin/collections/MapsKt;->linkedMapOf([Lkotlin/Pair;)Ljava/util/LinkedHashMap;

    move-result-object v2

    check-cast v2, Ljava/util/Map;

    sput-object v2, Lcom/geely/carreceiver/CommandBackend;->VHAL_DEFAULTS:Ljava/util/Map;

    .line 349
    nop

    .line 350
    const/16 v2, 0x1f

    new-array v2, v2, [Lkotlin/Pair;

    const-string v6, "OPEN_WINDOWS"

    invoke-static {v3, v6}, Lkotlin/TuplesKt;->to(Ljava/lang/Object;Ljava/lang/Object;)Lkotlin/Pair;

    move-result-object v3

    aput-object v3, v2, v4

    .line 351
    const-string v3, "CLOSE_WINDOWS"

    invoke-static {v5, v3}, Lkotlin/TuplesKt;->to(Ljava/lang/Object;Ljava/lang/Object;)Lkotlin/Pair;

    move-result-object v3

    const/4 v4, 0x1

    aput-object v3, v2, v4

    .line 350
    nop

    .line 352
    const-string v3, "OPEN_SUNROOF"

    invoke-static {v7, v3}, Lkotlin/TuplesKt;->to(Ljava/lang/Object;Ljava/lang/Object;)Lkotlin/Pair;

    move-result-object v3

    const/4 v4, 0x2

    aput-object v3, v2, v4

    .line 350
    nop

    .line 353
    const-string v3, "CLOSE_SUNROOF"

    invoke-static {v9, v3}, Lkotlin/TuplesKt;->to(Ljava/lang/Object;Ljava/lang/Object;)Lkotlin/Pair;

    move-result-object v3

    const/4 v4, 0x3

    aput-object v3, v2, v4

    .line 350
    nop

    .line 354
    const-string v3, "CMD_AC_ON"

    const-string v4, "AC_ON"

    invoke-static {v3, v4}, Lkotlin/TuplesKt;->to(Ljava/lang/Object;Ljava/lang/Object;)Lkotlin/Pair;

    move-result-object v3

    const/4 v4, 0x4

    aput-object v3, v2, v4

    .line 350
    nop

    .line 355
    const-string v3, "CMD_AC_OFF"

    const-string v4, "AC_OFF"

    invoke-static {v3, v4}, Lkotlin/TuplesKt;->to(Ljava/lang/Object;Ljava/lang/Object;)Lkotlin/Pair;

    move-result-object v3

    aput-object v3, v2, v16

    .line 350
    nop

    .line 356
    const-string v3, "UNFOLD_MIRRORS"

    invoke-static {v12, v3}, Lkotlin/TuplesKt;->to(Ljava/lang/Object;Ljava/lang/Object;)Lkotlin/Pair;

    move-result-object v3

    aput-object v3, v2, v17

    .line 350
    nop

    .line 357
    const-string v3, "FOLD_MIRRORS"

    invoke-static {v13, v3}, Lkotlin/TuplesKt;->to(Ljava/lang/Object;Ljava/lang/Object;)Lkotlin/Pair;

    move-result-object v3

    aput-object v3, v2, v18

    .line 350
    nop

    .line 358
    const-string v3, "OPEN_FUEL_CAP"

    invoke-static {v1, v3}, Lkotlin/TuplesKt;->to(Ljava/lang/Object;Ljava/lang/Object;)Lkotlin/Pair;

    move-result-object v1

    const/16 v3, 0x8

    aput-object v1, v2, v3

    .line 350
    nop

    .line 359
    const-string v1, "CLOSE_FUEL_CAP"

    invoke-static {v0, v1}, Lkotlin/TuplesKt;->to(Ljava/lang/Object;Ljava/lang/Object;)Lkotlin/Pair;

    move-result-object v0

    const/16 v1, 0x9

    aput-object v0, v2, v1

    .line 350
    nop

    .line 360
    const-string v0, "CMD_SUNSHADE_OPEN"

    const-string v1, "OPEN_SUNSHADE"

    invoke-static {v0, v1}, Lkotlin/TuplesKt;->to(Ljava/lang/Object;Ljava/lang/Object;)Lkotlin/Pair;

    move-result-object v0

    const/16 v1, 0xa

    aput-object v0, v2, v1

    .line 350
    nop

    .line 361
    const-string v0, "CMD_SUNSHADE_CLOSE"

    const-string v1, "CLOSE_SUNSHADE"

    invoke-static {v0, v1}, Lkotlin/TuplesKt;->to(Ljava/lang/Object;Ljava/lang/Object;)Lkotlin/Pair;

    move-result-object v0

    const/16 v1, 0xb

    aput-object v0, v2, v1

    .line 350
    nop

    .line 362
    const-string v0, "CMD_HEADLIGHTS_ON"

    const-string v1, "HEADLIGHTS_ON"

    invoke-static {v0, v1}, Lkotlin/TuplesKt;->to(Ljava/lang/Object;Ljava/lang/Object;)Lkotlin/Pair;

    move-result-object v0

    const/16 v1, 0xc

    aput-object v0, v2, v1

    .line 350
    nop

    .line 363
    const-string v0, "CMD_HEADLIGHTS_OFF"

    const-string v1, "HEADLIGHTS_OFF"

    invoke-static {v0, v1}, Lkotlin/TuplesKt;->to(Ljava/lang/Object;Ljava/lang/Object;)Lkotlin/Pair;

    move-result-object v0

    const/16 v1, 0xd

    aput-object v0, v2, v1

    .line 350
    nop

    .line 364
    const-string v0, "CMD_HIGHBEAM_ON"

    const-string v1, "HIGHBEAM_ON"

    invoke-static {v0, v1}, Lkotlin/TuplesKt;->to(Ljava/lang/Object;Ljava/lang/Object;)Lkotlin/Pair;

    move-result-object v0

    const/16 v1, 0xe

    aput-object v0, v2, v1

    .line 350
    nop

    .line 365
    const-string v0, "CMD_HIGHBEAM_OFF"

    const-string v1, "HIGHBEAM_OFF"

    invoke-static {v0, v1}, Lkotlin/TuplesKt;->to(Ljava/lang/Object;Ljava/lang/Object;)Lkotlin/Pair;

    move-result-object v0

    const/16 v1, 0xf

    aput-object v0, v2, v1

    .line 350
    nop

    .line 366
    const-string v0, "INTERIOR_ON"

    invoke-static {v14, v0}, Lkotlin/TuplesKt;->to(Ljava/lang/Object;Ljava/lang/Object;)Lkotlin/Pair;

    move-result-object v0

    const/16 v1, 0x10

    aput-object v0, v2, v1

    .line 350
    nop

    .line 367
    const-string v0, "INTERIOR_OFF"

    invoke-static {v15, v0}, Lkotlin/TuplesKt;->to(Ljava/lang/Object;Ljava/lang/Object;)Lkotlin/Pair;

    move-result-object v0

    const/16 v1, 0x11

    aput-object v0, v2, v1

    .line 350
    nop

    .line 368
    const-string v0, "CMD_FOG_ON"

    const-string v1, "FOG_ON"

    invoke-static {v0, v1}, Lkotlin/TuplesKt;->to(Ljava/lang/Object;Ljava/lang/Object;)Lkotlin/Pair;

    move-result-object v0

    const/16 v1, 0x12

    aput-object v0, v2, v1

    .line 350
    nop

    .line 369
    const-string v0, "CMD_FOG_OFF"

    const-string v1, "FOG_OFF"

    invoke-static {v0, v1}, Lkotlin/TuplesKt;->to(Ljava/lang/Object;Ljava/lang/Object;)Lkotlin/Pair;

    move-result-object v0

    const/16 v1, 0x13

    aput-object v0, v2, v1

    .line 350
    nop

    .line 370
    const-string v0, "DOOR_UNLOCK"

    invoke-static {v8, v0}, Lkotlin/TuplesKt;->to(Ljava/lang/Object;Ljava/lang/Object;)Lkotlin/Pair;

    move-result-object v0

    const/16 v1, 0x14

    aput-object v0, v2, v1

    .line 350
    nop

    .line 371
    const-string v0, "DOOR_LOCK"

    invoke-static {v10, v0}, Lkotlin/TuplesKt;->to(Ljava/lang/Object;Ljava/lang/Object;)Lkotlin/Pair;

    move-result-object v0

    const/16 v1, 0x15

    aput-object v0, v2, v1

    .line 350
    nop

    .line 372
    const-string v0, "CMD_TRUNK_OPEN"

    const-string v1, "TRUNK_OPEN"

    invoke-static {v0, v1}, Lkotlin/TuplesKt;->to(Ljava/lang/Object;Ljava/lang/Object;)Lkotlin/Pair;

    move-result-object v0

    const/16 v1, 0x16

    aput-object v0, v2, v1

    .line 350
    nop

    .line 373
    const-string v0, "CMD_TRUNK_CLOSE"

    const-string v1, "TRUNK_CLOSE"

    invoke-static {v0, v1}, Lkotlin/TuplesKt;->to(Ljava/lang/Object;Ljava/lang/Object;)Lkotlin/Pair;

    move-result-object v0

    const/16 v1, 0x17

    aput-object v0, v2, v1

    .line 350
    nop

    .line 374
    const-string v0, "CMD_HORN"

    const-string v1, "HORN"

    invoke-static {v0, v1}, Lkotlin/TuplesKt;->to(Ljava/lang/Object;Ljava/lang/Object;)Lkotlin/Pair;

    move-result-object v0

    const/16 v1, 0x18

    aput-object v0, v2, v1

    .line 350
    nop

    .line 375
    const-string v0, "CMD_RADIO_ON"

    const-string v1, "RADIO_ON"

    invoke-static {v0, v1}, Lkotlin/TuplesKt;->to(Ljava/lang/Object;Ljava/lang/Object;)Lkotlin/Pair;

    move-result-object v0

    const/16 v1, 0x19

    aput-object v0, v2, v1

    .line 350
    nop

    .line 376
    const-string v0, "CMD_RADIO_OFF"

    const-string v1, "RADIO_OFF"

    invoke-static {v0, v1}, Lkotlin/TuplesKt;->to(Ljava/lang/Object;Ljava/lang/Object;)Lkotlin/Pair;

    move-result-object v0

    const/16 v1, 0x1a

    aput-object v0, v2, v1

    .line 350
    nop

    .line 377
    const-string v0, "CMD_SEAT_HEAT_ON"

    const-string v1, "SEAT_HEAT_ON"

    invoke-static {v0, v1}, Lkotlin/TuplesKt;->to(Ljava/lang/Object;Ljava/lang/Object;)Lkotlin/Pair;

    move-result-object v0

    const/16 v1, 0x1b

    aput-object v0, v2, v1

    .line 350
    nop

    .line 378
    const-string v0, "CMD_SEAT_HEAT_OFF"

    const-string v1, "SEAT_HEAT_OFF"

    invoke-static {v0, v1}, Lkotlin/TuplesKt;->to(Ljava/lang/Object;Ljava/lang/Object;)Lkotlin/Pair;

    move-result-object v0

    const/16 v1, 0x1c

    aput-object v0, v2, v1

    .line 350
    nop

    .line 379
    const-string v0, "CMD_HAZARD_ON"

    const-string v1, "HAZARD_ON"

    invoke-static {v0, v1}, Lkotlin/TuplesKt;->to(Ljava/lang/Object;Ljava/lang/Object;)Lkotlin/Pair;

    move-result-object v0

    const/16 v1, 0x1d

    aput-object v0, v2, v1

    .line 350
    nop

    .line 380
    const-string v0, "CMD_HAZARD_OFF"

    const-string v1, "HAZARD_OFF"

    invoke-static {v0, v1}, Lkotlin/TuplesKt;->to(Ljava/lang/Object;Ljava/lang/Object;)Lkotlin/Pair;

    move-result-object v0

    const/16 v1, 0x1e

    aput-object v0, v2, v1

    .line 350
    nop

    .line 349
    invoke-static {v2}, Lkotlin/collections/MapsKt;->linkedMapOf([Lkotlin/Pair;)Ljava/util/LinkedHashMap;

    move-result-object v0

    sput-object v0, Lcom/geely/carreceiver/CommandBackend;->DEFAULTS:Ljava/util/LinkedHashMap;

    .line 384
    invoke-virtual {v0}, Ljava/util/LinkedHashMap;->keySet()Ljava/util/Set;

    move-result-object v0

    const-string v1, "<get-keys>(...)"

    invoke-static {v0, v1}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    const-string v1, "CMD_REBOOT"

    invoke-static {v0, v1}, Lkotlin/collections/SetsKt;->plus(Ljava/util/Set;Ljava/lang/Object;)Ljava/util/Set;

    move-result-object v0

    sput-object v0, Lcom/geely/carreceiver/CommandBackend;->KNOWN:Ljava/util/Set;

    return-void
.end method

.method public constructor <init>(Landroid/content/Context;Ljava/util/List;)V
    .registers 4
    .param p1, "context"    # Landroid/content/Context;
    .param p2, "suPaths"    # Ljava/util/List;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Landroid/content/Context;",
            "Ljava/util/List<",
            "Ljava/lang/String;",
            ">;)V"
        }
    .end annotation

    const-string v0, "context"

    invoke-static {p1, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    const-string v0, "suPaths"

    invoke-static {p2, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 41
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 42
    iput-object p1, p0, Lcom/geely/carreceiver/CommandBackend;->context:Landroid/content/Context;

    .line 43
    iput-object p2, p0, Lcom/geely/carreceiver/CommandBackend;->suPaths:Ljava/util/List;

    .line 54
    new-instance v0, Ljava/lang/Object;

    invoke-direct {v0}, Ljava/lang/Object;-><init>()V

    iput-object v0, p0, Lcom/geely/carreceiver/CommandBackend;->execLock:Ljava/lang/Object;

    .line 55
    new-instance v0, Ljava/lang/Object;

    invoke-direct {v0}, Ljava/lang/Object;-><init>()V

    iput-object v0, p0, Lcom/geely/carreceiver/CommandBackend;->suLock:Ljava/lang/Object;

    .line 41
    return-void
.end method

.method public synthetic constructor <init>(Landroid/content/Context;Ljava/util/List;ILkotlin/jvm/internal/DefaultConstructorMarker;)V
    .registers 5

    .line 41
    and-int/lit8 p3, p3, 0x2

    if-eqz p3, :cond_6

    .line 43
    sget-object p2, Lcom/geely/carreceiver/CommandBackend;->SU_PATHS:Ljava/util/List;

    .line 41
    :cond_6
    invoke-direct {p0, p1, p2}, Lcom/geely/carreceiver/CommandBackend;-><init>(Landroid/content/Context;Ljava/util/List;)V

    .line 426
    return-void
.end method

.method public static final synthetic access$getBROADCAST_DEFAULTS$cp()Ljava/util/Map;
    .registers 1

    .line 41
    sget-object v0, Lcom/geely/carreceiver/CommandBackend;->BROADCAST_DEFAULTS:Ljava/util/Map;

    return-object v0
.end method

.method public static final synthetic access$getDEFAULTS$cp()Ljava/util/LinkedHashMap;
    .registers 1

    .line 41
    sget-object v0, Lcom/geely/carreceiver/CommandBackend;->DEFAULTS:Ljava/util/LinkedHashMap;

    return-object v0
.end method

.method public static final synthetic access$getKNOWN$cp()Ljava/util/Set;
    .registers 1

    .line 41
    sget-object v0, Lcom/geely/carreceiver/CommandBackend;->KNOWN:Ljava/util/Set;

    return-object v0
.end method

.method public static final synthetic access$getSU_PATHS$cp()Ljava/util/List;
    .registers 1

    .line 41
    sget-object v0, Lcom/geely/carreceiver/CommandBackend;->SU_PATHS:Ljava/util/List;

    return-object v0
.end method

.method public static final synthetic access$getVHAL_DEFAULTS$cp()Ljava/util/Map;
    .registers 1

    .line 41
    sget-object v0, Lcom/geely/carreceiver/CommandBackend;->VHAL_DEFAULTS:Ljava/util/Map;

    return-object v0
.end method

.method private final execVhalGet(Ljava/lang/String;Z)Lcom/geely/carreceiver/CommandBackend$ExecResult;
    .registers 15
    .param p1, "spec"    # Ljava/lang/String;
    .param p2, "isBool"    # Z

    .line 203
    move-object v0, p1

    check-cast v0, Ljava/lang/CharSequence;

    new-instance v1, Lkotlin/text/Regex;

    const-string v2, "\\s+"

    invoke-direct {v1, v2}, Lkotlin/text/Regex;-><init>(Ljava/lang/String;)V

    const/4 v2, 0x0

    invoke-virtual {v1, v0, v2}, Lkotlin/text/Regex;->split(Ljava/lang/CharSequence;I)Ljava/util/List;

    move-result-object v0

    check-cast v0, Ljava/lang/Iterable;

    .local v0, "$this$filter$iv":Ljava/lang/Iterable;
    const/4 v1, 0x0

    .line 451
    .local v1, "$i$f$filter":I
    new-instance v3, Ljava/util/ArrayList;

    invoke-direct {v3}, Ljava/util/ArrayList;-><init>()V

    check-cast v3, Ljava/util/Collection;

    .local v3, "destination$iv$iv":Ljava/util/Collection;
    move-object v4, v0

    .local v4, "$this$filterTo$iv$iv":Ljava/lang/Iterable;
    const/4 v5, 0x0

    .line 452
    .local v5, "$i$f$filterTo":I
    invoke-interface {v4}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    move-result-object v6

    :cond_1f
    :goto_1f
    invoke-interface {v6}, Ljava/util/Iterator;->hasNext()Z

    move-result v7

    const/4 v8, 0x1

    if-eqz v7, :cond_3f

    invoke-interface {v6}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v7

    .local v7, "element$iv$iv":Ljava/lang/Object;
    move-object v9, v7

    check-cast v9, Ljava/lang/String;

    .local v9, "it":Ljava/lang/String;
    const/4 v10, 0x0

    .line 203
    .local v10, "$i$a$-filter-CommandBackend$execVhalGet$parts$1":I
    move-object v11, v9

    check-cast v11, Ljava/lang/CharSequence;

    invoke-interface {v11}, Ljava/lang/CharSequence;->length()I

    move-result v11

    if-lez v11, :cond_38

    goto :goto_39

    :cond_38
    move v8, v2

    .line 452
    .end local v9    # "it":Ljava/lang/String;
    .end local v10    # "$i$a$-filter-CommandBackend$execVhalGet$parts$1":I
    :goto_39
    if-eqz v8, :cond_1f

    invoke-interface {v3, v7}, Ljava/util/Collection;->add(Ljava/lang/Object;)Z

    goto :goto_1f

    .line 453
    .end local v7    # "element$iv$iv":Ljava/lang/Object;
    :cond_3f
    nop

    .end local v3    # "destination$iv$iv":Ljava/util/Collection;
    .end local v4    # "$this$filterTo$iv$iv":Ljava/lang/Iterable;
    .end local v5    # "$i$f$filterTo":I
    check-cast v3, Ljava/util/List;

    .line 451
    nop

    .line 203
    .end local v0    # "$this$filter$iv":Ljava/lang/Iterable;
    .end local v1    # "$i$f$filter":I
    move-object v0, v3

    .line 204
    .local v0, "parts":Ljava/util/List;
    if-eqz p2, :cond_49

    const-string v1, "VHAL_GET_BOOL"

    goto :goto_4b

    :cond_49
    const-string v1, "VHAL_GET_INT"

    .line 205
    .local v1, "kind":Ljava/lang/String;
    :goto_4b
    invoke-interface {v0}, Ljava/util/List;->size()I

    move-result v3

    const/4 v4, 0x2

    const/16 v5, 0x27

    if-eq v3, v4, :cond_75

    new-instance v3, Lcom/geely/carreceiver/CommandBackend$ExecResult;

    new-instance v4, Ljava/lang/StringBuilder;

    invoke-direct {v4}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v4, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v4

    const-string v6, " needs: <propertyId> <areaId>, got \'"

    invoke-virtual {v4, v6}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v4

    invoke-virtual {v4, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v4

    invoke-virtual {v4, v5}, Ljava/lang/StringBuilder;->append(C)Ljava/lang/StringBuilder;

    move-result-object v4

    invoke-virtual {v4}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v4

    invoke-direct {v3, v2, v4}, Lcom/geely/carreceiver/CommandBackend$ExecResult;-><init>(ZLjava/lang/String;)V

    return-object v3

    .line 206
    :cond_75
    invoke-interface {v0, v2}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v3

    check-cast v3, Ljava/lang/String;

    invoke-direct {p0, v3}, Lcom/geely/carreceiver/CommandBackend;->parseFlexInt(Ljava/lang/String;)Ljava/lang/Integer;

    move-result-object v3

    if-eqz v3, :cond_103

    invoke-virtual {v3}, Ljava/lang/Integer;->intValue()I

    move-result v3

    .line 207
    .local v3, "prop":I
    invoke-interface {v0, v8}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v6

    check-cast v6, Ljava/lang/String;

    invoke-direct {p0, v6}, Lcom/geely/carreceiver/CommandBackend;->parseFlexInt(Ljava/lang/String;)Ljava/lang/Integer;

    move-result-object v6

    if-eqz v6, :cond_e0

    invoke-virtual {v6}, Ljava/lang/Integer;->intValue()I

    move-result v5

    .line 208
    .local v5, "area":I
    sget-object v6, Lcom/geely/carreceiver/VhalAccess;->INSTANCE:Lcom/geely/carreceiver/VhalAccess;

    iget-object v7, p0, Lcom/geely/carreceiver/CommandBackend;->context:Landroid/content/Context;

    invoke-virtual {v7}, Landroid/content/Context;->getApplicationContext()Landroid/content/Context;

    move-result-object v7

    const-string v8, "getApplicationContext(...)"

    invoke-static {v7, v8}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    invoke-virtual {v6, v7}, Lcom/geely/carreceiver/VhalAccess;->manager(Landroid/content/Context;)Ljava/lang/Object;

    move-result-object v6

    if-nez v6, :cond_cb

    .line 209
    new-instance v4, Lcom/geely/carreceiver/CommandBackend$ExecResult;

    new-instance v6, Ljava/lang/StringBuilder;

    invoke-direct {v6}, Ljava/lang/StringBuilder;-><init>()V

    const-string v7, "VHAL unavailable: "

    invoke-virtual {v6, v7}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v6

    sget-object v7, Lcom/geely/carreceiver/VhalAccess;->INSTANCE:Lcom/geely/carreceiver/VhalAccess;

    invoke-virtual {v7}, Lcom/geely/carreceiver/VhalAccess;->lastError()Ljava/lang/String;

    move-result-object v7

    if-nez v7, :cond_bf

    const-string v7, "android.car.Car not found"

    :cond_bf
    invoke-virtual {v6, v7}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v6

    invoke-virtual {v6}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v6

    invoke-direct {v4, v2, v6}, Lcom/geely/carreceiver/CommandBackend$ExecResult;-><init>(ZLjava/lang/String;)V

    return-object v4

    .line 210
    .local v6, "mgr":Ljava/lang/Object;
    :cond_cb
    sget-object v7, Lcom/geely/carreceiver/VhalAccess;->INSTANCE:Lcom/geely/carreceiver/VhalAccess;

    invoke-virtual {v7, v6, v3, v5}, Lcom/geely/carreceiver/VhalAccess;->describeValue(Ljava/lang/Object;II)Ljava/lang/String;

    move-result-object v7

    .line 211
    .local v7, "value":Ljava/lang/String;
    const-string v8, "unreadable"

    const/4 v9, 0x0

    invoke-static {v7, v8, v2, v4, v9}, Lkotlin/text/StringsKt;->startsWith$default(Ljava/lang/String;Ljava/lang/String;ZILjava/lang/Object;)Z

    move-result v2

    .line 212
    .local v2, "failed":Z
    new-instance v4, Lcom/geely/carreceiver/CommandBackend$ExecResult;

    xor-int/lit8 v8, v2, 0x1

    invoke-direct {v4, v8, v7}, Lcom/geely/carreceiver/CommandBackend$ExecResult;-><init>(ZLjava/lang/String;)V

    return-object v4

    .line 207
    .end local v2    # "failed":Z
    .end local v5    # "area":I
    .end local v6    # "mgr":Ljava/lang/Object;
    .end local v7    # "value":Ljava/lang/String;
    :cond_e0
    new-instance v4, Lcom/geely/carreceiver/CommandBackend$ExecResult;

    new-instance v6, Ljava/lang/StringBuilder;

    invoke-direct {v6}, Ljava/lang/StringBuilder;-><init>()V

    const-string v7, "bad areaId \'"

    invoke-virtual {v6, v7}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v6

    invoke-interface {v0, v8}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v7

    check-cast v7, Ljava/lang/String;

    invoke-virtual {v6, v7}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v6

    invoke-virtual {v6, v5}, Ljava/lang/StringBuilder;->append(C)Ljava/lang/StringBuilder;

    move-result-object v5

    invoke-virtual {v5}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v5

    invoke-direct {v4, v2, v5}, Lcom/geely/carreceiver/CommandBackend$ExecResult;-><init>(ZLjava/lang/String;)V

    return-object v4

    .line 206
    .end local v3    # "prop":I
    :cond_103
    new-instance v3, Lcom/geely/carreceiver/CommandBackend$ExecResult;

    new-instance v4, Ljava/lang/StringBuilder;

    invoke-direct {v4}, Ljava/lang/StringBuilder;-><init>()V

    const-string v6, "bad propertyId \'"

    invoke-virtual {v4, v6}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v4

    invoke-interface {v0, v2}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v6

    check-cast v6, Ljava/lang/String;

    invoke-virtual {v4, v6}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v4

    invoke-virtual {v4, v5}, Ljava/lang/StringBuilder;->append(C)Ljava/lang/StringBuilder;

    move-result-object v4

    invoke-virtual {v4}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v4

    invoke-direct {v3, v2, v4}, Lcom/geely/carreceiver/CommandBackend$ExecResult;-><init>(ZLjava/lang/String;)V

    return-object v3
.end method

.method private final execVhalSet(Ljava/lang/String;Z)Lcom/geely/carreceiver/CommandBackend$ExecResult;
    .registers 23
    .param p1, "spec"    # Ljava/lang/String;
    .param p2, "isBool"    # Z

    .line 165
    move-object/from16 v0, p0

    move-object/from16 v1, p1

    move-object v2, v1

    check-cast v2, Ljava/lang/CharSequence;

    new-instance v3, Lkotlin/text/Regex;

    const-string v4, "\\s+"

    invoke-direct {v3, v4}, Lkotlin/text/Regex;-><init>(Ljava/lang/String;)V

    const/4 v4, 0x0

    invoke-virtual {v3, v2, v4}, Lkotlin/text/Regex;->split(Ljava/lang/CharSequence;I)Ljava/util/List;

    move-result-object v2

    check-cast v2, Ljava/lang/Iterable;

    .local v2, "$this$filter$iv":Ljava/lang/Iterable;
    const/4 v3, 0x0

    .line 434
    .local v3, "$i$f$filter":I
    new-instance v5, Ljava/util/ArrayList;

    invoke-direct {v5}, Ljava/util/ArrayList;-><init>()V

    check-cast v5, Ljava/util/Collection;

    .local v5, "destination$iv$iv":Ljava/util/Collection;
    move-object v6, v2

    .local v6, "$this$filterTo$iv$iv":Ljava/lang/Iterable;
    const/4 v7, 0x0

    .line 435
    .local v7, "$i$f$filterTo":I
    invoke-interface {v6}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    move-result-object v8

    :cond_23
    :goto_23
    invoke-interface {v8}, Ljava/util/Iterator;->hasNext()Z

    move-result v9

    const/4 v10, 0x1

    if-eqz v9, :cond_43

    invoke-interface {v8}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v9

    .local v9, "element$iv$iv":Ljava/lang/Object;
    move-object v11, v9

    check-cast v11, Ljava/lang/String;

    .local v11, "it":Ljava/lang/String;
    const/4 v12, 0x0

    .line 165
    .local v12, "$i$a$-filter-CommandBackend$execVhalSet$parts$1":I
    move-object v13, v11

    check-cast v13, Ljava/lang/CharSequence;

    invoke-interface {v13}, Ljava/lang/CharSequence;->length()I

    move-result v13

    if-lez v13, :cond_3c

    goto :goto_3d

    :cond_3c
    move v10, v4

    .line 435
    .end local v11    # "it":Ljava/lang/String;
    .end local v12    # "$i$a$-filter-CommandBackend$execVhalSet$parts$1":I
    :goto_3d
    if-eqz v10, :cond_23

    invoke-interface {v5, v9}, Ljava/util/Collection;->add(Ljava/lang/Object;)Z

    goto :goto_23

    .line 436
    .end local v9    # "element$iv$iv":Ljava/lang/Object;
    :cond_43
    nop

    .end local v5    # "destination$iv$iv":Ljava/util/Collection;
    .end local v6    # "$this$filterTo$iv$iv":Ljava/lang/Iterable;
    .end local v7    # "$i$f$filterTo":I
    check-cast v5, Ljava/util/List;

    .line 434
    nop

    .line 165
    .end local v2    # "$this$filter$iv":Ljava/lang/Iterable;
    .end local v3    # "$i$f$filter":I
    move-object v2, v5

    .line 166
    .local v2, "parts":Ljava/util/List;
    if-eqz p2, :cond_4d

    const-string v3, "VHAL_BOOL"

    goto :goto_4f

    :cond_4d
    const-string v3, "VHAL_INT"

    .line 167
    .local v3, "kind":Ljava/lang/String;
    :goto_4f
    invoke-interface {v2}, Ljava/util/List;->size()I

    move-result v5

    const/4 v6, 0x3

    const/16 v7, 0x27

    if-eq v5, v6, :cond_79

    new-instance v5, Lcom/geely/carreceiver/CommandBackend$ExecResult;

    new-instance v6, Ljava/lang/StringBuilder;

    invoke-direct {v6}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v6, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v6

    const-string v8, " needs: <propertyId> <areaId[,areaId..]> <value>, got \'"

    invoke-virtual {v6, v8}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v6

    invoke-virtual {v6, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v6

    invoke-virtual {v6, v7}, Ljava/lang/StringBuilder;->append(C)Ljava/lang/StringBuilder;

    move-result-object v6

    invoke-virtual {v6}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v6

    invoke-direct {v5, v4, v6}, Lcom/geely/carreceiver/CommandBackend$ExecResult;-><init>(ZLjava/lang/String;)V

    return-object v5

    .line 168
    :cond_79
    invoke-interface {v2, v4}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v5

    check-cast v5, Ljava/lang/String;

    invoke-direct {v0, v5}, Lcom/geely/carreceiver/CommandBackend;->parseFlexInt(Ljava/lang/String;)Ljava/lang/Integer;

    move-result-object v5

    if-eqz v5, :cond_2e7

    invoke-virtual {v5}, Ljava/lang/Integer;->intValue()I

    move-result v5

    .line 169
    .local v5, "prop":I
    invoke-interface {v2, v10}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v6

    move-object v11, v6

    check-cast v11, Ljava/lang/CharSequence;

    const-string v6, ","

    filled-new-array {v6}, [Ljava/lang/String;

    move-result-object v12

    const/4 v13, 0x0

    const/4 v14, 0x0

    const/4 v15, 0x6

    const/16 v16, 0x0

    invoke-static/range {v11 .. v16}, Lkotlin/text/StringsKt;->split$default(Ljava/lang/CharSequence;[Ljava/lang/String;ZIILjava/lang/Object;)Ljava/util/List;

    move-result-object v6

    check-cast v6, Ljava/lang/Iterable;

    .local v6, "$this$map$iv":Ljava/lang/Iterable;
    const/4 v8, 0x0

    .line 437
    .local v8, "$i$f$map":I
    new-instance v9, Ljava/util/ArrayList;

    const/16 v11, 0xa

    invoke-static {v6, v11}, Lkotlin/collections/CollectionsKt;->collectionSizeOrDefault(Ljava/lang/Iterable;I)I

    move-result v12

    invoke-direct {v9, v12}, Ljava/util/ArrayList;-><init>(I)V

    check-cast v9, Ljava/util/Collection;

    .local v9, "destination$iv$iv":Ljava/util/Collection;
    move-object v12, v6

    .local v12, "$this$mapTo$iv$iv":Ljava/lang/Iterable;
    const/4 v13, 0x0

    .line 438
    .local v13, "$i$f$mapTo":I
    invoke-interface {v12}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    move-result-object v14

    :goto_b5
    invoke-interface {v14}, Ljava/util/Iterator;->hasNext()Z

    move-result v15

    if-eqz v15, :cond_d6

    invoke-interface {v14}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v15

    .line 439
    .local v15, "item$iv$iv":Ljava/lang/Object;
    move-object/from16 v16, v15

    check-cast v16, Ljava/lang/String;

    .local v16, "it":Ljava/lang/String;
    const/16 v17, 0x0

    .line 169
    .local v17, "$i$a$-map-CommandBackend$execVhalSet$areas$1":I
    move-object/from16 v18, v16

    check-cast v18, Ljava/lang/CharSequence;

    invoke-static/range {v18 .. v18}, Lkotlin/text/StringsKt;->trim(Ljava/lang/CharSequence;)Ljava/lang/CharSequence;

    move-result-object v18

    invoke-virtual/range {v18 .. v18}, Ljava/lang/Object;->toString()Ljava/lang/String;

    move-result-object v10

    .line 439
    .end local v16    # "it":Ljava/lang/String;
    .end local v17    # "$i$a$-map-CommandBackend$execVhalSet$areas$1":I
    invoke-interface {v9, v10}, Ljava/util/Collection;->add(Ljava/lang/Object;)Z

    const/4 v10, 0x1

    goto :goto_b5

    .line 440
    .end local v15    # "item$iv$iv":Ljava/lang/Object;
    :cond_d6
    nop

    .end local v9    # "destination$iv$iv":Ljava/util/Collection;
    .end local v12    # "$this$mapTo$iv$iv":Ljava/lang/Iterable;
    .end local v13    # "$i$f$mapTo":I
    check-cast v9, Ljava/util/List;

    .line 437
    nop

    .end local v6    # "$this$map$iv":Ljava/lang/Iterable;
    .end local v8    # "$i$f$map":I
    check-cast v9, Ljava/lang/Iterable;

    .line 169
    move-object v6, v9

    .local v6, "$this$filter$iv":Ljava/lang/Iterable;
    const/4 v8, 0x0

    .line 441
    .local v8, "$i$f$filter":I
    new-instance v9, Ljava/util/ArrayList;

    invoke-direct {v9}, Ljava/util/ArrayList;-><init>()V

    check-cast v9, Ljava/util/Collection;

    .restart local v9    # "destination$iv$iv":Ljava/util/Collection;
    move-object v10, v6

    .local v10, "$this$filterTo$iv$iv":Ljava/lang/Iterable;
    const/4 v12, 0x0

    .line 442
    .local v12, "$i$f$filterTo":I
    invoke-interface {v10}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    move-result-object v13

    :cond_eb
    :goto_eb
    invoke-interface {v13}, Ljava/util/Iterator;->hasNext()Z

    move-result v14

    if-eqz v14, :cond_10f

    invoke-interface {v13}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v14

    .local v14, "element$iv$iv":Ljava/lang/Object;
    move-object v15, v14

    check-cast v15, Ljava/lang/String;

    .local v15, "it":Ljava/lang/String;
    const/16 v16, 0x0

    .line 169
    .local v16, "$i$a$-filter-CommandBackend$execVhalSet$areas$2":I
    move-object/from16 v17, v15

    check-cast v17, Ljava/lang/CharSequence;

    invoke-interface/range {v17 .. v17}, Ljava/lang/CharSequence;->length()I

    move-result v17

    if-lez v17, :cond_107

    const/16 v17, 0x1

    goto :goto_109

    :cond_107
    move/from16 v17, v4

    .line 442
    .end local v15    # "it":Ljava/lang/String;
    .end local v16    # "$i$a$-filter-CommandBackend$execVhalSet$areas$2":I
    :goto_109
    if-eqz v17, :cond_eb

    invoke-interface {v9, v14}, Ljava/util/Collection;->add(Ljava/lang/Object;)Z

    goto :goto_eb

    .line 443
    .end local v14    # "element$iv$iv":Ljava/lang/Object;
    :cond_10f
    nop

    .end local v9    # "destination$iv$iv":Ljava/util/Collection;
    .end local v10    # "$this$filterTo$iv$iv":Ljava/lang/Iterable;
    .end local v12    # "$i$f$filterTo":I
    check-cast v9, Ljava/util/List;

    .line 441
    nop

    .end local v6    # "$this$filter$iv":Ljava/lang/Iterable;
    .end local v8    # "$i$f$filter":I
    check-cast v9, Ljava/lang/Iterable;

    .line 169
    move-object v6, v9

    .local v6, "$this$map$iv":Ljava/lang/Iterable;
    const/4 v8, 0x0

    .line 444
    .local v8, "$i$f$map":I
    new-instance v9, Ljava/util/ArrayList;

    invoke-static {v6, v11}, Lkotlin/collections/CollectionsKt;->collectionSizeOrDefault(Ljava/lang/Iterable;I)I

    move-result v10

    invoke-direct {v9, v10}, Ljava/util/ArrayList;-><init>(I)V

    check-cast v9, Ljava/util/Collection;

    .restart local v9    # "destination$iv$iv":Ljava/util/Collection;
    move-object v10, v6

    .local v10, "$this$mapTo$iv$iv":Ljava/lang/Iterable;
    const/4 v11, 0x0

    .line 445
    .local v11, "$i$f$mapTo":I
    invoke-interface {v10}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    move-result-object v12

    :goto_128
    invoke-interface {v12}, Ljava/util/Iterator;->hasNext()Z

    move-result v13

    if-eqz v13, :cond_13e

    invoke-interface {v12}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v13

    .line 446
    .local v13, "item$iv$iv":Ljava/lang/Object;
    move-object v14, v13

    check-cast v14, Ljava/lang/String;

    .local v14, "it":Ljava/lang/String;
    const/4 v15, 0x0

    .line 169
    .local v15, "$i$a$-map-CommandBackend$execVhalSet$areas$3":I
    invoke-direct {v0, v14}, Lcom/geely/carreceiver/CommandBackend;->parseFlexInt(Ljava/lang/String;)Ljava/lang/Integer;

    move-result-object v14

    .line 446
    .end local v14    # "it":Ljava/lang/String;
    .end local v15    # "$i$a$-map-CommandBackend$execVhalSet$areas$3":I
    invoke-interface {v9, v14}, Ljava/util/Collection;->add(Ljava/lang/Object;)Z

    goto :goto_128

    .line 447
    .end local v13    # "item$iv$iv":Ljava/lang/Object;
    :cond_13e
    nop

    .end local v9    # "destination$iv$iv":Ljava/util/Collection;
    .end local v10    # "$this$mapTo$iv$iv":Ljava/lang/Iterable;
    .end local v11    # "$i$f$mapTo":I
    check-cast v9, Ljava/util/List;

    .line 444
    nop

    .line 169
    .end local v6    # "$this$map$iv":Ljava/lang/Iterable;
    .end local v8    # "$i$f$map":I
    move-object v6, v9

    .line 170
    .local v6, "areas":Ljava/util/List;
    invoke-interface {v6}, Ljava/util/List;->isEmpty()Z

    move-result v8

    if-nez v8, :cond_2c2

    move-object v8, v6

    check-cast v8, Ljava/lang/Iterable;

    .local v8, "$this$any$iv":Ljava/lang/Iterable;
    const/4 v9, 0x0

    .line 448
    .local v9, "$i$f$any":I
    instance-of v10, v8, Ljava/util/Collection;

    if-eqz v10, :cond_15c

    move-object v10, v8

    check-cast v10, Ljava/util/Collection;

    invoke-interface {v10}, Ljava/util/Collection;->isEmpty()Z

    move-result v10

    if-eqz v10, :cond_15c

    move v8, v4

    goto :goto_178

    .line 449
    :cond_15c
    invoke-interface {v8}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    move-result-object v10

    :cond_160
    invoke-interface {v10}, Ljava/util/Iterator;->hasNext()Z

    move-result v11

    if-eqz v11, :cond_177

    invoke-interface {v10}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v11

    .local v11, "element$iv":Ljava/lang/Object;
    move-object v12, v11

    check-cast v12, Ljava/lang/Integer;

    .local v12, "it":Ljava/lang/Integer;
    const/4 v13, 0x0

    .line 170
    .local v13, "$i$a$-any-CommandBackend$execVhalSet$1":I
    if-nez v12, :cond_172

    const/4 v12, 0x1

    goto :goto_173

    :cond_172
    move v12, v4

    .line 449
    .end local v12    # "it":Ljava/lang/Integer;
    .end local v13    # "$i$a$-any-CommandBackend$execVhalSet$1":I
    :goto_173
    if-eqz v12, :cond_160

    const/4 v8, 0x1

    goto :goto_178

    .line 450
    .end local v11    # "element$iv":Ljava/lang/Object;
    :cond_177
    move v8, v4

    .line 170
    .end local v8    # "$this$any$iv":Ljava/lang/Iterable;
    .end local v9    # "$i$f$any":I
    :goto_178
    if-eqz v8, :cond_17c

    goto/16 :goto_2c2

    .line 174
    :cond_17c
    const/4 v8, 0x0

    .line 175
    .local v8, "boolValue":Z
    const/4 v9, 0x0

    .line 176
    .local v9, "intValue":I
    const/4 v10, 0x2

    if-eqz p2, :cond_1e9

    .line 177
    invoke-interface {v2, v10}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v7

    check-cast v7, Ljava/lang/String;

    sget-object v11, Ljava/util/Locale;->ROOT:Ljava/util/Locale;

    invoke-virtual {v7, v11}, Ljava/lang/String;->toLowerCase(Ljava/util/Locale;)Ljava/lang/String;

    move-result-object v7

    const-string v11, "toLowerCase(...)"

    invoke-static {v7, v11}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    invoke-virtual {v7}, Ljava/lang/String;->hashCode()I

    move-result v11

    sparse-switch v11, :sswitch_data_30c

    :goto_199
    goto :goto_1c4

    :sswitch_19a
    const-string v11, "false"

    invoke-virtual {v7, v11}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v7

    if-nez v7, :cond_1c0

    goto :goto_199

    :sswitch_1a3
    const-string v11, "true"

    invoke-virtual {v7, v11}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v7

    if-nez v7, :cond_1b5

    goto :goto_199

    :sswitch_1ac
    const-string v11, "1"

    invoke-virtual {v7, v11}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v7

    if-nez v7, :cond_1b5

    goto :goto_199

    .line 178
    :cond_1b5
    const/4 v7, 0x1

    goto :goto_1c1

    .line 177
    :sswitch_1b7
    const-string v11, "0"

    invoke-virtual {v7, v11}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v7

    if-nez v7, :cond_1c0

    goto :goto_199

    .line 179
    :cond_1c0
    move v7, v4

    .line 177
    :goto_1c1
    nop

    .line 182
    .end local v8    # "boolValue":Z
    .local v7, "boolValue":Z
    const/4 v8, 0x0

    .end local v9    # "intValue":I
    .local v8, "intValue":I
    goto :goto_1ff

    .line 180
    .end local v7    # "boolValue":Z
    .local v8, "boolValue":Z
    .restart local v9    # "intValue":I
    :goto_1c4
    new-instance v7, Lcom/geely/carreceiver/CommandBackend$ExecResult;

    new-instance v11, Ljava/lang/StringBuilder;

    invoke-direct {v11}, Ljava/lang/StringBuilder;-><init>()V

    const-string v12, "bad boolean value \'"

    invoke-virtual {v11, v12}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v11

    invoke-interface {v2, v10}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v10

    check-cast v10, Ljava/lang/String;

    invoke-virtual {v11, v10}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v10

    const-string v11, "\' (use true/false)"

    invoke-virtual {v10, v11}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v10

    invoke-virtual {v10}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v10

    invoke-direct {v7, v4, v10}, Lcom/geely/carreceiver/CommandBackend$ExecResult;-><init>(ZLjava/lang/String;)V

    return-object v7

    .line 184
    :cond_1e9
    invoke-interface {v2, v10}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v11

    check-cast v11, Ljava/lang/String;

    invoke-direct {v0, v11}, Lcom/geely/carreceiver/CommandBackend;->parseFlexInt(Ljava/lang/String;)Ljava/lang/Integer;

    move-result-object v11

    if-eqz v11, :cond_29d

    invoke-virtual {v11}, Ljava/lang/Integer;->intValue()I

    move-result v7

    .line 185
    .end local v9    # "intValue":I
    .local v7, "intValue":I
    const/4 v8, 0x0

    move/from16 v19, v8

    move v8, v7

    move/from16 v7, v19

    .line 188
    .local v7, "boolValue":Z
    .local v8, "intValue":I
    :goto_1ff
    sget-object v9, Lcom/geely/carreceiver/VhalAccess;->INSTANCE:Lcom/geely/carreceiver/VhalAccess;

    iget-object v11, v0, Lcom/geely/carreceiver/CommandBackend;->context:Landroid/content/Context;

    invoke-virtual {v11}, Landroid/content/Context;->getApplicationContext()Landroid/content/Context;

    move-result-object v11

    const-string v12, "getApplicationContext(...)"

    invoke-static {v11, v12}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    invoke-virtual {v9, v11}, Lcom/geely/carreceiver/VhalAccess;->manager(Landroid/content/Context;)Ljava/lang/Object;

    move-result-object v9

    if-nez v9, :cond_235

    .line 189
    new-instance v9, Lcom/geely/carreceiver/CommandBackend$ExecResult;

    new-instance v10, Ljava/lang/StringBuilder;

    invoke-direct {v10}, Ljava/lang/StringBuilder;-><init>()V

    const-string v11, "VHAL unavailable: "

    invoke-virtual {v10, v11}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v10

    sget-object v11, Lcom/geely/carreceiver/VhalAccess;->INSTANCE:Lcom/geely/carreceiver/VhalAccess;

    invoke-virtual {v11}, Lcom/geely/carreceiver/VhalAccess;->lastError()Ljava/lang/String;

    move-result-object v11

    if-nez v11, :cond_229

    const-string v11, "android.car.Car not found"

    :cond_229
    invoke-virtual {v10, v11}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v10

    invoke-virtual {v10}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v10

    invoke-direct {v9, v4, v10}, Lcom/geely/carreceiver/CommandBackend$ExecResult;-><init>(ZLjava/lang/String;)V

    return-object v9

    .line 190
    .local v9, "mgr":Ljava/lang/Object;
    :cond_235
    new-instance v11, Ljava/lang/StringBuilder;

    invoke-direct {v11}, Ljava/lang/StringBuilder;-><init>()V

    .line 191
    .local v11, "sb":Ljava/lang/StringBuilder;
    const/4 v12, 0x1

    .line 192
    .local v12, "allOk":Z
    invoke-interface {v6}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    move-result-object v13

    :goto_23f
    invoke-interface {v13}, Ljava/util/Iterator;->hasNext()Z

    move-result v14

    if-eqz v14, :cond_284

    invoke-interface {v13}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v14

    check-cast v14, Ljava/lang/Integer;

    .line 193
    .local v14, "area":Ljava/lang/Integer;
    if-eqz p2, :cond_25b

    sget-object v15, Lcom/geely/carreceiver/VhalAccess;->INSTANCE:Lcom/geely/carreceiver/VhalAccess;

    invoke-static {v14}, Lkotlin/jvm/internal/Intrinsics;->checkNotNull(Ljava/lang/Object;)V

    invoke-virtual {v14}, Ljava/lang/Integer;->intValue()I

    move-result v4

    invoke-virtual {v15, v9, v5, v4, v7}, Lcom/geely/carreceiver/VhalAccess;->setBool(Ljava/lang/Object;IIZ)Lcom/geely/carreceiver/VhalAccess$SetOutcome;

    move-result-object v4

    goto :goto_268

    :cond_25b
    sget-object v4, Lcom/geely/carreceiver/VhalAccess;->INSTANCE:Lcom/geely/carreceiver/VhalAccess;

    invoke-static {v14}, Lkotlin/jvm/internal/Intrinsics;->checkNotNull(Ljava/lang/Object;)V

    invoke-virtual {v14}, Ljava/lang/Integer;->intValue()I

    move-result v15

    invoke-virtual {v4, v9, v5, v15, v8}, Lcom/geely/carreceiver/VhalAccess;->setInt(Ljava/lang/Object;III)Lcom/geely/carreceiver/VhalAccess$SetOutcome;

    move-result-object v4

    .line 194
    .local v4, "r":Lcom/geely/carreceiver/VhalAccess$SetOutcome;
    :goto_268
    if-eqz v12, :cond_272

    invoke-virtual {v4}, Lcom/geely/carreceiver/VhalAccess$SetOutcome;->getOk()Z

    move-result v15

    if-eqz v15, :cond_272

    const/4 v15, 0x1

    goto :goto_273

    :cond_272
    const/4 v15, 0x0

    :goto_273
    move v12, v15

    .line 195
    invoke-virtual {v4}, Lcom/geely/carreceiver/VhalAccess$SetOutcome;->getMessage()Ljava/lang/String;

    move-result-object v15

    invoke-virtual {v11, v15}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v15

    const-string v10, "; "

    invoke-virtual {v15, v10}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v4, 0x0

    const/4 v10, 0x2

    goto :goto_23f

    .line 197
    .end local v4    # "r":Lcom/geely/carreceiver/VhalAccess$SetOutcome;
    .end local v14    # "area":Ljava/lang/Integer;
    :cond_284
    new-instance v4, Lcom/geely/carreceiver/CommandBackend$ExecResult;

    invoke-virtual {v11}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v10

    const-string v13, "toString(...)"

    invoke-static {v10, v13}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    const/4 v13, 0x2

    new-array v13, v13, [C

    fill-array-data v13, :array_31e

    invoke-static {v10, v13}, Lkotlin/text/StringsKt;->trimEnd(Ljava/lang/String;[C)Ljava/lang/String;

    move-result-object v10

    invoke-direct {v4, v12, v10}, Lcom/geely/carreceiver/CommandBackend$ExecResult;-><init>(ZLjava/lang/String;)V

    return-object v4

    .line 184
    .end local v7    # "boolValue":Z
    .end local v11    # "sb":Ljava/lang/StringBuilder;
    .end local v12    # "allOk":Z
    .local v8, "boolValue":Z
    .local v9, "intValue":I
    :cond_29d
    move v13, v10

    new-instance v4, Lcom/geely/carreceiver/CommandBackend$ExecResult;

    new-instance v10, Ljava/lang/StringBuilder;

    invoke-direct {v10}, Ljava/lang/StringBuilder;-><init>()V

    const-string v11, "bad value \'"

    invoke-virtual {v10, v11}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v10

    invoke-interface {v2, v13}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v11

    check-cast v11, Ljava/lang/String;

    invoke-virtual {v10, v11}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v10

    invoke-virtual {v10, v7}, Ljava/lang/StringBuilder;->append(C)Ljava/lang/StringBuilder;

    move-result-object v7

    invoke-virtual {v7}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v7

    const/4 v10, 0x0

    invoke-direct {v4, v10, v7}, Lcom/geely/carreceiver/CommandBackend$ExecResult;-><init>(ZLjava/lang/String;)V

    return-object v4

    .line 170
    .end local v8    # "boolValue":Z
    .end local v9    # "intValue":I
    :cond_2c2
    :goto_2c2
    new-instance v4, Lcom/geely/carreceiver/CommandBackend$ExecResult;

    new-instance v8, Ljava/lang/StringBuilder;

    invoke-direct {v8}, Ljava/lang/StringBuilder;-><init>()V

    const-string v9, "bad areaId \'"

    invoke-virtual {v8, v9}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v8

    const/4 v9, 0x1

    invoke-interface {v2, v9}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v9

    check-cast v9, Ljava/lang/String;

    invoke-virtual {v8, v9}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v8

    invoke-virtual {v8, v7}, Ljava/lang/StringBuilder;->append(C)Ljava/lang/StringBuilder;

    move-result-object v7

    invoke-virtual {v7}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v7

    const/4 v8, 0x0

    invoke-direct {v4, v8, v7}, Lcom/geely/carreceiver/CommandBackend$ExecResult;-><init>(ZLjava/lang/String;)V

    return-object v4

    .line 168
    .end local v5    # "prop":I
    .end local v6    # "areas":Ljava/util/List;
    :cond_2e7
    move v8, v4

    new-instance v4, Lcom/geely/carreceiver/CommandBackend$ExecResult;

    new-instance v5, Ljava/lang/StringBuilder;

    invoke-direct {v5}, Ljava/lang/StringBuilder;-><init>()V

    const-string v6, "bad propertyId \'"

    invoke-virtual {v5, v6}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v5

    invoke-interface {v2, v8}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v6

    check-cast v6, Ljava/lang/String;

    invoke-virtual {v5, v6}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v5

    invoke-virtual {v5, v7}, Ljava/lang/StringBuilder;->append(C)Ljava/lang/StringBuilder;

    move-result-object v5

    invoke-virtual {v5}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v5

    invoke-direct {v4, v8, v5}, Lcom/geely/carreceiver/CommandBackend$ExecResult;-><init>(ZLjava/lang/String;)V

    return-object v4

    nop

    :sswitch_data_30c
    .sparse-switch
        0x30 -> :sswitch_1b7
        0x31 -> :sswitch_1ac
        0x36758e -> :sswitch_1a3
        0x5cb1923 -> :sswitch_19a
    .end sparse-switch

    :array_31e
    .array-data 2
        0x20s
        0x3bs
    .end array-data
.end method

.method private final findSu()Ljava/lang/String;
    .registers 8

    .line 252
    iget-object v0, p0, Lcom/geely/carreceiver/CommandBackend;->suPaths:Ljava/util/List;

    check-cast v0, Ljava/lang/Iterable;

    .local v0, "$this$firstOrNull$iv":Ljava/lang/Iterable;
    const/4 v1, 0x0

    .line 454
    .local v1, "$i$f$firstOrNull":I
    invoke-interface {v0}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    move-result-object v2

    :cond_9
    invoke-interface {v2}, Ljava/util/Iterator;->hasNext()Z

    move-result v3

    if-eqz v3, :cond_23

    invoke-interface {v2}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v3

    .local v3, "element$iv":Ljava/lang/Object;
    move-object v4, v3

    check-cast v4, Ljava/lang/String;

    .local v4, "it":Ljava/lang/String;
    const/4 v5, 0x0

    .line 252
    .local v5, "$i$a$-firstOrNull-CommandBackend$findSu$1":I
    new-instance v6, Ljava/io/File;

    invoke-direct {v6, v4}, Ljava/io/File;-><init>(Ljava/lang/String;)V

    invoke-virtual {v6}, Ljava/io/File;->exists()Z

    move-result v4

    .line 454
    .end local v4    # "it":Ljava/lang/String;
    .end local v5    # "$i$a$-firstOrNull-CommandBackend$findSu$1":I
    if-eqz v4, :cond_9

    goto :goto_24

    .line 455
    .end local v3    # "element$iv":Ljava/lang/Object;
    :cond_23
    const/4 v3, 0x0

    .end local v0    # "$this$firstOrNull$iv":Ljava/lang/Iterable;
    .end local v1    # "$i$f$firstOrNull":I
    :goto_24
    check-cast v3, Ljava/lang/String;

    .line 252
    return-object v3
.end method

.method private final getFile()Ljava/io/File;
    .registers 4

    .line 53
    new-instance v0, Ljava/io/File;

    iget-object v1, p0, Lcom/geely/carreceiver/CommandBackend;->context:Landroid/content/Context;

    invoke-virtual {v1}, Landroid/content/Context;->getFilesDir()Ljava/io/File;

    move-result-object v1

    const-string v2, "car_commands.txt"

    invoke-direct {v0, v1, v2}, Ljava/io/File;-><init>(Ljava/io/File;Ljava/lang/String;)V

    return-object v0
.end method

.method private final parse(Ljava/lang/String;)Lcom/geely/carreceiver/CommandBackend$Config;
    .registers 15
    .param p1, "text"    # Ljava/lang/String;

    .line 255
    new-instance v0, Ljava/util/HashMap;

    invoke-direct {v0}, Ljava/util/HashMap;-><init>()V

    .line 256
    .local v0, "options":Ljava/util/HashMap;
    new-instance v1, Ljava/util/HashMap;

    invoke-direct {v1}, Ljava/util/HashMap;-><init>()V

    .line 257
    .local v1, "commands":Ljava/util/HashMap;
    move-object v2, p1

    check-cast v2, Ljava/lang/CharSequence;

    invoke-static {v2}, Lkotlin/text/StringsKt;->lineSequence(Ljava/lang/CharSequence;)Lkotlin/sequences/Sequence;

    move-result-object v2

    invoke-interface {v2}, Lkotlin/sequences/Sequence;->iterator()Ljava/util/Iterator;

    move-result-object v2

    :cond_15
    :goto_15
    invoke-interface {v2}, Ljava/util/Iterator;->hasNext()Z

    move-result v3

    if-eqz v3, :cond_9d

    invoke-interface {v2}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v3

    check-cast v3, Ljava/lang/String;

    .line 258
    .local v3, "raw":Ljava/lang/String;
    move-object v4, v3

    check-cast v4, Ljava/lang/CharSequence;

    invoke-static {v4}, Lkotlin/text/StringsKt;->trim(Ljava/lang/CharSequence;)Ljava/lang/CharSequence;

    move-result-object v4

    invoke-virtual {v4}, Ljava/lang/Object;->toString()Ljava/lang/String;

    move-result-object v4

    .line 259
    .local v4, "line":Ljava/lang/String;
    move-object v5, v4

    check-cast v5, Ljava/lang/CharSequence;

    invoke-interface {v5}, Ljava/lang/CharSequence;->length()I

    move-result v5

    const/4 v6, 0x0

    if-nez v5, :cond_38

    const/4 v5, 0x1

    goto :goto_39

    :cond_38
    move v5, v6

    :goto_39
    if-nez v5, :cond_15

    const/4 v5, 0x2

    const/4 v7, 0x0

    const-string v8, "#"

    invoke-static {v4, v8, v6, v5, v7}, Lkotlin/text/StringsKt;->startsWith$default(Ljava/lang/String;Ljava/lang/String;ZILjava/lang/Object;)Z

    move-result v5

    if-eqz v5, :cond_46

    goto :goto_15

    .line 260
    :cond_46
    move-object v7, v4

    check-cast v7, Ljava/lang/CharSequence;

    const/16 v8, 0x3d

    const/4 v9, 0x0

    const/4 v10, 0x0

    const/4 v11, 0x6

    const/4 v12, 0x0

    invoke-static/range {v7 .. v12}, Lkotlin/text/StringsKt;->indexOf$default(Ljava/lang/CharSequence;CIZILjava/lang/Object;)I

    move-result v5

    .line 261
    .local v5, "eq":I
    if-lez v5, :cond_15

    .line 262
    invoke-virtual {v4, v6, v5}, Ljava/lang/String;->substring(II)Ljava/lang/String;

    move-result-object v6

    const-string v7, "substring(...)"

    invoke-static {v6, v7}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    check-cast v6, Ljava/lang/CharSequence;

    invoke-static {v6}, Lkotlin/text/StringsKt;->trim(Ljava/lang/CharSequence;)Ljava/lang/CharSequence;

    move-result-object v6

    invoke-virtual {v6}, Ljava/lang/Object;->toString()Ljava/lang/String;

    move-result-object v6

    .line 263
    .local v6, "key":Ljava/lang/String;
    add-int/lit8 v8, v5, 0x1

    invoke-virtual {v4, v8}, Ljava/lang/String;->substring(I)Ljava/lang/String;

    move-result-object v8

    invoke-static {v8, v7}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    check-cast v8, Ljava/lang/CharSequence;

    invoke-static {v8}, Lkotlin/text/StringsKt;->trim(Ljava/lang/CharSequence;)Ljava/lang/CharSequence;

    move-result-object v7

    invoke-virtual {v7}, Ljava/lang/Object;->toString()Ljava/lang/String;

    move-result-object v7

    .line 264
    .local v7, "value":Ljava/lang/String;
    sget-object v8, Lcom/geely/carreceiver/CommandBackend;->KNOWN:Ljava/util/Set;

    invoke-interface {v8, v6}, Ljava/util/Set;->contains(Ljava/lang/Object;)Z

    move-result v8

    if-eqz v8, :cond_8a

    move-object v8, v1

    check-cast v8, Ljava/util/Map;

    invoke-interface {v8, v6, v7}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    goto :goto_15

    :cond_8a
    move-object v8, v0

    check-cast v8, Ljava/util/Map;

    sget-object v9, Ljava/util/Locale;->ROOT:Ljava/util/Locale;

    invoke-virtual {v6, v9}, Ljava/lang/String;->toLowerCase(Ljava/util/Locale;)Ljava/lang/String;

    move-result-object v9

    const-string v10, "toLowerCase(...)"

    invoke-static {v9, v10}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    invoke-interface {v8, v9, v7}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    goto/16 :goto_15

    .line 266
    .end local v3    # "raw":Ljava/lang/String;
    .end local v4    # "line":Ljava/lang/String;
    .end local v5    # "eq":I
    .end local v6    # "key":Ljava/lang/String;
    .end local v7    # "value":Ljava/lang/String;
    :cond_9d
    new-instance v2, Lcom/geely/carreceiver/CommandBackend$Config;

    move-object v3, v0

    check-cast v3, Ljava/util/Map;

    move-object v4, v1

    check-cast v4, Ljava/util/Map;

    invoke-direct {v2, v3, v4}, Lcom/geely/carreceiver/CommandBackend$Config;-><init>(Ljava/util/Map;Ljava/util/Map;)V

    return-object v2
.end method

.method private final parseFlexInt(Ljava/lang/String;)Ljava/lang/Integer;
    .registers 10
    .param p1, "tok"    # Ljava/lang/String;

    .line 217
    nop

    .line 218
    const/4 v0, 0x0

    :try_start_2
    const-string v1, "-"

    const/4 v2, 0x0

    const/4 v3, 0x2

    invoke-static {p1, v1, v2, v3, v0}, Lkotlin/text/StringsKt;->startsWith$default(Ljava/lang/String;Ljava/lang/String;ZILjava/lang/Object;)Z

    move-result v1
    :try_end_a
    .catch Ljava/lang/Exception; {:try_start_2 .. :try_end_a} :catch_41

    .line 219
    .local v1, "neg":Z
    const-string v2, "substring(...)"

    const/4 v4, 0x1

    if-eqz v1, :cond_17

    :try_start_f
    invoke-virtual {p1, v4}, Ljava/lang/String;->substring(I)Ljava/lang/String;

    move-result-object v5

    invoke-static {v5, v2}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    goto :goto_18

    :cond_17
    move-object v5, p1

    .line 220
    .local v5, "body":Ljava/lang/String;
    :goto_18
    const-string v6, "0x"

    invoke-static {v5, v6, v4}, Lkotlin/text/StringsKt;->startsWith(Ljava/lang/String;Ljava/lang/String;Z)Z

    move-result v4

    if-eqz v4, :cond_32

    invoke-virtual {v5, v3}, Ljava/lang/String;->substring(I)Ljava/lang/String;

    move-result-object v3

    invoke-static {v3, v2}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    const/16 v2, 0x10

    invoke-static {v2}, Lkotlin/text/CharsKt;->checkRadix(I)I

    move-result v2

    invoke-static {v3, v2}, Ljava/lang/Long;->parseLong(Ljava/lang/String;I)J

    move-result-wide v2

    goto :goto_36

    :cond_32
    invoke-static {v5}, Ljava/lang/Long;->parseLong(Ljava/lang/String;)J

    move-result-wide v2

    .line 221
    .local v2, "v":J
    :goto_36
    if-eqz v1, :cond_3a

    neg-long v6, v2

    goto :goto_3b

    :cond_3a
    move-wide v6, v2

    :goto_3b
    long-to-int v1, v6

    .end local v1    # "neg":Z
    .end local v2    # "v":J
    .end local v5    # "body":Ljava/lang/String;
    invoke-static {v1}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v0
    :try_end_40
    .catch Ljava/lang/Exception; {:try_start_f .. :try_end_40} :catch_41

    goto :goto_43

    .line 222
    :catch_41
    move-exception v1

    .line 223
    .local v1, "e":Ljava/lang/Exception;
    nop

    .line 224
    .end local v1    # "e":Ljava/lang/Exception;
    :goto_43
    return-object v0
.end method

.method private final probeSu()Lcom/geely/carreceiver/CommandBackend$SuStatus;
    .registers 11

    .line 238
    invoke-direct {p0}, Lcom/geely/carreceiver/CommandBackend;->findSu()Ljava/lang/String;

    move-result-object v0

    const/4 v1, 0x0

    const/4 v2, 0x0

    if-nez v0, :cond_10

    new-instance v0, Lcom/geely/carreceiver/CommandBackend$SuStatus;

    const-string v3, "no su binary found"

    invoke-direct {v0, v1, v2, v3}, Lcom/geely/carreceiver/CommandBackend$SuStatus;-><init>(Ljava/lang/String;ZLjava/lang/String;)V

    return-object v0

    .line 239
    .local v0, "path":Ljava/lang/String;
    :cond_10
    sget-object v3, Lcom/geely/carreceiver/Shell;->INSTANCE:Lcom/geely/carreceiver/Shell;

    const-string v4, "-c"

    const-string v5, "id"

    filled-new-array {v0, v4, v5}, [Ljava/lang/String;

    move-result-object v4

    const-wide/16 v5, 0x1388

    const/4 v7, 0x0

    const/4 v8, 0x4

    const/4 v9, 0x0

    invoke-static/range {v3 .. v9}, Lcom/geely/carreceiver/Shell;->run$default(Lcom/geely/carreceiver/Shell;[Ljava/lang/String;JIILjava/lang/Object;)Lcom/geely/carreceiver/Shell$Out;

    move-result-object v3

    .line 240
    .local v3, "out":Lcom/geely/carreceiver/Shell$Out;
    invoke-virtual {v3}, Lcom/geely/carreceiver/Shell$Out;->getOk()Z

    move-result v4

    const/4 v5, 0x1

    if-eqz v4, :cond_3d

    invoke-virtual {v3}, Lcom/geely/carreceiver/Shell$Out;->getText()Ljava/lang/String;

    move-result-object v4

    check-cast v4, Ljava/lang/CharSequence;

    const-string v6, "uid=0"

    check-cast v6, Ljava/lang/CharSequence;

    const/4 v7, 0x2

    invoke-static {v4, v6, v2, v7, v1}, Lkotlin/text/StringsKt;->contains$default(Ljava/lang/CharSequence;Ljava/lang/CharSequence;ZILjava/lang/Object;)Z

    move-result v1

    if-eqz v1, :cond_3d

    move v1, v5

    goto :goto_3e

    :cond_3d
    move v1, v2

    .line 241
    .local v1, "works":Z
    :goto_3e
    invoke-virtual {v3}, Lcom/geely/carreceiver/Shell$Out;->getFailure()Ljava/lang/String;

    move-result-object v4

    .line 242
    .local v4, "failure":Ljava/lang/String;
    nop

    .line 243
    if-eqz v1, :cond_48

    const-string v2, "ok"

    goto :goto_8c

    .line 244
    :cond_48
    if-nez v4, :cond_8b

    .line 245
    invoke-virtual {v3}, Lcom/geely/carreceiver/Shell$Out;->getText()Ljava/lang/String;

    move-result-object v6

    check-cast v6, Ljava/lang/CharSequence;

    invoke-interface {v6}, Ljava/lang/CharSequence;->length()I

    move-result v6

    if-lez v6, :cond_57

    move v2, v5

    :cond_57
    if-eqz v2, :cond_73

    invoke-virtual {v3}, Lcom/geely/carreceiver/Shell$Out;->getText()Ljava/lang/String;

    move-result-object v2

    check-cast v2, Ljava/lang/CharSequence;

    new-instance v5, Lkotlin/text/Regex;

    const-string v6, "\\s+"

    invoke-direct {v5, v6}, Lkotlin/text/Regex;-><init>(Ljava/lang/String;)V

    const-string v6, " "

    invoke-virtual {v5, v2, v6}, Lkotlin/text/Regex;->replace(Ljava/lang/CharSequence;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v2

    const/16 v5, 0x78

    invoke-static {v2, v5}, Lkotlin/text/StringsKt;->take(Ljava/lang/String;I)Ljava/lang/String;

    move-result-object v2

    goto :goto_8c

    .line 246
    :cond_73
    new-instance v2, Ljava/lang/StringBuilder;

    invoke-direct {v2}, Ljava/lang/StringBuilder;-><init>()V

    const-string v5, "exit="

    invoke-virtual {v2, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    invoke-virtual {v3}, Lcom/geely/carreceiver/Shell$Out;->getExit()I

    move-result v5

    invoke-virtual {v2, v5}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v2

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v2

    goto :goto_8c

    .line 244
    :cond_8b
    move-object v2, v4

    .line 242
    :goto_8c
    nop

    .line 248
    .local v2, "message":Ljava/lang/String;
    new-instance v5, Lcom/geely/carreceiver/CommandBackend$SuStatus;

    invoke-direct {v5, v0, v1, v2}, Lcom/geely/carreceiver/CommandBackend$SuStatus;-><init>(Ljava/lang/String;ZLjava/lang/String;)V

    return-object v5
.end method

.method private final sendVehicleBroadcast(Ljava/lang/String;)Lcom/geely/carreceiver/CommandBackend$ExecResult;
    .registers 18
    .param p1, "spec"    # Ljava/lang/String;

    .line 143
    move-object/from16 v1, p1

    move-object v0, v1

    check-cast v0, Ljava/lang/CharSequence;

    new-instance v2, Lkotlin/text/Regex;

    const-string v3, "\\s+"

    invoke-direct {v2, v3}, Lkotlin/text/Regex;-><init>(Ljava/lang/String;)V

    const/4 v3, 0x0

    invoke-virtual {v2, v0, v3}, Lkotlin/text/Regex;->split(Ljava/lang/CharSequence;I)Ljava/util/List;

    move-result-object v0

    check-cast v0, Ljava/lang/Iterable;

    .local v0, "$this$filter$iv":Ljava/lang/Iterable;
    const/4 v2, 0x0

    .line 431
    .local v2, "$i$f$filter":I
    new-instance v4, Ljava/util/ArrayList;

    invoke-direct {v4}, Ljava/util/ArrayList;-><init>()V

    check-cast v4, Ljava/util/Collection;

    .local v4, "destination$iv$iv":Ljava/util/Collection;
    move-object v5, v0

    .local v5, "$this$filterTo$iv$iv":Ljava/lang/Iterable;
    const/4 v6, 0x0

    .line 432
    .local v6, "$i$f$filterTo":I
    invoke-interface {v5}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    move-result-object v7

    :cond_21
    :goto_21
    invoke-interface {v7}, Ljava/util/Iterator;->hasNext()Z

    move-result v8

    const/4 v9, 0x1

    if-eqz v8, :cond_41

    invoke-interface {v7}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v8

    .local v8, "element$iv$iv":Ljava/lang/Object;
    move-object v10, v8

    check-cast v10, Ljava/lang/String;

    .local v10, "it":Ljava/lang/String;
    const/4 v11, 0x0

    .line 143
    .local v11, "$i$a$-filter-CommandBackend$sendVehicleBroadcast$parts$1":I
    move-object v12, v10

    check-cast v12, Ljava/lang/CharSequence;

    invoke-interface {v12}, Ljava/lang/CharSequence;->length()I

    move-result v12

    if-lez v12, :cond_3a

    goto :goto_3b

    :cond_3a
    move v9, v3

    .line 432
    .end local v10    # "it":Ljava/lang/String;
    .end local v11    # "$i$a$-filter-CommandBackend$sendVehicleBroadcast$parts$1":I
    :goto_3b
    if-eqz v9, :cond_21

    invoke-interface {v4, v8}, Ljava/util/Collection;->add(Ljava/lang/Object;)Z

    goto :goto_21

    .line 433
    .end local v8    # "element$iv$iv":Ljava/lang/Object;
    :cond_41
    nop

    .end local v4    # "destination$iv$iv":Ljava/util/Collection;
    .end local v5    # "$this$filterTo$iv$iv":Ljava/lang/Iterable;
    .end local v6    # "$i$f$filterTo":I
    check-cast v4, Ljava/util/List;

    .line 431
    nop

    .line 143
    .end local v0    # "$this$filter$iv":Ljava/lang/Iterable;
    .end local v2    # "$i$f$filter":I
    move-object v2, v4

    .line 144
    .local v2, "parts":Ljava/util/List;
    invoke-interface {v2}, Ljava/util/List;->size()I

    move-result v0

    const/4 v4, 0x2

    if-eq v0, v4, :cond_6c

    new-instance v0, Lcom/geely/carreceiver/CommandBackend$ExecResult;

    new-instance v4, Ljava/lang/StringBuilder;

    invoke-direct {v4}, Ljava/lang/StringBuilder;-><init>()V

    const-string v5, "BROADCAST needs exactly: <action> <package>/<Class>, got \'"

    invoke-virtual {v4, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v4

    invoke-virtual {v4, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v4

    const/16 v5, 0x27

    invoke-virtual {v4, v5}, Ljava/lang/StringBuilder;->append(C)Ljava/lang/StringBuilder;

    move-result-object v4

    invoke-virtual {v4}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v4

    invoke-direct {v0, v3, v4}, Lcom/geely/carreceiver/CommandBackend$ExecResult;-><init>(ZLjava/lang/String;)V

    return-object v0

    .line 145
    :cond_6c
    invoke-interface {v2, v3}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v0

    move-object v5, v0

    check-cast v5, Ljava/lang/String;

    .local v5, "action":Ljava/lang/String;
    invoke-interface {v2, v9}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v0

    move-object v6, v0

    check-cast v6, Ljava/lang/String;

    .line 146
    .local v6, "target":Ljava/lang/String;
    move-object v10, v6

    check-cast v10, Ljava/lang/CharSequence;

    const/16 v11, 0x2f

    const/4 v12, 0x0

    const/4 v13, 0x0

    const/4 v14, 0x6

    const/4 v15, 0x0

    invoke-static/range {v10 .. v15}, Lkotlin/text/StringsKt;->indexOf$default(Ljava/lang/CharSequence;CIZILjava/lang/Object;)I

    move-result v7

    .line 147
    .local v7, "slash":I
    if-lez v7, :cond_136

    invoke-virtual {v6}, Ljava/lang/String;->length()I

    move-result v0

    sub-int/2addr v0, v9

    if-ne v7, v0, :cond_94

    move-object/from16 v11, p0

    goto/16 :goto_138

    .line 148
    :cond_94
    invoke-virtual {v6, v3, v7}, Ljava/lang/String;->substring(II)Ljava/lang/String;

    move-result-object v0

    const-string v8, "substring(...)"

    invoke-static {v0, v8}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    move-object v10, v0

    .line 149
    .local v10, "pkg":Ljava/lang/String;
    add-int/lit8 v0, v7, 0x1

    invoke-virtual {v6, v0}, Ljava/lang/String;->substring(I)Ljava/lang/String;

    move-result-object v0

    invoke-static {v0, v8}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    move-object v8, v0

    .line 150
    .local v8, "cls":Ljava/lang/String;
    const-string v0, "."

    const/4 v11, 0x0

    invoke-static {v8, v0, v3, v4, v11}, Lkotlin/text/StringsKt;->startsWith$default(Ljava/lang/String;Ljava/lang/String;ZILjava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_c3

    new-instance v0, Ljava/lang/StringBuilder;

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v0, v10}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    invoke-virtual {v0, v8}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    goto :goto_c4

    :cond_c3
    move-object v0, v8

    :goto_c4
    move-object v4, v0

    .line 151
    .local v4, "className":Ljava/lang/String;
    nop

    .line 152
    move-object/from16 v11, p0

    :try_start_c8
    iget-object v0, v11, Lcom/geely/carreceiver/CommandBackend;->context:Landroid/content/Context;

    invoke-virtual {v0}, Landroid/content/Context;->getApplicationContext()Landroid/content/Context;

    move-result-object v0

    new-instance v12, Landroid/content/Intent;

    invoke-direct {v12, v5}, Landroid/content/Intent;-><init>(Ljava/lang/String;)V

    invoke-virtual {v12, v10, v4}, Landroid/content/Intent;->setClassName(Ljava/lang/String;Ljava/lang/String;)Landroid/content/Intent;

    move-result-object v12

    invoke-virtual {v0, v12}, Landroid/content/Context;->sendBroadcast(Landroid/content/Intent;)V

    .line 153
    new-instance v0, Lcom/geely/carreceiver/CommandBackend$ExecResult;

    new-instance v12, Ljava/lang/StringBuilder;

    invoke-direct {v12}, Ljava/lang/StringBuilder;-><init>()V

    const-string v13, "broadcast \'"

    invoke-virtual {v12, v13}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v12

    invoke-virtual {v12, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v12

    const-string v13, "\' sent to "

    invoke-virtual {v12, v13}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v12

    invoke-virtual {v12, v10}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v12

    const/16 v13, 0x2f

    invoke-virtual {v12, v13}, Ljava/lang/StringBuilder;->append(C)Ljava/lang/StringBuilder;

    move-result-object v12

    invoke-virtual {v12, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v12

    const-string v13, " (fire-and-forget, not confirmed)"

    invoke-virtual {v12, v13}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v12

    invoke-virtual {v12}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v12

    invoke-direct {v0, v9, v12}, Lcom/geely/carreceiver/CommandBackend$ExecResult;-><init>(ZLjava/lang/String;)V
    :try_end_10c
    .catch Ljava/lang/Exception; {:try_start_c8 .. :try_end_10c} :catch_10d

    goto :goto_135

    .line 154
    :catch_10d
    move-exception v0

    .line 155
    .local v0, "e":Ljava/lang/Exception;
    new-instance v9, Lcom/geely/carreceiver/CommandBackend$ExecResult;

    new-instance v12, Ljava/lang/StringBuilder;

    invoke-direct {v12}, Ljava/lang/StringBuilder;-><init>()V

    const-string v13, "broadcast failed: "

    invoke-virtual {v12, v13}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v12

    invoke-virtual {v0}, Ljava/lang/Exception;->getMessage()Ljava/lang/String;

    move-result-object v13

    if-nez v13, :cond_129

    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    move-result-object v13

    invoke-virtual {v13}, Ljava/lang/Class;->getSimpleName()Ljava/lang/String;

    move-result-object v13

    :cond_129
    invoke-virtual {v12, v13}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v12

    invoke-virtual {v12}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v12

    invoke-direct {v9, v3, v12}, Lcom/geely/carreceiver/CommandBackend$ExecResult;-><init>(ZLjava/lang/String;)V

    move-object v0, v9

    .line 151
    .end local v0    # "e":Ljava/lang/Exception;
    :goto_135
    return-object v0

    .line 147
    .end local v4    # "className":Ljava/lang/String;
    .end local v8    # "cls":Ljava/lang/String;
    .end local v10    # "pkg":Ljava/lang/String;
    :cond_136
    move-object/from16 v11, p0

    :goto_138
    new-instance v0, Lcom/geely/carreceiver/CommandBackend$ExecResult;

    new-instance v4, Ljava/lang/StringBuilder;

    invoke-direct {v4}, Ljava/lang/StringBuilder;-><init>()V

    const-string v8, "bad BROADCAST target \'"

    invoke-virtual {v4, v8}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v4

    invoke-virtual {v4, v6}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v4

    const-string v8, "\' (expected package/Class)"

    invoke-virtual {v4, v8}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v4

    invoke-virtual {v4}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v4

    invoke-direct {v0, v3, v4}, Lcom/geely/carreceiver/CommandBackend$ExecResult;-><init>(ZLjava/lang/String;)V

    return-object v0
.end method


# virtual methods
.method public final ensureConfig()V
    .registers 2

    .line 62
    invoke-direct {p0}, Lcom/geely/carreceiver/CommandBackend;->getFile()Ljava/io/File;

    move-result-object v0

    invoke-virtual {v0}, Ljava/io/File;->exists()Z

    move-result v0

    if-nez v0, :cond_16

    .line 63
    nop

    .line 64
    :try_start_b
    sget-object v0, Lcom/geely/carreceiver/CommandBackend;->Companion:Lcom/geely/carreceiver/CommandBackend$Companion;

    invoke-virtual {v0}, Lcom/geely/carreceiver/CommandBackend$Companion;->defaultText()Ljava/lang/String;

    move-result-object v0

    invoke-virtual {p0, v0}, Lcom/geely/carreceiver/CommandBackend;->writeText(Ljava/lang/String;)V
    :try_end_14
    .catch Ljava/io/IOException; {:try_start_b .. :try_end_14} :catch_15

    goto :goto_16

    .line 65
    :catch_15
    move-exception v0

    .line 69
    :cond_16
    :goto_16
    return-void
.end method

.method public final execute(Ljava/lang/String;)Lcom/geely/carreceiver/CommandBackend$ExecResult;
    .registers 30
    .param p1, "cmd"    # Ljava/lang/String;

    move-object/from16 v1, p0

    move-object/from16 v2, p1

    const-string v0, "cmd"

    invoke-static {v2, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 89
    iget-object v3, v1, Lcom/geely/carreceiver/CommandBackend;->execLock:Ljava/lang/Object;

    monitor-enter v3

    const/4 v0, 0x0

    .line 90
    .local v0, "$i$a$-synchronized-CommandBackend$execute$1":I
    :try_start_d
    invoke-virtual/range {p0 .. p0}, Lcom/geely/carreceiver/CommandBackend;->readText()Ljava/lang/String;

    move-result-object v4

    invoke-direct {v1, v4}, Lcom/geely/carreceiver/CommandBackend;->parse(Ljava/lang/String;)Lcom/geely/carreceiver/CommandBackend$Config;

    move-result-object v4

    .line 91
    .local v4, "config":Lcom/geely/carreceiver/CommandBackend$Config;
    invoke-virtual {v4}, Lcom/geely/carreceiver/CommandBackend$Config;->getCommands()Ljava/util/Map;

    move-result-object v5

    invoke-interface {v5, v2}, Ljava/util/Map;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v5

    check-cast v5, Ljava/lang/String;

    const/4 v6, 0x0

    if-nez v5, :cond_3c

    new-instance v5, Lcom/geely/carreceiver/CommandBackend$ExecResult;

    new-instance v7, Ljava/lang/StringBuilder;

    invoke-direct {v7}, Ljava/lang/StringBuilder;-><init>()V

    const-string v8, "no command configured for "

    invoke-virtual {v7, v8}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v7

    invoke-virtual {v7, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v7

    invoke-virtual {v7}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v7

    invoke-direct {v5, v6, v7}, Lcom/geely/carreceiver/CommandBackend$ExecResult;-><init>(ZLjava/lang/String;)V
    :try_end_3a
    .catchall {:try_start_d .. :try_end_3a} :catchall_249

    .end local v0    # "$i$a$-synchronized-CommandBackend$execute$1":I
    .end local v4    # "config":Lcom/geely/carreceiver/CommandBackend$Config;
    monitor-exit v3

    return-object v5

    .line 92
    .restart local v0    # "$i$a$-synchronized-CommandBackend$execute$1":I
    .restart local v4    # "config":Lcom/geely/carreceiver/CommandBackend$Config;
    .local v5, "line":Ljava/lang/String;
    :cond_3c
    :try_start_3c
    move-object v7, v5

    check-cast v7, Ljava/lang/CharSequence;

    invoke-static {v7}, Lkotlin/text/StringsKt;->isBlank(Ljava/lang/CharSequence;)Z

    move-result v7

    if-eqz v7, :cond_5f

    new-instance v7, Lcom/geely/carreceiver/CommandBackend$ExecResult;

    new-instance v8, Ljava/lang/StringBuilder;

    invoke-direct {v8}, Ljava/lang/StringBuilder;-><init>()V

    const-string v9, "empty command for "

    invoke-virtual {v8, v9}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v8

    invoke-virtual {v8, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v8

    invoke-virtual {v8}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v8

    invoke-direct {v7, v6, v8}, Lcom/geely/carreceiver/CommandBackend$ExecResult;-><init>(ZLjava/lang/String;)V
    :try_end_5d
    .catchall {:try_start_3c .. :try_end_5d} :catchall_249

    .end local v0    # "$i$a$-synchronized-CommandBackend$execute$1":I
    .end local v4    # "config":Lcom/geely/carreceiver/CommandBackend$Config;
    .end local v5    # "line":Ljava/lang/String;
    monitor-exit v3

    return-object v7

    .line 94
    .restart local v0    # "$i$a$-synchronized-CommandBackend$execute$1":I
    .restart local v4    # "config":Lcom/geely/carreceiver/CommandBackend$Config;
    .restart local v5    # "line":Ljava/lang/String;
    :cond_5f
    :try_start_5f
    const-string v7, "BROADCAST "

    const/4 v8, 0x1

    invoke-static {v5, v7, v8}, Lkotlin/text/StringsKt;->startsWith(Ljava/lang/String;Ljava/lang/String;Z)Z

    move-result v7

    const/16 v9, 0xa

    if-eqz v7, :cond_83

    .line 95
    invoke-virtual {v5, v9}, Ljava/lang/String;->substring(I)Ljava/lang/String;

    move-result-object v6

    const-string v7, "substring(...)"

    invoke-static {v6, v7}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    check-cast v6, Ljava/lang/CharSequence;

    invoke-static {v6}, Lkotlin/text/StringsKt;->trim(Ljava/lang/CharSequence;)Ljava/lang/CharSequence;

    move-result-object v6

    invoke-virtual {v6}, Ljava/lang/Object;->toString()Ljava/lang/String;

    move-result-object v6

    invoke-direct {v1, v6}, Lcom/geely/carreceiver/CommandBackend;->sendVehicleBroadcast(Ljava/lang/String;)Lcom/geely/carreceiver/CommandBackend$ExecResult;

    move-result-object v6
    :try_end_81
    .catchall {:try_start_5f .. :try_end_81} :catchall_249

    .end local v0    # "$i$a$-synchronized-CommandBackend$execute$1":I
    .end local v4    # "config":Lcom/geely/carreceiver/CommandBackend$Config;
    .end local v5    # "line":Ljava/lang/String;
    monitor-exit v3

    return-object v6

    .line 97
    .restart local v0    # "$i$a$-synchronized-CommandBackend$execute$1":I
    .restart local v4    # "config":Lcom/geely/carreceiver/CommandBackend$Config;
    .restart local v5    # "line":Ljava/lang/String;
    :cond_83
    :try_start_83
    const-string v7, "VHAL_INT "

    invoke-static {v5, v7, v8}, Lkotlin/text/StringsKt;->startsWith(Ljava/lang/String;Ljava/lang/String;Z)Z

    move-result v7

    if-eqz v7, :cond_a6

    .line 98
    const/16 v7, 0x9

    invoke-virtual {v5, v7}, Ljava/lang/String;->substring(I)Ljava/lang/String;

    move-result-object v7

    const-string v8, "substring(...)"

    invoke-static {v7, v8}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    check-cast v7, Ljava/lang/CharSequence;

    invoke-static {v7}, Lkotlin/text/StringsKt;->trim(Ljava/lang/CharSequence;)Ljava/lang/CharSequence;

    move-result-object v7

    invoke-virtual {v7}, Ljava/lang/Object;->toString()Ljava/lang/String;

    move-result-object v7

    invoke-direct {v1, v7, v6}, Lcom/geely/carreceiver/CommandBackend;->execVhalSet(Ljava/lang/String;Z)Lcom/geely/carreceiver/CommandBackend$ExecResult;

    move-result-object v6
    :try_end_a4
    .catchall {:try_start_83 .. :try_end_a4} :catchall_249

    .end local v0    # "$i$a$-synchronized-CommandBackend$execute$1":I
    .end local v4    # "config":Lcom/geely/carreceiver/CommandBackend$Config;
    .end local v5    # "line":Ljava/lang/String;
    monitor-exit v3

    return-object v6

    .line 100
    .restart local v0    # "$i$a$-synchronized-CommandBackend$execute$1":I
    .restart local v4    # "config":Lcom/geely/carreceiver/CommandBackend$Config;
    .restart local v5    # "line":Ljava/lang/String;
    :cond_a6
    :try_start_a6
    const-string v7, "VHAL_BOOL "

    invoke-static {v5, v7, v8}, Lkotlin/text/StringsKt;->startsWith(Ljava/lang/String;Ljava/lang/String;Z)Z

    move-result v7

    if-eqz v7, :cond_c7

    .line 101
    invoke-virtual {v5, v9}, Ljava/lang/String;->substring(I)Ljava/lang/String;

    move-result-object v6

    const-string v7, "substring(...)"

    invoke-static {v6, v7}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    check-cast v6, Ljava/lang/CharSequence;

    invoke-static {v6}, Lkotlin/text/StringsKt;->trim(Ljava/lang/CharSequence;)Ljava/lang/CharSequence;

    move-result-object v6

    invoke-virtual {v6}, Ljava/lang/Object;->toString()Ljava/lang/String;

    move-result-object v6

    invoke-direct {v1, v6, v8}, Lcom/geely/carreceiver/CommandBackend;->execVhalSet(Ljava/lang/String;Z)Lcom/geely/carreceiver/CommandBackend$ExecResult;

    move-result-object v6
    :try_end_c5
    .catchall {:try_start_a6 .. :try_end_c5} :catchall_249

    .end local v0    # "$i$a$-synchronized-CommandBackend$execute$1":I
    .end local v4    # "config":Lcom/geely/carreceiver/CommandBackend$Config;
    .end local v5    # "line":Ljava/lang/String;
    monitor-exit v3

    return-object v6

    .line 103
    .restart local v0    # "$i$a$-synchronized-CommandBackend$execute$1":I
    .restart local v4    # "config":Lcom/geely/carreceiver/CommandBackend$Config;
    .restart local v5    # "line":Ljava/lang/String;
    :cond_c7
    :try_start_c7
    const-string v7, "VHAL_GET_INT "

    invoke-static {v5, v7, v8}, Lkotlin/text/StringsKt;->startsWith(Ljava/lang/String;Ljava/lang/String;Z)Z

    move-result v7

    if-eqz v7, :cond_ea

    .line 104
    const/16 v7, 0xd

    invoke-virtual {v5, v7}, Ljava/lang/String;->substring(I)Ljava/lang/String;

    move-result-object v7

    const-string v8, "substring(...)"

    invoke-static {v7, v8}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    check-cast v7, Ljava/lang/CharSequence;

    invoke-static {v7}, Lkotlin/text/StringsKt;->trim(Ljava/lang/CharSequence;)Ljava/lang/CharSequence;

    move-result-object v7

    invoke-virtual {v7}, Ljava/lang/Object;->toString()Ljava/lang/String;

    move-result-object v7

    invoke-direct {v1, v7, v6}, Lcom/geely/carreceiver/CommandBackend;->execVhalGet(Ljava/lang/String;Z)Lcom/geely/carreceiver/CommandBackend$ExecResult;

    move-result-object v6
    :try_end_e8
    .catchall {:try_start_c7 .. :try_end_e8} :catchall_249

    .end local v0    # "$i$a$-synchronized-CommandBackend$execute$1":I
    .end local v4    # "config":Lcom/geely/carreceiver/CommandBackend$Config;
    .end local v5    # "line":Ljava/lang/String;
    monitor-exit v3

    return-object v6

    .line 106
    .restart local v0    # "$i$a$-synchronized-CommandBackend$execute$1":I
    .restart local v4    # "config":Lcom/geely/carreceiver/CommandBackend$Config;
    .restart local v5    # "line":Ljava/lang/String;
    :cond_ea
    :try_start_ea
    const-string v7, "VHAL_GET_BOOL "

    invoke-static {v5, v7, v8}, Lkotlin/text/StringsKt;->startsWith(Ljava/lang/String;Ljava/lang/String;Z)Z

    move-result v7

    if-eqz v7, :cond_10d

    .line 107
    const/16 v6, 0xe

    invoke-virtual {v5, v6}, Ljava/lang/String;->substring(I)Ljava/lang/String;

    move-result-object v6

    const-string v7, "substring(...)"

    invoke-static {v6, v7}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    check-cast v6, Ljava/lang/CharSequence;

    invoke-static {v6}, Lkotlin/text/StringsKt;->trim(Ljava/lang/CharSequence;)Ljava/lang/CharSequence;

    move-result-object v6

    invoke-virtual {v6}, Ljava/lang/Object;->toString()Ljava/lang/String;

    move-result-object v6

    invoke-direct {v1, v6, v8}, Lcom/geely/carreceiver/CommandBackend;->execVhalGet(Ljava/lang/String;Z)Lcom/geely/carreceiver/CommandBackend$ExecResult;

    move-result-object v6
    :try_end_10b
    .catchall {:try_start_ea .. :try_end_10b} :catchall_249

    .end local v0    # "$i$a$-synchronized-CommandBackend$execute$1":I
    .end local v4    # "config":Lcom/geely/carreceiver/CommandBackend$Config;
    .end local v5    # "line":Ljava/lang/String;
    monitor-exit v3

    return-object v6

    .line 110
    .restart local v0    # "$i$a$-synchronized-CommandBackend$execute$1":I
    .restart local v4    # "config":Lcom/geely/carreceiver/CommandBackend$Config;
    .restart local v5    # "line":Ljava/lang/String;
    :cond_10d
    :try_start_10d
    invoke-virtual {v4}, Lcom/geely/carreceiver/CommandBackend$Config;->getOptions()Ljava/util/Map;

    move-result-object v7

    const-string v9, "timeout_ms"

    invoke-interface {v7, v9}, Ljava/util/Map;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v7

    check-cast v7, Ljava/lang/String;

    if-eqz v7, :cond_126

    invoke-static {v7}, Lkotlin/text/StringsKt;->toLongOrNull(Ljava/lang/String;)Ljava/lang/Long;

    move-result-object v7

    if-eqz v7, :cond_126

    invoke-virtual {v7}, Ljava/lang/Long;->longValue()J

    move-result-wide v9

    goto :goto_128

    :cond_126
    const-wide/16 v9, 0xfa0

    :goto_128
    move-wide v11, v9

    const-wide/16 v13, 0x1f4

    const-wide/16 v15, 0x4e20

    invoke-static/range {v11 .. v16}, Lkotlin/ranges/RangesKt;->coerceIn(JJJ)J

    move-result-wide v19

    .line 111
    .local v19, "timeoutMs":J
    invoke-virtual {v4}, Lcom/geely/carreceiver/CommandBackend$Config;->getOptions()Ljava/util/Map;

    move-result-object v7

    const-string v9, "run_as_root"

    invoke-interface {v7, v9}, Ljava/util/Map;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v7

    check-cast v7, Ljava/lang/String;

    if-nez v7, :cond_141

    const-string v7, "auto"

    :cond_141
    sget-object v9, Ljava/util/Locale;->ROOT:Ljava/util/Locale;

    invoke-virtual {v7, v9}, Ljava/lang/String;->toLowerCase(Ljava/util/Locale;)Ljava/lang/String;

    move-result-object v7

    const-string v9, "toLowerCase(...)"

    invoke-static {v7, v9}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    .line 112
    .local v7, "mode":Ljava/lang/String;
    invoke-virtual/range {p0 .. p0}, Lcom/geely/carreceiver/CommandBackend;->suStatus()Lcom/geely/carreceiver/CommandBackend$SuStatus;

    move-result-object v9

    .line 113
    .local v9, "su":Lcom/geely/carreceiver/CommandBackend$SuStatus;
    nop

    .line 114
    const-string v10, "true"

    invoke-static {v7, v10}, Lkotlin/jvm/internal/Intrinsics;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v10

    if-eqz v10, :cond_15b

    move v10, v8

    goto :goto_169

    .line 115
    :cond_15b
    const-string v10, "false"

    invoke-static {v7, v10}, Lkotlin/jvm/internal/Intrinsics;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v10

    if-eqz v10, :cond_165

    move v10, v6

    goto :goto_169

    .line 116
    :cond_165
    invoke-virtual {v9}, Lcom/geely/carreceiver/CommandBackend$SuStatus;->getWorks()Z

    move-result v10

    .line 113
    :goto_169
    nop

    .line 118
    .local v10, "useRoot":Z
    invoke-virtual {v9}, Lcom/geely/carreceiver/CommandBackend$SuStatus;->getPath()Ljava/lang/String;

    move-result-object v11

    .line 119
    .local v11, "suPath":Ljava/lang/String;
    if-eqz v10, :cond_17b

    if-nez v11, :cond_17b

    new-instance v8, Lcom/geely/carreceiver/CommandBackend$ExecResult;

    const-string v12, "run_as_root=true but no su binary was found"

    invoke-direct {v8, v6, v12}, Lcom/geely/carreceiver/CommandBackend$ExecResult;-><init>(ZLjava/lang/String;)V
    :try_end_179
    .catchall {:try_start_10d .. :try_end_179} :catchall_249

    .end local v0    # "$i$a$-synchronized-CommandBackend$execute$1":I
    .end local v4    # "config":Lcom/geely/carreceiver/CommandBackend$Config;
    .end local v5    # "line":Ljava/lang/String;
    .end local v7    # "mode":Ljava/lang/String;
    .end local v9    # "su":Lcom/geely/carreceiver/CommandBackend$SuStatus;
    .end local v10    # "useRoot":Z
    .end local v11    # "suPath":Ljava/lang/String;
    .end local v19    # "timeoutMs":J
    monitor-exit v3

    return-object v8

    .line 122
    .restart local v0    # "$i$a$-synchronized-CommandBackend$execute$1":I
    .restart local v4    # "config":Lcom/geely/carreceiver/CommandBackend$Config;
    .restart local v5    # "line":Ljava/lang/String;
    .restart local v7    # "mode":Ljava/lang/String;
    .restart local v9    # "su":Lcom/geely/carreceiver/CommandBackend$SuStatus;
    .restart local v10    # "useRoot":Z
    .restart local v11    # "suPath":Ljava/lang/String;
    .restart local v19    # "timeoutMs":J
    :cond_17b
    const/4 v12, 0x2

    const/4 v13, 0x3

    if-eqz v10, :cond_19a

    if-eqz v11, :cond_19a

    .line 123
    :try_start_181
    sget-object v17, Lcom/geely/carreceiver/Shell;->INSTANCE:Lcom/geely/carreceiver/Shell;

    new-array v13, v13, [Ljava/lang/String;

    aput-object v11, v13, v6

    const-string v14, "-c"

    aput-object v14, v13, v8

    aput-object v5, v13, v12

    const/16 v21, 0x0

    const/16 v22, 0x4

    const/16 v23, 0x0

    move-object/from16 v18, v13

    invoke-static/range {v17 .. v23}, Lcom/geely/carreceiver/Shell;->run$default(Lcom/geely/carreceiver/Shell;[Ljava/lang/String;JIILjava/lang/Object;)Lcom/geely/carreceiver/Shell$Out;

    move-result-object v12

    goto :goto_1b6

    .line 125
    :cond_19a
    sget-object v21, Lcom/geely/carreceiver/Shell;->INSTANCE:Lcom/geely/carreceiver/Shell;

    new-array v13, v13, [Ljava/lang/String;

    const-string v14, "sh"

    aput-object v14, v13, v6

    const-string v14, "-c"

    aput-object v14, v13, v8

    aput-object v5, v13, v12

    const/16 v25, 0x0

    const/16 v26, 0x4

    const/16 v27, 0x0

    move-object/from16 v22, v13

    move-wide/from16 v23, v19

    invoke-static/range {v21 .. v27}, Lcom/geely/carreceiver/Shell;->run$default(Lcom/geely/carreceiver/Shell;[Ljava/lang/String;JIILjava/lang/Object;)Lcom/geely/carreceiver/Shell$Out;

    move-result-object v12

    .line 122
    :goto_1b6
    nop

    .line 127
    .local v12, "out":Lcom/geely/carreceiver/Shell$Out;
    invoke-virtual {v12}, Lcom/geely/carreceiver/Shell$Out;->getOk()Z

    move-result v13

    if-eqz v13, :cond_1c8

    new-instance v6, Lcom/geely/carreceiver/CommandBackend$ExecResult;

    invoke-virtual {v12}, Lcom/geely/carreceiver/Shell$Out;->getText()Ljava/lang/String;

    move-result-object v13

    invoke-direct {v6, v8, v13}, Lcom/geely/carreceiver/CommandBackend$ExecResult;-><init>(ZLjava/lang/String;)V
    :try_end_1c6
    .catchall {:try_start_181 .. :try_end_1c6} :catchall_249

    .end local v0    # "$i$a$-synchronized-CommandBackend$execute$1":I
    .end local v4    # "config":Lcom/geely/carreceiver/CommandBackend$Config;
    .end local v5    # "line":Ljava/lang/String;
    .end local v7    # "mode":Ljava/lang/String;
    .end local v9    # "su":Lcom/geely/carreceiver/CommandBackend$SuStatus;
    .end local v10    # "useRoot":Z
    .end local v11    # "suPath":Ljava/lang/String;
    .end local v12    # "out":Lcom/geely/carreceiver/Shell$Out;
    .end local v19    # "timeoutMs":J
    monitor-exit v3

    return-object v6

    .line 129
    .restart local v0    # "$i$a$-synchronized-CommandBackend$execute$1":I
    .restart local v4    # "config":Lcom/geely/carreceiver/CommandBackend$Config;
    .restart local v5    # "line":Ljava/lang/String;
    .restart local v7    # "mode":Ljava/lang/String;
    .restart local v9    # "su":Lcom/geely/carreceiver/CommandBackend$SuStatus;
    .restart local v10    # "useRoot":Z
    .restart local v11    # "suPath":Ljava/lang/String;
    .restart local v12    # "out":Lcom/geely/carreceiver/Shell$Out;
    .restart local v19    # "timeoutMs":J
    :cond_1c8
    :try_start_1c8
    invoke-virtual {v12}, Lcom/geely/carreceiver/Shell$Out;->getFailure()Ljava/lang/String;

    move-result-object v13

    if-nez v13, :cond_213

    new-instance v13, Ljava/lang/StringBuilder;

    invoke-direct {v13}, Ljava/lang/StringBuilder;-><init>()V

    const-string v14, "exit="

    invoke-virtual {v13, v14}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v13

    invoke-virtual {v12}, Lcom/geely/carreceiver/Shell$Out;->getExit()I

    move-result v14

    invoke-virtual {v13, v14}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v13

    invoke-virtual {v12}, Lcom/geely/carreceiver/Shell$Out;->getText()Ljava/lang/String;

    move-result-object v14

    check-cast v14, Ljava/lang/CharSequence;

    invoke-interface {v14}, Ljava/lang/CharSequence;->length()I

    move-result v14

    if-lez v14, :cond_1ee

    goto :goto_1ef

    :cond_1ee
    move v8, v6

    :goto_1ef
    if-eqz v8, :cond_209

    new-instance v8, Ljava/lang/StringBuilder;

    invoke-direct {v8}, Ljava/lang/StringBuilder;-><init>()V

    const-string v14, ": "

    invoke-virtual {v8, v14}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v8

    invoke-virtual {v12}, Lcom/geely/carreceiver/Shell$Out;->getText()Ljava/lang/String;

    move-result-object v14

    invoke-virtual {v8, v14}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v8

    invoke-virtual {v8}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v8

    goto :goto_20b

    :cond_209
    const-string v8, ""

    :goto_20b
    invoke-virtual {v13, v8}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v8

    invoke-virtual {v8}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v13

    :cond_213
    move-object v8, v13

    .line 130
    .local v8, "detail":Ljava/lang/String;
    if-nez v10, :cond_242

    const-string v13, "false"

    invoke-static {v7, v13}, Lkotlin/jvm/internal/Intrinsics;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v13

    if-nez v13, :cond_242

    if-eqz v11, :cond_242

    new-instance v13, Ljava/lang/StringBuilder;

    invoke-direct {v13}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v13, v8}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v13

    const-string v14, "  [su unusable: "

    invoke-virtual {v13, v14}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v13

    invoke-virtual {v9}, Lcom/geely/carreceiver/CommandBackend$SuStatus;->getMessage()Ljava/lang/String;

    move-result-object v14

    invoke-virtual {v13, v14}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v13

    const/16 v14, 0x5d

    invoke-virtual {v13, v14}, Ljava/lang/StringBuilder;->append(C)Ljava/lang/StringBuilder;

    move-result-object v13

    invoke-virtual {v13}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v13

    move-object v8, v13

    .line 131
    :cond_242
    new-instance v13, Lcom/geely/carreceiver/CommandBackend$ExecResult;

    invoke-direct {v13, v6, v8}, Lcom/geely/carreceiver/CommandBackend$ExecResult;-><init>(ZLjava/lang/String;)V
    :try_end_247
    .catchall {:try_start_1c8 .. :try_end_247} :catchall_249

    .line 89
    .end local v0    # "$i$a$-synchronized-CommandBackend$execute$1":I
    .end local v4    # "config":Lcom/geely/carreceiver/CommandBackend$Config;
    .end local v5    # "line":Ljava/lang/String;
    .end local v7    # "mode":Ljava/lang/String;
    .end local v8    # "detail":Ljava/lang/String;
    .end local v9    # "su":Lcom/geely/carreceiver/CommandBackend$SuStatus;
    .end local v10    # "useRoot":Z
    .end local v11    # "suPath":Ljava/lang/String;
    .end local v12    # "out":Lcom/geely/carreceiver/Shell$Out;
    .end local v19    # "timeoutMs":J
    monitor-exit v3

    .line 132
    return-object v13

    .line 89
    :catchall_249
    move-exception v0

    monitor-exit v3

    throw v0
.end method

.method public final isKnown(Ljava/lang/String;)Z
    .registers 4
    .param p1, "cmd"    # Ljava/lang/String;

    const-string v0, "cmd"

    invoke-static {p1, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 59
    sget-object v0, Lcom/geely/carreceiver/CommandBackend;->KNOWN:Ljava/util/Set;

    invoke-interface {v0, p1}, Ljava/util/Set;->contains(Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_12

    const/4 v0, 0x1

    return v0

    :cond_12
    :try_start_13
    invoke-virtual {p0}, Lcom/geely/carreceiver/CommandBackend;->readText()Ljava/lang/String;

    move-result-object v0

    invoke-direct {p0, v0}, Lcom/geely/carreceiver/CommandBackend;->parse(Ljava/lang/String;)Lcom/geely/carreceiver/CommandBackend$Config;

    move-result-object v0

    invoke-virtual {v0}, Lcom/geely/carreceiver/CommandBackend$Config;->getCommands()Ljava/util/Map;

    move-result-object v0

    invoke-interface {v0, p1}, Ljava/util/Map;->containsKey(Ljava/lang/Object;)Z

    move-result v0
    :try_end_24
    .catch Ljava/lang/Exception; {:try_start_13 .. :try_end_24} :catch_25

    return v0

    :catch_25
    move-exception v0

    const/4 v0, 0x0

    return v0
.end method

.method public final readText()Ljava/lang/String;
    .registers 3

    .line 71
    nop

    .line 72
    :try_start_1
    invoke-direct {p0}, Lcom/geely/carreceiver/CommandBackend;->getFile()Ljava/io/File;

    move-result-object v0

    invoke-virtual {v0}, Ljava/io/File;->exists()Z

    move-result v0

    if-eqz v0, :cond_16

    invoke-direct {p0}, Lcom/geely/carreceiver/CommandBackend;->getFile()Ljava/io/File;

    move-result-object v0

    sget-object v1, Lkotlin/text/Charsets;->UTF_8:Ljava/nio/charset/Charset;

    invoke-static {v0, v1}, Lkotlin/io/FilesKt;->readText(Ljava/io/File;Ljava/nio/charset/Charset;)Ljava/lang/String;

    move-result-object v0

    goto :goto_25

    :cond_16
    sget-object v0, Lcom/geely/carreceiver/CommandBackend;->Companion:Lcom/geely/carreceiver/CommandBackend$Companion;

    invoke-virtual {v0}, Lcom/geely/carreceiver/CommandBackend$Companion;->defaultText()Ljava/lang/String;

    move-result-object v0
    :try_end_1c
    .catch Ljava/io/IOException; {:try_start_1 .. :try_end_1c} :catch_1d

    goto :goto_25

    .line 73
    :catch_1d
    move-exception v0

    .line 74
    .local v0, "e":Ljava/io/IOException;
    sget-object v1, Lcom/geely/carreceiver/CommandBackend;->Companion:Lcom/geely/carreceiver/CommandBackend$Companion;

    invoke-virtual {v1}, Lcom/geely/carreceiver/CommandBackend$Companion;->defaultText()Ljava/lang/String;

    move-result-object v1

    move-object v0, v1

    .line 75
    .end local v0    # "e":Ljava/io/IOException;
    :goto_25
    return-object v0
.end method

.method public final resetToDefault()V
    .registers 2
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    .line 83
    sget-object v0, Lcom/geely/carreceiver/CommandBackend;->Companion:Lcom/geely/carreceiver/CommandBackend$Companion;

    invoke-virtual {v0}, Lcom/geely/carreceiver/CommandBackend$Companion;->defaultText()Ljava/lang/String;

    move-result-object v0

    invoke-virtual {p0, v0}, Lcom/geely/carreceiver/CommandBackend;->writeText(Ljava/lang/String;)V

    return-void
.end method

.method public final suStatus()Lcom/geely/carreceiver/CommandBackend$SuStatus;
    .registers 10

    .line 227
    iget-object v0, p0, Lcom/geely/carreceiver/CommandBackend;->suLock:Ljava/lang/Object;

    monitor-enter v0

    const/4 v1, 0x0

    .line 228
    .local v1, "$i$a$-synchronized-CommandBackend$suStatus$1":I
    :try_start_4
    invoke-static {}, Ljava/lang/System;->currentTimeMillis()J

    move-result-wide v2

    .line 229
    .local v2, "now":J
    iget-object v4, p0, Lcom/geely/carreceiver/CommandBackend;->suCache:Lcom/geely/carreceiver/CommandBackend$SuStatus;

    .line 230
    .local v4, "cached":Lcom/geely/carreceiver/CommandBackend$SuStatus;
    if-eqz v4, :cond_19

    iget-wide v5, p0, Lcom/geely/carreceiver/CommandBackend;->suCacheAt:J
    :try_end_e
    .catchall {:try_start_4 .. :try_end_e} :catchall_24

    sub-long v5, v2, v5

    const-wide/32 v7, 0xea60

    cmp-long v5, v5, v7

    if-gez v5, :cond_19

    .end local v1    # "$i$a$-synchronized-CommandBackend$suStatus$1":I
    .end local v2    # "now":J
    .end local v4    # "cached":Lcom/geely/carreceiver/CommandBackend$SuStatus;
    monitor-exit v0

    return-object v4

    .line 231
    .restart local v1    # "$i$a$-synchronized-CommandBackend$suStatus$1":I
    .restart local v2    # "now":J
    .restart local v4    # "cached":Lcom/geely/carreceiver/CommandBackend$SuStatus;
    :cond_19
    :try_start_19
    invoke-direct {p0}, Lcom/geely/carreceiver/CommandBackend;->probeSu()Lcom/geely/carreceiver/CommandBackend$SuStatus;

    move-result-object v5

    .line 232
    .local v5, "fresh":Lcom/geely/carreceiver/CommandBackend$SuStatus;
    iput-object v5, p0, Lcom/geely/carreceiver/CommandBackend;->suCache:Lcom/geely/carreceiver/CommandBackend$SuStatus;

    .line 233
    iput-wide v2, p0, Lcom/geely/carreceiver/CommandBackend;->suCacheAt:J
    :try_end_21
    .catchall {:try_start_19 .. :try_end_21} :catchall_24

    .line 234
    nop

    .line 227
    .end local v1    # "$i$a$-synchronized-CommandBackend$suStatus$1":I
    .end local v2    # "now":J
    .end local v4    # "cached":Lcom/geely/carreceiver/CommandBackend$SuStatus;
    .end local v5    # "fresh":Lcom/geely/carreceiver/CommandBackend$SuStatus;
    monitor-exit v0

    .line 235
    return-object v5

    .line 227
    :catchall_24
    move-exception v1

    monitor-exit v0

    throw v1
.end method

.method public final usesPlaceholder()Z
    .registers 14

    .line 87
    invoke-virtual {p0}, Lcom/geely/carreceiver/CommandBackend;->readText()Ljava/lang/String;

    move-result-object v0

    invoke-direct {p0, v0}, Lcom/geely/carreceiver/CommandBackend;->parse(Ljava/lang/String;)Lcom/geely/carreceiver/CommandBackend$Config;

    move-result-object v0

    invoke-virtual {v0}, Lcom/geely/carreceiver/CommandBackend$Config;->getCommands()Ljava/util/Map;

    move-result-object v0

    invoke-interface {v0}, Ljava/util/Map;->values()Ljava/util/Collection;

    move-result-object v0

    check-cast v0, Ljava/lang/Iterable;

    .local v0, "$this$any$iv":Ljava/lang/Iterable;
    const/4 v1, 0x0

    .line 428
    .local v1, "$i$f$any":I
    instance-of v2, v0, Ljava/util/Collection;

    const/4 v3, 0x1

    const-string v4, "/dev/car_control"

    const/4 v5, 0x0

    if-eqz v2, :cond_26

    move-object v2, v0

    check-cast v2, Ljava/util/Collection;

    invoke-interface {v2}, Ljava/util/Collection;->isEmpty()Z

    move-result v2

    if-eqz v2, :cond_26

    move v0, v5

    goto :goto_49

    .line 429
    :cond_26
    invoke-interface {v0}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    move-result-object v2

    :cond_2a
    invoke-interface {v2}, Ljava/util/Iterator;->hasNext()Z

    move-result v6

    if-eqz v6, :cond_48

    invoke-interface {v2}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v6

    .local v6, "element$iv":Ljava/lang/Object;
    move-object v7, v6

    check-cast v7, Ljava/lang/String;

    .local v7, "it":Ljava/lang/String;
    const/4 v8, 0x0

    .line 87
    .local v8, "$i$a$-any-CommandBackend$usesPlaceholder$1":I
    move-object v9, v7

    check-cast v9, Ljava/lang/CharSequence;

    move-object v10, v4

    check-cast v10, Ljava/lang/CharSequence;

    const/4 v11, 0x2

    const/4 v12, 0x0

    invoke-static {v9, v10, v5, v11, v12}, Lkotlin/text/StringsKt;->contains$default(Ljava/lang/CharSequence;Ljava/lang/CharSequence;ZILjava/lang/Object;)Z

    move-result v7

    .line 429
    .end local v7    # "it":Ljava/lang/String;
    .end local v8    # "$i$a$-any-CommandBackend$usesPlaceholder$1":I
    if-eqz v7, :cond_2a

    move v0, v3

    goto :goto_49

    .line 430
    .end local v6    # "element$iv":Ljava/lang/Object;
    :cond_48
    move v0, v5

    .end local v0    # "$this$any$iv":Ljava/lang/Iterable;
    .end local v1    # "$i$f$any":I
    :goto_49
    if-eqz v0, :cond_57

    .line 87
    new-instance v0, Ljava/io/File;

    invoke-direct {v0, v4}, Ljava/io/File;-><init>(Ljava/lang/String;)V

    invoke-virtual {v0}, Ljava/io/File;->exists()Z

    move-result v0

    if-nez v0, :cond_57

    goto :goto_58

    :cond_57
    move v3, v5

    :goto_58
    return v3
.end method

.method public final writeText(Ljava/lang/String;)V
    .registers 4
    .param p1, "text"    # Ljava/lang/String;
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    const-string v0, "text"

    invoke-static {p1, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 79
    invoke-direct {p0}, Lcom/geely/carreceiver/CommandBackend;->getFile()Ljava/io/File;

    move-result-object v0

    sget-object v1, Lkotlin/text/Charsets;->UTF_8:Ljava/nio/charset/Charset;

    invoke-static {v0, p1, v1}, Lkotlin/io/FilesKt;->writeText(Ljava/io/File;Ljava/lang/String;Ljava/nio/charset/Charset;)V

    .line 80
    return-void
.end method
