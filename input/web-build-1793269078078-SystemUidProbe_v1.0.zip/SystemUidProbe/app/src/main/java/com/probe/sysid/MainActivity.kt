package com.probe.sysid

import android.app.Activity
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import android.os.Process
import android.widget.Button
import android.widget.TextView

/**
 * SystemUidProbe - تطبيق فحص فقط (قراءة فقط).
 *
 * لا يطلب sharedUserId ولا يتحكم بأي شيء في السيارة. يُثبَّت دائماً بشكل طبيعي
 * (مثل أي تطبيق عادي) بغض النظر عن أي شهادة توقيع، لأنه لا يطلب الانضمام إلى
 * أي UID خاص.
 *
 * الهدف: معرفة UID الحقيقي للتطبيقات على هذه السيارة تحديداً، وقراءة شهادة
 * التوقيع الحقيقية التي بُني بها نظام السيارة (الحزمة الخاصة "android" تمثّل
 * النظام الأساسي نفسه - شهادتها هي بالضبط ما يجب أن يطابقه أي تطبيق آخر ليحصل
 * على android.uid.system عند التثبيت). هذا يجيب بشكل قاطع (بدل التخمين) هل فكرة
 * "توقيع تطبيقنا بنفس مفتاح النظام" قابلة للتطبيق على هذه السيارة تحديداً، ومع
 * أي مفتاح بالضبط.
 */
class MainActivity : Activity() {

    // حزم معروفة من عملنا السابق يهمنا معرفة توقيعها بالتحديد
    private val interesting = listOf(
        "android" to "النظام الأساسي نفسه (platform) - المرجع",
        "com.geely.carreceiver" to "تطبيقنا نحن (GeelyReceiver) - للمقارنة فقط",
        "com.dmkcv.sunray" to "SunRay",
        "com.flyme.auto.launcher" to "لانشر السيارة (ويدجت النوافذ/السقف)",
        "com.flyme.auto.keyserver" to "AutoKeyServer (أزرار المقود)",
        "com.flyme.auto.hvac" to "HVAC",
        "com.geely.lifecontrol" to "LifeControl",
        "com.android.systemui" to "SystemUI"
    )

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        val reportView = findViewById<TextView>(R.id.report_text)
        val report = buildReport()
        reportView.text = report

        findViewById<Button>(R.id.btn_copy).setOnClickListener {
            val cm = getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
            cm.setPrimaryClip(ClipData.newPlainText("sysid_probe_report", report))
        }
        findViewById<Button>(R.id.btn_share).setOnClickListener {
            val send = Intent(Intent.ACTION_SEND)
            send.type = "text/plain"
            send.putExtra(Intent.EXTRA_TEXT, report)
            startActivity(Intent.createChooser(send, "مشاركة التقرير"))
        }
    }

    private fun buildReport(): String {
        val sb = StringBuilder()
        val pm = packageManager

        sb.append("== معلومات الجهاز ==\n")
        sb.append("MANUFACTURER=").append(Build.MANUFACTURER).append("\n")
        sb.append("MODEL=").append(Build.MODEL).append("\n")
        sb.append("ANDROID=").append(Build.VERSION.RELEASE).append(" (sdk=").append(Build.VERSION.SDK_INT).append(")\n\n")

        sb.append("== هذا التطبيق (نحن) ==\n")
        val myUid = Process.myUid()
        sb.append("package=").append(packageName).append("\n")
        sb.append("uid=").append(myUid)
        if (myUid == Process.SYSTEM_UID) {
            sb.append("  <<< هذا هو UID النظام (1000) !\n")
        } else {
            sb.append("  (عادي - ليس UID النظام 1000، وهذا متوقع لأن هذا التطبيق لا يطلب sharedUserId أصلاً)\n")
        }
        try {
            val info = pm.getPackageInfo(packageName, PackageManager.GET_PERMISSIONS)
            val perms = info.requestedPermissions
            if (perms.isNullOrEmpty()) {
                sb.append("الصلاحيات المطلوبة: لا شيء (هذا تطبيق قراءة فقط عن قصد)\n")
            } else {
                sb.append("الصلاحيات المطلوبة: ").append(perms.joinToString(", ")).append("\n")
            }
        } catch (e: Exception) {
            sb.append("تعذّرت قراءة صلاحياتنا: ").append(e.message).append("\n")
        }
        sb.append("\n")

        sb.append("== شهادات التوقيع (المقارنة بشهادة النظام الأساسي) ==\n")
        var platformSha: String? = null
        for ((pkg, label) in interesting) {
            val r = CertUtil.readInstalledPackageCert(pm, pkg)
            sb.append("--- ").append(pkg).append(" (").append(label).append(") ---\n")
            if (!r.found) {
                sb.append("  ").append(r.error).append("\n")
                continue
            }
            if (pkg == "android") platformSha = r.sha256
            sb.append("  subject: ").append(r.subject).append("\n")
            sb.append("  serial : ").append(r.serial).append("\n")
            sb.append("  sha256 : ").append(r.sha256).append("\n")
            if (platformSha != null && pkg != "android") {
                val match = r.sha256 == platformSha
                sb.append("  => مطابقة للنظام الأساسي؟ ").append(if (match) "نعم! نفس الشهادة تماماً (موقّع فعلياً كـ system)" else "لا - شهادة مختلفة (غير موقّع كنظام فعلياً)").append("\n")
            }
        }
        sb.append("\n")

        if (platformSha != null) {
            sb.append("== كل التطبيقات المثبتة الموقّعة بنفس مفتاح النظام (platform-signed) ==\n")
            sb.append("(هذه القائمة تخبرنا أي تطبيقات تملك فعلاً صلاحية النظام الحقيقية على جهازك)\n")
            try {
                @Suppress("DEPRECATION")
                val all = pm.getInstalledPackages(0)
                var count = 0
                for (p in all) {
                    val r = CertUtil.readInstalledPackageCert(pm, p.packageName)
                    if (r.found && r.sha256 == platformSha) {
                        count++
                        if (count <= 60) sb.append("  - ").append(p.packageName).append("\n")
                    }
                }
                sb.append("العدد الإجمالي: ").append(count).append(if (count > 60) " (عُرض أول 60 فقط)" else "").append("\n")
            } catch (e: Exception) {
                sb.append("تعذّر فحص كل التطبيقات: ").append(e.message).append("\n")
            }
        } else {
            sb.append("تعذّرت قراءة شهادة النظام الأساسي نفسه (\"android\") - غير متوقع، أخبرني بنص الخطأ أعلاه.\n")
        }

        return sb.toString()
    }
}
