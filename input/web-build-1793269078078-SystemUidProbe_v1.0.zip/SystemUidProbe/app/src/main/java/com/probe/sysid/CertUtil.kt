package com.probe.sysid

import android.content.pm.PackageInfo
import android.content.pm.PackageManager
import android.content.pm.Signature
import android.os.Build
import java.io.ByteArrayInputStream
import java.security.MessageDigest
import java.security.cert.CertificateFactory
import java.security.cert.X509Certificate

/**
 * أدوات قراءة شهادة توقيع أي حزمة مثبتة على الجهاز، عبر PackageManager العادي
 * (لا حاجة لقراءة ملفات APK يدوياً، ولا لأي صلاحية خاصة - هذا مسموح لأي تطبيق عادي).
 *
 * أهم استخدام هنا: الحزمة الخاصة "android" تمثل النظام الأساسي نفسه (platform) -
 * شهادتها هي بالضبط الشهادة التي يجب أن تطابقها أي حزمة أخرى تريد الانضمام إلى
 * android.uid.system (sharedUserId). مقارنة هذه الشهادة بشهادة أي تطبيق آخر (مثل
 * SunRay أو أي تطبيق نظامي) تخبرنا مباشرة هل ذلك التطبيق موقّع فعلاً بنفس مفتاح
 * النظام الحقيقي أم لا - بدون أي تخمين.
 */
object CertUtil {

    data class CertReport(
        val packageName: String,
        val found: Boolean,
        val subject: String = "",
        val issuer: String = "",
        val serial: String = "",
        val sha256: String = "",
        val error: String = ""
    )

    private fun describe(t: Throwable): String {
        val name = t.javaClass.simpleName
        val msg = t.message
        return if (msg.isNullOrBlank()) name else "$name: $msg"
    }

    private fun sha256Hex(bytes: ByteArray): String {
        val d = MessageDigest.getInstance("SHA-256").digest(bytes)
        return d.joinToString(":") { String.format("%02X", it) }
    }

    private fun toX509(raw: ByteArray): X509Certificate {
        val cf = CertificateFactory.getInstance("X.509")
        return cf.generateCertificate(ByteArrayInputStream(raw)) as X509Certificate
    }

    private fun firstSignature(pm: PackageManager, packageName: String): Signature? {
        return if (Build.VERSION.SDK_INT >= 28) {
            val info: PackageInfo = pm.getPackageInfo(packageName, PackageManager.GET_SIGNING_CERTIFICATES)
            val si = info.signingInfo ?: return null
            // apkContentsSigners يعطي دائماً الشهادة (الشهادات) الفعلية الحالية التي وُقّع بها
            // محتوى الـ APK، سواء كان موقّعاً بموقّع واحد أو عدة موقّعين (rotation) - وهذا بالضبط
            // ما تقارنه أندرويد عند التحقق من تطابق sharedUserId.
            si.apkContentsSigners?.firstOrNull()
        } else {
            @Suppress("DEPRECATION")
            val info: PackageInfo = pm.getPackageInfo(packageName, PackageManager.GET_SIGNATURES)
            @Suppress("DEPRECATION")
            info.signatures?.firstOrNull()
        }
    }

    /** يقرأ شهادة حزمة مثبتة بالاسم (مثلاً "android" للنظام نفسه). لا يرمي استثناء أبداً. */
    fun readInstalledPackageCert(pm: PackageManager, packageName: String): CertReport {
        return try {
            val sig = firstSignature(pm, packageName)
                ?: return CertReport(packageName, found = false, error = "لا توجد شهادة توقيع (null)")
            val cert = toX509(sig.toByteArray())
            CertReport(
                packageName = packageName,
                found = true,
                subject = cert.subjectDN?.toString() ?: "?",
                issuer = cert.issuerDN?.toString() ?: "?",
                serial = cert.serialNumber?.toString(16) ?: "?",
                sha256 = sha256Hex(cert.encoded)
            )
        } catch (e: PackageManager.NameNotFoundException) {
            CertReport(packageName, found = false, error = "الحزمة غير مثبتة على هذا الجهاز")
        } catch (e: Exception) {
            CertReport(packageName, found = false, error = describe(e))
        }
    }
}
