package com.onehub.floatgauge;

import android.app.AppOpsManager;
import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.app.usage.UsageStats;
import android.app.usage.UsageStatsManager;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.PixelFormat;
import android.os.Build;
import android.os.Handler;
import android.os.IBinder;
import android.os.Looper;
import android.os.Process;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.MotionEvent;
import android.view.ScaleGestureDetector;
import android.view.View;
import android.view.WindowManager;
import android.widget.FrameLayout;
import android.widget.Toast;

import androidx.core.app.NotificationCompat;

import java.util.HashSet;
import java.util.List;
import java.util.Set;
import java.util.SortedMap;
import java.util.TreeMap;

/**
 * Floating OneHub speedo.
 * Size math matches original f2: width = size * r[style] * q[style], height = size * r[style]
 * Pinch = zoom, long-press = drag + red X close. No bottom toolbar.
 */
public class FloatService extends Service implements CarDataReader.Listener {

    public static final String ACTION_START = "START";
    public static final String ACTION_STOP = "STOP";
    private static final String CH = "float_gauge";
    private static final int NID = 42;
    private static final String PREFS = "onehub_float";
    private static final long LONG_MS = 450;
    private static final long EDIT_MS = 5000;

    private WindowManager wm;
    private View root;
    private View btnCloseTop;
    private WindowManager.LayoutParams params;
    private FrameLayout content;
    private SpeedoView speedo;
    private CarDataReader reader;
    /** Base size in dp – maps to original spd_s */
    private int baseDp = 280;
    private float pinch = 1f;
    private final Handler handler = new Handler(Looper.getMainLooper());

    private boolean editMode;
    private boolean dragging;
    private boolean hiddenForApp;
    private int ix, iy;
    private float downX, downY, itx, ity;
    private ScaleGestureDetector scaleDetector;
    private final Runnable hideEdit = () -> setEditMode(false);
    private final Runnable pollFg = this::checkForegroundApp;

    @Override
    public IBinder onBind(Intent i) { return null; }

    @Override
    public void onCreate() {
        super.onCreate();
        wm = (WindowManager) getSystemService(WINDOW_SERVICE);
        if (Build.VERSION.SDK_INT >= 26) {
            NotificationChannel c = new NotificationChannel(CH, "OneHub Float", NotificationManager.IMPORTANCE_LOW);
            NotificationManager nm = getSystemService(NotificationManager.class);
            if (nm != null) nm.createNotificationChannel(c);
        }
        scaleDetector = new ScaleGestureDetector(this, new ScaleGestureDetector.SimpleOnScaleGestureListener() {
            @Override
            public boolean onScale(ScaleGestureDetector d) {
                pinch *= d.getScaleFactor();
                pinch = Math.max(0.5f, Math.min(2.2f, pinch));
                getSharedPreferences(PREFS, MODE_PRIVATE).edit().putFloat("pinch", pinch).apply();
                relayout();
                return true;
            }
        });
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        SharedPreferences p = getSharedPreferences(PREFS, MODE_PRIVATE);
        if (intent != null && ACTION_STOP.equals(intent.getAction())) {
            stopAll();
            return START_NOT_STICKY;
        }
        if (root == null) {
            baseDp = p.getInt("size", 280);
            pinch = p.getFloat("pinch", 1f);
            show();
            reader = new CarDataReader(this, this);
            reader.start();
            handler.post(pollFg);
        }
        startForeground(NID, notif());
        return START_STICKY;
    }

    private void show() {
        root = LayoutInflater.from(this).inflate(R.layout.float_root, null);
        content = root.findViewById(R.id.content);
        btnCloseTop = root.findViewById(R.id.btn_close_top);
        speedo = new SpeedoView(this);
        SharedPreferences p = getSharedPreferences(PREFS, MODE_PRIVATE);
        speedo.setStyle(p.getInt("style", 0));
        speedo.setThemeIndex(p.getInt("theme", 0));
        content.addView(speedo, new FrameLayout.LayoutParams(
                FrameLayout.LayoutParams.MATCH_PARENT, FrameLayout.LayoutParams.MATCH_PARENT));

        int type = Build.VERSION.SDK_INT >= 26
                ? WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
                : WindowManager.LayoutParams.TYPE_PHONE;

        int[] wh = sizeFor();
        params = new WindowManager.LayoutParams(wh[0], wh[1], type,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE | WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
                PixelFormat.TRANSLUCENT);
        params.gravity = Gravity.TOP | Gravity.START;
        params.x = 30;
        params.y = 60;
        applyContentSize(wh[0], wh[1]);

        root.setOnTouchListener(this::onRootTouch);
        if (btnCloseTop != null) {
            btnCloseTop.setOnClickListener(v -> {
                getSharedPreferences(PREFS, MODE_PRIVATE).edit().putBoolean("on", false).apply();
                stopAll();
            });
        }

        try {
            wm.addView(root, params);
        } catch (Exception e) {
            Toast.makeText(this, "امنح إذن الظهور فوق التطبيقات", Toast.LENGTH_LONG).show();
            stopSelf();
        }
    }

    private boolean onRootTouch(View v, MotionEvent e) {
        scaleDetector.onTouchEvent(e);
        if (scaleDetector.isInProgress()) {
            handler.removeCallbacksAndMessages(null);
            return true;
        }
        switch (e.getActionMasked()) {
            case MotionEvent.ACTION_DOWN:
                downX = e.getX();
                downY = e.getY();
                itx = e.getRawX();
                ity = e.getRawY();
                ix = params.x;
                iy = params.y;
                dragging = false;
                handler.postDelayed(() -> {
                    setEditMode(true);
                    dragging = true;
                }, LONG_MS);
                return true;
            case MotionEvent.ACTION_MOVE:
                if (dragging || editMode) {
                    handler.removeCallbacks(hideEdit);
                    params.x = ix + (int) (e.getRawX() - itx);
                    params.y = iy + (int) (e.getRawY() - ity);
                    try { wm.updateViewLayout(root, params); } catch (Exception ignored) {}
                    return true;
                }
                if (Math.hypot(e.getRawX() - itx, e.getRawY() - ity) > dp(14)) {
                    handler.removeCallbacksAndMessages(null);
                }
                return true;
            case MotionEvent.ACTION_UP:
            case MotionEvent.ACTION_CANCEL:
                handler.removeCallbacksAndMessages(null);
                if (!dragging && !editMode) handleGaugeTap(downX, downY);
                if (editMode) bumpEdit();
                dragging = false;
                return true;
        }
        return false;
    }

    private void handleGaugeTap(float x, float y) {
        if (speedo == null) return;
        int w = speedo.getWidth();
        int h = speedo.getHeight();
        if (w <= 0 || h <= 0) return;
        if (y < h * 0.72f) return;
        if (x < w * 0.5f) {
            speedo.nextTheme();
            getSharedPreferences(PREFS, MODE_PRIVATE).edit()
                    .putInt("theme", speedo.getThemeIndex()).apply();
        } else {
            speedo.nextStyle();
            getSharedPreferences(PREFS, MODE_PRIVATE).edit()
                    .putInt("style", speedo.getStyle()).apply();
            relayout();
        }
    }

    private void setEditMode(boolean on) {
        editMode = on;
        if (btnCloseTop != null) btnCloseTop.setVisibility(on ? View.VISIBLE : View.GONE);
        if (on) bumpEdit();
    }

    private void bumpEdit() {
        handler.removeCallbacks(hideEdit);
        handler.postDelayed(hideEdit, EDIT_MS);
    }

    /**
     * Match OneHub f2.b():
     *   height = size * r[style]
     *   width  = height * q[style]   (= size * r * q)
     */
    private int[] sizeFor() {
        float[] rArr = SpeedoEngine.f1038r;
        float[] qArr = SpeedoEngine.f1037q;
        int si = speedo != null ? speedo.getStyle() : 0;
        float r = (si >= 0 && si < rArr.length) ? rArr[si] : 1f;
        float q = (si >= 0 && si < qArr.length) ? qArr[si] : 1f;
        if (r < 0.5f) r = 0.5f;
        if (q < 0.8f) q = 0.8f;

        float sizePx = dp(baseDp) * pinch;
        int height = Math.round(sizePx * r);
        int width = Math.round(sizePx * r * q);

        // Extra padding so engine-drawn side gauges / buttons are not clipped
        int pad = dp(12);
        int closePad = editMode ? dp(8) : 0;
        width = Math.max(width + pad * 2, dp(180));
        height = Math.max(height + pad * 2 + closePad, dp(140));
        return new int[]{width, height};
    }

    private void applyContentSize(int totalW, int totalH) {
        FrameLayout.LayoutParams lp = (FrameLayout.LayoutParams) content.getLayoutParams();
        lp.width = totalW;
        lp.height = totalH;
        lp.topMargin = 0;
        content.setLayoutParams(lp);
    }

    private void relayout() {
        if (params == null || root == null) return;
        int[] wh = sizeFor();
        params.width = wh[0];
        params.height = wh[1];
        applyContentSize(wh[0], wh[1]);
        try { wm.updateViewLayout(root, params); } catch (Exception ignored) {}
    }

    private Set<String> excludedPackages() {
        String raw = getSharedPreferences(PREFS, MODE_PRIVATE).getString("exclude", "");
        Set<String> set = new HashSet<>();
        if (raw != null && !raw.isEmpty()) {
            for (String s : raw.split(",")) {
                s = s.trim();
                if (!s.isEmpty()) set.add(s);
            }
        }
        return set;
    }

    private boolean hasUsageAccess() {
        try {
            AppOpsManager ops = (AppOpsManager) getSystemService(APP_OPS_SERVICE);
            int mode = ops.checkOpNoThrow(AppOpsManager.OPSTR_GET_USAGE_STATS, Process.myUid(), getPackageName());
            return mode == AppOpsManager.MODE_ALLOWED;
        } catch (Throwable t) {
            return false;
        }
    }

    private String foregroundPackage() {
        if (!hasUsageAccess()) return null;
        try {
            UsageStatsManager usm = (UsageStatsManager) getSystemService(USAGE_STATS_SERVICE);
            long now = System.currentTimeMillis();
            List<UsageStats> stats = usm.queryUsageStats(UsageStatsManager.INTERVAL_DAILY, now - 60_000, now);
            if (stats == null || stats.isEmpty()) return null;
            SortedMap<Long, UsageStats> sorted = new TreeMap<>();
            for (UsageStats u : stats) sorted.put(u.getLastTimeUsed(), u);
            if (sorted.isEmpty()) return null;
            return sorted.get(sorted.lastKey()).getPackageName();
        } catch (Throwable t) {
            return null;
        }
    }

    private void checkForegroundApp() {
        try {
            Set<String> ex = excludedPackages();
            if (!ex.isEmpty()) {
                String fg = foregroundPackage();
                boolean hide = fg != null && ex.contains(fg);
                if (hide != hiddenForApp) {
                    hiddenForApp = hide;
                    if (root != null) root.setVisibility(hide ? View.GONE : View.VISIBLE);
                }
            } else if (hiddenForApp) {
                hiddenForApp = false;
                if (root != null) root.setVisibility(View.VISIBLE);
            }
        } catch (Throwable ignored) {
        }
        handler.postDelayed(pollFg, 1500);
    }

    @Override
    public void onData(float speed, int gearIdx, int batt, int fuel, int powerKw, int tempOut, int tempBatt, boolean fromCar) {
        if (speedo != null) {
            speedo.setData(speed, gearIdx, batt, fuel, powerKw, tempOut, tempBatt);
        }
    }

    private void stopAll() {
        handler.removeCallbacksAndMessages(null);
        if (reader != null) { reader.stop(); reader = null; }
        if (root != null) {
            try { wm.removeView(root); } catch (Exception ignored) {}
            root = null;
        }
        stopForeground(true);
        stopSelf();
    }

    private Notification notif() {
        Intent stop = new Intent(this, FloatService.class).setAction(ACTION_STOP);
        PendingIntent pi = PendingIntent.getService(this, 0, stop,
                PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
        Intent open = new Intent(this, MainActivity.class);
        PendingIntent oi = PendingIntent.getActivity(this, 1, open,
                PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
        return new NotificationCompat.Builder(this, CH)
                .setContentTitle("OneHub Float")
                .setContentText("قرص للتكبير · ضغط مطوّل للسحب و✕")
                .setSmallIcon(android.R.drawable.ic_menu_compass)
                .setContentIntent(oi)
                .addAction(0, "إيقاف", pi)
                .setOngoing(true)
                .setPriority(NotificationCompat.PRIORITY_LOW)
                .build();
    }

    private int dp(int v) {
        return Math.round(v * getResources().getDisplayMetrics().density);
    }

    @Override
    public void onDestroy() {
        handler.removeCallbacksAndMessages(null);
        if (reader != null) reader.stop();
        if (root != null) {
            try { wm.removeView(root); } catch (Exception ignored) {}
        }
        super.onDestroy();
    }
}
