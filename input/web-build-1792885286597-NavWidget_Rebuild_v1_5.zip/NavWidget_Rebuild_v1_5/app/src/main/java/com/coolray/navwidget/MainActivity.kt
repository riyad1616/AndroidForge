package com.coolray.navwidget

import android.Manifest
import android.app.Activity
import android.app.AppOpsManager
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Color
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import android.widget.Button
import android.widget.LinearLayout
import android.widget.RadioButton
import android.widget.RadioGroup
import android.widget.ScrollView
import android.widget.Switch
import android.widget.TextView

class MainActivity : Activity() {
    private val prefs by lazy { getSharedPreferences("nav_widget", Context.MODE_PRIVATE) }
    private var root: LinearLayout? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        render()
    }

    override fun onResume() {
        super.onResume()
        if (root != null) render()
    }

    private fun render() {
        val container = LinearLayout(this)
        container.orientation = LinearLayout.VERTICAL
        container.setPadding(24, 22, 24, 24)
        container.setBackgroundColor(Color.rgb(15, 23, 42))
        root = container

        fun label(s: String, accent: Boolean): TextView {
            val t = TextView(this)
            t.text = s
            t.textSize = 14f
            t.setTextColor(if (accent) Color.rgb(85, 153, 255) else Color.LTGRAY)
            t.setPadding(0, 16, 0, 7)
            return t
        }

        fun line(s: String): TextView {
            val t = TextView(this)
            t.text = s
            t.setTextColor(Color.WHITE)
            return t
        }

        fun button(s: String, action: () -> Unit): Button {
            val b = Button(this)
            b.text = s
            b.setOnClickListener { action() }
            return b
        }

        val title = TextView(this)
        title.text = "Nav Widget 1.5"
        title.textSize = 25f
        title.setTextColor(Color.WHITE)
        container.addView(title)

        val subtitle = TextView(this)
        subtitle.text = "Floating navigation card"
        subtitle.textSize = 14f
        subtitle.setTextColor(Color.LTGRAY)
        container.addView(subtitle)

        container.addView(label("PERMISSIONS", true))

        container.addView(line("Overlay: " + (if (Settings.canDrawOverlays(this)) "Allowed" else "Required")))
        container.addView(button("OPEN overlay permission") {
            startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:" + packageName)))
        })

        container.addView(line("Notification access: " + (if (notificationAccessEnabled()) "Allowed" else "Required")))
        container.addView(button("OPEN notification access") {
            startActivity(Intent("android.settings.ACTION_NOTIFICATION_LISTENER_SETTINGS"))
        })

        container.addView(line("Usage access (needed for auto-hide): " + (if (usageAccessEnabled()) "Allowed" else "Required")))
        container.addView(button("OPEN usage access") {
            startActivity(Intent(Settings.ACTION_USAGE_ACCESS_SETTINGS))
        })

        container.addView(line("Location (speed + GPS status): " + (if (locationGranted()) "Allowed" else "Required")))
        container.addView(button("GRANT location permission") {
            requestPermissions(arrayOf(Manifest.permission.ACCESS_FINE_LOCATION), 7)
        })
        container.addView(button("OPEN app settings (if the dialog does not appear)") {
            startActivity(Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:" + packageName)))
        })

        container.addView(label("WIDGET", true))

        val showSwitch = Switch(this)
        showSwitch.text = "Show floating card"
        showSwitch.setTextColor(Color.WHITE)
        showSwitch.isChecked = prefs.getBoolean("enabled", false)
        showSwitch.setOnCheckedChangeListener { _, checked ->
            prefs.edit().putBoolean("enabled", checked).apply()
            if (checked) {
                startWidget(false)
            } else {
                stopService(Intent(this@MainActivity, FloatingWidgetService::class.java))
            }
        }
        container.addView(showSwitch)

        val hideSwitch = Switch(this)
        hideSwitch.text = "Hide card when Maps is in foreground"
        hideSwitch.setTextColor(Color.WHITE)
        hideSwitch.isChecked = prefs.getBoolean("hide_maps", false)
        hideSwitch.setOnCheckedChangeListener { _, checked ->
            prefs.edit().putBoolean("hide_maps", checked).apply()
        }
        container.addView(hideSwitch)

        val limitSwitch = Switch(this)
        limitSwitch.text = "Show speed limit (online, OpenStreetMap)"
        limitSwitch.setTextColor(Color.WHITE)
        limitSwitch.isChecked = prefs.getBoolean("show_limit", true)
        limitSwitch.setOnCheckedChangeListener { _, checked ->
            prefs.edit().putBoolean("show_limit", checked).apply()
        }
        container.addView(limitSwitch)

        container.addView(label("SIZE", true))
        val group = RadioGroup(this)
        group.orientation = RadioGroup.HORIZONTAL
        val sizeNames = listOf("Small", "Normal", "Large")
        val currentSize = prefs.getInt("size", 1)
        for (i in sizeNames.indices) {
            val rb = RadioButton(this)
            rb.text = sizeNames[i]
            rb.setTextColor(Color.WHITE)
            rb.id = 200 + i
            rb.isChecked = (currentSize == i)
            group.addView(rb)
        }
        group.setOnCheckedChangeListener { _, checkedId ->
            prefs.edit().putInt("size", checkedId - 200).apply()
            if (prefs.getBoolean("enabled", false)) startWidget(false)
        }
        container.addView(group)

        container.addView(button("PREVIEW") { startWidget(true) })
        container.addView(button("RESET POSITION") {
            prefs.edit().remove("x").remove("y").apply()
            if (Settings.canDrawOverlays(this)) startWidget(true)
        })

        container.addView(label("LAST NAVIGATION NOTICE", true))
        val last = TextView(this)
        val lastText = prefs.getString("navigation_text", "").orEmpty()
        last.text = if (lastText.isBlank()) "Waiting for a Google Maps navigation notification." else lastText
        last.setTextColor(Color.LTGRAY)
        last.textSize = 12f
        container.addView(last)

        container.addView(label("RAW NOTIFICATION (send this if the card shows wrong data)", true))
        val raw = TextView(this)
        val rawText = prefs.getString("navigation_raw", "").orEmpty()
        raw.text = if (rawText.isBlank()) "-" else rawText
        raw.setTextColor(Color.GRAY)
        raw.textSize = 11f
        container.addView(raw)

        val scroll = ScrollView(this)
        scroll.addView(container)
        setContentView(scroll)
    }

    private fun notificationAccessEnabled(): Boolean {
        val s = Settings.Secure.getString(contentResolver, "enabled_notification_listeners").orEmpty()
        return s.contains(packageName)
    }

    private fun usageAccessEnabled(): Boolean {
        val appOps = getSystemService(Context.APP_OPS_SERVICE) as AppOpsManager
        return try {
            appOps.checkOpNoThrow("android:get_usage_stats", android.os.Process.myUid(), packageName) ==
                AppOpsManager.MODE_ALLOWED
        } catch (e: Exception) {
            false
        }
    }

    private fun locationGranted(): Boolean {
        return checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED
    }

    private fun startWidget(preview: Boolean) {
        if (!Settings.canDrawOverlays(this)) {
            startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:" + packageName)))
            return
        }
        startService(Intent(this, FloatingWidgetService::class.java).putExtra("preview", preview))
    }
}
