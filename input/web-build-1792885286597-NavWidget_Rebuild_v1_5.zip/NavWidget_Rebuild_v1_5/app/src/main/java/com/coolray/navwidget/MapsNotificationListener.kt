package com.coolray.navwidget

import android.app.Notification
import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.drawable.Drawable
import android.graphics.drawable.Icon
import android.os.Bundle
import android.service.notification.NotificationListenerService
import android.service.notification.StatusBarNotification
import android.view.View
import android.view.ViewGroup
import android.widget.FrameLayout
import android.widget.RemoteViews
import android.widget.TextView

class MapsNotificationListener : NotificationListenerService() {

    companion object {
        private const val MAPS_PACKAGE = "com.google.android.apps.maps"
    }

    override fun onNotificationPosted(sbn: StatusBarNotification) {
        if (sbn.packageName != MAPS_PACKAGE) return
        try {
            handlePosted(sbn)
        } catch (ignored: Exception) {
        }
    }

    override fun onNotificationRemoved(sbn: StatusBarNotification) {
        if (sbn.packageName != MAPS_PACKAGE) return
        if (!isNavigation(sbn)) return
        NavStore.maneuver = null
        val ed = getSharedPreferences("nav_widget", Context.MODE_PRIVATE).edit()
        ed.putString("navigation_text", "")
        ed.putString("nav_distance", "")
        ed.putString("nav_instruction", "")
        ed.putString("nav_street", "")
        ed.putString("nav_next", "")
        ed.putString("nav_remaining", "")
        ed.putString("nav_duration", "")
        ed.putString("nav_eta", "")
        ed.apply()
        sendBroadcast(Intent(FloatingWidgetService.ACTION_REFRESH).setPackage(packageName))
    }

    private fun isNavigation(sbn: StatusBarNotification): Boolean {
        val n = sbn.notification
        val ongoing = (n.flags and Notification.FLAG_ONGOING_EVENT) != 0
        return ongoing || n.category == Notification.CATEGORY_NAVIGATION
    }

    private fun handlePosted(sbn: StatusBarNotification) {
        val n = sbn.notification
        val extras = n.extras
        val prefs = getSharedPreferences("nav_widget", Context.MODE_PRIVATE)

        val extraLines = ArrayList<String>()
        val keys = listOf(
            "android.title", "android.text", "android.subText",
            "android.bigText", "android.infoText", "android.summaryText"
        )
        for (key in keys) {
            val s = extras.getCharSequence(key)?.toString()?.trim()
            if (s != null && s.isNotEmpty()) extraLines.add(s)
        }
        val textLines = extras.getCharSequenceArray("android.textLines")
        if (textLines != null) {
            for (c in textLines) {
                val s = c?.toString()?.trim()
                if (s != null && s.isNotEmpty()) extraLines.add(s)
            }
        }

        val viewLines = collectViewTexts(n)
        val dump = dumpExtras(n, extras, viewLines)

        if (!isNavigation(sbn)) {
            // نحفظ السجل فقط لمساعدة التشخيص ولا نغيّر البطاقة بإشعار ليس ملاحة
            prefs.edit().putString("navigation_raw", dump).apply()
            return
        }

        var lines: List<String> = extraLines.distinct()
        var info = NavParser.parse(lines)
        if (info.instruction.isEmpty() && viewLines.isNotEmpty()) {
            lines = (extraLines + viewLines).distinct()
            info = NavParser.parse(lines)
        }

        val icon: Icon? = n.getLargeIcon()
        if (icon != null) {
            try {
                val drawable = icon.loadDrawable(this)
                if (drawable != null) {
                    val bmp = drawableToBitmap(drawable)
                    if (bmp != null) NavStore.maneuver = bmp
                }
            } catch (ignored: Exception) {
            }
        }

        val ed = prefs.edit()
        ed.putString("navigation_text", lines.joinToString("\n"))
        ed.putString("navigation_raw", dump)
        ed.putString("nav_distance", info.distance)
        ed.putString("nav_instruction", info.instruction)
        ed.putString("nav_street", info.street)
        ed.putString("nav_next", info.next)
        ed.putString("nav_remaining", info.remaining)
        ed.putString("nav_duration", info.duration)
        ed.putString("nav_eta", info.eta)
        ed.apply()
        sendBroadcast(Intent(FloatingWidgetService.ACTION_REFRESH).setPackage(packageName))
    }

    private fun drawableToBitmap(d: Drawable): Bitmap? {
        val w = if (d.intrinsicWidth > 0) d.intrinsicWidth else 96
        val h = if (d.intrinsicHeight > 0) d.intrinsicHeight else 96
        val bmp = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
        val canvas = Canvas(bmp)
        d.setBounds(0, 0, w, h)
        d.draw(canvas)
        return bmp
    }

    /** نصوص الواجهة المخصصة في الإشعار (RemoteViews) إن وُجدت، عبر reflection حتى لا نعتمد على واجهة مخفية. */
    private fun collectViewTexts(n: Notification): List<String> {
        val out = ArrayList<String>()
        val fieldNames = listOf("bigContentView", "contentView")
        for (name in fieldNames) {
            try {
                val field = Notification::class.java.getField(name)
                val rv = field.get(n) as? RemoteViews
                if (rv != null) {
                    val holder = FrameLayout(this)
                    val root = rv.apply(this, holder)
                    collectTexts(root, out)
                }
            } catch (t: Throwable) {
            }
        }
        return out
    }

    private fun collectTexts(v: View?, out: MutableList<String>) {
        if (v is TextView) {
            val s = v.text?.toString()?.trim()
            if (s != null && s.isNotEmpty()) out.add(s)
        } else if (v is ViewGroup) {
            for (i in 0 until v.childCount) {
                collectTexts(v.getChildAt(i), out)
            }
        }
    }

    @Suppress("DEPRECATION")
    private fun dumpExtras(n: Notification, extras: Bundle, viewLines: List<String>): String {
        val sb = StringBuilder()
        val ongoing = (n.flags and Notification.FLAG_ONGOING_EVENT) != 0
        sb.append("ongoing=").append(ongoing).append(" category=").append(n.category).append('\n')
        for (key in extras.keySet()) {
            val v: Any? = extras.get(key)
            val s: String = when (v) {
                null -> "null"
                is CharSequence -> v.toString()
                is Bitmap -> "Bitmap"
                is Icon -> "Icon"
                is Bundle -> "Bundle"
                is Array<*> -> "[" + v.joinToString("|") + "]"
                else -> v.toString()
            }
            sb.append(key).append('=').append(s.take(120)).append('\n')
        }
        if (viewLines.isNotEmpty()) {
            sb.append("views=").append(viewLines.joinToString(" | ").take(400)).append('\n')
        }
        return sb.toString().take(1800)
    }
}
