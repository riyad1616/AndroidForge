package com.coolray.navwidget

import android.graphics.Bitmap

/** آخر أيقونة منعطف استلمناها من إشعار Google Maps (في الذاكرة فقط). */
object NavStore {
    @Volatile
    var maneuver: Bitmap? = null
}

data class NavInfo(
    val distance: String = "",
    val instruction: String = "",
    val street: String = "",
    val next: String = "",
    val remaining: String = "",
    val duration: String = "",
    val eta: String = ""
)

/**
 * يحوّل أسطر نص إشعار Google Maps إلى حقول. الإشعار لا يوثّق شكله، لذلك التصنيف
 * يعتمد على شكل النص (مسافة، مدة، ساعة) وليس على اسم الحقل.
 */
object NavParser {
    private const val UNIT = "(?:km|كم|mi|ft|yd|متر|m|م)"

    private val turnDistance = Regex("^\\p{L}{0,6}\\s*\\d+(?:[.,]\\d+)?\\s*" + UNIT + "\\.?$", RegexOption.IGNORE_CASE)
    private val remainingDistance = Regex("^\\d+(?:[.,]\\d+)?\\s*" + UNIT + "\\.?$", RegexOption.IGNORE_CASE)
    private val timeOfDay = Regex("(\\d{1,2}):(\\d{2})\\s*(?:[AaPp][Mm])?")
    private val durationWord = Regex(
        "\\d+\\s*(?:min|mins|mn|minutes|minute|دقيقة|دقائق|د|hr|hrs|h|hour|hours|ساعة|ساعات|س)",
        RegexOption.IGNORE_CASE
    )

    /** يحوّل الأرقام العربية-الهندية والفارسية إلى أرقام لاتينية (بنفس الطول) للمطابقة فقط. */
    fun normalizeDigits(s: String): String {
        val sb = StringBuilder(s.length)
        for (ch in s) {
            if (ch in '٠'..'٩') {
                sb.append('0' + (ch - '٠'))
            } else if (ch in '۰'..'۹') {
                sb.append('0' + (ch - '۰'))
            } else if (ch == '٫') {
                sb.append('.')
            } else if (ch == '٬') {
                sb.append(',')
            } else {
                sb.append(ch)
            }
        }
        return sb.toString()
    }

    private fun splitTokens(line: String): List<String> {
        val parts = line.split("·", "•", "|", "،")
        val out = ArrayList<String>()
        for (p in parts) {
            val t = p.trim()
            if (t.isNotEmpty()) out.add(t)
        }
        return out
    }

    private fun isInfoToken(normalized: String): Boolean {
        if (timeOfDay.containsMatchIn(normalized)) return true
        if (remainingDistance.matches(normalized)) return true
        if (normalized.length <= 18 && durationWord.containsMatchIn(normalized)) return true
        return false
    }

    fun parse(rawLines: List<String>): NavInfo {
        var distance = ""
        var remaining = ""
        var duration = ""
        var eta = ""
        val text = ArrayList<String>()

        for (raw in rawLines) {
            val line = raw.trim()
            if (line.isEmpty()) continue
            if (line.equals("Google Maps", ignoreCase = true) || line.equals("Maps", ignoreCase = true)) continue

            val normalizedLine = normalizeDigits(line)
            val tokens = splitTokens(line)

            // سطر معلومات الرحلة مثل: 16 min · 8.4 km · 18:42
            if (tokens.size >= 2 && tokens.all { isInfoToken(normalizeDigits(it)) }) {
                for (tk in tokens) {
                    val n = normalizeDigits(tk)
                    val tm = timeOfDay.find(n)
                    if (tm != null) {
                        if (eta.isEmpty()) eta = tm.value.trim()
                    } else if (remainingDistance.matches(n)) {
                        if (remaining.isEmpty()) remaining = tk
                    } else {
                        if (duration.isEmpty()) duration = tk
                    }
                }
                continue
            }

            // سطر مسافة فقط مثل: 600 m
            if (turnDistance.matches(normalizedLine)) {
                if (distance.isEmpty()) {
                    distance = line
                } else if (remaining.isEmpty()) {
                    remaining = line
                }
                continue
            }

            // سطر فيه ساعة الوصول أو المدة وحدها
            if (tokens.size == 1) {
                val tm = timeOfDay.find(normalizedLine)
                if (tm != null) {
                    if (eta.isEmpty()) eta = tm.value.trim()
                    continue
                }
                if (normalizedLine.length <= 18 && durationWord.containsMatchIn(normalizedLine)) {
                    if (duration.isEmpty()) duration = line
                    continue
                }
            }

            text.add(line)
        }

        val instruction = text.getOrElse(0) { "" }
        val street = text.getOrElse(1) { "" }
        val next = if (text.size > 2) text.drop(2).joinToString(" ") else ""
        return NavInfo(distance, instruction, street, next, remaining, duration, eta)
    }
}
