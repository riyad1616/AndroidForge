package com.coolray.navwidget

import android.Manifest
import android.annotation.SuppressLint
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.app.usage.UsageEvents
import android.app.usage.UsageStatsManager
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.PorterDuff
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.location.Location
import android.location.LocationListener
import android.location.LocationManager
import android.os.Bundle
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.provider.Settings
import android.text.TextUtils
import android.util.TypedValue
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.ViewGroup
import android.view.ViewOutlineProvider
import android.view.WindowManager
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder

class FloatingWidgetService : Service() {

    companion object {
        const val ACTION_REFRESH = "com.coolray.navwidget.REFRESH"
        private const val CHANNEL_ID = "nav_widget_service"
        private const val NOTIFICATION_ID = 41
        private const val MAPS_PACKAGE = "com.google.android.apps.maps"
    }

    /** كل عناصر البطاقة التي نحتاج تحديثها. */
    private class CardViews(
        val root: LinearLayout,
        val status: TextView,
        val distance: TextView,
        val instruction: TextView,
        val street: TextView,
        val arrowImage: ImageView,
        val arrowGlyph: TextView,
        val limitSign: TextView,
        val speedValue: TextView,
        val next: TextView,
        val nextDivider: View,
        val bottomBar: LinearLayout,
        val remaining: TextView,
        val duration: TextView,
        val dot: TextView,
        val eta: TextView
    )

    private val handler = Handler(Looper.getMainLooper())
    private val prefs by lazy { getSharedPreferences("nav_widget", Context.MODE_PRIVATE) }

    private var wm: WindowManager? = null
    private var card: LinearLayout? = null
    private var views: CardViews? = null
    private var params: WindowManager.LayoutParams? = null
    private var builtForSize = -1
    private var preview = false

    // السرعة وحد السرعة
    private var locationManager: LocationManager? = null
    private var locationStarted = false
    private var speedKmh = -1
    private var lastFixTime = 0L
    private var speedLimit = 0
    private var limitUpdatedAt = 0L
    private var fetching = false
    private var lastQueryTime = 0L
    private var lastQueryLat = 0.0
    private var lastQueryLon = 0.0

    private var cachedForegroundPackage = ""

    private val locationListener = object : LocationListener {
        override fun onLocationChanged(location: Location) {
            handleLocation(location)
        }

        override fun onStatusChanged(provider: String?, status: Int, extras: Bundle?) {
        }

        override fun onProviderEnabled(provider: String) {
        }

        override fun onProviderDisabled(provider: String) {
        }
    }

    private val foregroundCheck: Runnable = object : Runnable {
        override fun run() {
            val c = card
            if (c != null) {
                if (!preview && prefs.getBoolean("hide_maps", false) && usageAccessGranted()) {
                    c.visibility = if (isMapsForeground()) View.GONE else View.VISIBLE
                } else {
                    c.visibility = View.VISIBLE
                }
            }
            updateSpeedViews()
            handler.postDelayed(this, 1200L)
        }
    }

    private val receiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context?, intent: Intent?) {
            refreshContent()
        }
    }

    @Suppress("DEPRECATION")
    override fun onCreate() {
        super.onCreate()
        val filter = IntentFilter(ACTION_REFRESH)
        if (android.os.Build.VERSION.SDK_INT >= 33) {
            registerReceiver(receiver, filter, Context.RECEIVER_NOT_EXPORTED)
        } else {
            registerReceiver(receiver, filter)
        }
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        preview = intent?.getBooleanExtra("preview", false) ?: false
        if (!Settings.canDrawOverlays(this)) {
            stopSelf()
            return START_NOT_STICKY
        }
        startAsForeground()
        val sizePref = prefs.getInt("size", 1)
        if (card == null || builtForSize != sizePref) {
            removeCard()
            buildCard()
        }
        refreshContent()
        updateSpeedViews()
        startLocation()
        handler.removeCallbacks(foregroundCheck)
        handler.post(foregroundCheck)
        return START_STICKY
    }

    private fun startAsForeground() {
        try {
            val nm = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
            val channel = NotificationChannel(CHANNEL_ID, "Nav Widget", NotificationManager.IMPORTANCE_LOW)
            nm.createNotificationChannel(channel)
            val notification = Notification.Builder(this, CHANNEL_ID)
                .setContentTitle("Nav Widget")
                .setContentText("Floating navigation card is running")
                .setSmallIcon(android.R.drawable.ic_menu_mylocation)
                .setOngoing(true)
                .build()
            startForeground(NOTIFICATION_ID, notification)
        } catch (ignored: Exception) {
        }
    }

    // ---------------------------------------------------------------- البطاقة

    private fun cardWidthPx(): Int {
        val screenW = resources.displayMetrics.widthPixels
        val fraction = when (prefs.getInt("size", 1)) {
            0 -> 0.22f
            2 -> 0.36f
            else -> 0.28f
        }
        return Math.max((screenW * fraction).toInt(), 300)
    }

    private fun removeCard() {
        val c = card
        if (c != null) {
            try {
                wm?.removeView(c)
            } catch (ignored: Exception) {
            }
        }
        card = null
        views = null
    }

    private fun buildCard() {
        val widthPx = cardWidthPx()
        val u = widthPx / 400f
        val matchParent = ViewGroup.LayoutParams.MATCH_PARENT
        val wrapContent = ViewGroup.LayoutParams.WRAP_CONTENT

        fun d(v: Float): Int = Math.round(v * u)

        fun makeText(size: Float, color: Int, bold: Boolean): TextView {
            val t = TextView(this)
            t.setTextSize(TypedValue.COMPLEX_UNIT_PX, size * u)
            t.setTextColor(color)
            if (bold) t.typeface = Typeface.DEFAULT_BOLD
            t.includeFontPadding = false
            return t
        }

        fun makeDivider(): View {
            val v = View(this)
            v.setBackgroundColor(Color.argb(40, 255, 255, 255))
            return v
        }

        val cBg = Color.argb(245, 14, 22, 38)
        val cStroke = Color.rgb(36, 112, 88)
        val cGreen = Color.rgb(82, 190, 140)
        val cGray = Color.rgb(154, 165, 180)

        wm = getSystemService(Context.WINDOW_SERVICE) as WindowManager

        val root = LinearLayout(this)
        root.orientation = LinearLayout.VERTICAL
        val rootBg = GradientDrawable()
        rootBg.setColor(cBg)
        rootBg.cornerRadius = d(22f).toFloat()
        rootBg.setStroke(Math.max(1, d(1.5f)), cStroke)
        root.background = rootBg
        root.clipToOutline = true
        root.outlineProvider = ViewOutlineProvider.BACKGROUND

        // الصف العلوي: حالة GPS + شارة GOOGLE MAPS
        val top = LinearLayout(this)
        top.orientation = LinearLayout.HORIZONTAL
        top.gravity = Gravity.CENTER_VERTICAL
        top.setPadding(d(16f), d(11f), d(16f), d(11f))
        val status = makeText(12.5f, cGray, true)
        status.text = "GPS"
        top.addView(status, LinearLayout.LayoutParams(0, wrapContent, 1f))
        val pill = makeText(12f, cGreen, true)
        pill.text = "GOOGLE MAPS"
        pill.setPadding(d(14f), d(6f), d(14f), d(6f))
        val pillBg = GradientDrawable()
        pillBg.setColor(Color.argb(40, 82, 190, 140))
        pillBg.cornerRadius = d(20f).toFloat()
        pillBg.setStroke(Math.max(1, d(1f)), cStroke)
        pill.background = pillBg
        top.addView(pill, LinearLayout.LayoutParams(wrapContent, wrapContent))
        root.addView(top, LinearLayout.LayoutParams(matchParent, wrapContent))
        root.addView(makeDivider(), LinearLayout.LayoutParams(matchParent, Math.max(1, d(1f))))

        // الصف الرئيسي: [لافتة السرعة + السرعة الحالية] [المسافة والتعليمات] [السهم]
        val main = LinearLayout(this)
        main.orientation = LinearLayout.HORIZONTAL
        main.setPadding(d(16f), d(14f), d(16f), d(14f))

        val left = LinearLayout(this)
        left.orientation = LinearLayout.HORIZONTAL
        left.gravity = Gravity.TOP

        val limitSign = TextView(this)
        limitSign.setTextSize(TypedValue.COMPLEX_UNIT_PX, 16f * u)
        limitSign.setTextColor(Color.BLACK)
        limitSign.typeface = Typeface.DEFAULT_BOLD
        limitSign.gravity = Gravity.CENTER
        limitSign.includeFontPadding = false
        val limitBg = GradientDrawable()
        limitBg.setShape(GradientDrawable.OVAL)
        limitBg.setColor(Color.WHITE)
        limitBg.setStroke(Math.max(2, d(4f)), Color.rgb(220, 50, 50))
        limitSign.background = limitBg
        limitSign.visibility = View.GONE
        val limitLp = LinearLayout.LayoutParams(d(38f), d(38f))
        limitLp.rightMargin = d(8f)
        left.addView(limitSign, limitLp)

        val speedBox = LinearLayout(this)
        speedBox.orientation = LinearLayout.VERTICAL
        speedBox.gravity = Gravity.CENTER
        val boxBg = GradientDrawable()
        boxBg.setColor(Color.argb(50, 255, 255, 255))
        boxBg.cornerRadius = d(9f).toFloat()
        boxBg.setStroke(Math.max(1, d(1f)), Color.argb(70, 255, 255, 255))
        speedBox.background = boxBg
        val speedValue = makeText(20f, Color.WHITE, true)
        speedValue.text = "--"
        speedValue.gravity = Gravity.CENTER
        speedBox.addView(speedValue, LinearLayout.LayoutParams(wrapContent, wrapContent))
        val speedUnit = makeText(9.5f, cGray, false)
        speedUnit.text = "كم/ساعة"
        speedUnit.gravity = Gravity.CENTER
        speedBox.addView(speedUnit, LinearLayout.LayoutParams(wrapContent, wrapContent))
        left.addView(speedBox, LinearLayout.LayoutParams(d(50f), d(42f)))
        main.addView(left, LinearLayout.LayoutParams(wrapContent, wrapContent))

        val textCol = LinearLayout(this)
        textCol.orientation = LinearLayout.VERTICAL
        val distance = makeText(34f, cGreen, true)
        distance.gravity = Gravity.RIGHT
        distance.text = "—"
        textCol.addView(distance, LinearLayout.LayoutParams(matchParent, wrapContent))
        val instruction = makeText(16.5f, Color.WHITE, true)
        instruction.gravity = Gravity.RIGHT
        instruction.maxLines = 2
        instruction.ellipsize = TextUtils.TruncateAt.END
        val instructionLp = LinearLayout.LayoutParams(matchParent, wrapContent)
        instructionLp.topMargin = d(6f)
        textCol.addView(instruction, instructionLp)
        val street = makeText(13.5f, cGray, false)
        street.gravity = Gravity.RIGHT
        street.maxLines = 1
        street.ellipsize = TextUtils.TruncateAt.END
        val streetLp = LinearLayout.LayoutParams(matchParent, wrapContent)
        streetLp.topMargin = d(4f)
        textCol.addView(street, streetLp)
        val textColLp = LinearLayout.LayoutParams(0, wrapContent, 1f)
        textColLp.leftMargin = d(10f)
        textColLp.rightMargin = d(12f)
        main.addView(textCol, textColLp)

        val tile = FrameLayout(this)
        val tileBg = GradientDrawable()
        tileBg.setColor(cGreen)
        tileBg.cornerRadius = d(18f).toFloat()
        tile.background = tileBg
        val arrowImage = ImageView(this)
        arrowImage.scaleType = ImageView.ScaleType.FIT_CENTER
        arrowImage.setPadding(d(14f), d(14f), d(14f), d(14f))
        arrowImage.visibility = View.GONE
        tile.addView(arrowImage, FrameLayout.LayoutParams(matchParent, matchParent))
        val arrowGlyph = makeText(46f, Color.WHITE, true)
        arrowGlyph.text = "↑"
        arrowGlyph.gravity = Gravity.CENTER
        tile.addView(arrowGlyph, FrameLayout.LayoutParams(matchParent, matchParent))
        main.addView(tile, LinearLayout.LayoutParams(d(80f), d(80f)))
        root.addView(main, LinearLayout.LayoutParams(matchParent, wrapContent))

        // سطر "ثم ..." (يظهر فقط إن وُجد نص)
        val nextDivider = makeDivider()
        nextDivider.visibility = View.GONE
        root.addView(nextDivider, LinearLayout.LayoutParams(matchParent, Math.max(1, d(1f))))
        val next = makeText(13f, cGray, false)
        next.gravity = Gravity.RIGHT
        next.maxLines = 2
        next.ellipsize = TextUtils.TruncateAt.END
        next.setPadding(d(16f), d(10f), d(16f), d(10f))
        next.visibility = View.GONE
        root.addView(next, LinearLayout.LayoutParams(matchParent, wrapContent))

        // الشريط السفلي: المسافة المتبقية | المدة • وقت الوصول
        val bottom = LinearLayout(this)
        bottom.orientation = LinearLayout.HORIZONTAL
        bottom.gravity = Gravity.CENTER_VERTICAL
        bottom.setBackgroundColor(Color.argb(90, 0, 0, 0))
        bottom.setPadding(d(16f), d(10f), d(16f), d(10f))
        val remaining = makeText(15f, cGray, false)
        remaining.typeface = Typeface.MONOSPACE
        bottom.addView(remaining, LinearLayout.LayoutParams(0, wrapContent, 1f))
        val duration = makeText(14f, cGray, false)
        bottom.addView(duration, LinearLayout.LayoutParams(wrapContent, wrapContent))
        val dot = makeText(14f, cGray, false)
        dot.text = "  •  "
        bottom.addView(dot, LinearLayout.LayoutParams(wrapContent, wrapContent))
        val eta = makeText(17f, Color.WHITE, true)
        bottom.addView(eta, LinearLayout.LayoutParams(wrapContent, wrapContent))
        root.addView(bottom, LinearLayout.LayoutParams(matchParent, wrapContent))

        val lp = WindowManager.LayoutParams(
            widthPx,
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
            PixelFormat.TRANSLUCENT
        )
        lp.gravity = Gravity.TOP or Gravity.START
        lp.x = prefs.getInt("x", 30)
        lp.y = prefs.getInt("y", 180)

        var startX = 0
        var startY = 0
        var touchX = 0f
        var touchY = 0f
        root.setOnTouchListener { _, event ->
            when (event.action) {
                MotionEvent.ACTION_DOWN -> {
                    startX = lp.x
                    startY = lp.y
                    touchX = event.rawX
                    touchY = event.rawY
                    true
                }
                MotionEvent.ACTION_MOVE -> {
                    lp.x = startX + (event.rawX - touchX).toInt()
                    lp.y = startY + (event.rawY - touchY).toInt()
                    try {
                        wm?.updateViewLayout(root, lp)
                    } catch (ignored: Exception) {
                    }
                    true
                }
                MotionEvent.ACTION_UP -> {
                    prefs.edit().putInt("x", lp.x).putInt("y", lp.y).apply()
                    true
                }
                else -> false
            }
        }

        try {
            wm?.addView(root, lp)
        } catch (e: Exception) {
            stopSelf()
            return
        }

        card = root
        params = lp
        builtForSize = prefs.getInt("size", 1)
        views = CardViews(
            root, status, distance, instruction, street, arrowImage, arrowGlyph,
            limitSign, speedValue, next, nextDivider, bottom, remaining, duration, dot, eta
        )
    }

    // ---------------------------------------------------------------- المحتوى

    private fun previewInfo(): NavInfo {
        return NavInfo(
            distance = "600 m",
            instruction = "اتجه شمالاً على الشارع العام",
            street = "الشارع العام",
            next = "ثم بعد 600 م انعطف يميناً إلى طريق الملك فهد",
            remaining = "8.4 km",
            duration = "16 دقيقة",
            eta = "18:42"
        )
    }

    private fun loadInfo(): NavInfo {
        return NavInfo(
            distance = prefs.getString("nav_distance", "").orEmpty(),
            instruction = prefs.getString("nav_instruction", "").orEmpty(),
            street = prefs.getString("nav_street", "").orEmpty(),
            next = prefs.getString("nav_next", "").orEmpty(),
            remaining = prefs.getString("nav_remaining", "").orEmpty(),
            duration = prefs.getString("nav_duration", "").orEmpty(),
            eta = prefs.getString("nav_eta", "").orEmpty()
        )
    }

    private fun glyphFor(text: String): String {
        val t = text.lowercase()
        if (t.contains("u-turn") || t.contains("demi-tour") || t.contains("استدر") || t.contains("دوران")) return "↶"
        if (t.contains("left") || t.contains("gauche") || t.contains("يسار")) return "↰"
        if (t.contains("right") || t.contains("droite") || t.contains("يمين")) return "↱"
        return "↑"
    }

    private fun setOrHide(t: TextView, s: String) {
        if (s.isEmpty()) {
            t.visibility = View.GONE
        } else {
            t.text = s
            t.visibility = View.VISIBLE
        }
    }

    private fun refreshContent() {
        val v = views ?: return
        val info = if (preview) previewInfo() else loadInfo()

        v.distance.text = if (info.distance.isNotEmpty()) info.distance else "—"
        v.instruction.text = if (info.instruction.isNotEmpty()) info.instruction else "بانتظار الملاحة في Google Maps"
        setOrHide(v.street, info.street)
        setOrHide(v.next, info.next)
        v.nextDivider.visibility = v.next.visibility

        val hasBottom = info.remaining.isNotEmpty() || info.duration.isNotEmpty() || info.eta.isNotEmpty()
        v.bottomBar.visibility = if (hasBottom) View.VISIBLE else View.GONE
        v.remaining.text = info.remaining
        v.duration.text = info.duration
        v.eta.text = info.eta
        v.dot.visibility = if (info.duration.isNotEmpty() && info.eta.isNotEmpty()) View.VISIBLE else View.GONE

        val bmp: Bitmap? = if (preview) null else NavStore.maneuver
        if (bmp != null) {
            v.arrowImage.setImageBitmap(bmp)
            var transparentCorner = false
            try {
                transparentCorner = Color.alpha(bmp.getPixel(0, 0)) < 40
            } catch (ignored: Exception) {
            }
            if (transparentCorner) {
                v.arrowImage.setColorFilter(Color.WHITE, PorterDuff.Mode.SRC_IN)
            } else {
                v.arrowImage.clearColorFilter()
            }
            v.arrowImage.visibility = View.VISIBLE
            v.arrowGlyph.visibility = View.GONE
        } else {
            v.arrowImage.visibility = View.GONE
            v.arrowGlyph.visibility = View.VISIBLE
            v.arrowGlyph.text = glyphFor(info.instruction)
        }
    }

    // ---------------------------------------------------------------- السرعة وحد السرعة

    private fun hasLocationPermission(): Boolean {
        return checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED
    }

    @SuppressLint("MissingPermission")
    private fun startLocation() {
        if (locationStarted) return
        if (!hasLocationPermission()) return
        try {
            val lm = getSystemService(Context.LOCATION_SERVICE) as LocationManager
            lm.requestLocationUpdates(LocationManager.GPS_PROVIDER, 1000L, 0f, locationListener)
            locationManager = lm
            locationStarted = true
        } catch (e: Exception) {
        }
    }

    private fun stopLocation() {
        try {
            locationManager?.removeUpdates(locationListener)
        } catch (e: Exception) {
        }
        locationStarted = false
    }

    private fun handleLocation(loc: Location) {
        lastFixTime = System.currentTimeMillis()
        var kmh = -1
        if (loc.hasSpeed()) {
            kmh = Math.round(loc.speed * 3.6f)
            if (kmh < 3) kmh = 0
        }
        speedKmh = kmh
        updateSpeedViews()
        maybeFetchLimit(loc)
    }

    private fun updateSpeedViews() {
        val v = views ?: return
        if (preview) {
            v.status.text = "GPS Active"
            v.speedValue.text = "48"
            v.speedValue.setTextColor(Color.WHITE)
            v.limitSign.text = "60"
            v.limitSign.visibility = View.VISIBLE
            return
        }
        val now = System.currentTimeMillis()
        val fresh = lastFixTime != 0L && now - lastFixTime < 6000L
        if (!hasLocationPermission()) {
            v.status.text = "Location permission needed"
        } else if (fresh) {
            v.status.text = "GPS Active"
        } else {
            v.status.text = "GPS searching..."
        }
        if (fresh && speedKmh >= 0) {
            v.speedValue.text = speedKmh.toString()
        } else {
            v.speedValue.text = "--"
        }
        val showLimit = prefs.getBoolean("show_limit", true)
        if (showLimit && speedLimit > 0) {
            v.limitSign.text = speedLimit.toString()
            v.limitSign.visibility = View.VISIBLE
            val over = fresh && speedKmh > speedLimit + 2
            v.speedValue.setTextColor(if (over) Color.rgb(255, 110, 110) else Color.WHITE)
        } else {
            v.limitSign.visibility = View.GONE
            v.speedValue.setTextColor(Color.WHITE)
        }
    }

    private fun maybeFetchLimit(loc: Location) {
        if (!prefs.getBoolean("show_limit", true)) return
        if (fetching) return
        val now = System.currentTimeMillis()
        if (now - lastQueryTime < 12000L) return
        val moved = FloatArray(1)
        Location.distanceBetween(lastQueryLat, lastQueryLon, loc.latitude, loc.longitude, moved)
        if (lastQueryTime != 0L && moved[0] < 40f && now - lastQueryTime < 60000L) return

        val lat = loc.latitude
        val lon = loc.longitude
        fetching = true
        lastQueryTime = now
        lastQueryLat = lat
        lastQueryLon = lon
        Thread {
            val limit = queryOverpass(lat, lon)
            handler.post {
                fetching = false
                applyLimit(limit)
            }
        }.start()
    }

    private fun applyLimit(limit: Int) {
        if (views == null) return
        if (limit > 0) {
            speedLimit = limit
            limitUpdatedAt = System.currentTimeMillis()
        } else if (System.currentTimeMillis() - limitUpdatedAt > 45000L) {
            speedLimit = 0
        }
        updateSpeedViews()
    }

    /** يطلب حد السرعة من بيانات OpenStreetMap عبر Overpass. يرجع 0 إن لم يجد قيمة. */
    private fun queryOverpass(lat: Double, lon: Double): Int {
        var conn: HttpURLConnection? = null
        var result = 0
        try {
            val query = "[out:json][timeout:8];way(around:18," + lat + "," + lon + ")[\"highway\"][\"maxspeed\"];out tags;"
            val url = URL("https://overpass-api.de/api/interpreter?data=" + URLEncoder.encode(query, "UTF-8"))
            val c = url.openConnection() as HttpURLConnection
            conn = c
            c.connectTimeout = 6000
            c.readTimeout = 8000
            c.setRequestProperty("User-Agent", "NavWidget/1.5 (Android car overlay)")
            if (c.responseCode == 200) {
                val body = c.inputStream.bufferedReader().use { it.readText() }
                val elements = JSONObject(body).optJSONArray("elements")
                if (elements != null) {
                    var i = 0
                    while (i < elements.length() && result == 0) {
                        val tags = elements.getJSONObject(i).optJSONObject("tags")
                        if (tags != null) {
                            result = parseMaxSpeed(tags.optString("maxspeed", ""))
                        }
                        i++
                    }
                }
            }
        } catch (e: Exception) {
            result = 0
        } finally {
            try {
                conn?.disconnect()
            } catch (e: Exception) {
            }
        }
        return result
    }

    private fun parseMaxSpeed(s: String): Int {
        val m = Regex("^(\\d{1,3})\\s*(mph)?$").find(s.trim()) ?: return 0
        val n = m.groupValues[1].toInt()
        val isMph = m.groupValues[2].isNotEmpty()
        val kmh = if (isMph) Math.round(n * 1.609f) else n
        return if (kmh in 5..140) kmh else 0
    }

    // ---------------------------------------------------------------- إخفاء البطاقة عند فتح Maps

    private fun usageAccessGranted(): Boolean {
        val appOps = getSystemService(Context.APP_OPS_SERVICE) as android.app.AppOpsManager
        return try {
            appOps.checkOpNoThrow("android:get_usage_stats", android.os.Process.myUid(), packageName) ==
                android.app.AppOpsManager.MODE_ALLOWED
        } catch (e: Exception) {
            false
        }
    }

    private fun isMapsForeground(): Boolean {
        try {
            val usm = getSystemService(Context.USAGE_STATS_SERVICE) as UsageStatsManager
            val end = System.currentTimeMillis()
            val events = usm.queryEvents(end - 60000L, end)
            val event = UsageEvents.Event()
            var lastPackage = ""
            var lastTime = 0L
            while (events.hasNextEvent()) {
                events.getNextEvent(event)
                if (event.eventType == UsageEvents.Event.MOVE_TO_FOREGROUND ||
                    event.eventType == UsageEvents.Event.ACTIVITY_RESUMED
                ) {
                    if (event.timeStamp >= lastTime) {
                        lastTime = event.timeStamp
                        lastPackage = event.packageName ?: ""
                    }
                }
            }
            if (lastPackage.isNotEmpty()) cachedForegroundPackage = lastPackage
        } catch (e: Exception) {
        }
        return cachedForegroundPackage == MAPS_PACKAGE
    }

    // ---------------------------------------------------------------- الإنهاء

    override fun onDestroy() {
        handler.removeCallbacksAndMessages(null)
        try {
            unregisterReceiver(receiver)
        } catch (e: Exception) {
        }
        stopLocation()
        removeCard()
        try {
            stopForeground(true)
        } catch (e: Exception) {
        }
        super.onDestroy()
    }

    override fun onBind(intent: Intent?): IBinder? = null
}
