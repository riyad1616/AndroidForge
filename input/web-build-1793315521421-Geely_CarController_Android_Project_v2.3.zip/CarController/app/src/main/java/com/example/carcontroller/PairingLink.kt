package com.example.carcontroller

/**
 * QR / deep-link payload used to pair the phone with the car screen:
 *
 *     geelycar://pair?ip=192.168.43.1,192.168.1.20&pin=123456
 *
 * The car lists every IPv4 address it has (it may be reachable on several networks); the phone
 * tries them in order and keeps the first one that answers. Pure Kotlin (no Android imports) so it
 * is unit-tested on a plain JVM; the same file is used by both apps.
 */
object PairingLink {
    const val SCHEME = "geelycar"
    private const val PREFIX = "geelycar://pair?"

    data class Data(val ips: List<String>, val pin: String)

    private val IPV4 = Regex("^(\\d{1,3})\\.(\\d{1,3})\\.(\\d{1,3})\\.(\\d{1,3})$")
    private val PIN = Regex("^\\d{4,8}$")

    fun isValidIp(ip: String): Boolean {
        val m = IPV4.matchEntire(ip) ?: return false
        return m.groupValues.drop(1).all { it.toInt() in 0..255 }
    }

    fun isValidPin(pin: String) = PIN.matches(pin)

    fun build(ips: List<String>, pin: String): String {
        val clean = ips.filter { isValidIp(it) }
        require(clean.isNotEmpty()) { "no valid IPv4 address" }
        require(isValidPin(pin)) { "invalid PIN" }
        return PREFIX + "ip=" + clean.joinToString(",") + "&pin=" + pin
    }

    /** @return null when [text] is not a valid pairing link. */
    fun parse(text: String): Data? {
        val t = text.trim()
        if (!t.startsWith(PREFIX, ignoreCase = true)) return null
        val query = t.substring(PREFIX.length)
        var ips: List<String> = emptyList()
        var pin = ""
        for (part in query.split('&')) {
            val i = part.indexOf('=')
            if (i <= 0) continue
            val key = part.substring(0, i)
            val value = part.substring(i + 1)
            when (key) {
                "ip" -> ips = value.split(',').map { it.trim() }.filter { it.isNotEmpty() }
                "pin" -> pin = value.trim()
            }
        }
        if (ips.isEmpty() || !ips.all { isValidIp(it) } || !isValidPin(pin)) return null
        return Data(ips.distinct(), pin)
    }
}
