package com.example.carcontroller

import java.io.BufferedReader
import java.io.IOException
import java.io.InputStreamReader
import java.io.OutputStreamWriter
import java.net.ConnectException
import java.net.InetSocketAddress
import java.net.NoRouteToHostException
import java.net.Socket
import java.net.SocketTimeoutException
import java.net.UnknownHostException

/**
 * One request = one short TCP connection to the Receiver app on the car screen.
 *
 *   request : "AUTH <pin> <COMMAND>\n"
 *   reply   : "OK" | "ERR_AUTH" | "ERR_LOCKED" | "ERR_UNKNOWN" | "ERR_FORMAT" | "ERR_EXEC <reason>"
 *
 * Blocking: call from a background thread.
 */
class CarClient(
    private val host: String,
    private val pin: String,
    private val port: Int = DEFAULT_PORT
) {
    enum class Code { OK, AUTH, LOCKED, UNKNOWN, EXEC, FORMAT, UNREACHABLE, TIMEOUT, BAD_IP, NO_REPLY, IO }

    data class Result(val code: Code, val detail: String = "") {
        val ok: Boolean get() = code == Code.OK
    }

    fun ping(): Result = send(Cmd.PING)

    fun send(cmd: String): Result {
        val socket = Socket()
        return try {
            val address = InetSocketAddress(host, port)
            if (address.isUnresolved) return Result(Code.BAD_IP)
            socket.connect(address, CONNECT_TIMEOUT_MS)
            socket.soTimeout = READ_TIMEOUT_MS

            val cleanPin = pin.filter { !it.isWhitespace() }
            val out = OutputStreamWriter(socket.getOutputStream(), Charsets.UTF_8)
            out.write("AUTH $cleanPin $cmd\n")
            out.flush()

            val reader = BufferedReader(InputStreamReader(socket.getInputStream(), Charsets.UTF_8))
            val line = reader.readLine()?.trim() ?: return Result(Code.NO_REPLY)
            parseReply(line)
        } catch (e: SocketTimeoutException) {
            Result(Code.TIMEOUT)
        } catch (e: UnknownHostException) {
            Result(Code.BAD_IP)
        } catch (e: ConnectException) {
            Result(Code.UNREACHABLE, e.message.orEmpty())
        } catch (e: NoRouteToHostException) {
            Result(Code.UNREACHABLE, e.message.orEmpty())
        } catch (e: IOException) {
            Result(Code.IO, e.message.orEmpty())
        } finally {
            try {
                socket.close()
            } catch (e: IOException) {
                // ignore: nothing useful to do if close() fails
            }
        }
    }

    companion object {
        const val DEFAULT_PORT = 8888
        const val CONNECT_TIMEOUT_MS = 3000
        const val READ_TIMEOUT_MS = 8000

        fun parseReply(line: String): Result = when {
            line == "OK" -> Result(Code.OK)
            line == "ERR_AUTH" -> Result(Code.AUTH)
            line == "ERR_LOCKED" -> Result(Code.LOCKED)
            line == "ERR_UNKNOWN" -> Result(Code.UNKNOWN)
            line == "ERR_FORMAT" -> Result(Code.FORMAT)
            line.startsWith("ERR_EXEC") -> Result(Code.EXEC, line.removePrefix("ERR_EXEC").trim())
            else -> Result(Code.NO_REPLY, line)
        }
    }
}
