package com.onehub.floatgauge;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.RectF;
import android.graphics.Typeface;
import android.util.AttributeSet;
import android.view.View;

/**
 * OneHub engine host.
 * Mode badge (colored). Gear step 1..7 drawn on the RIGHT side (no "D" prefix).
 * No D1..D7 strip. Battery icon suppressed in engine.
 */
public class SpeedoView extends View {

    public static final int STYLE_COUNT = 10;
    public static final int THEME_COUNT = SpeedoEngine.f1039s.size();

    private final SpeedoEngine engine = new SpeedoEngine();
    private final SpeedoData data = new SpeedoData();
    private final Paint paint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final RectF tmp = new RectF();
    private int styleIndex = 0;
    private int themeIndex = 0;

    public SpeedoView(Context c) { super(c); init(); }
    public SpeedoView(Context c, AttributeSet a) { super(c, a); init(); }

    private void init() {
        paint.setTypeface(Typeface.create("sans-serif-medium", Typeface.BOLD));
    }

    public void setStyle(int s) {
        styleIndex = ((s % STYLE_COUNT) + STYLE_COUNT) % STYLE_COUNT;
        requestLayout();
        invalidate();
    }
    public int getStyle() { return styleIndex; }
    public void nextStyle() { setStyle(styleIndex + 1); }

    public void setThemeIndex(int t) {
        themeIndex = ((t % THEME_COUNT) + THEME_COUNT) % THEME_COUNT;
        invalidate();
    }
    public int getThemeIndex() { return themeIndex; }
    public void nextTheme() { setThemeIndex(themeIndex + 1); }

    public void setData(float speed, int gearIdx, int gearStep, String gearLetter,
                        String driveMode, int batt, int fuel, int powerKw,
                        int tempOut, int tempBatt) {
        // Slot 0 = gear step (replaces battery). Engine s(0) reads gearStep.
        data.set(speed, gearIdx, gearStep, gearLetter, driveMode,
                gearStep > 0 ? gearStep : Integer.MIN_VALUE,
                fuel, powerKw, tempOut, tempBatt);
        invalidate();
    }

    public float aspect() {
        float[] q = SpeedoEngine.f1037q;
        if (styleIndex < 0 || styleIndex >= q.length) return 1f;
        return q[styleIndex];
    }

    private static int modeColor(String mode) {
        if (mode == null) return 0xFF80CBC4;
        switch (mode) {
            case "ADAPTATIF":    return 0xFF00E5FF;
            case "SPORT":        return 0xFFFF1744;
            case "ÉCO":
            case "ECO":          return 0xFF00E676;
            case "CONFORT":      return 0xFF448AFF;
            case "NEIGE":        return 0xFFE0F7FA;
            case "NORMAL":       return 0xFFB0BEC5;
            case "PERSO":        return 0xFFD500F9;
            case "TOUT-TERRAIN": return 0xFFFF9100;
            default:             return 0xFF80CBC4;
        }
    }

    @Override
    protected void onDraw(Canvas canvas) {
        super.onDraw(canvas);
        float w = getWidth();
        float h = getHeight();
        if (w < 4 || h < 4) return;
        try {
            engine.j(canvas, w, h, styleIndex, themeIndex, data);
        } catch (Throwable ignored) {}

        drawModeBadge(canvas, w, h);
        drawRightGearNumber(canvas, w, h);
    }

    private void drawModeBadge(Canvas canvas, float w, float h) {
        String mode = data.driveMode;
        if (mode == null || mode.isEmpty() || "—".equals(mode)) return;

        float textSize = Math.max(15f, Math.min(w, h) * 0.05f);
        paint.setTextSize(textSize);
        paint.setTypeface(Typeface.create("sans-serif-medium", Typeface.BOLD));
        paint.setTextAlign(Paint.Align.LEFT);
        float pad = textSize * 0.4f;
        float tw = paint.measureText(mode);
        float x = w * 0.04f;
        float y = h * 0.055f + textSize;

        int col = modeColor(mode);
        paint.setStyle(Paint.Style.FILL);
        paint.setColor((col & 0x00FFFFFF) | 0x44000000);
        tmp.set(x - pad * 0.25f, y - textSize * 0.95f, x + tw + pad, y + textSize * 0.3f);
        canvas.drawRoundRect(tmp, textSize * 0.3f, textSize * 0.3f, paint);

        paint.setColor(col);
        canvas.drawText(mode, x, y, paint);
    }

    /**
     * Large gear number on the RIGHT panel area (annotation "1"),
     * without the "D" prefix. Shows 1..7 when in D1..D7, else P/R/N/D.
     */
    private void drawRightGearNumber(Canvas canvas, float w, float h) {
        String label;
        if (data.gearStep > 0) {
            label = String.valueOf(data.gearStep); // "1" .. "7"  NO "D"
        } else if (data.gearLetter != null && data.gearLetter.length() > 0) {
            label = data.gearLetter; // P R N D
        } else {
            return;
        }

        float cx = w * 0.82f;
        float cy = h * 0.42f;
        float textSize = Math.max(28f, Math.min(w, h) * 0.14f);

        // Soft disc so number stays readable on any style
        paint.setStyle(Paint.Style.FILL);
        paint.setColor(0xAA0A0E14);
        float r = textSize * 0.95f;
        canvas.drawCircle(cx, cy, r, paint);
        paint.setStyle(Paint.Style.STROKE);
        paint.setStrokeWidth(Math.max(2f, textSize * 0.06f));
        paint.setColor(0xFF00E5FF);
        canvas.drawCircle(cx, cy, r, paint);

        paint.setStyle(Paint.Style.FILL);
        paint.setTextSize(textSize);
        paint.setTypeface(Typeface.create("sans-serif", Typeface.BOLD));
        paint.setTextAlign(Paint.Align.CENTER);
        paint.setColor(0xFFFFFFFF);
        // baseline center
        Paint.FontMetrics fm = paint.getFontMetrics();
        float baseline = cy - (fm.ascent + fm.descent) / 2f;
        canvas.drawText(label, cx, baseline, paint);
    }
}
