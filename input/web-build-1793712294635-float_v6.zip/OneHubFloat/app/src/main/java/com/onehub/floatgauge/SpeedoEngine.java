package com.onehub.floatgauge;

import android.graphics.Canvas;
import android.graphics.LinearGradient;
import android.graphics.Matrix;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.RadialGradient;
import android.graphics.RectF;
import android.graphics.Shader;
import android.graphics.SweepGradient;
import android.graphics.Typeface;
import android.graphics.Color;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;

/**
 * Port of OneHub C0026d2 (d2) speedometer renderer – all styles & themes.
 */


public final class SpeedoEngine {

    public static final String[] f1035o = {"STATISTIC_SOC_BATTERY_PERCENTAGE", "STATISTIC_FUEL_PERCENTAGE", "STATISTIC_ELEC_DRIVING_RANGE", "STATISTIC_FUEL_DRIVING_RANGE", "ENGINE_POWER", "AC_TEMP_OUT", "AC_CMD_OTA_SUB_BATTERY_TEMPRATURE"};

    public static final int[] f1036p = {1145045040, 1246785600, 1246765118, 1246773304, 339738656, 1077936184, 1150287912};

    public static final float[] f1037q = {1.0f, 1.8f, 1.65f, 1.55f, 3.0f, 1.0f, 1.45f, 1.85f, 1.0f, 1.9f};

    public static final float[] f1038r = {1.0f, 0.85f, 0.85f, 0.8f, 0.5f, 1.0f, 0.85f, 0.85f, 0.9f, 0.75f};

    public static final List<ThemeColors> f1039s = themeList(new ThemeColors(-15721933, -16447473, -14009754, 822083583, -16718337, -13669377, -3151617, -1, -8410920), new ThemeColors(-14021363, -16120571, -10871009, 822083583, -20448, -54742, -7984, -1, -2584448), new ThemeColors(-15916010, -16512506, -14726610, 822083583, -2818246, -16723350, -2031640, -1, -7944292), new ThemeColors(-14413254, -16120558, -12179346, 822083583, -42280, -7643905, -990977, -1, -5203240), new ThemeColors(-14278636, -16054011, -9743067, 822083583, -3672, -2842601, -661824, -2858, -3559302), new ThemeColors(-1, -2104082, -4669232, 570425344, -13319169, -14461953, -13946299, -15459798, -10655872), new ThemeColors(-13947599, -15855855, -11183777, 822083583, -1, -6642771, -2104344, -1, -6643544), new ThemeColors(-12970192, -15596014, -9819574, 822083583, -11713, -49793, -6418, -1, -2057544), new ThemeColors(-1378561, -4597262, -7358246, 570437712, -12592912, -14906113, -15452582, -15914424, -11899248), new ThemeColors(-15848914, -16510958, -14790056, 822083583, -10551336, -16735325, -2555910, -1, -8403780));

    public final Paint f1040a = new Paint(1);
    public final Paint b = new Paint(1);

    public final Typeface f1041c = Typeface.create("sans-serif-condensed", 1);

    public final Typeface f1042d = Typeface.create("sans-serif-medium", 0);

    public final RectF f1043e = new RectF();
    public final RectF f = new RectF();

    public final Path f1044g = new Path();

    public final HashMap f1045h = new HashMap();

    public String f1046i = "";

    public final float[] f1047j = new float[3];

    public final float[] f1048k = new float[3];

    public float f1049l;

    public float f1050m;

    public float f1051n;

    public static /* synthetic */ void D(SpeedoEngine c0026d2, Canvas canvas, String str, float f, float f2, float f3, int i2, Typeface typeface) {
        c0026d2.C(canvas, str, f, f2, f3, i2, typeface, Paint.Align.CENTER);
    }

    public static final LinearGradient a(SpeedoEngine c0026d2, float f, float f2, ThemeColors c0022c2) {
        c0026d2.getClass();
        float f3 = f - f2;
        float f4 = f + f2;
        int e2 = lerpColor(c0022c2.f1021c, -1, 0.35f);
        int i2 = c0022c2.f1021c;
        return new LinearGradient(0.0f, f3, 0.0f, f4, new int[]{e2, i2, lerpColor(i2, -16777216, 0.55f)}, (float[]) null, Shader.TileMode.CLAMP);
    }

    public static int l(SpeedoData c0018b2) {
        return (!valid(1, c0018b2.f1013d[1]) || c0018b2.f1013d[1] >= 10) ? -20448 : -50384;
    }

    public static String n(int i2) {
        return i2 != 1 ? i2 != 2 ? i2 != 3 ? i2 != 4 ? "–" : "D" : "N" : "R" : "P";
    }

    public static void r(SpeedoEngine c0026d2, Canvas canvas, float f, float f2, float f3, ThemeColors c0022c2, String str, Float f4, Integer num, String str2, String str3, int i2, int i3, boolean z2, int i4) {
        HashMap hashMap;
        Paint paint;
        int i5;
        Paint paint2;
        SpeedoEngine c0026d22;
        Object obj;
        boolean z3 = (i4 & 8192) != 0 ? false : z2;
        c0026d2.k(-16777216);
        Paint paint3 = c0026d2.f1040a;
        String concat = str.concat(".ms");
        HashMap hashMap2 = c0026d2.f1045h;
        Object obj2 = hashMap2.get(concat);
        if (obj2 == null) {
            hashMap = hashMap2;
            paint = paint3;
            i5 = 0;
            obj2 = new RadialGradient(f, f2, f3 * 1.08f, new int[]{1610612736, 1610612736, 0}, new float[]{0.0f, 0.88f, 1.0f}, Shader.TileMode.CLAMP);
            hashMap.put(concat, obj2);
        } else {
            hashMap = hashMap2;
            paint = paint3;
            i5 = 0;
        }
        paint.setShader((Shader) obj2);
        canvas.drawCircle(f, f2, f3 * 1.08f, paint);
        String concat2 = str.concat(".bz");
        Object obj3 = hashMap.get(concat2);
        if (obj3 == null) {
            paint2 = paint;
            c0026d22 = c0026d2;
            obj3 = a(c0026d22, f2, f3, c0022c2);
            hashMap.put(concat2, obj3);
        } else {
            paint2 = paint;
            c0026d22 = c0026d2;
        }
        paint2.setShader((Shader) obj3);
        canvas.drawCircle(f, f2, f3, paint2);
        String concat3 = str.concat(".fc");
        Object obj4 = hashMap.get(concat3);
        if (obj4 == null) {
            RadialGradient radialGradient = new RadialGradient(f, f2 - (0.3f * f3), f3 * 1.25f, c0022c2.f1020a, c0022c2.b, Shader.TileMode.CLAMP);
            hashMap.put(concat3, radialGradient);
            obj4 = radialGradient;
        }
        paint2.setShader((Shader) obj4);
        canvas.drawCircle(f, f2, 0.92f * f3, paint2);
        paint2.setShader(null);
        float f5 = f3 * 0.76f;
        float f6 = f3 * 0.11f;
        if (z3) {
            canvas.save();
            canvas.scale(-1.0f, 1.0f, f, f2);
        }
        RectF rectF = c0026d22.f1043e;
        rectF.set(f - f5, f2 - f5, f + f5, f2 + f5);
        c0026d22.A(c0022c2.f1022d, f6, true);
        canvas.drawArc(rectF, 150.0f, 240.0f, false, paint2);
        if (f4 != null) {
            float i6 = clampf(f4.floatValue(), 0.0f, 1.0f);
            float min = (Math.min(i6, 0.0f) * 240.0f) + 150.0f;
            float abs = Math.abs(i6 - 0.0f) * 240.0f;
            if (abs > 0.5f) {
                if (num != null) {
                    c0026d22.A(withAlpha(num.intValue(), 60), 1.9f * f6, true);
                    canvas.drawArc(rectF, min, abs, false, paint2);
                    c0026d22.A(num.intValue(), f6, true);
                    canvas.drawArc(rectF, min, abs, false, paint2);
                } else {
                    String concat4 = str.concat(".sw");
                    Object obj5 = hashMap.get(concat4);
                    if (obj5 == null) {
                        int i7 = c0022c2.f;
                        SweepGradient sweepGradient = new SweepGradient(f, f2, new int[]{c0022c2.f1023e, i7, i7}, new float[]{0.0f, 0.6666667f, 1.0f});
                        Matrix matrix = new Matrix();
                        matrix.setRotate(150.0f, f, f2);
                        sweepGradient.setLocalMatrix(matrix);
                        hashMap.put(concat4, sweepGradient);
                        obj = sweepGradient;
                    } else {
                        obj = obj5;
                    }
                    Shader shader = (Shader) obj;
                    c0026d22.A(-16777216, 1.9f * f6, true);
                    paint2.setShader(shader);
                    paint2.setAlpha(60);
                    canvas.drawArc(rectF, min, abs, false, paint2);
                    c0026d22.A(-16777216, f6, true);
                    paint2.setShader(shader);
                    canvas.drawArc(rectF, min, abs, false, paint2);
                    paint2.setShader(null);
                }
            }
        }
        for (int i8 = i5; i8 < 5; i8++) {
            float a2 = mapAngle(240.0f, i8, 4.0f, 150.0f);
            c0026d22.A(withAlpha(c0022c2.f1024g, 130), 0.025f * f3, true);
            float f7 = f5 - (0.9f * f6);
            float i9 = polarX(f, f7, a2);
            float l2 = polarY(f2, f7, a2);
            float f8 = f5 - (1.6f * f6);
            canvas.drawLine(i9, l2, polarX(f, f8, a2), polarY(f2, f8, a2), paint2);
        }
        if (z3) {
            canvas.restore();
        }
        Typeface typeface = c0026d22.f1041c;
        nn(typeface, "bold");
        D(c0026d2, canvas, str2, f, (0.12f * f3) + f2, f3 * 0.4f, c0022c2.f1025h, typeface);
        Typeface typeface2 = c0026d22.f1042d;
        nn(typeface2, "medium");
        D(c0026d2, canvas, str3, f, (0.33f * f3) + f2, f3 * 0.16f, c0022c2.f1026i, typeface2);
        c0026d2.p(canvas, i2, f, (0.64f * f3) + f2, 0.24f * f3, i3);
    }

    public static String s(SpeedoData c0018b2, int i2) {
        // Slot 0 = gear (replaces battery): 1..7 or P/R/N/D — never a percent
        if (i2 == 0) {
            if (c0018b2.gearStep > 0) return String.valueOf(c0018b2.gearStep);
            if (c0018b2.gearLetter != null && c0018b2.gearLetter.length() > 0) {
                return c0018b2.gearLetter; // P R N D
            }
            return "";
        }
        return valid(i2, c0018b2.f1013d[i2]) ? String.valueOf(c0018b2.f1013d[i2]) : "--";
    }

    public static Float t(SpeedoData c0018b2, int i2) {
        if (i2 == 0 && c0018b2.gearStep > 0) {
            return Float.valueOf(c0018b2.gearStep / 7.0f);
        }
        if (i2 == 0) return null;
        if (valid(i2, c0018b2.f1013d[i2])) {
            return Float.valueOf(c0018b2.f1013d[i2] / 100.0f);
        }
        return null;
    }

    public static int y(SpeedoData c0018b2) {
        return (!valid(0, c0018b2.f1013d[0]) || c0018b2.f1013d[0] >= 15) ? -13315175 : -50384;
    }

    public static String z(SpeedoData c0018b2) {
        return c0018b2.b ? String.valueOf(clampi(lerp(c0018b2.f1011a), 0, 999)) : "--";
    }

    public final void A(int i2, float f, boolean z2) {
        Paint paint = this.f1040a;
        paint.reset();
        paint.setAntiAlias(true);
        paint.setStyle(Paint.Style.STROKE);
        paint.setColor(i2);
        paint.setStrokeWidth(f);
        if (z2) {
            paint.setStrokeCap(Paint.Cap.ROUND);
        }
    }

    public final Shader B(String str, float f, float f2, ThemeColors c0022c2) {
        String concat = str.concat(".sw");
        HashMap hashMap = this.f1045h;
        Object obj = hashMap.get(concat);
        Object obj2 = obj;
        if (obj == null) {
            int i2 = c0022c2.f1023e;
            int i3 = c0022c2.f;
            SweepGradient sweepGradient = new SweepGradient(f, f2, new int[]{i2, i3, i3}, new float[]{0.0f, 0.75f, 1.0f});
            Matrix matrix = new Matrix();
            matrix.setRotate(135.0f, f, f2);
            sweepGradient.setLocalMatrix(matrix);
            hashMap.put(concat, sweepGradient);
            obj2 = sweepGradient;
        }
        return (Shader) obj2;
    }

    public final void C(Canvas canvas, String str, float f, float f2, float f3, int i2, Typeface typeface, Paint.Align align) {
        Paint paint = this.b;
        paint.reset();
        paint.setAntiAlias(true);
        paint.setTextAlign(align);
        paint.setLetterSpacing(0.0f);
        paint.setTextScaleX(1.0f);
        paint.setTypeface(typeface);
        paint.setTextSize(f3);
        paint.setColor(i2);
        canvas.drawText(str, f, f2, paint);
    }

    public final void b(Canvas canvas, float f, float f2, float f3, ThemeColors c0022c2, SpeedoData c0018b2) {
        float f4;
        Paint paint;
        Typeface typeface;
        int i2;
        String str;
        Typeface typeface2;
        SpeedoEngine c0026d2;
        int b;
        float f5;
        Paint paint2;
        float f6;
        SpeedoEngine c0026d22 = this;
        float i3 = clampf(c0018b2.f1011a / 240.0f, 0.0f, 1.0f);
        g(f, f2, f3, canvas, c0022c2);
        float f7 = f3 * 0.8f;
        float f8 = f3 * 0.075f;
        RectF rectF = c0026d22.f1043e;
        rectF.set(f - f7, f2 - f7, f + f7, f2 + f7);
        c0026d22.A(c0022c2.f1022d, f8, true);
        Paint paint3 = c0026d22.f1040a;
        canvas.drawArc(rectF, 135.0f, 270.0f, false, paint3);
        if (i3 <= 0.002f || !c0018b2.b) {
            f4 = f7;
            paint = paint3;
        } else {
            Shader B2 = c0026d22.B("c", f, f2, c0022c2);
            c0026d22.A(-16777216, 2.5f * f8, true);
            paint3.setShader(B2);
            paint3.setAlpha(40);
            float f9 = i3 * 270.0f;
            canvas.drawArc(rectF, 135.0f, f9, false, paint3);
            c0026d22.A(-16777216, 1.6f * f8, true);
            paint3.setShader(B2);
            paint3.setAlpha(90);
            f4 = f7;
            canvas.drawArc(rectF, 135.0f, f9, false, paint3);
            c0026d22.A(-16777216, f8, true);
            paint = paint3;
            paint.setShader(B2);
            canvas.drawArc(rectF, 135.0f, f9, false, paint);
            paint.setShader(null);
        }
        int i4 = 0;
        while (true) {
            typeface = c0026d22.f1042d;
            i2 = c0022c2.f1023e;
            if (i4 > 240) {
                break;
            }
            float f10 = i4;
            float f11 = f10 / 240.0f;
            float f12 = (f11 * 270.0f) + 135.0f;
            boolean z2 = i4 % 20 == 0;
            boolean z3 = f10 <= c0018b2.f1011a + 0.5f && c0018b2.b;
            if (z3) {
                b = lerpColor(i2, c0022c2.f, f11);
            } else {
                b = withAlpha(c0022c2.f1024g, z2 ? 150 : 90);
            }
            c0026d22.A(b, (z2 ? 0.02f : 0.011f) * f3, true);
            float f13 = (z2 ? 0.61f : 0.65f) * f3;
            float f14 = 0.7f * f3;
            int i5 = i4;
            canvas.drawLine(polarX(f, f14, f12), polarY(f2, f14, f12), polarX(f, f13, f12), polarY(f2, f13, f12), paint);
            if (z2) {
                String valueOf = String.valueOf(i5);
                float f15 = f3 * 0.5f;
                float i6 = polarX(f, f15, f12);
                float f16 = f3 * 0.085f;
                float l2 = (0.36f * f16) + polarY(f2, f15, f12);
                int b2 = z3 ? c0022c2.f1025h : withAlpha(c0022c2.f1026i, 190);
                nn(typeface, "medium");
                f5 = f8;
                paint2 = paint;
                f6 = f4;
                D(this, canvas, valueOf, i6, l2, f16, b2, typeface);
            } else {
                f5 = f8;
                paint2 = paint;
                f6 = f4;
            }
            i4 = i5 + 10;
            f4 = f6;
            paint = paint2;
            f8 = f5;
            c0026d22 = this;
        }
        float f17 = f8;
        float f18 = f4;
        if (c0018b2.b) {
            float f19 = (i3 * 270.0f) + 135.0f;
            Paint paint4 = paint;
            c(canvas, f, f2, f19, f3 * 0.56f, f3 * 0.9f, f3, c0022c2);
            float i7 = polarX(f, f18, f19);
            float l3 = polarY(f2, f18, f19);
            c0026d2 = this;
            str = "medium";
            c0026d2.k(withAlpha(i2, 90));
            typeface2 = typeface;
            canvas.drawCircle(i7, l3, f17 * 0.95f, paint4);
            c0026d2.k(-1);
            canvas.drawCircle(i7, l3, f17 * 0.42f, paint4);
        } else {
            str = "medium";
            typeface2 = typeface;
            c0026d2 = this;
        }
        Typeface typeface3 = c0026d2.f1041c;
        nn(typeface3, "bold");
        D(this, canvas, z(c0018b2), f, (0.1f * f3) + f2, f3 * 0.4f, c0022c2.f1025h, typeface3);
        nn(typeface2, str);
        D(this, canvas, "km/h", f, (0.25f * f3) + f2, f3 * 0.085f, c0022c2.f1026i, typeface2);
        o(canvas, c0022c2, c0018b2, f - ((1.5f * f3) * 0.14f), (0.44f * f3) + f2, f3 * 0.078f, f3 * 0.14f, Paint.Align.CENTER);
    }

    public final void c(Canvas canvas, float f, float f2, float f3, float f4, float f5, float f6, ThemeColors c0022c2) {
        double radians = Math.toRadians(f3);
        float cos = (float) Math.cos(radians);
        float sin = (float) Math.sin(radians);
        float f7 = -sin;
        float f8 = 0.04f * f6;
        float f9 = 0.008f * f6;
        Path path = this.f1044g;
        path.reset();
        float f10 = (cos * f4) + f;
        float f11 = f7 * f8;
        float f12 = (sin * f4) + f2;
        float f13 = f8 * cos;
        path.moveTo(f10 + f11, f12 + f13);
        float f14 = (cos * f5) + f;
        float f15 = f7 * f9;
        float f16 = (sin * f5) + f2;
        float f17 = cos * f9;
        path.lineTo(f14 + f15, f16 + f17);
        path.lineTo(f14 - f15, f16 - f17);
        path.lineTo(f10 - f11, f12 - f13);
        path.close();
        A(withAlpha(c0022c2.f, 70), 0.05f * f6, true);
        Paint paint = this.f1040a;
        paint.setStrokeJoin(Paint.Join.ROUND);
        canvas.drawPath(path, paint);
        k(lerpColor(c0022c2.f1025h, c0022c2.f1023e, 0.25f));
        canvas.drawPath(path, paint);
    }

    public final void d(Canvas canvas, ThemeColors c0022c2, float f, float f2, float f3, float f4, float f5) {
        float[] fArr = this.f1047j;
        fArr[0] = f;
        fArr[1] = f2;
        fArr[2] = f5;
        float[] fArr2 = this.f1048k;
        fArr2[0] = f3;
        fArr2[1] = f4;
        fArr2[2] = f5;
        k(-16777216);
        Paint paint = this.f1040a;
        HashMap hashMap = this.f1045h;
        Object obj = hashMap.get("btn");
        if (obj == null) {
            obj = new LinearGradient(f - f5, f2 - f5, f + f5, f2 + f5, c0022c2.f1023e, c0022c2.f, Shader.TileMode.CLAMP);
            hashMap.put("btn", obj);
        }
        paint.setShader((Shader) obj);
        canvas.drawCircle(f, f2, f5, paint);
        paint.setShader(null);
        float f6 = 0.17f * f5;
        A(withAlpha(c0022c2.f1025h, 200), f6, true);
        canvas.drawCircle(f, f2, f5, paint);
        k(withAlpha(-1, 230));
        for (int i2 = 0; i2 < 3; i2++) {
            float f7 = 0.45f * f5;
            float f8 = (i2 * 120.0f) - 90.0f;
            canvas.drawCircle(polarX(f, f7, f8), polarY(f2, f7, f8), f6, paint);
        }
        k(lerpColor(c0022c2.f, -16777216, 0.35f));
        canvas.drawCircle(f3, f4, f5, paint);
        A(withAlpha(c0022c2.f1023e, 230), f6, true);
        canvas.drawCircle(f3, f4, f5, paint);
        A(withAlpha(-1, 235), 0.13f * f5, false);
        canvas.drawCircle(f3 - f6, f4 - (0.12f * f5), 0.27f * f5, paint);
        RectF rectF = this.f;
        float f9 = 0.02f * f5;
        rectF.set(f3 - f9, f4 - f9, (0.44f * f5) + f3, (0.42f * f5) + f4);
        canvas.drawRect(rectF, paint);
    }

    public final void e(Canvas canvas, ThemeColors c0022c2, String str, float f, float f2, float f3, float f4, float f5) {
        float max = Math.max(1.5f, (f4 - f2) * 0.012f);
        RectF rectF = this.f;
        rectF.set(f + max, f2 + max, f3 - max, f4 - max);
        k(-16777216);
        Paint paint = this.f1040a;
        String concat = str.concat(".cd");
        HashMap hashMap = this.f1045h;
        Object obj = hashMap.get(concat);
        if (obj == null) {
            obj = new LinearGradient(0.0f, f2, 0.0f, f4, c0022c2.f1020a, c0022c2.b, Shader.TileMode.CLAMP);
            hashMap.put(concat, obj);
        }
        paint.setShader((Shader) obj);
        canvas.drawRoundRect(rectF, f5, f5, paint);
        paint.setShader(null);
        A(c0022c2.f1021c, max * 1.6f, false);
        canvas.drawRoundRect(rectF, f5, f5, paint);
    }

    public final void f(Canvas canvas, ThemeColors c0022c2, float f, float f2, int i2, int i3, String str, int i4, int i5, int i6, int i7) {
        String str2;
        String str3;
        if (i2 != 0) p(canvas, i2, f, f2 * 0.21f, f2 * 0.12f, i3);
        Typeface typeface = this.f1041c;
        nn(typeface, "bold");
        D(this, canvas, str, f, f2 * 0.47f, f2 * 0.18f, c0022c2.f1025h, typeface);
        if (valid(i5, i4)) {
            str2 = i4 + " km";
        } else {
            str2 = "-- km";
        }
        String str4 = str2;
        Typeface typeface2 = this.f1042d;
        nn(typeface2, "medium");
        D(this, canvas, str4, f, f2 * 0.59f, f2 * 0.08f, c0022c2.f1026i, typeface2);
        float f3 = f2 * 0.8f;
        float f4 = f2 * 0.075f;
        if (valid(i7, i6)) {
            str3 = i6 + "°";
        } else {
            str3 = "--°";
        }
        w(canvas, c0022c2, f, f3, f4, 3, c0022c2.f1026i, str3);
    }

    public final void g(float f, float f2, float f3, Canvas canvas, ThemeColors c0022c2) {
        k(-16777216);
        Paint paint = this.f1040a;
        HashMap hashMap = this.f1045h;
        Object obj = hashMap.get("c.sh");
        if (obj == null) {
            RadialGradient radialGradient = new RadialGradient(f, f2, f3 * 1.06f, new int[]{1879048192, 1879048192, 0}, new float[]{0.0f, 0.9f, 1.0f}, Shader.TileMode.CLAMP);
            hashMap.put("c.sh", radialGradient);
            obj = radialGradient;
        }
        paint.setShader((Shader) obj);
        canvas.drawCircle(f, f2, f3 * 1.06f, paint);
        Object obj2 = hashMap.get("c.bz");
        if (obj2 == null) {
            obj2 = a(this, f2, f3, c0022c2);
            hashMap.put("c.bz", obj2);
        }
        paint.setShader((Shader) obj2);
        canvas.drawCircle(f, f2, f3, paint);
        Object obj3 = hashMap.get("c.fc");
        if (obj3 == null) {
            RadialGradient radialGradient2 = new RadialGradient(f, f2 - (0.3f * f3), f3 * 1.25f, c0022c2.f1020a, c0022c2.b, Shader.TileMode.CLAMP);
            hashMap.put("c.fc", radialGradient2);
            obj3 = radialGradient2;
        }
        paint.setShader((Shader) obj3);
        canvas.drawCircle(f, f2, 0.94f * f3, paint);
        paint.setShader(null);
    }

    public final void h(float f, float f2, float f3) {
        this.f1049l = f;
        this.f1050m = f2;
        this.f1051n = f3;
    }

    public final void i(Canvas canvas, ThemeColors c0022c2, int i2) {
        float f = this.f1051n;
        float f2 = (9 / 2.0f) * f;
        RectF rectF = this.f;
        float f3 = this.f1049l;
        float f4 = 0.8f * f;
        float f5 = this.f1050m;
        float f6 = f * 0.62f;
        rectF.set((f3 - f2) - f4, f5 - f6, f3 + f2 + f4, f6 + f5);
        k(withAlpha(-16777216, 120));
        float f7 = this.f1051n * 0.62f;
        Paint paint = this.f1040a;
        canvas.drawRoundRect(rectF, f7, f7, paint);
        int i3 = 0;
        while (i3 < 10) {
            k(i3 == i2 ? c0022c2.f1023e : withAlpha(-1, 110));
            float f8 = this.f1049l - f2;
            float f9 = this.f1051n;
            canvas.drawCircle((i3 * f9) + f8, this.f1050m, f9 * (i3 == i2 ? 0.38f : 0.24f), paint);
            i3++;
        }
    }

    public final void j(Canvas canvas, float f, float f2, int i2, int i3, SpeedoData c0018b2) {
        ThemeColors c0022c2;
        int i4;
        int i5;
        SpeedoData c0018b22;
        ThemeColors c0022c22;
        int i6;
        int i7;
        int i8;
        ThemeColors c0022c23;
        SpeedoData c0018b23;
        int i9;
        float f3;
        int i10;
        int i11;
        float f4;
        SpeedoEngine c0026d2;
        int i12;
        int i13;
        int b;
        Paint paint;
        String str;
        Typeface typeface;
        String str2;
        ThemeColors c0022c24;
        float f5;
        SpeedoEngine c0026d22;
        Canvas canvas2;
        int i14;
        
        
        if (f < 4.0f || f2 < 4.0f) {
            return;
        }
        List<ThemeColors> list = f1039s;
        int j2 = clampi(i3, 0, list.size() - 1);
        int j3 = clampi(i2, 0, 9);
        ThemeColors c0022c25 = (ThemeColors) list.get(j2);
        String str3 = ((int) f) + "x" + ((int) f2) + "|" + j2 + "|" + j3;
        boolean a2 = eq(str3, this.f1046i);
        HashMap hashMap = this.f1045h;
        if (!a2) {
            hashMap.clear();
            this.f1046i = str3;
        }
        this.f1047j[2] = 0.0f;
        this.f1048k[2] = 0.0f;
        RectF rectF = this.f1043e;
        Paint paint2 = this.f1040a;
        Typeface typeface2 = this.f1042d;
        Typeface typeface3 = this.f1041c;
        int[] iArr = c0018b2.f1013d;
        switch (j3) {
            case 0:
                c0022c2 = c0022c25;
                i4 = j2;
                i5 = j3;
                c0018b22 = c0018b2;
                float min = (Math.min(f, f2) / 2.0f) * 0.93f;
                float f6 = f / 2.0f;
                float f7 = f2 / 2.0f;
                b(canvas, f6, f7, min, c0022c2, c0018b2);
                m(f6, f7, min, canvas, c0022c2);
                break;
            case 1:
                i4 = j2;
                i5 = j3;
                float f8 = f2 / 2.0f;
                float f9 = f8 * 0.93f;
                float f10 = f / 2.0f;
                float f11 = f9 * 0.5f;
                float f12 = (0.55f * f11) + f9;
                float f13 = (0.2f * f9) + f8;
                r(this, canvas, f10 - f12, f13, f11, c0022c25, "l", t(c0018b2, 0), Integer.valueOf(y(c0018b2)), s(c0018b2, 0), "", 0, y(c0018b2), false, 12288);
                float f14 = f10 + f12;
                int i15 = iArr[6];
                if (valid(1, iArr[1]) || !valid(6, i15)) {
                    c0022c2 = c0022c25;
                    c0018b22 = c0018b2;
                    r(this, canvas, f14, f13, f11, c0022c2, "r", t(c0018b2, 1), Integer.valueOf(l(c0018b2)), s(c0018b2, 1), "%", 1, l(c0018b2), true, 4096);
                } else {
                    c0022c2 = c0022c25;
                    r(this, canvas, f14, f13, f11, c0022c25, "r", Float.valueOf((i15 + 20.0f) / 80.0f), i15 >= 50 ? -50384 : null, String.valueOf(i15), "°C", 3, c0022c25.f1026i, true, 4096);
                    c0018b22 = c0018b2;
                }
                ThemeColors c0022c26 = c0022c2;
                b(canvas, f10, f8, f9, c0022c26, c0018b2);
                m(f10, f8, f9, canvas, c0022c26);
                break;
            case 2:
                i4 = j2;
                i5 = j3;
                c0022c22 = c0022c25;
                float f15 = f2 / 2.0f;
                float f16 = f15 * 0.86f;
                float f17 = f / 2.0f;
                b(canvas, f17, f15, f16, c0022c22, c0018b2);
                float f18 = f16 * 1.13f;
                float f19 = f16 * 0.075f;
                rectF.set(f17 - f18, f15 - f18, f17 + f18, f15 + f18);
                A(c0022c22.f1022d, f19, true);
                canvas.drawArc(rectF, 140.0f, 80.0f, false, paint2);
                int i16 = iArr[4];
                boolean M2 = valid(4, i16);
                int i17 = c0022c22.f1023e;
                if (M2) {
                    float i18 = clampf((i16 + 50.0f) / 200.0f, 0.0f, 1.0f);
                    int e2 = i18 < 0.25f ? -14498466 : lerpColor(i17, c0022c22.f, i18);
                    A(withAlpha(e2, 70), f19 * 1.9f, true);
                    float f20 = i18 - 0.25f;
                    i6 = i17;
                    i7 = 70;
                    i8 = i16;
                    canvas.drawArc(rectF, (Math.min(i18, 0.25f) * 80.0f) + 140.0f, Math.abs(f20) * 80.0f, false, paint2);
                    A(e2, f19, true);
                    canvas.drawArc(rectF, (Math.min(i18, 0.25f) * 80.0f) + 140.0f, Math.abs(f20) * 80.0f, false, paint2);
                } else {
                    i6 = i17;
                    i7 = 70;
                    i8 = i16;
                }
                A(withAlpha(c0022c22.f1025h, 200), 0.018f * f16, true);
                float f21 = f18 - f19;
                float f22 = f18 + f19;
                canvas.drawLine(polarX(f17, f21, 160.0f), polarY(f15, f21, 160.0f), polarX(f17, f22, 160.0f), polarY(f15, f22, 160.0f), paint2);
                A(c0022c22.f1022d, f19, true);
                canvas.drawArc(rectF, 40.0f, -80.0f, false, paint2);
                int i19 = iArr[0];
                if (valid(0, i19) && i19 > 0) {
                    int i20 = i19 < 15 ? -50384 : -13315175;
                    A(withAlpha(i20, i7), f19 * 1.9f, true);
                    float f23 = (i19 * (-80.0f)) / 100.0f;
                    canvas.drawArc(rectF, 40.0f, f23, false, paint2);
                    A(i20, f19, true);
                    canvas.drawArc(rectF, 40.0f, f23, false, paint2);
                }
                float f24 = f16 * 1.52f;
                float f25 = f17 - f24;
                float f26 = 0.3f * f16;
                float f27 = f15 - (0.6f * f16);
                float f28 = (0.46f * f16) + f15;
                float f29 = f16 * 0.16f;
                e(canvas, c0022c22, "lc", f25 - f26, f27, f25 + f26, f28, f29);
                float f30 = f24 + f17;
                e(canvas, c0022c22, "rc", f30 - f26, f27, f30 + f26, f28, f29);
                int i21 = i8;
                v(canvas, c0022c22, f25, f15, f16, 2, (!valid(4, i21) || i21 >= 0) ? i6 : -14498466, valid(4, i21) ? String.valueOf(i21) : "--", "kW");
                v(canvas, c0022c22, f30, f15, f16, 0, y(c0018b2), s(c0018b2, 0), "");
                m(f17, f15, f16, canvas, c0022c22);
                c0018b22 = c0018b2;
                c0022c2 = c0022c22;
                break;
            case 3:
                i4 = j2;
                i5 = j3;
                String str4 = "%";
                c0022c23 = c0022c25;
                e(canvas, c0022c25, "p", 0.0f, 0.0f, f, f2, f2 * 0.09f);
                float f31 = f2 * 0.08f;
                float f32 = f2 * 0.03f;
                float f33 = f2 * 0.085f;
                Paint.Align align = Paint.Align.LEFT;
                o(canvas, c0022c25, c0018b2, f31 + f32, (0.16f * f2) + f31, f33, f33, align);
                String z2 = z(c0018b2);
                float f34 = f / 2.0f;
                float f35 = f2 * 0.535f;
                float f36 = f2 * 0.4f;
                nn(typeface3, "bold");
                D(this, canvas, z2, f34, f35, f36, c0022c23.f1025h, typeface3);
                Paint paint3 = this.b;
                paint3.reset();
                paint3.setLetterSpacing(0.0f);
                paint3.setTextScaleX(1.0f);
                paint3.setTypeface(typeface3);
                paint3.setTextSize(f36);
                nn(typeface2, "medium");
                C(canvas, "km/h", (paint3.measureText(z2) / 2.0f) + f34 + f32, f35, f2 * 0.075f, c0022c23.f1026i, typeface2, align);
                float f37 = f - f31;
                float f38 = f2 * 0.6f;
                float f39 = f2 * 0.05f;
                float f40 = 30;
                float f41 = (f37 - f31) / f40;
                float i22 = clampf(c0018b2.f1011a / 240.0f, 0.0f, 1.0f);
                int i23 = 0;
                for (int i24 = 30; i23 < i24; i24 = 30) {
                    if (c0018b2.b && c0018b2.f1011a > 0.5f) {
                        float f42 = i23;
                        if ((f42 + 0.5f) / f40 <= i22) {
                            i9 = lerpColor(c0022c23.f1023e, c0022c23.f, f42 / (f40 - 1.0f));
                            k(i9);
                            RectF rectF2 = this.f;
                            float f43 = f41 * 0.14f;
                            float f44 = (i23 * f41) + f31 + f43;
                            i23++;
                            rectF2.set(f44, f38, ((i23 * f41) + f31) - f43, f38 + f39);
                            float f45 = f39 * 0.2f;
                            canvas.drawRoundRect(rectF2, f45, f45, paint2);
                            str4 = str4;
                        }
                    }
                    i9 = c0022c23.f1022d;
                    k(i9);
                    RectF rectF22 = this.f;
                    float f432 = f41 * 0.14f;
                    float f442 = (i23 * f41) + f31 + f432;
                    i23++;
                    rectF22.set(f442, f38, ((i23 * f41) + f31) - f432, f38 + f39);
                    float f452 = f39 * 0.2f;
                    canvas.drawRoundRect(rectF22, f452, f452, paint2);
                    str4 = str4;
                }
                String str5 = str4;
                float f46 = f2 * 0.82f;
                q(canvas, c0022c23, f31, f * 0.47f, f46, f2, 0, y(c0018b2), t(c0018b2, 0), s(c0018b2, 0));
                c0018b23 = c0018b2;
                q(canvas, c0022c23, f * 0.53f, f37, f46, f2, 1, l(c0018b2), t(c0018b2, 1), s(c0018b2, 1) + str5);
                float f47 = f2 * 0.035f;
                float f48 = f31 + f47;
                d(canvas, c0022c23, f37 - (f2 * 0.17f), f48, f37 - (0.04f * f2), f48, f39);
                h(f34, 0.715f * f2, f47);
                c0022c2 = c0022c23;
                c0018b22 = c0018b23;
                break;
            case 4:
                i4 = j2;
                i5 = j3;
                c0022c22 = c0022c25;
                float f49 = f2 / 2.0f;
                e(canvas, c0022c25, "p", 0.0f, 0.0f, f, f2, f49);
                float f50 = f2 * 0.5f;
                float f51 = f2 * 0.31f;
                k(c0022c22.b);
                canvas.drawCircle(f50, f49, f51, paint2);
                rectF.set(f50 - f51, f49 - f51, f50 + f51, f49 + f51);
                float f52 = f2 * 0.05f;
                A(c0022c22.f1022d, f52, true);
                canvas.drawArc(rectF, 135.0f, 270.0f, false, paint2);
                float i25 = clampf(c0018b2.f1011a / 240.0f, 0.0f, 1.0f);
                if (!c0018b2.b || i25 <= 0.002f) {
                    f3 = f49;
                } else {
                    A(-16777216, f52, true);
                    paint2.setShader(B("pg", f50, f49, c0022c22));
                    f3 = f49;
                    canvas.drawArc(rectF, 135.0f, i25 * 270.0f, false, paint2);
                    paint2.setShader(null);
                }
                nn(typeface3, "bold");
                D(this, canvas, n(c0018b2.f1012c), f50, (0.36f * f51) + f3, f51 * 1.0f, c0022c22.f1023e, typeface3);
                Paint.Align align2 = Paint.Align.LEFT;
                C(canvas, z(c0018b2), f2 * 1.0f, f2 * 0.64f, f2 * 0.52f, c0022c22.f1025h, typeface3, align2);
                nn(typeface2, "medium");
                C(canvas, "km/h", f2 * 1.03f, f2 * 0.87f, f2 * 0.13f, c0022c22.f1026i, typeface2, align2);
                float f53 = f2 * 2.05f;
                float f54 = f2 * 0.2f;
                p(canvas, 0, f53, f51, f54, y(c0018b2));
                float f55 = f2 * 0.16f;
                float f56 = f53 + f55;
                float f57 = f2 * 0.06f;
                // battery % removed
                float f58 = f2 * 0.69f;
                p(canvas, 1, f53, f58, f54, l(c0018b2));
                C(canvas, s(c0018b2, 1) + "%", f56, f58 + f57, f55, c0022c22.f1025h, typeface3, align2);
                float f59 = f - (0.24f * f2);
                float f60 = f2 * 0.1f;
                d(canvas, c0022c22, f59, f2 * 0.3f, f59, f2 * 0.7f, f60);
                h(f / 2.0f, f60, f57);
                c0018b22 = c0018b2;
                c0022c2 = c0022c22;
                break;
            case 5:
                i4 = j2;
                i5 = j3;
                c0018b22 = c0018b2;
                c0022c22 = c0022c25;
                float min2 = (Math.min(f, f2) / 2.0f) * 0.93f;
                float f61 = f / 2.0f;
                float f62 = f2 / 2.0f;
                g(f61, f62, min2, canvas, c0022c22);
                float f63 = min2 * 0.1f;
                x(canvas, f61, f62, min2 * 0.8f, f63, c0022c22.f1022d, c0018b22.b ? clampf(c0018b22.f1011a / 240.0f, 0.0f, 1.0f) : 0.0f, null, c0022c22, "s");
                float f64 = min2 * 0.64f;
                Float t2 = t(c0018b22, 0);
                x(canvas, f61, f62, f64, f63, c0022c22.f1022d, t2 != null ? t2.floatValue() : 0.0f, Integer.valueOf(y(c0018b2)), c0022c22, "b");
                float f65 = min2 * 0.48f;
                Float t3 = t(c0018b22, 1);
                x(canvas, f61, f62, f65, f63, c0022c22.f1022d, t3 != null ? t3.floatValue() : 0.0f, Integer.valueOf(l(c0018b2)), c0022c22, "f");
                nn(typeface3, "bold");
                D(this, canvas, n(c0018b22.f1012c), f61, f62 - (0.2f * min2), min2 * 0.13f, c0022c22.f1023e, typeface3);
                D(this, canvas, z(c0018b2), f61, (0.12f * min2) + f62, min2 * 0.34f, c0022c22.f1025h, typeface3);
                nn(typeface2, "medium");
                D(this, canvas, "km/h", f61, (0.26f * min2) + f62, min2 * 0.075f, c0022c22.f1026i, typeface2);
                float f66 = min2 * 0.25f;
                float f67 = (0.6f * min2) + f62;
                w(canvas, c0022c22, f61 - f66, f67, f63, 0, y(c0018b2), s(c0018b22, 0));
                w(canvas, c0022c22, f61 + f66, f67, f63, 1, l(c0018b2), s(c0018b22, 1) + "%");
                float f68 = 0.105f * min2;
                float f69 = (0.82f * min2) + f62;
                d(canvas, c0022c22, f61 - f68, f69, f61 + f68, f69, min2 * 0.068f);
                h(f61, (0.44f * min2) + f62, min2 * 0.058f);
                c0022c2 = c0022c22;
                break;
            case 6:
                i4 = j2;
                i5 = j3;
                c0022c22 = c0022c25;
                float f70 = f / 2.0f;
                float min3 = Math.min(f70 * 0.94f, f2 * 0.7f);
                float f71 = f2 * 0.74f;
                float f72 = f71 - (min3 * 0.02f);
                String str6 = "medium";
                Typeface typeface4 = typeface2;
                e(canvas, c0022c22, "pl", f * 0.03f, f72, 0.97f * f, f2, f2 * 0.08f);
                canvas.save();
                float f73 = min3 * 0.07f;
                canvas.clipRect(0.0f, 0.0f, f, f71 + f73);
                k(-16777216);
                Object obj = hashMap.get("sz");
                if (obj == null) {
                    obj = a(this, f71, min3, c0022c22);
                    hashMap.put("sz", obj);
                }
                Paint paint4 = paint2;
                paint4.setShader((Shader) obj);
                canvas.drawCircle(f70, f71, min3, paint4);
                Object obj2 = hashMap.get("sf");
                if (obj2 == null) {
                    obj2 = new RadialGradient(f70, f71 - (min3 * 0.3f), min3 * 1.25f, c0022c22.f1020a, c0022c22.b, Shader.TileMode.CLAMP);
                    hashMap.put("sf", obj2);
                }
                paint4.setShader((Shader) obj2);
                canvas.drawCircle(f70, f71, min3 * 0.94f, paint4);
                paint4.setShader(null);
                canvas.restore();
                float f74 = min3 * 0.84f;
                float f75 = min3 * 0.075f;
                rectF.set(f70 - f74, f71 - f74, f70 + f74, f74 + f71);
                A(c0022c22.f1022d, f75, false);
                canvas.drawArc(rectF, 180.0f, 180.0f, false, paint4);
                float i26 = clampf(c0018b2.f1011a / 240.0f, 0.0f, 1.0f);
                boolean z3 = c0018b2.b;
                int i27 = c0022c22.f;
                int i28 = c0022c22.f1023e;
                if (!z3 || i26 <= 0.002f) {
                    i10 = i28;
                    i11 = i27;
                    c0018b22 = c0018b2;
                    f4 = f75;
                } else {
                    Object obj3 = hashMap.get("sa");
                    Object obj4 = obj3;
                    if (obj3 == null) {
                        SweepGradient sweepGradient = new SweepGradient(f70, f71, new int[]{i28, i27, i27}, new float[]{0.0f, 0.5f, 1.0f});
                        Matrix matrix = new Matrix();
                        matrix.setRotate(180.0f, f70, f71);
                        sweepGradient.setLocalMatrix(matrix);
                        hashMap.put("sa", sweepGradient);
                        obj4 = sweepGradient;
                    }
                    Shader shader = (Shader) obj4;
                    f4 = f75;
                    A(-16777216, f4 * 2.3f, false);
                    paint4.setShader(shader);
                    paint4.setAlpha(45);
                    float f76 = i26 * 180.0f;
                    i10 = i28;
                    i11 = i27;
                    c0018b22 = c0018b2;
                    canvas.drawArc(rectF, 180.0f, f76, false, paint4);
                    A(-16777216, f4, false);
                    paint4.setShader(shader);
                    canvas.drawArc(rectF, 180.0f, f76, false, paint4);
                    paint4.setShader(null);
                }
                int i29 = 0;
                while (i29 <= 240) {
                    float f77 = i29;
                    float a3 = mapAngle(f77, 180.0f, 240.0f, 180.0f);
                    boolean z4 = i29 % 40 == 0;
                    boolean z5 = c0018b22.b && f77 <= c0018b22.f1011a + 0.5f;
                    if (z5) {
                        i12 = i10;
                        i13 = i11;
                        b = lerpColor(i12, i13, f77 / 240.0f);
                    } else {
                        i12 = i10;
                        i13 = i11;
                        b = withAlpha(c0022c22.f1024g, z4 ? 150 : 80);
                    }
                    A(b, (z4 ? 0.02f : 0.01f) * min3, true);
                    float f78 = min3 * 0.74f;
                    int i30 = i12;
                    int i31 = i13;
                    canvas.drawLine(polarX(f70, f78, a3), polarY(f71, f78, a3), polarX(f70, (z4 ? 0.64f : 0.68f) * min3, a3), polarY(f71, (z4 ? 0.64f : 0.68f) * min3, a3), paint4);
                    if (z4) {
                        String valueOf = String.valueOf(i29);
                        float f79 = 0.55f * min3;
                        float i32 = polarX(f70, f79, a3);
                        float l2 = (min3 * 0.03f) + polarY(f71, f79, a3);
                        int b2 = z5 ? c0022c22.f1025h : withAlpha(c0022c22.f1026i, 190);
                        String str7 = str6;
                        Typeface typeface5 = typeface4;
                        nn(typeface5, str7);
                        str = str7;
                        typeface = typeface5;
                        paint = paint4;
                        D(this, canvas, valueOf, i32, l2, f4, b2, typeface);
                    } else {
                        paint = paint4;
                        str = str6;
                        typeface = typeface4;
                    }
                    i29 += 10;
                    str6 = str;
                    i10 = i30;
                    i11 = i31;
                    typeface4 = typeface;
                    paint4 = paint;
                }
                String str8 = str6;
                Typeface typeface6 = typeface4;
                int i33 = i10;
                if (c0018b22.b) {
                    c0026d2 = this;
                    c(canvas, f70, f71, (i26 * 180.0f) + 180.0f, min3 * 0.6f, min3 * 0.92f, min3, c0022c22);
                } else {
                    c0026d2 = this;
                }
                nn(typeface3, "bold");
                D(this, canvas, z(c0018b2), f70, f71 - (min3 * 0.16f), min3 * 0.36f, c0022c22.f1025h, typeface3);
                float f80 = min3 * 0.1f;
                D(this, canvas, n(c0018b22.f1012c), f70 - f80, f72, f80, c0022c22.f1023e, typeface3);
                nn(typeface6, str8);
                D(this, canvas, "km/h", f70 + f73, f72, f4, c0022c22.f1026i, typeface6);
                int i34 = iArr[4];
                float f81 = f2 * 0.92f;
                float f82 = f2 * 0.085f;
                w(canvas, c0022c22, f * 0.17f, f81, f82, 2, (!valid(4, i34) || i34 >= 0) ? i33 : -14498466, (valid(4, i34) ? String.valueOf(i34) : "--") + " kW");
                w(canvas, c0022c22, f * 0.83f, f81, f82, 0, y(c0018b2), s(c0018b22, 0));
                float f83 = f2 * 0.075f;
                float f84 = f2 * 0.915f;
                d(canvas, c0022c22, f70 - f83, f84, f70 + f83, f84, f2 * 0.05f);
                c0026d2.h(f70, f71 - (min3 * 0.62f), min3 * 0.05f);
                c0022c2 = c0022c22;
                break;
            case 7:
                i4 = j2;
                i5 = j3;
                c0018b23 = c0018b2;
                c0022c23 = c0022c25;
                float f85 = f2 / 2.0f;
                float f86 = f85 * 0.93f;
                float f87 = f / 2.0f;
                float f88 = f86 * 0.62f;
                e(canvas, c0022c25, "p", f * 0.02f, f85 - f88, f * 0.98f, f85 + f88, f88);
                float f89 = 0.46f * f86;
                float f90 = f86 * 1.42f;
                int i35 = iArr[2];
                u(canvas, c0022c23, f87 - f90, f85, f89, t(c0018b23, 0), y(c0018b2), 0, valid(2, i35) ? String.valueOf(i35) : "--", "km");
                int i36 = iArr[3];
                int i37 = iArr[5];
                if (valid(3, i36) || !valid(5, i37)) {
                    u(canvas, c0022c23, f87 + f90, f85, f89, t(c0018b23, 1), l(c0018b2), 1, valid(3, i36) ? String.valueOf(i36) : "--", "km");
                } else {
                    u(canvas, c0022c23, f87 + f90, f85, f89, null, c0022c23.f1026i, 3, i37 + "°", "C");
                }
                b(canvas, f87, f85, f86, c0022c23, c0018b2);
                m(f87, f85, f86, canvas, c0022c23);
                c0022c2 = c0022c23;
                c0018b22 = c0018b23;
                break;
            case 8:
                c0022c23 = c0022c25;
                i4 = j2;
                i5 = j3;
                float min4 = (Math.min(f, f2) / 2.0f) * 0.93f;
                float f91 = f / 2.0f;
                float f92 = f2 / 2.0f;
                k(withAlpha(c0022c23.b, 216));
                canvas.drawCircle(f91, f92, min4, paint2);
                A(withAlpha(c0022c23.f1021c, 200), min4 * 0.02f, true);
                canvas.drawCircle(f91, f92, 0.99f * min4, paint2);
                float f93 = 0.86f * min4;
                rectF.set(f91 - f93, f92 - f93, f91 + f93, f93 + f92);
                A(c0022c23.f1022d, min4 * 0.035f, true);
                canvas.drawArc(rectF, 135.0f, 270.0f, false, paint2);
                float i38 = clampf(c0018b2.f1011a / 240.0f, 0.0f, 1.0f);
                if (!c0018b2.b || i38 <= 0.002f) {
                    str2 = "%";
                    c0018b23 = c0018b2;
                } else {
                    Shader B2 = B("m", f91, f92, c0022c23);
                    A(-16777216, 0.11f * min4, true);
                    paint2.setShader(B2);
                    paint2.setAlpha(40);
                    float f94 = i38 * 270.0f;
                    str2 = "%";
                    c0018b23 = c0018b2;
                    canvas.drawArc(rectF, 135.0f, f94, false, paint2);
                    A(-16777216, min4 * 0.05f, true);
                    paint2.setShader(B2);
                    canvas.drawArc(rectF, 135.0f, f94, false, paint2);
                    paint2.setShader(null);
                }
                nn(typeface3, "bold");
                D(this, canvas, n(c0018b23.f1012c), f91, f92 - (0.38f * min4), min4 * 0.14f, c0022c23.f1023e, typeface3);
                float f95 = min4 * 0.56f;
                D(this, canvas, z(c0018b2), f91, (min4 * 0.17f) + f92, f95, c0022c23.f1025h, typeface3);
                nn(typeface2, "medium");
                D(this, canvas, "km/h", f91, (min4 * 0.34f) + f92, min4 * 0.09f, c0022c23.f1026i, typeface2);
                float f96 = min4 * 0.1f;
                w(canvas, c0022c23, f91, f92 + f95, f96, 0, y(c0018b2), s(c0018b23, 0));
                float f97 = (min4 * 0.8f) + f92;
                d(canvas, c0022c23, f91 - f96, f97, f91 + f96, f97, min4 * 0.065f);
                h(f91, f92 - (min4 * 0.58f), min4 * 0.058f);
                c0022c2 = c0022c23;
                c0018b22 = c0018b23;
                break;
            case 9:
                i4 = j2;
                i5 = j3;
                e(canvas, c0022c25, "p", 0.0f, 0.0f, f, f2, f2 * 0.12f);
                float f98 = f / 2.0f;
                float f99 = f2 * 0.45f;
                float f100 = f2 * 0.36f;
                float f101 = f100 * 0.1f;
                if (c0018b2.b) {
                    f5 = clampf(c0018b2.f1011a / 240.0f, 0.0f, 1.0f);
                    c0022c24 = c0022c25;
                } else {
                    c0022c24 = c0022c25;
                    f5 = 0.0f;
                }
                ThemeColors c0022c27 = c0022c24;
                x(canvas, f98, f99, f100, f101, c0022c24.f1022d, f5, null, c0022c27, "s");
                float f102 = f100 * 0.22f;
                nn(typeface3, "bold");
                D(this, canvas, n(c0018b2.f1012c), f98, f99 - (0.4f * f100), f102, c0022c27.f1023e, typeface3);
                D(this, canvas, z(c0018b2), f98, f99 + f102, f100 * 0.62f, c0022c27.f1025h, typeface3);
                nn(typeface2, "medium");
                D(this, canvas, "km/h", f98, (0.48f * f100) + f99, f100 * 0.17f, c0022c27.f1026i, typeface2);
                f(canvas, c0022c27, f * 0.17f, f2, 0, y(c0018b2), s(c0018b2, 0), iArr[2], 2, iArr[6], 6);
                f(canvas, c0022c27, f * 0.83f, f2, 1, l(c0018b2), s(c0018b2, 1) + "%", iArr[3], 3, iArr[5], 5);
                c0022c22 = c0022c27;
                A(withAlpha(c0022c22.f1026i, 60), 0.006f * f2, false);
                float f103 = f * 0.31f;
                float f104 = f2 * 0.16f;
                float f105 = f2 * 0.84f;
                canvas.drawLine(f103, f104, f103, f105, paint2);
                float f106 = f * 0.69f;
                canvas.drawLine(f106, f104, f106, f105, paint2);
                float f107 = f2 * 0.07f;
                float f108 = f2 * 0.88f;
                d(canvas, c0022c22, f98 - f107, f108, f98 + f107, f108, f2 * 0.05f);
                h(f98, f2 * 0.08f, f2 * 0.035f);
                c0018b22 = c0018b2;
                c0022c2 = c0022c22;
                break;
            default:
                c0022c2 = c0022c25;
                i4 = j2;
                i5 = j3;
                c0018b22 = c0018b2;
                break;
        }
        int i39 = c0018b22.f1014e;
        if (i39 != 0) {
            if (i39 == 1) {
                c0026d22 = this;
                canvas2 = canvas;
                i14 = i4;
            } else {
                c0026d22 = this;
                canvas2 = canvas;
                i14 = i5;
            }
            c0026d22.i(canvas2, c0022c2, i14);
        }
    }

    public final void k(int i2) {
        Paint paint = this.f1040a;
        paint.reset();
        paint.setAntiAlias(true);
        paint.setStyle(Paint.Style.FILL);
        paint.setColor(i2);
    }

    public final void m(float f, float f2, float f3, Canvas canvas, ThemeColors c0022c2) {
        float f4 = 0.105f * f3;
        float f5 = (0.79f * f3) + f2;
        d(canvas, c0022c2, f - f4, f5, f + f4, f5, f3 * 0.072f);
        h(f, (0.6f * f3) + f2, f3 * 0.058f);
    }

    public final void o(Canvas canvas, ThemeColors c0022c2, SpeedoData c0018b2, float f, float f2, float f3, float f4, Paint.Align align) {
        String[] strArr = {"P", "R", "N", "D"};
        int i2 = 0;
        while (i2 < 4) {
            int i3 = i2 + 1;
            boolean z2 = c0018b2.f1012c == i3;
            String str = strArr[i2];
            float f5 = (i2 * f4) + f;
            int b = z2 ? c0022c2.f1023e : withAlpha(c0022c2.f1026i, 110);
            Typeface typeface = this.f1041c;
            nn(typeface, "bold");
            C(canvas, str, f5, f2, f3, b, typeface, align);
            i2 = i3;
        }
    }

    public final void p(Canvas canvas, int i2, float f, float f2, float f3, int i3) {
        // Battery glyph only: skip icon drawing for type 0
        if (i2 == 0) return;
        Paint paint = this.f1040a;
        paint.reset();
        paint.setAntiAlias(true);
        Paint.Style style = Paint.Style.STROKE;
        paint.setStyle(style);
        paint.setStrokeWidth(0.11f * f3);
        paint.setStrokeCap(Paint.Cap.ROUND);
        paint.setStrokeJoin(Paint.Join.ROUND);
        paint.setColor(i3);
        RectF rectF = this.f;
        if (i2 == 0) {
            float f4 = f3 * 0.27f;
            rectF.set(f - (0.46f * f3), f2 - f4, (0.36f * f3) + f, f2 + f4);
            float f5 = f3 * 0.08f;
            canvas.drawRoundRect(rectF, f5, f5, paint);
            paint.setStyle(Paint.Style.FILL);
            float f6 = f3 * 0.12f;
            rectF.set((f3 * 0.4f) + f, f2 - f6, (0.5f * f3) + f, f2 + f6);
            float f7 = 0.03f * f3;
            canvas.drawRoundRect(rectF, f7, f7, paint);
            float f8 = f3 * 0.14f;
            rectF.set(f - (0.33f * f3), f2 - f8, f - (f3 * 0.02f), f2 + f8);
            canvas.drawRect(rectF, paint);
            return;
        }
        Path path = this.f1044g;
        if (i2 == 1) {
            float f9 = 0.44f * f3;
            float f10 = (0.12f * f3) + f;
            rectF.set(f - (0.38f * f3), f2 - f9, f10, f2 + f9);
            float f11 = f3 * 0.06f;
            canvas.drawRoundRect(rectF, f11, f11, paint);
            paint.setStyle(Paint.Style.FILL);
            rectF.set(f - (f3 * 0.27f), f2 - (0.32f * f3), (0.01f * f3) + f, f2 - (0.08f * f3));
            canvas.drawRect(rectF, paint);
            paint.setStyle(style);
            path.reset();
            path.moveTo(f10, f2 - (0.18f * f3));
            float f12 = (0.34f * f3) + f;
            path.lineTo(f12, f2 - (f3 * 0.02f));
            path.lineTo(f12, (f3 * 0.28f) + f2);
            path.quadTo(f12, (f3 * 0.4f) + f2, (0.23f * f3) + f, (0.36f * f3) + f2);
            canvas.drawPath(path, paint);
            return;
        }
        if (i2 != 2) {
            if (i2 != 3) {
                return;
            }
            canvas.drawLine(f, f2 - (0.42f * f3), f, (f3 * 0.1f) + f2, paint);
            paint.setStyle(Paint.Style.FILL);
            canvas.drawCircle(f, (0.26f * f3) + f2, 0.17f * f3, paint);
            paint.setStyle(style);
            paint.setStrokeWidth(0.07f * f3);
            float f13 = (f3 * 0.14f) + f;
            float f14 = f2 - (f3 * 0.3f);
            float f15 = f + (f3 * 0.28f);
            canvas.drawLine(f13, f14, f15, f14, paint);
            float f16 = f2 - (f3 * 0.12f);
            canvas.drawLine(f13, f16, f15, f16, paint);
            return;
        }
        paint.setStyle(Paint.Style.FILL);
        path.reset();
        float f17 = f3 * 0.1f;
        float f18 = 0.48f * f3;
        path.moveTo(f + f17, f2 - f18);
        float f19 = f3 * 0.3f;
        float f20 = f3 * 0.06f;
        float f21 = f2 + f20;
        path.lineTo(f - f19, f21);
        float f22 = f3 * 0.02f;
        path.lineTo(f - f22, f21);
        path.lineTo(f - f17, f2 + f18);
        float f23 = f + f19;
        float f24 = f2 - f20;
        path.lineTo(f23, f24);
        path.lineTo(f + f22, f24);
        path.close();
        canvas.drawPath(path, paint);
    }

    public final void q(Canvas canvas, ThemeColors c0022c2, float f, float f2, float f3, float f4, int i2, int i3, Float f5, String str) {
        p(canvas, i2, (0.05f * f4) + f, f3, f4 * 0.1f, i3);
        Typeface typeface = this.f1041c;
        nn(typeface, "bold");
        C(canvas, str, f2, (0.03f * f4) + f3, f4 * 0.085f, c0022c2.f1025h, typeface, Paint.Align.RIGHT);
        float f6 = (0.13f * f4) + f;
        float f7 = f2 - (0.24f * f4);
        float f8 = 0.045f * f4;
        if (f7 <= f6) {
            return;
        }
        RectF rectF = this.f;
        float f9 = f8 / 2.0f;
        float f10 = f3 - f9;
        float f11 = f3 + f9;
        rectF.set(f6, f10, f7, f11);
        k(c0022c2.f1022d);
        Paint paint = this.f1040a;
        canvas.drawRoundRect(rectF, f9, f9, paint);
        if (f5 == null || f5.floatValue() <= 0.003f) {
            return;
        }
        rectF.set(f6, f10, (clampf(f5.floatValue(), 0.0f, 1.0f) * (f7 - f6)) + f6, f11);
        k(i3);
        canvas.drawRoundRect(rectF, f9, f9, paint);
    }

    public final void u(Canvas canvas, ThemeColors c0022c2, float f, float f2, float f3, Float f4, int i2, int i3, String str, String str2) {
        k(withAlpha(c0022c2.b, 235));
        Paint paint = this.f1040a;
        canvas.drawCircle(f, f2, f3, paint);
        float f5 = 0.88f * f3;
        float f6 = 0.1f * f3;
        RectF rectF = this.f1043e;
        rectF.set(f - f5, f2 - f5, f + f5, f5 + f2);
        A(c0022c2.f1022d, f6, true);
        canvas.drawArc(rectF, 120.0f, 300.0f, false, paint);
        if (f4 != null && f4.floatValue() > 0.003f) {
            A(withAlpha(i2, 60), 1.9f * f6, true);
            canvas.drawArc(rectF, 120.0f, clampf(f4.floatValue(), 0.0f, 1.0f) * 300.0f, false, paint);
            A(i2, f6, true);
            canvas.drawArc(rectF, 120.0f, clampf(f4.floatValue(), 0.0f, 1.0f) * 300.0f, false, paint);
        }
        p(canvas, i3, f, f2 - (0.42f * f3), f3 * 0.26f, i2);
        Typeface typeface = this.f1041c;
        nn(typeface, "bold");
        D(this, canvas, str, f, (0.2f * f3) + f2, f3 * 0.46f, c0022c2.f1025h, typeface);
        Typeface typeface2 = this.f1042d;
        nn(typeface2, "medium");
        D(this, canvas, str2, f, (0.48f * f3) + f2, f3 * 0.17f, c0022c2.f1026i, typeface2);
    }

    public final void v(Canvas canvas, ThemeColors c0022c2, float f, float f2, float f3, int i2, int i3, String str, String str2) {
        float f4 = f3 * 0.34f;
        p(canvas, i2, f, f2 - f4, f3 * 0.24f, i3);
        Typeface typeface = this.f1041c;
        nn(typeface, "bold");
        D(this, canvas, str, f, (0.13f * f3) + f2, f4, c0022c2.f1025h, typeface);
        Typeface typeface2 = this.f1042d;
        nn(typeface2, "medium");
        D(this, canvas, str2, f, f2 + f4, f3 * 0.14f, c0022c2.f1026i, typeface2);
    }

    public final void w(Canvas canvas, ThemeColors c0022c2, float f, float f2, float f3, int i2, int i3, String str) {
        Typeface typeface = this.f1041c;
        nn(typeface, "bold");
        Paint paint = this.b;
        paint.reset();
        paint.setLetterSpacing(0.0f);
        paint.setTextScaleX(1.0f);
        paint.setTypeface(typeface);
        paint.setTextSize(f3);
        float f4 = f3 * 1.15f;
        float measureText = f - ((paint.measureText(str) + f4) / 2.0f);
        p(canvas, i2, (0.45f * f3) + measureText, f2 - (0.34f * f3), f3 * 0.95f, i3);
        C(canvas, str, measureText + f4, f2, f3, c0022c2.f1025h, typeface, Paint.Align.LEFT);
    }

    public final void x(Canvas canvas, float f, float f2, float f3, float f4, int i2, float f5, Integer num, ThemeColors c0022c2, String str) {
        RectF rectF = this.f1043e;
        rectF.set(f - f3, f2 - f3, f + f3, f2 + f3);
        A(i2, f4, true);
        Paint paint = this.f1040a;
        canvas.drawArc(rectF, 135.0f, 270.0f, false, paint);
        float i3 = clampf(f5, 0.0f, 1.0f);
        if (i3 <= 0.002f) {
            return;
        }
        if (num != null) {
            A(withAlpha(num.intValue(), 60), f4 * 1.8f, true);
            float f6 = i3 * 270.0f;
            canvas.drawArc(rectF, 135.0f, f6, false, paint);
            A(num.intValue(), f4, true);
            canvas.drawArc(rectF, 135.0f, f6, false, paint);
            return;
        }
        Shader B2 = B(str, f, f2, c0022c2);
        A(-16777216, f4 * 1.8f, true);
        paint.setShader(B2);
        paint.setAlpha(60);
        float f7 = i3 * 270.0f;
        canvas.drawArc(rectF, 135.0f, f7, false, paint);
        A(-16777216, f4, true);
        paint.setShader(B2);
        canvas.drawArc(rectF, 135.0f, f7, false, paint);
        paint.setShader(null);
    }

    // ---- ported helpers (from C.i / C0015b / V.e / androidx) ----
    private static boolean eq(Object a, Object b) {
        return a == b || (a != null && a.equals(b));
    }
    private static void req(Object o, String m) {
        if (o == null) throw new NullPointerException(m);
    }
    /** Kotlin checkNotNull – return value, ignore message */
    private static <T> T nn(T o) {
        if (o == null) throw new NullPointerException();
        return o;
    }
    private static <T> T nn(T o, String msg) {
        if (o == null) throw new NullPointerException(msg);
        return o;
    }
    private static int clampi(int v, int lo, int hi) {
        return v < lo ? lo : (v > hi ? hi : v);
    }
    private static float clampf(float v, float lo, float hi) {
        return v < lo ? lo : (v > hi ? hi : v);
    }
    /** linear interpolate */
    private static float lerp(float a, float b, float t) {
        return a + (b - a) * t;
    }
    /** OneHub C.i.H(float) ≈ Math.round */
    private static int lerp(float v) {
        return Math.round(v);
    }
    /**
     * androidx.activity.result.b.a used by decompiler:
     * mapAngle(a, b, c, w) = w + a * (b / c)
     */
    private static float mapAngle(float a, float b, float c, float w) {
        return w + a * (b / c);
    }
    private static boolean valid(int idx, int val) {
        return val != Integer.MIN_VALUE;
    }
    private static int withAlpha(int color, int alpha) {
        return (color & 0x00FFFFFF) | ((alpha & 0xFF) << 24);
    }
    private static int lerpColor(int c1, int c2, float t) {
        t = clampf(t, 0f, 1f);
        int a1 = (c1 >> 24) & 0xFF, r1 = (c1 >> 16) & 0xFF, g1 = (c1 >> 8) & 0xFF, b1 = c1 & 0xFF;
        int a2 = (c2 >> 24) & 0xFF, r2 = (c2 >> 16) & 0xFF, g2 = (c2 >> 8) & 0xFF, b2 = c2 & 0xFF;
        int a = (int)(a1 + (a2 - a1) * t);
        int r = (int)(r1 + (r2 - r1) * t);
        int g = (int)(g1 + (g2 - g1) * t);
        int b = (int)(b1 + (b2 - b1) * t);
        return (a << 24) | (r << 16) | (g << 8) | b;
    }
    private static float polarX(float cx, float r, float deg) {
        return cx + (float)(r * Math.cos(Math.toRadians(deg)));
    }
    private static float polarY(float cy, float r, float deg) {
        return cy + (float)(r * Math.sin(Math.toRadians(deg)));
    }
    @SafeVarargs
    private static List<ThemeColors> themeList(ThemeColors... items) {
        return new ArrayList<>(Arrays.asList(items));
    }
}
