package com.geely.carreceiver

import android.os.Handler
import android.os.Looper

/** Process-wide state shared by the service (writer) and the screen (reader). */
object ReceiverState {
    data class Entry(val time: Long, val command: String, val ok: Boolean, val detail: String)

    @Volatile
    var running: Boolean = false
        private set

    @Volatile
    var lastError: String? = null
        private set

    /** Called on the main thread whenever something changed. */
    @Volatile
    var listener: (() -> Unit)? = null

    private val entries = ArrayList<Entry>()
    private val main = Handler(Looper.getMainLooper())

    fun setRunning(value: Boolean, error: String? = null) {
        running = value
        lastError = error
        notifyChanged()
    }

    fun addLog(entry: Entry) {
        synchronized(entries) {
            entries.add(0, entry)
            while (entries.size > MAX_ENTRIES) entries.removeAt(entries.size - 1)
        }
        notifyChanged()
    }

    fun snapshot(): List<Entry> = synchronized(entries) { ArrayList(entries) }

    private fun notifyChanged() {
        main.post { listener?.invoke() }
    }

    private const val MAX_ENTRIES = 30
}
