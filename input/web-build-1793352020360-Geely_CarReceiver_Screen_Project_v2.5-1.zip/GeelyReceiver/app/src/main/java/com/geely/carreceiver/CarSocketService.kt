package com.geely.carreceiver

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Intent
import android.os.Build
import android.os.IBinder
import android.util.Log
import androidx.core.app.NotificationCompat
import java.io.BufferedReader
import java.io.IOException
import java.io.InputStreamReader
import java.io.OutputStreamWriter
import java.net.InetSocketAddress
import java.net.ServerSocket
import java.net.Socket
import java.net.SocketException
import java.util.concurrent.ExecutorService
import java.util.concurrent.Executors
import kotlin.concurrent.thread

/**
 * TCP server on port 8888. One short connection per request:
 *
 *   request : "AUTH <pin> <COMMAND>\n"      (COMMAND = PING or one of CommandBackend.KNOWN)
 *   reply   : "OK" | "ERR_AUTH" | "ERR_LOCKED" | "ERR_UNKNOWN" | "ERR_FORMAT" | "ERR_EXEC <reason>"
 *
 * Compared with the original: the PIN is checked (the original executed anything sent by anybody on
 * the network, including door unlock and reboot), stopping the service really closes the port,
 * stalled clients cannot block the server, and the phone gets the real result of every command.
 */
class CarSocketService : Service() {

    private var serverSocket: ServerSocket? = null
    private val pool: ExecutorService = Executors.newFixedThreadPool(4)
    private lateinit var backend: CommandBackend

    private lateinit var processor: RequestProcessor

    @Volatile
    private var stopping = false

    override fun onCreate() {
        super.onCreate()
        startForegroundNotification()
        backend = CommandBackend(this)
        backend.ensureConfig()
        processor = RequestProcessor(
            pin = { Prefs.pin(this) },
            isKnown = { backend.isKnown(it) },
            execute = { backend.execute(it) },
            log = { command, ok, detail ->
                ReceiverState.addLog(ReceiverState.Entry(System.currentTimeMillis(), command, ok, detail))
            },
            authFailedText = { getString(R.string.log_auth_failed, it) }
        )
        startServer()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int = START_STICKY

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onDestroy() {
        stopping = true
        try {
            serverSocket?.close()
        } catch (e: IOException) {
            // already closed
        }
        pool.shutdownNow()
        ReceiverState.setRunning(false, ReceiverState.lastError)
        super.onDestroy()
    }

    // ------------------------------------------------------------------ foreground notification

    private fun startForegroundNotification() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                CHANNEL_ID,
                getString(R.string.notif_channel),
                NotificationManager.IMPORTANCE_LOW
            )
            getSystemService(NotificationManager::class.java)?.createNotificationChannel(channel)
        }
        val open = PendingIntent.getActivity(
            this, 0, Intent(this, MainActivity::class.java), PendingIntent.FLAG_IMMUTABLE
        )
        val notification: Notification = NotificationCompat.Builder(this, CHANNEL_ID)
            .setContentTitle(getString(R.string.notif_title))
            .setContentText(getString(R.string.notif_text))
            .setSmallIcon(R.drawable.ic_stat_car)
            .setContentIntent(open)
            .setOngoing(true)
            .build()
        startForeground(NOTIFICATION_ID, notification)
    }

    // ------------------------------------------------------------------ server

    private fun startServer() {
        thread(name = "car-accept") {
            var error: String? = null
            var server: ServerSocket? = null
            try {
                server = bindWithRetry()
                serverSocket = server
                // stopped while we were still waiting for the port: do not report "running"
                if (!stopping) {
                    ReceiverState.setRunning(true, null)
                    Log.i(TAG, "listening on port $PORT")
                }
                while (!stopping) {
                    val client = try {
                        server.accept()
                    } catch (e: SocketException) {
                        if (stopping) break else throw e
                    }
                    try {
                        pool.execute { handle(client) }
                    } catch (e: Exception) {
                        closeQuietly(client)
                        if (stopping) break
                    }
                }
            } catch (e: Exception) {
                if (!stopping) {
                    error = e.message ?: e.javaClass.simpleName
                    Log.e(TAG, "socket server error", e)
                }
            } finally {
                // whatever happened, never leave the port open behind us
                server?.let { closeQuietly(it) }
                if (!stopping) {
                    ReceiverState.setRunning(false, error)
                    stopSelf()
                }
            }
        }
    }

    /** The port can still be busy for a moment after a restart: retry a few times. */
    private fun bindWithRetry(): ServerSocket {
        var last: IOException? = null
        for (attempt in 1..5) {
            val server = ServerSocket()
            try {
                server.reuseAddress = true
                server.bind(InetSocketAddress(PORT))
                return server
            } catch (e: IOException) {
                last = e
                closeQuietly(server)
                if (stopping) break
                try {
                    Thread.sleep(1000)
                } catch (ie: InterruptedException) {
                    break
                }
            }
        }
        throw last ?: IOException("cannot bind port $PORT")
    }

    private fun handle(client: Socket) {
        try {
            client.soTimeout = READ_TIMEOUT_MS
            val ip = client.inetAddress?.hostAddress ?: "?"
            val reader = BufferedReader(InputStreamReader(client.getInputStream(), Charsets.UTF_8))
            val line = reader.readLine() ?: return
            val reply = processor.process(ip, line.take(200))
            val writer = OutputStreamWriter(client.getOutputStream(), Charsets.UTF_8)
            writer.write(reply + "\n")
            writer.flush()
        } catch (e: Exception) {
            Log.w(TAG, "client error: " + e.message)
        } finally {
            closeQuietly(client)
        }
    }

    private fun closeQuietly(socket: Socket) {
        try {
            socket.close()
        } catch (e: IOException) {
            // nothing to do
        }
    }

    private fun closeQuietly(server: ServerSocket) {
        try {
            server.close()
        } catch (e: IOException) {
            // nothing to do
        }
    }

    companion object {
        const val PORT = 8888
        private const val TAG = "CarSocketService"
        private const val CHANNEL_ID = "CarSocketServiceChannel"
        private const val NOTIFICATION_ID = 1
        private const val READ_TIMEOUT_MS = 3000
    }
}
