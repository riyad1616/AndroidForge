package com.geely.carreceiver

import android.graphics.Bitmap
import android.graphics.Color
import com.google.zxing.BarcodeFormat
import com.google.zxing.EncodeHintType
import com.google.zxing.qrcode.QRCodeWriter
import com.google.zxing.qrcode.decoder.ErrorCorrectionLevel

object QrCode {
    /**
     * Black-on-white QR bitmap, at most [maxPx] wide, with a whole number of pixels per module so the
     * edges stay sharp. The white quiet zone is provided by the white box around the ImageView.
     */
    fun render(text: String, maxPx: Int): Bitmap? {
        return try {
            val hints = HashMap<EncodeHintType, Any>()
            hints[EncodeHintType.ERROR_CORRECTION] = ErrorCorrectionLevel.M
            hints[EncodeHintType.MARGIN] = 0
            hints[EncodeHintType.CHARACTER_SET] = "UTF-8"
            val matrix = QRCodeWriter().encode(text, BarcodeFormat.QR_CODE, 0, 0, hints)
            val modules = matrix.width
            val scale = (maxPx / modules).coerceAtLeast(1)
            val size = modules * scale
            val pixels = IntArray(size * size)
            for (y in 0 until size) {
                val my = y / scale
                for (x in 0 until size) {
                    pixels[y * size + x] = if (matrix.get(x / scale, my)) Color.BLACK else Color.WHITE
                }
            }
            Bitmap.createBitmap(pixels, size, size, Bitmap.Config.ARGB_8888)
        } catch (e: Exception) {
            null
        }
    }
}
