package com.geely.carreceiver

import java.net.Inet4Address
import java.net.NetworkInterface
import java.util.Collections

object NetUtils {
    data class Addr(val iface: String, val ip: String)

    /** Usable IPv4 addresses of this head unit, Wi-Fi / hotspot interfaces first. */
    fun localIpv4(): List<Addr> {
        val found = ArrayList<Addr>()
        try {
            val interfaces = NetworkInterface.getNetworkInterfaces() ?: return found
            for (nif in Collections.list(interfaces)) {
                if (!nif.isUp || nif.isLoopback) continue
                for (address in Collections.list(nif.inetAddresses)) {
                    if (address !is Inet4Address || address.isLoopbackAddress || address.isLinkLocalAddress) continue
                    val ip = address.hostAddress ?: continue
                    found.add(Addr(nif.name, ip))
                }
            }
        } catch (e: Exception) {
            // no network information available
        }
        return found.sortedBy { rank(it.iface) }
    }

    private fun rank(name: String): Int = when {
        name.startsWith("wlan") -> 0
        name.startsWith("ap") || name.startsWith("swlan") -> 1
        name.startsWith("eth") -> 2
        else -> 3
    }
}
