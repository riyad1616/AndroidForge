package com.geely.carreceiver

import java.security.MessageDigest

/**
 * Protocol logic of the car-side server, kept free of Android classes so it can be tested on a plain JVM.
 *
 *   request : "AUTH <pin> <COMMAND>"
 *   reply   : "OK" | "ERR_AUTH" | "ERR_LOCKED" | "ERR_UNKNOWN" | "ERR_FORMAT" | "ERR_EXEC <reason>"
 *
 * Five wrong PINs from the same address lock that address for one minute, so the 6-digit PIN cannot be
 * guessed over the network.
 */
class RequestProcessor(
    private val pin: () -> String,
    private val isKnown: (String) -> Boolean,
    private val execute: (String) -> CommandBackend.ExecResult,
    private val log: (command: String, ok: Boolean, detail: String) -> Unit,
    private val authFailedText: (String) -> String,
    private val clock: () -> Long = { System.currentTimeMillis() }
) {
    private class Failures(var count: Int, var lockedUntil: Long)

    private val failures = HashMap<String, Failures>()

    fun process(ip: String, line: String): String {
        val parts = line.trim().split(' ', limit = 3)
        if (parts.size != 3 || parts[0] != "AUTH") return "ERR_FORMAT"
        if (isLocked(ip)) return "ERR_LOCKED"

        val expected = pin().toByteArray(Charsets.UTF_8)
        if (!MessageDigest.isEqual(parts[1].toByteArray(Charsets.UTF_8), expected)) {
            registerFailure(ip)
            log("AUTH", false, authFailedText(ip))
            return "ERR_AUTH"
        }
        clearFailures(ip)

        val cmd = parts[2].trim()
        if (cmd == "PING") return "OK"
        if (!isKnown(cmd)) return "ERR_UNKNOWN"

        val result = execute(cmd)
        log(cmd, result.ok, result.message)
        return if (result.ok) "OK" else "ERR_EXEC " + result.message.replace(Regex("\\s+"), " ").take(160)
    }

    private fun isLocked(ip: String): Boolean = synchronized(failures) {
        (failures[ip]?.lockedUntil ?: 0L) > clock()
    }

    private fun registerFailure(ip: String) {
        synchronized(failures) {
            val f = failures.getOrPut(ip) { Failures(0, 0L) }
            f.count++
            if (f.count >= MAX_FAILURES) {
                f.count = 0
                f.lockedUntil = clock() + LOCK_MS
            }
        }
    }

    private fun clearFailures(ip: String) {
        synchronized(failures) { failures.remove(ip) }
    }

    companion object {
        const val MAX_FAILURES = 5
        const val LOCK_MS = 60_000L
    }
}
