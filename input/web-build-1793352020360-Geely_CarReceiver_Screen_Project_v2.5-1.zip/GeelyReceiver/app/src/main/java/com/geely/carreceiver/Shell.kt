package com.geely.carreceiver

import java.io.IOException

/** Runs a process with a hard timeout (Process.waitFor(timeout) needs API 26; minSdk here is 24). */
object Shell {
    /** [failure] is set when the process could not start or was killed by the timeout. */
    data class Out(val exit: Int, val text: String, val failure: String?) {
        val ok: Boolean get() = failure == null && exit == 0
    }

    fun run(argv: Array<String>, timeoutMs: Long, maxChars: Int = 4000): Out {
        val process = try {
            ProcessBuilder(*argv).redirectErrorStream(true).start()
        } catch (e: IOException) {
            return Out(-1, "", e.message ?: "cannot start process")
        }
        try {
            process.outputStream.close()
        } catch (e: IOException) {
            // stdin is not used
        }

        val input = process.inputStream
        val text = StringBuilder()
        val buffer = ByteArray(1024)
        val deadline = System.currentTimeMillis() + timeoutMs

        // Always keep reading, even past the cap: a process whose pipe is full would block forever.
        fun drain() {
            try {
                while (input.available() > 0) {
                    val n = input.read(buffer)
                    if (n <= 0) break
                    if (text.length < maxChars) text.append(String(buffer, 0, n, Charsets.UTF_8))
                }
            } catch (e: IOException) {
                // process closed its output
            }
        }

        var exit: Int? = null
        while (exit == null) {
            drain()
            try {
                exit = process.exitValue()
            } catch (e: IllegalThreadStateException) {
                if (System.currentTimeMillis() > deadline) {
                    process.destroy()
                    return Out(-1, text.toString().trim(), "timeout after " + timeoutMs + " ms")
                }
                try {
                    Thread.sleep(40)
                } catch (ie: InterruptedException) {
                    process.destroy()
                    Thread.currentThread().interrupt()
                    return Out(-1, text.toString().trim(), "interrupted")
                }
            }
        }
        drain()
        return Out(exit, text.toString().trim(), null)
    }
}
