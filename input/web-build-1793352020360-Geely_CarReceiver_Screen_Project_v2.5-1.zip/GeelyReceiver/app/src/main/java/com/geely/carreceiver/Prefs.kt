package com.geely.carreceiver

import android.content.Context
import java.security.SecureRandom
import java.util.Locale

/** The pairing PIN: random, created on first use, shown on screen and inside the QR code. */
object Prefs {
    private const val FILE = "receiver"
    private const val KEY_PIN = "pin"

    @Synchronized
    fun pin(context: Context): String {
        val saved = context.getSharedPreferences(FILE, Context.MODE_PRIVATE).getString(KEY_PIN, null)
        if (saved != null && PairingLink.isValidPin(saved)) return saved
        return regenerate(context)
    }

    @Synchronized
    fun regenerate(context: Context): String {
        val pin = String.format(Locale.ROOT, "%06d", SecureRandom().nextInt(1_000_000))
        context.getSharedPreferences(FILE, Context.MODE_PRIVATE).edit().putString(KEY_PIN, pin).apply()
        return pin
    }
}
