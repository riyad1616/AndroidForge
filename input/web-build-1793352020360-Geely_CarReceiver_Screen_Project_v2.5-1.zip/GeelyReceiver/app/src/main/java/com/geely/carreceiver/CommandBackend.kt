package com.geely.carreceiver

import android.content.Context
import android.content.Intent
import java.io.File
import java.io.IOException

/**
 * Turns a command name received from the phone into something that actually runs on this head unit.
 *
 * The table lives in an editable text file (see [defaultText]) so it can be changed on the car screen
 * ("أوامر السيارة" button) without rebuilding the app. Most commands still write a token to
 * /dev/car_control, exactly like the original project; that device does not exist on a real head unit,
 * so those lines must still be replaced with commands that really work on the car (see the "فحص النظام"
 * report). The windows and sunroof already use a real mechanism: this car's launcher app
 * (com.flyme.auto.launcher) ships two exported, unprotected broadcast receivers — the same ones its own
 * widget buttons use — that call the real android.car.hardware.property.CarPropertyManager for us, with
 * no root needed. A line of the form `COMMAND=BROADCAST <action> <package>/<Class>` sends that broadcast
 * instead of running a shell command; see [execute].
 *
 * A second, different mechanism is also understood: `COMMAND=VHAL_INT <propertyId> <areaId[,areaId..]> <value>`
 * and `COMMAND=VHAL_BOOL <propertyId> <areaId[,areaId..]> <true|false>` write straight to the real Vehicle
 * HAL through android.car, from this app's own process (see [VhalAccess]) - no other app involved. In
 * general this is *not* expected to work: most vehicle-body properties need a signature|privileged
 * permission this app does not hold, so it may simply fail with SecurityException. `VHAL_GET_INT`/
 * `VHAL_GET_BOOL <propertyId> <areaId>` read a property back the same way, for testing. Run "فحص النظام"
 * (Diagnostics) first on any new property - it probes a list of candidates read-only and reports exactly
 * which ones this app can even see, before wiring a COMMAND to a VHAL_* write.
 *
 * Mirror fold/unfold, interior (dome) light, fuel cap, door lock, trunk and sunshade ([VHAL_DEFAULTS]) are
 * wired to exactly that, using REAL property ids read straight out of the car's own full VHAL catalogue -
 * not guessed or reverse-engineered. That catalogue came from `dumpsys car_service`, run from a genuine
 * root shell the user obtained on 2026-10-29 through a third-party on-device shell app, over an already-open
 * TCP adb port (this ECU ships with ro.secure=0, so adb/that shell is uid=0 directly, no su needed). An
 * earlier 2026-10-28 probe (from this app's own unprivileged process, no android.car.permission.* declared)
 * had found two of these ids ("mirror fold", "ambient light") readable - but those exact ids do NOT exist in
 * the real catalogue, so CarPropertyManager's legacy-id compat layer was silently remapping them to
 * something else; they have been replaced with the real, named properties below. Whether THIS app's own
 * unprivileged process is allowed to *write* each one, and the true/false polarity, are still unconfirmed.
 */
class CommandBackend(
    private val context: Context,
    private val suPaths: List<String> = SU_PATHS
) {

    data class ExecResult(val ok: Boolean, val message: String)

    /** Can this app really become root through su? [message] is "ok" or the reason su refused. */
    class SuStatus(val path: String?, val works: Boolean, val message: String)

    private class Config(val options: Map<String, String>, val commands: Map<String, String>)

    private val file: File get() = File(context.filesDir, FILE_NAME)
    private val execLock = Any()
    private val suLock = Any()
    private var suCache: SuStatus? = null
    private var suCacheAt = 0L

    fun isKnown(cmd: String) = cmd in KNOWN

    fun ensureConfig() {
        if (!file.exists()) {
            try {
                writeText(defaultText())
            } catch (e: IOException) {
                // execute() falls back to the built-in defaults when the file cannot be read
            }
        }
    }

    fun readText(): String = try {
        if (file.exists()) file.readText(Charsets.UTF_8) else defaultText()
    } catch (e: IOException) {
        defaultText()
    }

    @Throws(IOException::class)
    fun writeText(text: String) {
        file.writeText(text, Charsets.UTF_8)
    }

    @Throws(IOException::class)
    fun resetToDefault() = writeText(defaultText())

    /** True while at least one command still points at the placeholder device and that device is missing. */
    fun usesPlaceholder(): Boolean =
        parse(readText()).commands.values.any { it.contains(PLACEHOLDER_DEVICE) } && !File(PLACEHOLDER_DEVICE).exists()

    fun execute(cmd: String): ExecResult = synchronized(execLock) {
        val config = parse(readText())
        val line = config.commands[cmd] ?: return ExecResult(false, "no command configured for $cmd")
        if (line.isBlank()) return ExecResult(false, "empty command for $cmd")

        if (line.startsWith("BROADCAST ", ignoreCase = true)) {
            return sendVehicleBroadcast(line.substring("BROADCAST ".length).trim())
        }
        if (line.startsWith("VHAL_INT ", ignoreCase = true)) {
            return execVhalSet(line.substring("VHAL_INT ".length).trim(), isBool = false)
        }
        if (line.startsWith("VHAL_BOOL ", ignoreCase = true)) {
            return execVhalSet(line.substring("VHAL_BOOL ".length).trim(), isBool = true)
        }
        if (line.startsWith("VHAL_GET_INT ", ignoreCase = true)) {
            return execVhalGet(line.substring("VHAL_GET_INT ".length).trim(), isBool = false)
        }
        if (line.startsWith("VHAL_GET_BOOL ", ignoreCase = true)) {
            return execVhalGet(line.substring("VHAL_GET_BOOL ".length).trim(), isBool = true)
        }

        val timeoutMs = (config.options["timeout_ms"]?.toLongOrNull() ?: 4000L).coerceIn(500L, 20000L)
        val mode = (config.options["run_as_root"] ?: "auto").lowercase()
        val su = suStatus()
        val useRoot = when (mode) {
            "true" -> true
            "false" -> false
            else -> su.works // auto: only when su really gives root to this app
        }
        val suPath = su.path
        if (useRoot && suPath == null) return ExecResult(false, "run_as_root=true but no su binary was found")

        // The command runs exactly once: no silent retry without su (it hid the real reason and could repeat side effects).
        val out = if (useRoot && suPath != null) {
            Shell.run(arrayOf(suPath, "-c", line), timeoutMs)
        } else {
            Shell.run(arrayOf("sh", "-c", line), timeoutMs)
        }
        if (out.ok) return ExecResult(true, out.text)

        var detail = out.failure ?: ("exit=" + out.exit + (if (out.text.isNotEmpty()) ": " + out.text else ""))
        if (!useRoot && mode != "false" && suPath != null) detail += "  [su unusable: " + su.message + "]"
        ExecResult(false, detail)
    }

    /**
     * `BROADCAST <action> <package>/<Class>`: sends an explicit broadcast Intent to a component in another
     * app, exactly like tapping that app's own widget button would. Works without root, because Android lets
     * any app send a broadcast to a component that the target declares `exported` with no `android:permission`
     * — the vehicle operation itself then runs inside the TARGET app's process, using its own permissions,
     * not ours. This is fire-and-forget: a successful send only means the broadcast was dispatched, not that
     * the window (or whatever it controls) actually moved — there is no reply to confirm that.
     */
    private fun sendVehicleBroadcast(spec: String): ExecResult {
        val parts = spec.split(Regex("\\s+")).filter { it.isNotEmpty() }
        if (parts.size != 2) return ExecResult(false, "BROADCAST needs exactly: <action> <package>/<Class>, got '$spec'")
        val (action, target) = parts
        val slash = target.indexOf('/')
        if (slash <= 0 || slash == target.length - 1) return ExecResult(false, "bad BROADCAST target '$target' (expected package/Class)")
        val pkg = target.substring(0, slash)
        val cls = target.substring(slash + 1)
        val className = if (cls.startsWith(".")) pkg + cls else cls
        return try {
            context.applicationContext.sendBroadcast(Intent(action).setClassName(pkg, className))
            ExecResult(true, "broadcast '$action' sent to $pkg/$className (fire-and-forget, not confirmed)")
        } catch (e: Exception) {
            ExecResult(false, "broadcast failed: " + (e.message ?: e.javaClass.simpleName))
        }
    }

    /** `VHAL_INT <propertyId> <areaId[,areaId..]> <value>` / `VHAL_BOOL ... <true|false>`: writes straight
     *  to CarPropertyManager from inside this app's own process (see [VhalAccess]). Several comma-separated
     *  areas are written in sequence with the same value (e.g. folding both mirrors with one command). Not
     *  confirmed to work in general - the real error (often SecurityException) is reported back verbatim
     *  when it does not. */
    private fun execVhalSet(spec: String, isBool: Boolean): ExecResult {
        val parts = spec.split(Regex("\\s+")).filter { it.isNotEmpty() }
        val kind = if (isBool) "VHAL_BOOL" else "VHAL_INT"
        if (parts.size != 3) return ExecResult(false, "$kind needs: <propertyId> <areaId[,areaId..]> <value>, got '$spec'")
        val prop = parseFlexInt(parts[0]) ?: return ExecResult(false, "bad propertyId '${parts[0]}'")
        val areas = parts[1].split(",").map { it.trim() }.filter { it.isNotEmpty() }.map { parseFlexInt(it) }
        if (areas.isEmpty() || areas.any { it == null }) return ExecResult(false, "bad areaId '${parts[1]}'")

        // Parse and validate the value before touching VhalAccess, so a bad line is always reported as a
        // parse error, not masked by "VHAL unavailable" on a device/sandbox that cannot reach android.car.
        val boolValue: Boolean
        val intValue: Int
        if (isBool) {
            boolValue = when (parts[2].lowercase()) {
                "true", "1" -> true
                "false", "0" -> false
                else -> return ExecResult(false, "bad boolean value '${parts[2]}' (use true/false)")
            }
            intValue = 0
        } else {
            intValue = parseFlexInt(parts[2]) ?: return ExecResult(false, "bad value '${parts[2]}'")
            boolValue = false
        }

        val mgr = VhalAccess.manager(context.applicationContext)
            ?: return ExecResult(false, "VHAL unavailable: " + (VhalAccess.lastError() ?: "android.car.Car not found"))
        val sb = StringBuilder()
        var allOk = true
        for (area in areas) {
            val r = if (isBool) VhalAccess.setBool(mgr, prop, area!!, boolValue) else VhalAccess.setInt(mgr, prop, area!!, intValue)
            allOk = allOk && r.ok
            sb.append(r.message).append("; ")
        }
        return ExecResult(allOk, sb.toString().trimEnd(' ', ';'))
    }

    /** `VHAL_GET_INT <propertyId> <areaId>` / `VHAL_GET_BOOL ...`: reads a property back the same way, for
     *  testing from the phone without rebuilding the app. Read-only. */
    private fun execVhalGet(spec: String, isBool: Boolean): ExecResult {
        val parts = spec.split(Regex("\\s+")).filter { it.isNotEmpty() }
        val kind = if (isBool) "VHAL_GET_BOOL" else "VHAL_GET_INT"
        if (parts.size != 2) return ExecResult(false, "$kind needs: <propertyId> <areaId>, got '$spec'")
        val prop = parseFlexInt(parts[0]) ?: return ExecResult(false, "bad propertyId '${parts[0]}'")
        val area = parseFlexInt(parts[1]) ?: return ExecResult(false, "bad areaId '${parts[1]}'")
        val mgr = VhalAccess.manager(context.applicationContext)
            ?: return ExecResult(false, "VHAL unavailable: " + (VhalAccess.lastError() ?: "android.car.Car not found"))
        val value = VhalAccess.describeValue(mgr, prop, area)
        val failed = value.startsWith("unreadable")
        return ExecResult(!failed, value)
    }

    /** Accepts `0x`-prefixed hex (optionally negative) or plain decimal; used for VHAL property/area/value
     *  tokens, which the sources we found them in write in both forms. */
    private fun parseFlexInt(tok: String): Int? = try {
        val neg = tok.startsWith("-")
        val body = if (neg) tok.substring(1) else tok
        val v = if (body.startsWith("0x", ignoreCase = true)) body.substring(2).toLong(16) else body.toLong()
        (if (neg) -v else v).toInt()
    } catch (e: Exception) {
        null
    }

    /** Result of a real `su -c id` test, cached for a minute (running su before every command would be slow). */
    fun suStatus(): SuStatus = synchronized(suLock) {
        val now = System.currentTimeMillis()
        val cached = suCache
        if (cached != null && now - suCacheAt < SU_CACHE_MS) return cached
        val fresh = probeSu()
        suCache = fresh
        suCacheAt = now
        fresh
    }

    private fun probeSu(): SuStatus {
        val path = findSu() ?: return SuStatus(null, false, "no su binary found")
        val out = Shell.run(arrayOf(path, "-c", "id"), SU_PROBE_TIMEOUT_MS)
        val works = out.ok && out.text.contains("uid=0")
        val failure = out.failure
        val message = when {
            works -> "ok"
            failure != null -> failure
            out.text.isNotEmpty() -> out.text.replace(Regex("\\s+"), " ").take(120)
            else -> "exit=" + out.exit
        }
        return SuStatus(path, works, message)
    }

    private fun findSu(): String? =
        suPaths.firstOrNull { File(it).exists() }

    private fun parse(text: String): Config {
        val options = HashMap<String, String>()
        val commands = HashMap<String, String>()
        for (raw in text.lineSequence()) {
            val line = raw.trim()
            if (line.isEmpty() || line.startsWith("#")) continue
            val eq = line.indexOf('=')
            if (eq <= 0) continue
            val key = line.substring(0, eq).trim()
            val value = line.substring(eq + 1).trim()
            if (key in KNOWN) commands[key] = value else options[key.lowercase()] = value
        }
        return Config(options, commands)
    }

    companion object {
        const val FILE_NAME = "car_commands.txt"
        const val PLACEHOLDER_DEVICE = "/dev/car_control"
        private const val SU_CACHE_MS = 60_000L
        private const val SU_PROBE_TIMEOUT_MS = 5000L

        val SU_PATHS: List<String> = listOf(
            "/system/bin/su", "/system/xbin/su", "/sbin/su", "/su/bin/su", "/vendor/bin/su", "/system/sbin/su"
        )

        /** Found by reading this car's own launcher app (com.flyme.auto.launcher): its two exported,
         *  unprotected widget receivers, and the action string each one of its buttons sends. */
        private const val LAUNCHER_PKG = "com.flyme.auto.launcher"
        private const val WINDOWS_WIDGET = "com.coolray.vehicle.WindowsWidgetV2"
        private const val ROOF_WIDGET = "com.coolray.vehicle.RoofWidgetV2"

        /** command name -> BROADCAST line, for the commands wired to that real mechanism. */
        private val BROADCAST_DEFAULTS: Map<String, String> = linkedMapOf(
            "CMD_WINDOW_OPEN" to "BROADCAST com.coolray.vehicle.ALL_OPEN $LAUNCHER_PKG/$WINDOWS_WIDGET",
            "CMD_WINDOW_CLOSE" to "BROADCAST com.coolray.vehicle.ALL_CLOSE $LAUNCHER_PKG/$WINDOWS_WIDGET",
            "CMD_SUNROOF_OPEN" to "BROADCAST com.coolray.vehicle.ROOF_OPEN $LAUNCHER_PKG/$ROOF_WIDGET",
            "CMD_SUNROOF_CLOSE" to "BROADCAST com.coolray.vehicle.ROOF_CLOSE $LAUNCHER_PKG/$ROOF_WIDGET"
        )

        /** 2026-10-29: the user got a real root shell on the car (a third-party on-device shell app, over
         *  an already-open TCP adb port - ro.secure=0 on this build makes that shell uid=0 directly, no su
         *  needed). `dumpsys car_service` run from that root shell dumped the car's ENTIRE real property
         *  catalogue - 1407 properties, each with its vendor name, access level and area ids. That is ground
         *  truth, not a guess: the ids below are copied from that dump, not reverse-engineered.
         *
         *  This also *corrects* two ids used in v2.3/v2.4: 0x20090200 ("mirror fold") and 0x21051000
         *  ("ambient light") do NOT appear anywhere in the real catalogue - they are not real properties on
         *  this ECU. CarPropertyManager's internal legacy-id compat layer silently remapped them to *some*
         *  other property when v2.4 "read" them successfully, which is almost certainly why writing them did
         *  nothing. MIRROR_FOLD and the interior light below are the real, named, access=READ_WRITE
         *  properties from the dump - this needs fresh testing from scratch, not just a true/false swap. */
        private const val MIRROR_FOLD_PROP = 0x21402023 // real name: MIRROR_FOLD
        private const val MIRROR_FOLD_AREA = "0x0" // single global area (dump shows no per-area breakdown)
        private const val DOME_LIGHT_PROP = 0x21402069 // real name: BODY_LIGHT_DOME_ON (cabin/dome light)
        private const val FUEL_CAP_PROP = 0x11200308 // real name: FUEL_DOOR_OPEN - already confirmed correct

        /** Also from the same 2026-10-29 dump: real door-lock and trunk properties exist and are
         *  access=READ_WRITE, so CMD_DOOR_LOCK/UNLOCK and CMD_TRUNK_OPEN/CLOSE (already defined as phone-app
         *  commands, previously only writing to the placeholder device) are now wired to them too - all
         *  four doors at once via the comma-separated area list VHAL_BOOL already supports. */
        private const val DOOR_LOCK_PROP = 0x264020aa // real name: DOOR_LOCK
        private const val DOOR_LOCK_AREAS = "0x1,0x4,0x10,0x40" // row1 left/right, row2 left/right
        private const val TRUNK_POS_PROP = 0x264020a9 // real name: DOOR_POS
        private const val TRUNK_AREA = "0x20000000" // the REAR area of DOOR_POS = trunk/tailgate

        /** The user reported the sunroof opens but the *interior* part does not close. The real catalogue
         *  explains why: the glass roof and the interior sunshade are two separate properties. The existing
         *  BROADCAST_DEFAULTS ROOF_OPEN/ROOF_CLOSE only drive the glass; this new command drives the shade
         *  on its own, directly via VHAL. */
        private const val SUNSHADE_STATE_PROP = 0x2140209e // real name: BODY_WINDOW_SUNSHADE_STATE

        /** command name -> VHAL_BOOL line, for the commands wired to a direct (not BROADCAST) VHAL write.
         *  Every entry here is a *real*, named, access=READ_WRITE property from the 2026-10-29 dump - but
         *  "real property" only means the car accepts the write; true/false polarity and whether this app's
         *  process (no android.car.permission.* declared) is actually allowed to write it are still
         *  unconfirmed. Test each one and report back; swap true<->false in "أوامر السيارة" if backwards. */
        private val VHAL_DEFAULTS: Map<String, String> = linkedMapOf(
            "CMD_MIRROR_UNFOLD" to "VHAL_BOOL $MIRROR_FOLD_PROP $MIRROR_FOLD_AREA false",
            "CMD_MIRROR_FOLD" to "VHAL_BOOL $MIRROR_FOLD_PROP $MIRROR_FOLD_AREA true",
            "CMD_INTERIOR_ON" to "VHAL_BOOL $DOME_LIGHT_PROP 0x0 true",
            "CMD_INTERIOR_OFF" to "VHAL_BOOL $DOME_LIGHT_PROP 0x0 false",
            "CMD_FUEL_CAP_OPEN" to "VHAL_BOOL $FUEL_CAP_PROP 0x0 true",
            "CMD_FUEL_CAP_CLOSE" to "VHAL_BOOL $FUEL_CAP_PROP 0x0 false",
            "CMD_DOOR_LOCK" to "VHAL_BOOL $DOOR_LOCK_PROP $DOOR_LOCK_AREAS true",
            "CMD_DOOR_UNLOCK" to "VHAL_BOOL $DOOR_LOCK_PROP $DOOR_LOCK_AREAS false",
            "CMD_TRUNK_OPEN" to "VHAL_BOOL $TRUNK_POS_PROP $TRUNK_AREA true",
            "CMD_TRUNK_CLOSE" to "VHAL_BOOL $TRUNK_POS_PROP $TRUNK_AREA false",
            "CMD_SUNSHADE_OPEN" to "VHAL_BOOL $SUNSHADE_STATE_PROP 0x0 true",
            "CMD_SUNSHADE_CLOSE" to "VHAL_BOOL $SUNSHADE_STATE_PROP 0x0 false"
        )

        /** command name -> token written to the placeholder device (same table as the original project).
         *  Commands present in [BROADCAST_DEFAULTS] or [VHAL_DEFAULTS] are overridden with those in
         *  [defaultText]; their entries below only matter if someone deletes that line and wants the old
         *  placeholder back. */
        private val DEFAULTS: LinkedHashMap<String, String> = linkedMapOf(
            "CMD_WINDOW_OPEN" to "OPEN_WINDOWS",
            "CMD_WINDOW_CLOSE" to "CLOSE_WINDOWS",
            "CMD_SUNROOF_OPEN" to "OPEN_SUNROOF",
            "CMD_SUNROOF_CLOSE" to "CLOSE_SUNROOF",
            "CMD_AC_ON" to "AC_ON",
            "CMD_AC_OFF" to "AC_OFF",
            "CMD_MIRROR_UNFOLD" to "UNFOLD_MIRRORS",
            "CMD_MIRROR_FOLD" to "FOLD_MIRRORS",
            "CMD_FUEL_CAP_OPEN" to "OPEN_FUEL_CAP",
            "CMD_FUEL_CAP_CLOSE" to "CLOSE_FUEL_CAP",
            "CMD_SUNSHADE_OPEN" to "OPEN_SUNSHADE",
            "CMD_SUNSHADE_CLOSE" to "CLOSE_SUNSHADE",
            "CMD_HEADLIGHTS_ON" to "HEADLIGHTS_ON",
            "CMD_HEADLIGHTS_OFF" to "HEADLIGHTS_OFF",
            "CMD_HIGHBEAM_ON" to "HIGHBEAM_ON",
            "CMD_HIGHBEAM_OFF" to "HIGHBEAM_OFF",
            "CMD_INTERIOR_ON" to "INTERIOR_ON",
            "CMD_INTERIOR_OFF" to "INTERIOR_OFF",
            "CMD_FOG_ON" to "FOG_ON",
            "CMD_FOG_OFF" to "FOG_OFF",
            "CMD_DOOR_UNLOCK" to "DOOR_UNLOCK",
            "CMD_DOOR_LOCK" to "DOOR_LOCK",
            "CMD_TRUNK_OPEN" to "TRUNK_OPEN",
            "CMD_TRUNK_CLOSE" to "TRUNK_CLOSE",
            "CMD_HORN" to "HORN",
            "CMD_RADIO_ON" to "RADIO_ON",
            "CMD_RADIO_OFF" to "RADIO_OFF",
            "CMD_SEAT_HEAT_ON" to "SEAT_HEAT_ON",
            "CMD_SEAT_HEAT_OFF" to "SEAT_HEAT_OFF",
            "CMD_HAZARD_ON" to "HAZARD_ON",
            "CMD_HAZARD_OFF" to "HAZARD_OFF"
        )

        /** Every command the phone may send (the table above plus the reboot command). */
        val KNOWN: Set<String> = DEFAULTS.keys + "CMD_REBOOT"

        fun defaultText(): String {
            val sb = StringBuilder()
            sb.append("# Geely Receiver - command table\n")
            sb.append("# Several kinds of line are understood:\n")
            sb.append("#   COMMAND_NAME=shell command                              (run with: sh -c ...)\n")
            sb.append("#   COMMAND_NAME=BROADCAST <action> <package>/<Class>       (sends a broadcast, no shell)\n")
            sb.append("#   COMMAND_NAME=VHAL_INT <propId> <area[,area..]> <value>  (writes android.car directly)\n")
            sb.append("#   COMMAND_NAME=VHAL_BOOL <propId> <area[,area..]> <true|false>\n")
            sb.append("#   COMMAND_NAME=VHAL_GET_INT <propId> <area>  / VHAL_GET_BOOL <propId> <area>  (read-only)\n")
            sb.append("# The /dev/car_control lines below are placeholders from the original project.\n")
            sb.append("# Replace them with commands that really work on this head unit.\n")
            sb.append("# The 4 BROADCAST lines below are real: this car's own launcher app exposes the\n")
            sb.append("# exact same window/sunroof buttons its widgets use, with no permission needed to call them.\n")
            sb.append("# The VHAL_BOOL lines below (mirror, interior/dome light, fuel cap, door lock, trunk,\n")
            sb.append("# sunshade) use REAL property ids copied from the car's own full property catalogue\n")
            sb.append("# (dumpsys car_service from a real root shell, 2026-10-29) - not guessed. Whether THIS\n")
            sb.append("# app's process (no android.car permission declared) is allowed to write each one, and the\n")
            sb.append("# true/false polarity, are still unconfirmed - test each button and report back; if one does\n")
            sb.append("# the opposite of its label, swap true<->false on just that line.\n")
            sb.append("# Any other VHAL_* line you add yourself is NOT confirmed to work - run \"فحص النظام\" first,\n")
            sb.append("# it probes candidate properties read-only and reports which ones this app can even see\n")
            sb.append("# before you wire a COMMAND to write one. propId/area accept 0x hex.\n")
            sb.append("# Avoid backslashes. Lines starting with # are ignored.\n")
            sb.append("#\n")
            sb.append("# run_as_root: auto = use su when it exists | true | false (BROADCAST lines ignore this)\n")
            sb.append("run_as_root=auto\n")
            sb.append("timeout_ms=4000\n\n")
            for ((name, token) in DEFAULTS) {
                val broadcast = BROADCAST_DEFAULTS[name]
                val vhal = VHAL_DEFAULTS[name]
                when {
                    broadcast != null -> sb.append(name).append('=').append(broadcast).append('\n')
                    vhal != null -> sb.append(name).append('=').append(vhal).append('\n')
                    else -> sb.append(name).append("=echo '").append(token).append("' > ").append(PLACEHOLDER_DEVICE).append('\n')
                }
            }
            sb.append("CMD_REBOOT=reboot\n")
            return sb.toString()
        }
    }
}
