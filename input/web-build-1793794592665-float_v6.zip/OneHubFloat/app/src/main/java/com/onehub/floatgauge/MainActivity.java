package com.onehub.floatgauge;

import android.app.AppOpsManager;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.ApplicationInfo;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.Manifest;
import android.os.Build;
import android.os.Bundle;
import android.os.Process;
import android.provider.Settings;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.SeekBar;
import android.widget.Switch;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import java.util.ArrayList;
import java.util.Collections;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

public class MainActivity extends AppCompatActivity {

    private static final String PREFS = "onehub_float";
    private Switch sw;
    private Switch swHome;
    private TextView status;
    private TextView excludeSummary;
    private boolean waitPerm;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        // Home-only ON by default
        SharedPreferences sp0 = getSharedPreferences(PREFS, MODE_PRIVATE);
        if (!sp0.contains("home_only")) {
            sp0.edit().putBoolean("home_only", true).apply();
        }
        sw = findViewById(R.id.switch_float);
        swHome = findViewById(R.id.switch_home_only);
        status = findViewById(R.id.status);
        excludeSummary = findViewById(R.id.exclude_summary);

        SharedPreferences p = getSharedPreferences(PREFS, MODE_PRIVATE);
        boolean on = p.getBoolean("on", false);
        sw.setChecked(on);
        setStatus(on);
        refreshExcludeSummary();
        if (swHome != null) {
            swHome.setChecked(p.getBoolean("home_only", true));
            swHome.setOnCheckedChangeListener((b, checked) -> {
                getSharedPreferences(PREFS, MODE_PRIVATE).edit()
                        .putBoolean("home_only", checked).apply();
                if (checked && !hasUsageAccess()) {
                    Toast.makeText(this, R.string.need_usage_home, Toast.LENGTH_LONG).show();
                }
            });
        }

        // Transparency 20% .. 100%
        final SeekBar seekAlpha = findViewById(R.id.seek_alpha);
        final TextView alphaValue = findViewById(R.id.alpha_value);
        final Button btnAlphaDown = findViewById(R.id.btn_alpha_down);
        final Button btnAlphaUp = findViewById(R.id.btn_alpha_up);
        int alphaPct = Math.round(p.getFloat("alpha", 1.0f) * 100f);
        if (alphaPct < 20) alphaPct = 20;
        if (alphaPct > 100) alphaPct = 100;
        if (seekAlpha != null) {
            seekAlpha.setProgress(alphaPct);
            if (alphaValue != null) alphaValue.setText(alphaPct + "%");
            seekAlpha.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
                @Override public void onProgressChanged(SeekBar s, int progress, boolean fromUser) {
                    int v = Math.max(20, progress);
                    if (v != progress) s.setProgress(v);
                    if (alphaValue != null) alphaValue.setText(v + "%");
                    getSharedPreferences(PREFS, MODE_PRIVATE).edit()
                            .putFloat("alpha", v / 100f).apply();
                }
                @Override public void onStartTrackingTouch(SeekBar s) {}
                @Override public void onStopTrackingTouch(SeekBar s) {}
            });
        }
        if (btnAlphaDown != null) {
            btnAlphaDown.setOnClickListener(v -> {
                if (seekAlpha == null) return;
                int n = Math.max(20, seekAlpha.getProgress() - 5);
                seekAlpha.setProgress(n);
            });
        }
        if (btnAlphaUp != null) {
            btnAlphaUp.setOnClickListener(v -> {
                if (seekAlpha == null) return;
                int n = Math.min(100, seekAlpha.getProgress() + 5);
                seekAlpha.setProgress(n);
            });
        }

        if (on && canOverlay()) startSvc();

        sw.setOnCheckedChangeListener((b, checked) -> {
            if (checked) enable();
            else disable();
        });

        Button btnEx = findViewById(R.id.btn_exclude);
        if (btnEx != null) {
            btnEx.setOnClickListener(v -> openExcludePicker());
        }
        Button btnUsage = findViewById(R.id.btn_usage);
        if (btnUsage != null) {
            btnUsage.setOnClickListener(v -> {
                try {
                    startActivity(new Intent(Settings.ACTION_USAGE_ACCESS_SETTINGS));
                } catch (Exception e) {
                    Toast.makeText(this, "افتح إعدادات وصول الاستخدام يدوياً", Toast.LENGTH_LONG).show();
                }
            });
        }
    }

    @Override
    protected void onResume() {
        super.onResume();
        refreshExcludeSummary();
        if (waitPerm) {
            waitPerm = false;
            if (canOverlay()) {
                sw.setChecked(true);
                getSharedPreferences(PREFS, MODE_PRIVATE).edit().putBoolean("on", true).apply();
                startSvc();
                setStatus(true);
            } else {
                sw.setChecked(false);
                setStatus(false);
                Toast.makeText(this, "لم يُمنح الإذن", Toast.LENGTH_SHORT).show();
            }
        }
    }

    private void openExcludePicker() {
        if (!hasUsageAccess()) {
            new AlertDialog.Builder(this)
                    .setTitle("إذن مطلوب")
                    .setMessage("لاستثناء تطبيقات، امنح إذن «وصول الاستخدام» ثم عد واختر التطبيقات.")
                    .setPositiveButton("فتح الإعدادات", (d, w) -> {
                        try {
                            startActivity(new Intent(Settings.ACTION_USAGE_ACCESS_SETTINGS));
                        } catch (Exception ignored) {}
                    })
                    .setNegativeButton("لاحقاً", null)
                    .show();
            return;
        }

        PackageManager pm = getPackageManager();
        // All launchable apps (home-screen apps) - not only "non-system"
        Intent launcher = new Intent(Intent.ACTION_MAIN, null);
        launcher.addCategory(Intent.CATEGORY_LAUNCHER);
        List<android.content.pm.ResolveInfo> resolved =
                pm.queryIntentActivities(launcher, 0);
        List<String> labels = new ArrayList<>();
        List<String> pkgs = new ArrayList<>();
        Set<String> seen = new HashSet<>();
        for (android.content.pm.ResolveInfo ri : resolved) {
            if (ri.activityInfo == null) continue;
            String pkg = ri.activityInfo.packageName;
            if (pkg == null || pkg.equals(getPackageName())) continue;
            if (!seen.add(pkg)) continue;
            CharSequence label = ri.loadLabel(pm);
            if (label == null) label = pkg;
            labels.add(label + "\n" + pkg);
            pkgs.add(pkg);
        }
        // Also include other installed user apps without launcher icon
        for (ApplicationInfo ai : pm.getInstalledApplications(0)) {
            if (ai.packageName.equals(getPackageName())) continue;
            if (!seen.add(ai.packageName)) continue;
            // skip pure system framework packages without a label worth listing
            if ((ai.flags & ApplicationInfo.FLAG_SYSTEM) != 0
                    && (ai.flags & ApplicationInfo.FLAG_UPDATED_SYSTEM_APP) == 0) {
                continue;
            }
            CharSequence label = pm.getApplicationLabel(ai);
            labels.add(label + "\n" + ai.packageName);
            pkgs.add(ai.packageName);
        }
        List<Integer> order = new ArrayList<>();
        for (int i = 0; i < labels.size(); i++) order.add(i);
        Collections.sort(order, (a, b) -> labels.get(a).compareToIgnoreCase(labels.get(b)));

        Set<String> selected = loadExclude();
        boolean[] checked = new boolean[order.size()];
        CharSequence[] items = new CharSequence[order.size()];
        for (int i = 0; i < order.size(); i++) {
            int idx = order.get(i);
            items[i] = labels.get(idx);
            checked[i] = selected.contains(pkgs.get(idx));
        }

        new AlertDialog.Builder(this)
                .setTitle(R.string.exclude_dialog_title)
                .setMultiChoiceItems(items, checked, (d, which, isChecked) -> checked[which] = isChecked)
                .setPositiveButton(R.string.save, (d, w) -> {
                    Set<String> out = new HashSet<>();
                    for (int i = 0; i < checked.length; i++) {
                        if (checked[i]) out.add(pkgs.get(order.get(i)));
                    }
                    saveExclude(out);
                    refreshExcludeSummary();
                    Toast.makeText(this, "تم الحفظ (" + out.size() + ")", Toast.LENGTH_SHORT).show();
                })
                .setNeutralButton(R.string.clear_all, (d, w) -> {
                    saveExclude(new HashSet<>());
                    refreshExcludeSummary();
                })
                .setNegativeButton(R.string.cancel, null)
                .show();
    }

    private Set<String> loadExclude() {
        String raw = getSharedPreferences(PREFS, MODE_PRIVATE).getString("exclude", "");
        Set<String> set = new HashSet<>();
        if (raw != null && !raw.isEmpty()) {
            for (String s : raw.split(",")) {
                s = s.trim();
                if (!s.isEmpty()) set.add(s);
            }
        }
        return set;
    }

    private void saveExclude(Set<String> set) {
        getSharedPreferences(PREFS, MODE_PRIVATE).edit()
                .putString("exclude", String.join(",", set))
                .apply();
    }

    private void refreshExcludeSummary() {
        if (excludeSummary == null) return;
        int n = loadExclude().size();
        excludeSummary.setText(n == 0 ? getString(R.string.no_exclude) : (n + " / " + getString(R.string.btn_exclude)));
    }

    private boolean hasUsageAccess() {
        try {
            AppOpsManager ops = (AppOpsManager) getSystemService(APP_OPS_SERVICE);
            int mode = ops.checkOpNoThrow(AppOpsManager.OPSTR_GET_USAGE_STATS, Process.myUid(), getPackageName());
            return mode == AppOpsManager.MODE_ALLOWED;
        } catch (Throwable t) {
            return false;
        }
    }

    private void enable() {
        if (!canOverlay()) {
            sw.setOnCheckedChangeListener(null);
            sw.setChecked(false);
            sw.setOnCheckedChangeListener((b, c) -> { if (c) enable(); else disable(); });
            waitPerm = true;
            Toast.makeText(this, R.string.need_overlay, Toast.LENGTH_LONG).show();
            startActivity(new Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                    Uri.parse("package:" + getPackageName())));
            return;
        }
        getSharedPreferences(PREFS, MODE_PRIVATE).edit().putBoolean("on", true).apply();
        if (Build.VERSION.SDK_INT >= 23) {
            if (checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
                requestPermissions(new String[]{
                        Manifest.permission.ACCESS_FINE_LOCATION,
                        Manifest.permission.ACCESS_COARSE_LOCATION
                }, 99);
            }
        }
        startSvc();
        setStatus(true);
    }

    private void disable() {
        getSharedPreferences(PREFS, MODE_PRIVATE).edit().putBoolean("on", false).apply();
        startService(new Intent(this, FloatService.class).setAction(FloatService.ACTION_STOP));
        setStatus(false);
    }

    private void startSvc() {
        Intent i = new Intent(this, FloatService.class).setAction(FloatService.ACTION_START);
        if (Build.VERSION.SDK_INT >= 26) startForegroundService(i);
        else startService(i);
    }

    private boolean canOverlay() {
        return Build.VERSION.SDK_INT < 23 || Settings.canDrawOverlays(this);
    }

    private void setStatus(boolean on) {
        status.setText(on ? getString(R.string.status_on) : getString(R.string.status_off));
        status.setTextColor(on ? 0xFF4CAF50 : 0xFF888888);
    }
}
