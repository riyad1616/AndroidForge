
package com.onehub.floatgauge;

import android.Manifest;
import android.content.Context;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.location.Location;
import android.location.LocationListener;
import android.location.LocationManager;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.util.Log;

import java.lang.reflect.Method;
import java.util.concurrent.Executors;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.atomic.AtomicBoolean;

/**
 * Coolray / Gear Display property map.
 *
 * PRND: 0x11400401 (same as Gear Display 289408001)
 *   4=P 2=R 1=N else Drive
 *
 * Auto 7DCT gear step 1..7:
 *   Gear Display gets it from MCU DID 55647 via vendor HIDL.
 *   We estimate from speed when in D (automatic only, no manual).
 *   Also try vendor byte property 0x2170A034 when available.
 */
public class CarDataReader {
    private static final String TAG = "CarDataReader";

    public static final int PROP_SPEED = 0x11600207;
    public static final int PROP_GEAR = 0x11400401;       // 289408001
    public static final int PROP_FUEL = 0x2140a569;
    public static final int PROP_DRIVE_MODE = 0x22010100; // 570491136 Gear Display
    public static final int PROP_DRIVE_MODE_ALT = 0x214020d5;
    public static final int PROP_IGNITION = 0x11400409;   // 289408009
    public static final int PROP_VENDOR_BYTES = 0x2170A034; // 561030708
    public static final int PROP_COOLANT = 0x11600301; // ENGINE_COOLANT_TEMP
    public static final int PROP_COOLANT_ALT = 0x11600305;
    public static final int PROP_BATTERY_VOLT = 0x2140a568;
    public static final int PROP_BATTERY_VOLT_ALT = 0x2140010a;
    public static final int PROP_RPM = 0x11600204; // ENGINE_RPM
    public static final int PROP_RPM_ALT = 0x11600205;

    public interface Listener {
        void onData(float speedKmh, int gearIdx, int gearStep, String gearLetter,
                    String driveMode, int batt, int fuel, int powerKw,
                    int tempOut, int tempBatt, boolean fromCar, String source);
    }

    private final Context ctx;
    private final Listener listener;
    private final Handler main = new Handler(Looper.getMainLooper());
    private ScheduledExecutorService exec;
    private final AtomicBoolean running = new AtomicBoolean(false);

    private Object car, pm;
    private Method getFloat, getInt, getProperty;
    private boolean carOk;

    private LocationManager locationManager;
    private volatile float gpsSpeedKmh = -1f;
    private volatile long gpsAt;

    /** Last MCU-reported candidates (if vendor property works). */
    private int mcuGearA = -1, mcuGearB = -1;

    /** Adaptive speed thresholds (upper limit for gears 1..6; gear 7 is above). */
    private final float[] gearUp = {12f, 28f, 45f, 65f, 85f, 105f};
    private int lastStep = 1;
    private float lastRpm = -1f;
    private long lastCalibAt = 0;
    private static final String PREF_GEAR = "gear_thresholds";

    private final LocationListener locListener = new LocationListener() {
        @Override public void onLocationChanged(Location loc) {
            if (loc != null && loc.hasSpeed()) {
                gpsSpeedKmh = Math.max(0f, loc.getSpeed() * 3.6f);
                gpsAt = System.currentTimeMillis();
            }
        }
        @Override public void onStatusChanged(String p, int s, Bundle e) {}
        @Override public void onProviderEnabled(String p) {}
        @Override public void onProviderDisabled(String p) {}
    };

    public CarDataReader(Context c, Listener l) {
        ctx = c.getApplicationContext();
        listener = l;
        initCar();
        initGps();
        loadThresholds();
    }

    private void loadThresholds() {
        try {
            SharedPreferences sp = ctx.getSharedPreferences(PREF_GEAR, Context.MODE_PRIVATE);
            for (int i = 0; i < 6; i++) {
                gearUp[i] = sp.getFloat("up" + i, gearUp[i]);
            }
        } catch (Throwable ignored) {}
    }

    private void saveThresholds() {
        try {
            SharedPreferences.Editor e = ctx.getSharedPreferences(PREF_GEAR, Context.MODE_PRIVATE).edit();
            for (int i = 0; i < 6; i++) e.putFloat("up" + i, gearUp[i]);
            e.apply();
        } catch (Throwable ignored) {}
    }

    private void initCar() {
        try {
            Class<?> carCl = Class.forName("android.car.Car");
            car = carCl.getMethod("createCar", Context.class).invoke(null, ctx);
            if (car == null) return;
            pm = carCl.getMethod("getCarManager", String.class).invoke(car, "property");
            if (pm == null) return;
            getFloat = pm.getClass().getMethod("getFloatProperty", int.class, int.class);
            getInt = pm.getClass().getMethod("getIntProperty", int.class, int.class);
            try {
                getProperty = pm.getClass().getMethod("getProperty", int.class, int.class);
            } catch (Throwable ignored) {}
            carOk = true;
            Log.i(TAG, "CarPropertyManager OK");
        } catch (Throwable t) {
            Log.w(TAG, "Car API: " + t.getMessage());
            carOk = false;
        }
    }

    private void initGps() {
        try {
            locationManager = (LocationManager) ctx.getSystemService(Context.LOCATION_SERVICE);
            if (locationManager == null) return;
            boolean ok = ctx.checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION)
                    == PackageManager.PERMISSION_GRANTED
                    || ctx.checkSelfPermission(Manifest.permission.ACCESS_COARSE_LOCATION)
                    == PackageManager.PERMISSION_GRANTED;
            if (!ok) return;
            if (locationManager.isProviderEnabled(LocationManager.GPS_PROVIDER)) {
                locationManager.requestLocationUpdates(LocationManager.GPS_PROVIDER,
                        200L, 0f, locListener, Looper.getMainLooper());
            }
            if (locationManager.isProviderEnabled(LocationManager.NETWORK_PROVIDER)) {
                locationManager.requestLocationUpdates(LocationManager.NETWORK_PROVIDER,
                        500L, 0f, locListener, Looper.getMainLooper());
            }
        } catch (Throwable t) {
            Log.w(TAG, "GPS: " + t.getMessage());
        }
    }

    public boolean isCarOk() { return carOk; }

    public void start() {
        if (running.getAndSet(true)) return;
        exec = Executors.newSingleThreadScheduledExecutor();
        exec.scheduleAtFixedRate(this::poll, 0, 120, TimeUnit.MILLISECONDS);
    }

    public void stop() {
        running.set(false);
        if (exec != null) { exec.shutdownNow(); exec = null; }
        if (locationManager != null) {
            try { locationManager.removeUpdates(locListener); } catch (Throwable ignored) {}
        }
    }

    private Float carFloat(int prop) {
        if (!carOk || getFloat == null) return null;
        try {
            Object v = getFloat.invoke(pm, prop, 0);
            if (v instanceof Float && !Float.isNaN((Float) v)) return (Float) v;
        } catch (Throwable ignored) {}
        return null;
    }

    private Integer carInt(int prop) {
        if (!carOk || getInt == null) return null;
        int[] areas = {0, 1, 2, 4, 8, 16, 0x117};
        for (int area : areas) {
            try {
                Object v = getInt.invoke(pm, prop, area);
                if (v instanceof Integer) {
                    int i = (Integer) v;
                    if (i != Integer.MIN_VALUE) return i;
                }
            } catch (Throwable ignored) {}
        }
        return null;
    }

    /** Try read vendor byte blob (Gear Display 0x2170A034). */
    private void tryVendorGearBytes() {
        if (!carOk || getProperty == null) return;
        try {
            Object propVal = getProperty.invoke(pm, PROP_VENDOR_BYTES, 0);
            if (propVal == null) return;
            Object value = propVal.getClass().getMethod("getValue").invoke(propVal);
            if (!(value instanceof byte[])) return;
            byte[] b = (byte[]) value;
            // Gear Display: response payload after UDS, DID 55647 → two gear candidates
            // Heuristic scan for two consecutive bytes in 1..7
            for (int i = 0; i < b.length - 1; i++) {
                int a = b[i] & 0xFF;
                int c = b[i + 1] & 0xFF;
                if (a >= 1 && a <= 7 && c >= 1 && c <= 7) {
                    mcuGearA = a;
                    mcuGearB = c;
                    return;
                }
            }
            for (int i = 0; i < b.length; i++) {
                int a = b[i] & 0xFF;
                if (a >= 1 && a <= 7) {
                    mcuGearA = a;
                    mcuGearB = -1;
                    return;
                }
            }
        } catch (Throwable ignored) {}
    }

    /**
     * Gear Display mapping for PRND (field m):
     * 4=P, 2=R, 1=N, else Drive.
     * Step 1..7 from MCU or speed estimate.
     */
    public static final class GearInfo {
        public final String letter;
        public final int step;
        public final int oneHubIdx;
        public GearInfo(String letter, int step, int oneHubIdx) {
            this.letter = letter;
            this.step = step;
            this.oneHubIdx = oneHubIdx;
        }
    }

    public static GearInfo decodePrnd(int raw) {
        if (raw == 4) return new GearInfo("P", 0, 1);
        if (raw == 2) return new GearInfo("R", 0, 2);
        if (raw == 1) return new GearInfo("N", 0, 3);
        // 8 or any other = Drive (automatic)
        if (raw == 8 || raw > 4) return new GearInfo("D", 0, 4);
        return new GearInfo("P", 0, 1);
    }

    /**
     * Estimate engaged gear for 7-speed DCT from vehicle speed (automatic only).
     * Rough bands - better than frozen blank.
     */
    /**
     * Adaptive 7DCT estimate:
     * 1) Prefer MCU bytes
     * 2) RPM/speed ratio when RPM available → also auto-calibrates speed bands
     * 3) Adaptive speed thresholds with hysteresis
     */
    private int estimateAutoGear(float speedKmh, float rpm) {
        int fromRpm = -1;
        if (rpm > 600f && speedKmh > 5f) {
            // proxy ratio: higher rpm/speed => lower gear
            float ratio = rpm / Math.max(speedKmh, 1f);
            // Typical 7DCT clusters (approximate, refined by calibration)
            if (ratio > 55f) fromRpm = 1;
            else if (ratio > 38f) fromRpm = 2;
            else if (ratio > 28f) fromRpm = 3;
            else if (ratio > 21f) fromRpm = 4;
            else if (ratio > 16f) fromRpm = 5;
            else if (ratio > 12f) fromRpm = 6;
            else fromRpm = 7;

            // Auto-calibrate speed upper bounds toward observed shift speeds
            long now = System.currentTimeMillis();
            if (fromRpm >= 1 && fromRpm <= 7 && now - lastCalibAt > 2500L) {
                // Soft-move threshold between gear g and g+1 toward current speed
                if (fromRpm >= 2 && fromRpm <= 7) {
                    int idx = fromRpm - 2; // threshold below this gear
                    // when in gear N, previous upper bound should be near this speed
                    float target = speedKmh - 3f;
                    if (target > 8f && target < 160f) {
                        gearUp[idx] = gearUp[idx] * 0.92f + target * 0.08f;
                    }
                }
                if (fromRpm >= 1 && fromRpm <= 6) {
                    int idx = fromRpm - 1;
                    float target = speedKmh + 5f;
                    if (target > 10f && target < 170f) {
                        gearUp[idx] = gearUp[idx] * 0.92f + target * 0.08f;
                    }
                }
                // Keep ordered and reasonable spacing
                gearUp[0] = clampF(gearUp[0], 8f, 25f);
                for (int i = 1; i < 6; i++) {
                    gearUp[i] = clampF(gearUp[i], gearUp[i - 1] + 8f, gearUp[i - 1] + 35f);
                }
                lastCalibAt = now;
                saveThresholds();
            }
        }

        int fromSpeed = gearFromSpeed(speedKmh);

        int step;
        if (fromRpm > 0) {
            // blend: trust RPM more when stable
            step = fromRpm;
        } else {
            step = fromSpeed;
        }

        // Hysteresis: don't flicker ±1 every sample
        if (step == lastStep) return step;
        if (step > lastStep) {
            // upshift: need speed above threshold + margin
            float need = (lastStep >= 1 && lastStep <= 6) ? gearUp[lastStep - 1] + 2f : 0f;
            if (speedKmh < need && fromRpm <= 0) step = lastStep;
        } else {
            // downshift: need speed below previous threshold - margin
            float need = (step >= 1 && step <= 6) ? gearUp[step - 1] - 2f : 999f;
            if (speedKmh > need && fromRpm <= 0) step = lastStep;
        }
        lastStep = step;
        return step;
    }

    private int gearFromSpeed(float speedKmh) {
        if (speedKmh < gearUp[0]) return 1;
        if (speedKmh < gearUp[1]) return 2;
        if (speedKmh < gearUp[2]) return 3;
        if (speedKmh < gearUp[3]) return 4;
        if (speedKmh < gearUp[4]) return 5;
        if (speedKmh < gearUp[5]) return 6;
        return 7;
    }

    private static float clampF(float v, float lo, float hi) {
        return v < lo ? lo : (v > hi ? hi : v);
    }

    public static String decodeMode(int raw) {
        // Gear Display uses 0x22010100 family (hex == decimal of same constants)
        switch (raw) {
            case 0x22010141: // 570491201
                return "ADAPTATIF";
            case 0x22010140:
                return "PERSO";
            case 0x22010113:
                return "TOUT-TERRAIN";
            case 0x22010111:
                return "NORMAL";
            case 0x22010109:
                return "NEIGE";
            case 0x22010103: // 570491139
                return "SPORT";
            case 0x22010102: // 570491138
                return "CONFORT";
            case 0x22010101: // 570491137
                return "ECO";
            case 0xFF:
                return "-";
            default:
                if (raw == Integer.MIN_VALUE) return "-";
                return null;
        }
    }

    private void poll() {
        if (!running.get()) return;

        float speed = -1f;
        int fuel = Integer.MIN_VALUE;
        int batt = Integer.MIN_VALUE;
        int power = Integer.MIN_VALUE;
        int temp = Integer.MIN_VALUE;
        int tbatt = Integer.MIN_VALUE;
        int gearRaw = -1;
        int modeRaw = Integer.MIN_VALUE;
        boolean fromCar = false;
        String source = "none";

        Float cs = carFloat(PROP_SPEED);
        if (cs != null && cs >= 0f) {
            speed = Math.max(0f, Math.min(cs, 320f));
            fromCar = true;
            source = "car";
        }

        Integer fuelI = carInt(PROP_FUEL);
        if (fuelI != null && fuelI >= 0 && fuelI <= 100) {
            fuel = fuelI;
            fromCar = true;
        }

        // Engine coolant °C
        Float cool = carFloat(PROP_COOLANT);
        if (cool == null) cool = carFloat(PROP_COOLANT_ALT);
        // Some head-units report deci-degrees (890 = 89.0°)
        if (cool != null) {
            float c = cool;
            if (c > 150f && c < 1500f) c = c / 10f;
            if (c > 20f && c < 130f) { // ignore 0 and noise
                temp = Math.round(c);
                fromCar = true;
            }
        }
        if (temp == Integer.MIN_VALUE) {
            Integer ci = carInt(PROP_COOLANT);
            if (ci == null) ci = carInt(PROP_COOLANT_ALT);
            if (ci != null) {
                float c = ci;
                if (c > 150f && c < 1500f) c = c / 10f;
                if (c > 20f && c < 130f) {
                    temp = Math.round(c);
                    fromCar = true;
                }
            }
        }
        // 12V battery voltage (store as decidegrees: 11.8V -> 118) for display
        Float volt = carFloat(PROP_BATTERY_VOLT);
        if (volt == null) volt = carFloat(PROP_BATTERY_VOLT_ALT);
        if (volt == null) {
            Integer vi = carInt(PROP_BATTERY_VOLT);
            if (vi == null) vi = carInt(PROP_BATTERY_VOLT_ALT);
            if (vi != null && vi > 50 && vi < 200) volt = vi / 10f;
            else if (vi != null && vi > 5 && vi < 20) volt = (float) vi;
        }
        if (volt != null) {
            float vv = volt;
            if (vv > 50f && vv < 200f) vv = vv / 10f; // 138 -> 13.8
            if (vv > 9f && vv < 16f) {
                tbatt = Math.round(vv * 10f); // store decidegrees
                fromCar = true;
            }
        }

        Integer gearI = carInt(PROP_GEAR);
        if (gearI != null) {
            gearRaw = gearI;
            fromCar = true;
        }

        Integer modeI = carInt(PROP_DRIVE_MODE);
        if (modeI == null) modeI = carInt(PROP_DRIVE_MODE_ALT);
        if (modeI != null) {
            modeRaw = modeI;
            fromCar = true;
        }

        tryVendorGearBytes();

        float rpm = -1f;
        Float rpmF = carFloat(PROP_RPM);
        if (rpmF == null) rpmF = carFloat(PROP_RPM_ALT);
        if (rpmF != null && rpmF > 200f && rpmF < 8000f) {
            rpm = rpmF;
            lastRpm = rpm;
            fromCar = true;
        } else if (lastRpm > 0) {
            rpm = lastRpm; // brief hold
        }

        boolean gpsFresh = gpsSpeedKmh >= 0f && (System.currentTimeMillis() - gpsAt) < 3000;
        if (speed < 0f && gpsFresh) {
            speed = gpsSpeedKmh;
            source = "gps";
        } else if (speed >= 0f && speed < 0.5f && gpsFresh && gpsSpeedKmh > 2f) {
            speed = gpsSpeedKmh;
            source = "gps";
        }
        if (speed < 0f) speed = 0f;

        GearInfo gi;
        if (gearRaw >= 0) {
            gi = decodePrnd(gearRaw);
        } else {
            gi = speed > 1.5f ? new GearInfo("D", 0, 4) : new GearInfo("P", 0, 1);
        }

        // Resolve 1..7 for automatic Drive
        int step = 0;
        if ("D".equals(gi.letter)) {
            if (mcuGearA >= 1 && mcuGearA <= 7) {
                step = mcuGearA;
            } else if (mcuGearB >= 1 && mcuGearB <= 7) {
                step = mcuGearB;
            } else {
                // Automatic only: estimate from speed (Gear Display uses MCU ratios)
                step = estimateAutoGear(speed, rpm);
            }
            gi = new GearInfo("D", step, 4);
        }

        String mode = decodeMode(modeRaw);
        if (mode == null) mode = "-";

        // Autonomie (range) instead of kW — estimate from fuel % if no car range
        int rangeKm = Integer.MIN_VALUE;
        if (fuel >= 0 && fuel <= 100) {
            // ~7.4 km per % matches user photo (~216 km at ~29%)
            rangeKm = Math.max(0, Math.round(fuel * 7.4f));
        }

        final float s = speed;
        final int gIdx = gi.oneHubIdx;
        final int gStep = gi.step;
        final String gLet = gi.letter;
        final String dm = mode;
        final int ba = batt, fu = fuel, pw = (rangeKm != Integer.MIN_VALUE ? rangeKm : power), te = temp, tb = tbatt;
        final boolean fc = fromCar || "gps".equals(source);
        final String src = source;

        main.post(() -> {
            if (listener != null) {
                listener.onData(s, gIdx, gStep, gLet, dm, ba, fu, pw, te, tb, fc, src);
            }
        });
    }
}
