package com.onehub.floatgauge;

/** Port of OneHub C0022c2 - keep original field names for engine compatibility. */
public final class ThemeColors {
    public final int f1020a;
    public final int b;
    public final int f1021c;
    public final int f1022d;
    public final int f1023e;
    public final int f;
    public final int f1024g;
    public final int f1025h;
    public final int f1026i;

    public ThemeColors(int a, int b, int c, int d, int e, int f, int g, int h, int i) {
        this.f1020a = a;
        this.b = b;
        this.f1021c = c;
        this.f1022d = d;
        this.f1023e = e;
        this.f = f;
        this.f1024g = g;
        this.f1025h = h;
        this.f1026i = i;
    }
}
