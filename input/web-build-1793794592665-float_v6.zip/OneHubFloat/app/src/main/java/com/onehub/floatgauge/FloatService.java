package com.onehub.floatgauge;

import android.app.AppOpsManager;
import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.app.usage.UsageStats;
import android.app.usage.UsageStatsManager;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.PixelFormat;
import android.os.Build;
import android.os.Handler;
import android.os.IBinder;
import android.os.Looper;
import android.os.Process;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.MotionEvent;
import android.view.ScaleGestureDetector;
import android.view.View;
import android.view.WindowManager;
import android.widget.FrameLayout;
import android.widget.Toast;

import androidx.core.app.NotificationCompat;

import java.util.HashSet;
import java.util.List;
import java.util.Set;
import java.util.SortedMap;
import java.util.TreeMap;

/**
 * Floating OneHub speedo.
 * Size math matches original f2: width = size * r[style] * q[style], height = size * r[style]
 * Pinch = zoom, long-press = drag + red X close. No bottom toolbar.
 */
public class FloatService extends Service implements CarDataReader.Listener {

    public static final String ACTION_START = "START";
    public static final String ACTION_STOP = "STOP";
    private static final String CH = "float_gauge";
    private static final int NID = 42;
    private static final String PREFS = "onehub_float";
    private static final long LONG_MS = 450;
    private static final long EDIT_MS = 5000;

    private WindowManager wm;
    private View root;
    private View btnCloseTop;
    private WindowManager.LayoutParams params;
    private FrameLayout content;
    private SpeedoView speedo;
    private CarDataReader reader;
    /** Base size in dp - maps to original spd_s */
    private int baseDp = 280;
    private float pinch = 1f;
    private final Handler handler = new Handler(Looper.getMainLooper());

    private boolean editMode;
    private boolean dragging;
    private boolean hiddenForApp;
    private int ix, iy;
    private float downX, downY, itx, ity;
    private ScaleGestureDetector scaleDetector;
    private final Runnable hideEdit = () -> setEditMode(false);
    private final Runnable pollFg = this::checkForegroundApp;

    @Override
    public IBinder onBind(Intent i) { return null; }

    @Override
    public void onCreate() {
        super.onCreate();
        wm = (WindowManager) getSystemService(WINDOW_SERVICE);
        if (Build.VERSION.SDK_INT >= 26) {
            NotificationChannel c = new NotificationChannel(CH, "OneHub Float", NotificationManager.IMPORTANCE_LOW);
            NotificationManager nm = getSystemService(NotificationManager.class);
            if (nm != null) nm.createNotificationChannel(c);
        }
        scaleDetector = new ScaleGestureDetector(this, new ScaleGestureDetector.SimpleOnScaleGestureListener() {
            @Override
            public boolean onScale(ScaleGestureDetector d) {
                pinch *= d.getScaleFactor();
                pinch = Math.max(0.5f, Math.min(2.2f, pinch));
                getSharedPreferences(PREFS, MODE_PRIVATE).edit().putFloat("pinch", pinch).apply();
                relayout();
                return true;
            }
        });
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        SharedPreferences p = getSharedPreferences(PREFS, MODE_PRIVATE);
        if (intent != null && ACTION_STOP.equals(intent.getAction())) {
            stopAll();
            return START_NOT_STICKY;
        }
        if (root == null) {
            baseDp = p.getInt("size", 320);
            pinch = p.getFloat("pinch", 1f);
            show();
            reader = new CarDataReader(this, this);
            reader.start();
            handler.post(pollFg);
        }
        startForeground(NID, notif());
        return START_STICKY;
    }

    private void show() {
        root = LayoutInflater.from(this).inflate(R.layout.float_root, null);
        content = (FrameLayout) root.findViewById(R.id.content);
        btnCloseTop = root.findViewById(R.id.btn_close_top);
        speedo = new SpeedoView(this);
        SharedPreferences p = getSharedPreferences(PREFS, MODE_PRIVATE);
        speedo.setStyle(p.getInt("style", 0));
        speedo.setThemeIndex(p.getInt("theme", 0));
        content.addView(speedo, new FrameLayout.LayoutParams(
                FrameLayout.LayoutParams.MATCH_PARENT, FrameLayout.LayoutParams.MATCH_PARENT));

        int type = Build.VERSION.SDK_INT >= 26
                ? WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
                : WindowManager.LayoutParams.TYPE_PHONE;

        int[] wh = sizeFor();
        params = new WindowManager.LayoutParams(wh[0], wh[1], type,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE | WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
                PixelFormat.TRANSLUCENT);
        params.gravity = Gravity.TOP | Gravity.START;
        params.x = 30;
        params.y = 60;
        applyContentSize(wh[0], wh[1]);

        root.setOnTouchListener(this::onRootTouch);
        if (btnCloseTop != null) {
            btnCloseTop.setOnClickListener(v -> {
                getSharedPreferences(PREFS, MODE_PRIVATE).edit().putBoolean("on", false).apply();
                stopAll();
            });
        }

        try {
            wm.addView(root, params);
            applyAlpha();
        } catch (Exception e) {
            Toast.makeText(this, "امنح إذن الظهور فوق التطبيقات", Toast.LENGTH_LONG).show();
            stopSelf();
        }
    }

    private void applyAlpha() {
        if (root == null) return;
        float a = getSharedPreferences(PREFS, MODE_PRIVATE).getFloat("alpha", 1.0f);
        if (a < 0.2f) a = 0.2f;
        if (a > 1.0f) a = 1.0f;
        root.setAlpha(a);
    }

    private boolean onRootTouch(View v, MotionEvent e) {
        scaleDetector.onTouchEvent(e);
        if (scaleDetector.isInProgress()) {
            handler.removeCallbacksAndMessages(null);
            return true;
        }
        switch (e.getActionMasked()) {
            case MotionEvent.ACTION_DOWN:
                downX = e.getX();
                downY = e.getY();
                itx = e.getRawX();
                ity = e.getRawY();
                ix = params.x;
                iy = params.y;
                dragging = false;
                handler.postDelayed(() -> {
                    setEditMode(true);
                    dragging = true;
                }, LONG_MS);
                return true;
            case MotionEvent.ACTION_MOVE:
                if (dragging || editMode) {
                    handler.removeCallbacks(hideEdit);
                    params.x = ix + (int) (e.getRawX() - itx);
                    params.y = iy + (int) (e.getRawY() - ity);
                    try { wm.updateViewLayout(root, params); } catch (Exception ignored) {}
                    return true;
                }
                if (Math.hypot(e.getRawX() - itx, e.getRawY() - ity) > dp(14)) {
                    handler.removeCallbacksAndMessages(null);
                }
                return true;
            case MotionEvent.ACTION_UP:
            case MotionEvent.ACTION_CANCEL:
                handler.removeCallbacksAndMessages(null);
                if (!dragging && !editMode) handleGaugeTap(downX, downY);
                if (editMode) bumpEdit();
                dragging = false;
                return true;
        }
        return false;
    }

    private void handleGaugeTap(float x, float y) {
        if (speedo == null) return;
        int w = speedo.getWidth();
        int h = speedo.getHeight();
        if (w <= 0 || h <= 0) return;

        // OneHub draws the two control dots either at the BOTTOM center
        // or at the TOP-RIGHT (card / compact styles). Hit-test both zones.
        boolean topZone = y < h * 0.32f;
        boolean bottomZone = y > h * 0.68f;
        if (!topZone && !bottomZone) return;

        boolean theme;
        if (topZone) {
            // top-right pair: left dot = theme, right dot = style
            if (x < w * 0.50f) return; // ignore left half of top
            theme = x < w * 0.78f;
        } else {
            // bottom pair: left = theme, right = style
            theme = x < w * 0.50f;
        }

        if (theme) {
            speedo.nextTheme();
            getSharedPreferences(PREFS, MODE_PRIVATE).edit()
                    .putInt("theme", speedo.getThemeIndex()).apply();
        } else {
            speedo.nextStyle();
            getSharedPreferences(PREFS, MODE_PRIVATE).edit()
                    .putInt("style", speedo.getStyle()).apply();
            relayout();
        }
    }

    private void setEditMode(boolean on) {
        editMode = on;
        if (btnCloseTop != null) btnCloseTop.setVisibility(on ? View.VISIBLE : View.GONE);
        if (on) bumpEdit();
    }

    private void bumpEdit() {
        handler.removeCallbacks(hideEdit);
        handler.postDelayed(hideEdit, EDIT_MS);
    }

    /**
     * Match OneHub f2.b():
     *   height = size * r[style]
     *   width  = height * q[style]   (= size * r * q)
     */
    private int[] sizeFor() {
        float[] rArr = SpeedoEngine.f1038r;
        float[] qArr = SpeedoEngine.f1037q;
        int si = speedo != null ? speedo.getStyle() : 0;
        float r = (si >= 0 && si < rArr.length) ? rArr[si] : 1f;
        float q = (si >= 0 && si < qArr.length) ? qArr[si] : 1f;
        if (r < 0.5f) r = 0.5f;
        if (q < 0.8f) q = 0.8f;

        float sizePx = dp(baseDp) * pinch;
        int height = Math.round(sizePx * r);
        int width = Math.round(sizePx * r * q);

        // Extra padding so engine-drawn side gauges / buttons are not clipped
        int pad = dp(12);
        int closePad = editMode ? dp(8) : 0;
        width = Math.max(width + pad * 2, dp(180));
        height = Math.max(height + pad * 2 + closePad, dp(140));
        return new int[]{width, height};
    }

    private void applyContentSize(int totalW, int totalH) {
        FrameLayout.LayoutParams lp = (FrameLayout.LayoutParams) content.getLayoutParams();
        lp.width = totalW;
        lp.height = totalH;
        lp.topMargin = 0;
        content.setLayoutParams(lp);
    }

    private void relayout() {
        if (params == null || root == null) return;
        int[] wh = sizeFor();
        params.width = wh[0];
        params.height = wh[1];
        applyContentSize(wh[0], wh[1]);
        try { wm.updateViewLayout(root, params); } catch (Exception ignored) {}
    }

    private Set<String> excludedPackages() {
        String raw = getSharedPreferences(PREFS, MODE_PRIVATE).getString("exclude", "");
        Set<String> set = new HashSet<>();
        if (raw != null && !raw.isEmpty()) {
            for (String s : raw.split(",")) {
                s = s.trim();
                if (!s.isEmpty()) set.add(s);
            }
        }
        return set;
    }

    private boolean hasUsageAccess() {
        try {
            AppOpsManager ops = (AppOpsManager) getSystemService(APP_OPS_SERVICE);
            int mode = ops.checkOpNoThrow(AppOpsManager.OPSTR_GET_USAGE_STATS, Process.myUid(), getPackageName());
            return mode == AppOpsManager.MODE_ALLOWED;
        } catch (Throwable t) {
            return false;
        }
    }

    /** package name of foreground app, or null */
    private String foregroundPackage() {
        String[] pa = foregroundPkgAndActivity();
        return pa != null ? pa[0] : null;
    }

    /** [0]=package, [1]=activity class (may be "") */
    private String[] foregroundPkgAndActivity() {
        try {
            android.app.ActivityManager am =
                    (android.app.ActivityManager) getSystemService(ACTIVITY_SERVICE);
            if (am != null) {
                java.util.List<android.app.ActivityManager.RunningTaskInfo> tasks =
                        am.getRunningTasks(1);
                if (tasks != null && !tasks.isEmpty() && tasks.get(0).topActivity != null) {
                    android.content.ComponentName cn = tasks.get(0).topActivity;
                    return new String[]{ cn.getPackageName(), cn.getClassName() != null ? cn.getClassName() : "" };
                }
            }
        } catch (Throwable ignored) {
        }
        if (!hasUsageAccess()) return null;
        try {
            UsageStatsManager usm = (UsageStatsManager) getSystemService(USAGE_STATS_SERVICE);
            long now = System.currentTimeMillis();
            List<UsageStats> stats = usm.queryUsageStats(
                    UsageStatsManager.INTERVAL_DAILY, now - 8_000, now);
            if (stats == null || stats.isEmpty()) return null;
            SortedMap<Long, UsageStats> sorted = new TreeMap<>();
            for (UsageStats u : stats) {
                if (u.getLastTimeUsed() > 0) sorted.put(u.getLastTimeUsed(), u);
            }
            if (sorted.isEmpty()) return null;
            return new String[]{ sorted.get(sorted.lastKey()).getPackageName(), "" };
        } catch (Throwable t) {
            return null;
        }
    }

    /** Packages that count as home / launcher (page 1). */
    private Set<String> launcherPackages() {
        Set<String> set = new HashSet<>();
        try {
            android.content.pm.PackageManager pm = getPackageManager();
            Intent home = new Intent(Intent.ACTION_MAIN);
            home.addCategory(Intent.CATEGORY_HOME);
            java.util.List<android.content.pm.ResolveInfo> list =
                    pm.queryIntentActivities(home, 0);
            if (list != null) {
                for (android.content.pm.ResolveInfo ri : list) {
                    if (ri.activityInfo != null && ri.activityInfo.packageName != null) {
                        set.add(ri.activityInfo.packageName);
                    }
                }
            }
            android.content.pm.ResolveInfo def = pm.resolveActivity(home, 0);
            if (def != null && def.activityInfo != null) {
                set.add(def.activityInfo.packageName);
            }
        } catch (Throwable ignored) {
        }
        // Phone launchers
        set.add("com.android.launcher");
        set.add("com.android.launcher3");
        set.add("com.google.android.apps.nexuslauncher");
        set.add("com.samsung.android.launcher");
        set.add("com.sec.android.app.launcher");
        set.add("com.miui.home");
        set.add("com.huawei.android.launcher");
        set.add("com.oppo.launcher");
        set.add("com.oneplus.launcher");
        set.add("com.realme.launcher");
        set.add("com.bbk.launcher2");
        set.add("com.teslacoilsw.launcher");
        set.add("com.nova.launcher");
        set.add("com.microsoft.launcher");
        // Car / OEM home
        set.add("com.android.car.carlauncher");
        set.add("com.android.car.home");
        set.add("android.car.home");
        set.add("com.ecarx.mycar");
        set.add("com.geely.launcher");
        set.add("com.geely.auto.launcher");
        set.add("com.flyme.auto.launcher");
        set.add("com.autolink.launcher");
        set.add("com.mx.car.launcher");
        set.add("com.ts.car.launcher");
        set.add("com.carbit.launcher");
        set.add("com.sgmw.launcher");
        set.add("com.baidu.car.launcher");
        set.add("com.banma.launcher");
        set.add("com.yandex.launcher");
        return set;
    }

    private void checkForegroundApp() {
        try {
            SharedPreferences prefs = getSharedPreferences(PREFS, MODE_PRIVATE);
            boolean homeOnly = prefs.getBoolean("home_only", true);
            String[] pa = foregroundPkgAndActivity();
            String fg = pa != null ? pa[0] : null;
            String act = pa != null ? pa[1] : "";

            if (!homeOnly) {
                Set<String> ex = excludedPackages();
                boolean hide = fg != null && ex.contains(fg);
                applyHide(hide);
            } else {
                boolean onHome = isHomeScreen(fg, act);
                applyHide(!onHome);
            }
        } catch (Throwable ignored) {
        }
        applyAlpha();
        handler.postDelayed(pollFg, 250); // faster hide
    }

    private void applyHide(boolean hide) {
        if (hide == hiddenForApp) return;
        if (hide) {
            // Hide immediately — no vote delay
            hideVotes = 0;
            showVotes = 0;
            hiddenForApp = true;
            if (root != null) root.setVisibility(View.GONE);
            return;
        }
        // Show only after 2 consecutive home readings (anti-flicker)
        showVotes++;
        hideVotes = 0;
        if (showVotes < 2) return;
        hiddenForApp = false;
        if (root != null) {
            root.setVisibility(View.VISIBLE);
            applyAlpha();
        }
    }

    private int hideVotes = 0;
    private int showVotes = 0;

    /**
     * Show only on home/launcher workspace. Hide on every other app and app-list page.
     */
    private boolean isHomeScreen(String fg, String activity) {
        if (fg == null || fg.isEmpty()) return false;
        if (fg.equals(getPackageName())) return false;

        String act = activity != null ? activity.toLowerCase() : "";

        // App list / drawer / settings -> always hide
        if (act.contains("allapp") || act.contains("appdrawer") || act.contains("app_drawer")
                || act.contains("applist") || act.contains("app_list") || act.contains("drawer")
                || act.contains("appscustomize") || act.contains("appcenter")
                || act.contains("application") || act.contains("appsactivity")
                || act.contains("grid") || act.contains("settings") || act.contains("preference")) {
            return false;
        }

        // Strict: only known launcher packages (NOT every package containing OEM name)
        if (launcherPackages().contains(fg)) {
            return true;
        }
        String low = fg.toLowerCase();
        return low.contains("launcher") || low.contains("trebuchet")
                || low.contains("carlauncher") || low.endsWith(".home")
                || low.contains("android.car.home");
    }


    @Override
    public void onData(float speed, int gearIdx, int gearStep, String gearLetter,
                       String driveMode, int batt, int fuel, int powerKw,
                       int tempOut, int tempBatt, boolean fromCar, String source) {
        if (speedo != null) {
            speedo.setData(speed, gearIdx, gearStep, gearLetter, driveMode,
                    batt, fuel, powerKw, tempOut, tempBatt);
        }
    }

    private void stopAll() {
        handler.removeCallbacksAndMessages(null);
        if (reader != null) { reader.stop(); reader = null; }
        if (root != null) {
            try { wm.removeView(root); } catch (Exception ignored) {}
            root = null;
        }
        stopForeground(true);
        stopSelf();
    }

    private Notification notif() {
        Intent stop = new Intent(this, FloatService.class).setAction(ACTION_STOP);
        PendingIntent pi = PendingIntent.getService(this, 0, stop,
                PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
        Intent open = new Intent(this, MainActivity.class);
        PendingIntent oi = PendingIntent.getActivity(this, 1, open,
                PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
        return new NotificationCompat.Builder(this, CH)
                .setContentTitle("OneHub Float")
                .setContentText(getString(R.string.notif_text))
                .setSmallIcon(android.R.drawable.ic_menu_compass)
                .setContentIntent(oi)
                .addAction(0, getString(R.string.stop), pi)
                .setOngoing(true)
                .setPriority(NotificationCompat.PRIORITY_LOW)
                .build();
    }

    private int dp(int v) {
        return Math.round(v * getResources().getDisplayMetrics().density);
    }

    @Override
    public void onDestroy() {
        handler.removeCallbacksAndMessages(null);
        if (reader != null) reader.stop();
        if (root != null) {
            try { wm.removeView(root); } catch (Exception ignored) {}
        }
        super.onDestroy();
    }
}
