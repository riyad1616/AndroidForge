package com.coolray.navwidget

import android.app.Service
import android.app.usage.UsageStatsManager
import android.app.usage.UsageEvents
import android.os.Handler
import android.os.Looper
import android.content.*
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.IBinder
import android.provider.Settings
import android.view.*
import android.widget.*
import android.animation.ValueAnimator
import android.view.animation.LinearInterpolator

class FloatingWidgetService : Service() {
    companion object { const val ACTION_REFRESH="com.coolray.navwidget.REFRESH" }
    private var wm:WindowManager?=null
    private var card:LinearLayout?=null
    private var distance:TextView?=null
    private var directionArrow:TextView?=null
    private var instruction:TextView?=null
    private var summary:TextView?=null
    private var osmInfo:TextView?=null
    private var signalDistance:TextView?=null
    private var speedLimitText:TextView?=null
    private var currentSpeedText:TextView?=null
    private var lastOsmLookup=0L
    private var lastOsmText="OSM: waiting for GPS permission"
    private var progressTrack:FrameLayout?=null
    private var progressIndicator:View?=null
    private var progressAnimator:ValueAnimator?=null
    private var params:WindowManager.LayoutParams?=null
    private var preview=false
    private var attached=false
    private val handler=Handler(Looper.getMainLooper())
    private val foregroundCheck=object:Runnable {
        override fun run() {
            if (!preview && prefs.getBoolean("hide_maps", false) && usageAccessGranted()) {
                val mapsForeground = isMapsForeground()
                card?.visibility = if (mapsForeground) View.GONE else View.VISIBLE
            } else {
                card?.visibility = View.VISIBLE
            }
            handler.postDelayed(this, 1200L)
        }
    }
    private val prefs by lazy { getSharedPreferences("nav_widget",Context.MODE_PRIVATE) }
    private val receiver=object:BroadcastReceiver(){
        override fun onReceive(context:Context?,intent:Intent?){ refreshContent() }
    }
    // Keep online road data fresh even when Google Maps sends no new notification.
    private val osmRefreshLoop = object : Runnable {
        override fun run() {
            if (!preview && card != null) {
                updateOsmIfNeeded()
                osmInfo?.text = lastOsmText
            }
            handler.postDelayed(this, 30000L)
        }
    }
    override fun onCreate(){
        super.onCreate()
        val filter = IntentFilter(ACTION_REFRESH)
        if (android.os.Build.VERSION.SDK_INT >= 33) {
            registerReceiver(receiver, filter, Context.RECEIVER_NOT_EXPORTED)
        } else {
            @Suppress("DEPRECATION")
            registerReceiver(receiver, filter)
        }
    }

    override fun onStartCommand(intent:Intent?,flags:Int,startId:Int):Int {
        preview=intent?.getBooleanExtra("preview",false)?:false
        if(!Settings.canDrawOverlays(this)){stopSelf();return START_NOT_STICKY}
        if(card==null) createCard() else { updateSize(); refreshContent() }
        handler.removeCallbacks(foregroundCheck)
        handler.post(foregroundCheck)
        handler.removeCallbacks(osmRefreshLoop)
        handler.post(osmRefreshLoop)
        return START_STICKY
    }

    private fun createCard(){
        wm=getSystemService(WINDOW_SERVICE) as WindowManager
        fun panel(color:Int, radius:Float=16f, stroke:Int=Color.rgb(37,99,145)) = GradientDrawable().apply {
            setColor(color); cornerRadius=dp(radius.toInt()).toFloat(); setStroke(dp(1),stroke)
        }
        fun text(value:String,size:Float,color:Int=Color.WHITE,bold:Boolean=false)=TextView(this).apply {
            text=value; textSize=size; setTextColor(color); gravity=Gravity.CENTER_VERTICAL
            if(bold) typeface=Typeface.DEFAULT_BOLD
        }
        fun divider()=View(this).apply { setBackgroundColor(Color.rgb(39,83,120)); layoutParams=LinearLayout.LayoutParams(dp(1),-1) }
        card=LinearLayout(this).apply {
            orientation=LinearLayout.VERTICAL
            setPadding(dp(16),dp(12),dp(16),dp(12))
            background=panel(Color.rgb(4,22,45),22f,Color.rgb(42,112,164))
            elevation=dp(12).toFloat()
        }
        // Header: custom app icon + renamed app, online status and settings.
        val header=LinearLayout(this).apply { orientation=LinearLayout.HORIZONTAL; gravity=Gravity.CENTER_VERTICAL }
        val appIcon=FrameLayout(this).apply {
            background=GradientDrawable(GradientDrawable.Orientation.TL_BR,
                intArrayOf(Color.rgb(0,142,255),Color.rgb(0,211,160),Color.rgb(255,190,35))).apply { cornerRadius=dp(12).toFloat() }
            layoutParams=LinearLayout.LayoutParams(dp(44),dp(44))
        }
        appIcon.addView(TextView(this).apply { text="➤"; textSize=28f; typeface=Typeface.DEFAULT_BOLD; setTextColor(Color.WHITE); gravity=Gravity.CENTER; rotation=-25f })
        header.addView(appIcon)
        header.addView(text("  FlyMap",19f,Color.WHITE,true),LinearLayout.LayoutParams(0,dp(44),1f))
        val online=text("● Online",13f,Color.rgb(0,235,178),true).apply {
            gravity=Gravity.CENTER; setPadding(dp(10),dp(5),dp(10),dp(5)); background=panel(Color.rgb(3,49,58),22f,Color.rgb(0,165,135))
        }
        header.addView(online)
        header.addView(text("   ◆  ⚙",17f,Color.WHITE,true).apply { gravity=Gravity.CENTER })
        card!!.addView(header)
        card!!.addView(View(this).apply { setBackgroundColor(Color.rgb(35,81,119)); layoutParams=LinearLayout.LayoutParams(-1,dp(1)).apply { topMargin=dp(10); bottomMargin=dp(10) } })

        // Main row: speed, turn instruction and nearby traffic light.
        val main=LinearLayout(this).apply { orientation=LinearLayout.HORIZONTAL; gravity=Gravity.CENTER_VERTICAL }
        val speedPanel=LinearLayout(this).apply { orientation=LinearLayout.VERTICAL; gravity=Gravity.CENTER; setPadding(dp(3),dp(4),dp(8),dp(4)) }
        val limit=text("60",27f,Color.BLACK,true).apply {
            gravity=Gravity.CENTER; background=GradientDrawable().apply { shape=GradientDrawable.OVAL; setColor(Color.WHITE); setStroke(dp(6),Color.rgb(239,38,55)) }
        }
        speedPanel.addView(limit,LinearLayout.LayoutParams(dp(66),dp(66)))
        speedLimitText=text("حد السرعة",10f,Color.WHITE,true).apply { gravity=Gravity.CENTER; setPadding(0,dp(4),0,0) }
        speedPanel.addView(speedLimitText)
        currentSpeedText=text("48 كم/س",12f,Color.rgb(205,225,248),true).apply { gravity=Gravity.CENTER }
        speedPanel.addView(currentSpeedText)
        main.addView(speedPanel,LinearLayout.LayoutParams(dp(82),-2))
        main.addView(divider(),LinearLayout.LayoutParams(dp(1),dp(110)))

        val maneuver=LinearLayout(this).apply { orientation=LinearLayout.VERTICAL; setPadding(dp(10),dp(4),dp(10),dp(4)) }
        val maneuverTop=LinearLayout(this).apply { orientation=LinearLayout.HORIZONTAL; gravity=Gravity.CENTER_VERTICAL }
        directionArrow=TextView(this).apply {
            text="↱"; textSize=36f; typeface=Typeface.DEFAULT_BOLD; setTextColor(Color.rgb(120,255,214)); gravity=Gravity.CENTER
            background=GradientDrawable().apply { setColor(Color.rgb(0,105,78)); cornerRadius=dp(14).toFloat(); setStroke(dp(1),Color.rgb(0,193,139)) }
        }
        maneuverTop.addView(directionArrow,LinearLayout.LayoutParams(dp(60),dp(60)))
        val instructionColumn=LinearLayout(this).apply { orientation=LinearLayout.VERTICAL; setPadding(dp(9),0,0,0) }
        distance=text("150 m",26f,Color.WHITE,true)
        instructionColumn.addView(distance)
        instruction=text("انعطف يمينًا على الطريق القادم",13f,Color.WHITE).apply { maxLines=2 }
        instructionColumn.addView(instruction)
        maneuverTop.addView(instructionColumn,LinearLayout.LayoutParams(0,-2,1f))
        maneuver.addView(maneuverTop)
        val track=FrameLayout(this).apply {
            background=GradientDrawable().apply { setColor(Color.rgb(8,42,78)); cornerRadius=dp(8).toFloat() }
            layoutParams=LinearLayout.LayoutParams(-1,dp(8)).apply { topMargin=dp(12) }
        }
        progressTrack=track
        progressIndicator=View(this).apply {
            background=GradientDrawable().apply { setColor(Color.rgb(0,144,255)); cornerRadius=dp(8).toFloat() }
            layoutParams=FrameLayout.LayoutParams(dp(90),-1,Gravity.START)
        }
        track.addView(progressIndicator)
        track.addOnLayoutChangeListener { _, l, _, r, _, oldL, _, oldR, _ -> if(r-l!=oldR-oldL) startProgressAnimation() }
        maneuver.addView(track)
        main.addView(maneuver,LinearLayout.LayoutParams(0,-2,1f))
        main.addView(divider(),LinearLayout.LayoutParams(dp(1),dp(110)))

        val signal=LinearLayout(this).apply { orientation=LinearLayout.VERTICAL; gravity=Gravity.CENTER; setPadding(dp(8),dp(4),dp(2),dp(4)); background=panel(Color.rgb(5,29,57),14f,Color.rgb(35,88,132)) }
        signal.addView(text("🚦",30f,Color.WHITE).apply { gravity=Gravity.CENTER })
        signalDistance=text("200 m",17f,Color.WHITE,true).apply { gravity=Gravity.CENTER }
        signal.addView(signalDistance)
        signal.addView(text("إشارة مرور",10f,Color.rgb(215,231,249)).apply { gravity=Gravity.CENTER })
        main.addView(signal,LinearLayout.LayoutParams(dp(76),dp(110)))
        card!!.addView(main)

        // Footer route information and online road-data line.
        card!!.addView(View(this).apply { setBackgroundColor(Color.rgb(35,81,119)); layoutParams=LinearLayout.LayoutParams(-1,dp(1)).apply { topMargin=dp(12); bottomMargin=dp(8) } })
        val footer=LinearLayout(this).apply { orientation=LinearLayout.HORIZONTAL; gravity=Gravity.CENTER_VERTICAL }
        footer.addView(text("●  8.4 km\n   إلى الوجهة",12f,Color.WHITE,true),LinearLayout.LayoutParams(0,dp(42),1f))
        footer.addView(divider(),LinearLayout.LayoutParams(dp(1),dp(34)))
        footer.addView(text("  ◷  18:58\n      الوصول المتوقع",11f,Color.WHITE,true),LinearLayout.LayoutParams(0,dp(42),1f))
        footer.addView(divider(),LinearLayout.LayoutParams(dp(1),dp(34)))
        footer.addView(text("  ╱  D6\n     الطريق الحالي",11f,Color.WHITE,true),LinearLayout.LayoutParams(0,dp(42),1f))
        card!!.addView(footer)
        osmInfo=text("OpenStreetMap · بانتظار الموقع",10f,Color.rgb(99,224,193)).apply { setPadding(dp(2),dp(4),0,0); maxLines=2 }
        card!!.addView(osmInfo)

        params=WindowManager.LayoutParams(widthForSize(),WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
            PixelFormat.TRANSLUCENT).apply {
            gravity=Gravity.TOP or Gravity.START;x=prefs.getInt("x",30);y=prefs.getInt("y",180)
        }
        card!!.setOnTouchListener(object:View.OnTouchListener{
            var sx=0;var sy=0;var tx=0f;var ty=0f
            override fun onTouch(v:View,e:MotionEvent):Boolean{
                when(e.action){
                    MotionEvent.ACTION_DOWN->{sx=params!!.x;sy=params!!.y;tx=e.rawX;ty=e.rawY;return true}
                    MotionEvent.ACTION_MOVE->{params!!.x=sx+(e.rawX-tx).toInt();params!!.y=sy+(e.rawY-ty).toInt();try{wm?.updateViewLayout(card,params)}catch(_:Exception){};return true}
                    MotionEvent.ACTION_UP->{prefs.edit().putInt("x",params!!.x).putInt("y",params!!.y).apply();return true}
                };return false
            }
        })
        wm?.addView(card,params); attached=true; refreshContent()
    }

    private fun usageAccessGranted():Boolean {
        val appOps=getSystemService(Context.APP_OPS_SERVICE) as android.app.AppOpsManager
        return try {
            appOps.checkOpNoThrow("android:get_usage_stats", android.os.Process.myUid(), packageName) == android.app.AppOpsManager.MODE_ALLOWED
        } catch (_:Exception) { false }
    }

    private fun isMapsForeground():Boolean {
        return try {
            val usm=getSystemService(Context.USAGE_STATS_SERVICE) as UsageStatsManager
            val end=System.currentTimeMillis()
            val events=usm.queryEvents(end-5000L,end)
            val event=UsageEvents.Event()
            var lastPackage=""
            var lastTime=0L
            while(events.hasNextEvent()) {
                events.getNextEvent(event)
                if(event.eventType==UsageEvents.Event.MOVE_TO_FOREGROUND ||
                   event.eventType==UsageEvents.Event.ACTIVITY_RESUMED) {
                    if(event.timeStamp>=lastTime) {
                        lastTime=event.timeStamp
                        lastPackage=event.packageName ?: ""
                    }
                }
            }
            lastPackage=="com.google.android.apps.maps"
        } catch (_:Exception) { false }
    }

    private fun dp(value:Int):Int = (value * resources.displayMetrics.density + 0.5f).toInt()
    private fun widthForSize()=when(prefs.getInt("size",2)){0->dp(280);1->dp(340);2->dp(420);else->dp(500)}
    private fun updateSize(){
        val c=card?:return; val p=params?:return; p.width=widthForSize()
        val scale=when(prefs.getInt("size",2)){0->0.88f;1->0.96f;2->1.08f;else->1.18f}
        c.setPadding(dp((18*scale).toInt()),dp((14*scale).toInt()),dp((18*scale).toInt()),dp((13*scale).toInt()))
        distance?.textSize=25f*scale; instruction?.textSize=14f*scale; summary?.textSize=17f*scale
        try{wm?.updateViewLayout(c,p)}catch(_:Exception){}
        startProgressAnimation()
    }

    // Decorative indeterminate activity indicator only; it is deliberately not presented as route progress.
    private fun startProgressAnimation(){
        val track=progressTrack ?: return
        val indicator=progressIndicator ?: return
        progressAnimator?.cancel()
        track.post {
            val travel=(track.width-indicator.width).coerceAtLeast(0).toFloat()
            if(travel<=0f) return@post
            progressAnimator=ValueAnimator.ofFloat(0f,travel).apply {
                duration=1250L; repeatCount=ValueAnimator.INFINITE; repeatMode=ValueAnimator.REVERSE
                interpolator=LinearInterpolator()
                addUpdateListener { animator -> indicator.translationX=animator.animatedValue as Float }
                start()
            }
        }
    }

    private fun refreshContent(){
        updateOsmIfNeeded()
        osmInfo?.text=lastOsmText
        val payload=prefs.getString("navigation_text","").orEmpty()
        if(preview){
            distance?.text="150 m"
            instruction?.text="انعطف يمينًا على الطريق القادم"
            summary?.text="FlyMap · Google Maps"
            directionArrow?.text="↱"
            signalDistance?.text="200 m"
            return
        }
        if(payload.isBlank()){
            distance?.text="—"
            instruction?.text="ابدأ الملاحة في Google Maps"
            summary?.text="FlyMap · بانتظار بيانات الملاحة"
            directionArrow?.text="➤"
            return
        }
        val lines=payload.lines().map { it.trim() }.filter { it.isNotBlank() }.distinct()
        val joined=lines.joinToString(" · ")
        val distanceMatch=Regex("(?i)(\\d+(?:[.,]\\d+)?\\s*(?:m|km|mi|ft|meters?|kilometers?|mètres?|kilomètres?))").find(joined)
        val distanceText=distanceMatch?.value?.replace(Regex("\\s+")," ")
        val instructionLine=lines.firstOrNull { line ->
            line.contains("turn",true) || line.contains("continue",true) || line.contains("head",true) ||
            line.contains("rond-point",true) || line.contains("rond point",true) || line.contains("tournez",true) ||
            line.contains("continuez",true) || line.contains("tourne",true) || line.contains("prenez",true) ||
            line.contains("انحرف") || line.contains("اتجه") || line.contains("استمر") || line.contains("دوار")
        } ?: lines.firstOrNull()
        distance?.text=distanceText ?: lines.firstOrNull()?.take(24) ?: "Navigation"
        instruction?.text=instructionLine?.takeIf { it != distanceText } ?: lines.getOrNull(1) ?: "Google Maps navigation"
        summary?.text=if(lines.size>2) lines.filter { it != instructionLine && it != distanceText }.joinToString(" · ").take(100) else "Navigation active"
        val directionSource=(instructionLine ?: joined).lowercase()
        directionArrow?.text=when {
            listOf("left","gauche","links","يسار","يسارًا").any { directionSource.contains(it) } -> "↰"
            listOf("right","droite","rechts","يمين","يمينًا").any { directionSource.contains(it) } -> "↱"
            listOf("u-turn","demi-tour","demi tour","retournez","استدر").any { directionSource.contains(it) } -> "↶"
            listOf("roundabout","rond-point","rond point","دوار").any { directionSource.contains(it) } -> "⟳"
            else -> "↑"
        }
    }

    private fun updateOsmIfNeeded() {
        if (preview || System.currentTimeMillis() - lastOsmLookup < 30000L) return
        lastOsmLookup = System.currentTimeMillis()
        if (checkSelfPermission(android.Manifest.permission.ACCESS_FINE_LOCATION) != android.content.pm.PackageManager.PERMISSION_GRANTED &&
            checkSelfPermission(android.Manifest.permission.ACCESS_COARSE_LOCATION) != android.content.pm.PackageManager.PERMISSION_GRANTED) {
            lastOsmText = "OSM: enable location permission in NavWidget settings"
            return
        }
        try {
            val lm = getSystemService(LOCATION_SERVICE) as android.location.LocationManager
            val loc = lm.getLastKnownLocation(android.location.LocationManager.GPS_PROVIDER)
                ?: lm.getLastKnownLocation(android.location.LocationManager.NETWORK_PROVIDER)
            if (loc == null) { lastOsmText = "OSM: waiting for GPS location"; return }
            lastOsmText = "OpenStreetMap: checking nearby roads…"
            OsmRoadInfoClient.lookup(loc) { result ->
                handler.post {
                    val parts = mutableListOf<String>()
                    if (result.speedLimit != null) parts.add("Limit ${result.speedLimit}")
                    if (result.trafficSignalDistance != null) parts.add("Traffic light ~${result.trafficSignalDistance} m")
                    lastOsmText = if (parts.isEmpty()) result.status else "OSM · " + parts.joinToString("  |  ")
                    osmInfo?.text = lastOsmText
                }
            }
        } catch (_: SecurityException) { lastOsmText = "OSM: location permission required" }
          catch (_: Exception) { lastOsmText = "OSM: location unavailable" }
    }

    override fun onDestroy(){
        handler.removeCallbacks(foregroundCheck)
        handler.removeCallbacks(osmRefreshLoop)
        progressAnimator?.cancel(); progressAnimator=null
        try{unregisterReceiver(receiver)}catch(_:Exception){}
        try{card?.let{wm?.removeView(it)}}catch(_:Exception){}
        attached=false
        card=null;super.onDestroy()
    }
    override fun onBind(intent:Intent?):IBinder?=null
}
