package com.coolray.navwidget

import android.location.Location
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder
import kotlin.concurrent.thread

/** Online OpenStreetMap/Overpass lookup. Nearby data is advisory; it is not guaranteed to match the active route. */
object OsmRoadInfoClient {
    data class Result(val speedLimit: String?, val trafficSignalDistance: Int?, val status: String)

    fun lookup(location: Location, callback: (Result) -> Unit) {
        thread(name = "osm-road-lookup") {
            var result = Result(null, null, "OSM: no nearby mapped data")
            var conn: HttpURLConnection? = null
            try {
                val lat = location.latitude
                val lon = location.longitude
                val q = "[out:json][timeout:12];(way(around:150,$lat,$lon)[highway][maxspeed];node(around:250,$lat,$lon)[highway=traffic_signals];);out center tags;"
                conn = URL("https://overpass-api.de/api/interpreter").openConnection() as HttpURLConnection
                conn.requestMethod = "POST"
                conn.connectTimeout = 7000
                conn.readTimeout = 15000
                conn.doOutput = true
                conn.setRequestProperty("Content-Type", "application/x-www-form-urlencoded; charset=UTF-8")
                conn.setRequestProperty("User-Agent", "NavWidget/1.6 (OpenStreetMap road information)")
                val body = "data=" + URLEncoder.encode(q, "UTF-8")
                conn.outputStream.use { it.write(body.toByteArray(Charsets.UTF_8)) }
                if (conn.responseCode !in 200..299) throw Exception("Overpass HTTP ${conn.responseCode}")
                val json = JSONObject(conn.inputStream.bufferedReader().use { it.readText() })
                val elements = json.optJSONArray("elements")
                var bestSpeed: String? = null
                var bestSpeedDistance = Float.MAX_VALUE
                var bestSignal: Int? = null
                if (elements != null) for (i in 0 until elements.length()) {
                    val e = elements.optJSONObject(i) ?: continue
                    val tags = e.optJSONObject("tags") ?: JSONObject()
                    val isNode = e.optString("type") == "node"
                    val eLat = if (isNode) e.optDouble("lat", Double.NaN) else e.optJSONObject("center")?.optDouble("lat", Double.NaN) ?: Double.NaN
                    val eLon = if (isNode) e.optDouble("lon", Double.NaN) else e.optJSONObject("center")?.optDouble("lon", Double.NaN) ?: Double.NaN
                    if (eLat.isNaN() || eLon.isNaN()) continue
                    val target = Location("osm").apply { latitude = eLat; longitude = eLon }
                    val meters = location.distanceTo(target)
                    if (isNode && tags.optString("highway") == "traffic_signals") {
                        val d = meters.toInt()
                        if (bestSignal == null || d < bestSignal!!) bestSignal = d
                    }
                    if (!isNode) {
                        val raw = tags.optString("maxspeed", "")
                        if (raw.isNotBlank() && meters < bestSpeedDistance) {
                            bestSpeedDistance = meters
                            bestSpeed = raw
                        }
                    }
                }
                result = Result(bestSpeed, bestSignal, if (bestSpeed == null && bestSignal == null) "OSM: no nearby mapped data" else "OpenStreetMap · nearby data")
            } catch (e: Exception) {
                result = Result(null, null, "OSM offline/unavailable")
            } finally { conn?.disconnect() }
            callback(result)
        }
    }
}
