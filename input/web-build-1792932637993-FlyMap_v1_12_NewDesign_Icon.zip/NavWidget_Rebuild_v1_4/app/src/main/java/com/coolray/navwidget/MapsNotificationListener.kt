package com.coolray.navwidget

import android.content.Intent
import android.service.notification.NotificationListenerService
import android.service.notification.StatusBarNotification

class MapsNotificationListener : NotificationListenerService() {
    override fun onNotificationPosted(sbn: StatusBarNotification) {
        if(sbn.packageName != "com.google.android.apps.maps") return
        val e=sbn.notification.extras
        val lines=listOf("android.title","android.text","android.bigText").mapNotNull {
            e.getCharSequence(it)?.toString()?.trim()?.takeIf { value -> value.isNotEmpty() }
        }.distinct()
        getSharedPreferences("nav_widget",MODE_PRIVATE).edit().putString("navigation_text",lines.joinToString("\n")).apply()
        sendBroadcast(Intent(FloatingWidgetService.ACTION_REFRESH).setPackage(packageName))
    }
    override fun onNotificationRemoved(sbn: StatusBarNotification) {
        if(sbn.packageName=="com.google.android.apps.maps") {
            getSharedPreferences("nav_widget",MODE_PRIVATE).edit().putString("navigation_text","").apply()
            sendBroadcast(Intent(FloatingWidgetService.ACTION_REFRESH).setPackage(packageName))
        }
    }
}
