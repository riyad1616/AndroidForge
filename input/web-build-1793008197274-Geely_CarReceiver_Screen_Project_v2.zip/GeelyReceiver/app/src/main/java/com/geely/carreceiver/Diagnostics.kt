package com.geely.carreceiver

import android.content.Context
import android.os.Build
import java.io.File
import java.io.IOException
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/**
 * Read-only report about this head unit: what Android it runs, whether root exists and which
 * car-related services/packages are present. Send it to whoever adapts the command table.
 */
object Diagnostics {

    private val CHECKS = listOf(
        "user id" to "id",
        "su binary" to "ls -l /system/bin/su /system/xbin/su /sbin/su /su/bin/su 2>&1",
        "placeholder device" to "ls -l /dev/car_control 2>&1",
        "car related properties" to "getprop | grep -iE 'geely|ecarx|vehicle|flyme|car|auto' | head -n 60",
        "car related services" to "service list | grep -iE 'car|vehicle|can|hvac|geely|ecarx|window|door|light|seat' | head -n 80",
        "car related packages" to "pm list packages | grep -iE 'geely|ecarx|flyme|vehicle|car|auto' | head -n 120",
        "/dev entries" to "ls /dev | head -n 200",
        "network" to "ip addr 2>&1 | grep -E 'inet |^[0-9]+:' | head -n 30"
    )

    /** Blocking (several seconds): call from a background thread. */
    fun run(context: Context): String {
        val sb = StringBuilder()
        sb.append("Geely Receiver diagnostics ").append(SimpleDateFormat("yyyy-MM-dd HH:mm", Locale.US).format(Date())).append("\n\n")
        sb.append("manufacturer: ").append(Build.MANUFACTURER).append('\n')
        sb.append("model: ").append(Build.MODEL).append('\n')
        sb.append("device: ").append(Build.DEVICE).append('\n')
        sb.append("android: ").append(Build.VERSION.RELEASE).append(" (sdk ").append(Build.VERSION.SDK_INT).append(")\n")
        sb.append("build: ").append(Build.DISPLAY).append('\n')
        sb.append("fingerprint: ").append(Build.FINGERPRINT).append("\n\n")
        for ((title, command) in CHECKS) {
            sb.append("## ").append(title).append("\n$ ").append(command).append('\n')
            val out = Shell.run(arrayOf("sh", "-c", command), 6000L, 6000)
            when {
                out.failure != null -> sb.append("[").append(out.failure).append("]\n")
                out.text.isEmpty() -> sb.append("(no output, exit=").append(out.exit).append(")\n")
                else -> sb.append(out.text).append('\n')
            }
            sb.append('\n')
        }
        sb.append("command table: ").append(File(context.filesDir, CommandBackend.FILE_NAME).absolutePath).append('\n')
        return sb.toString()
    }

    /** @return the path of the saved report, or null when it could not be written. */
    fun save(context: Context, report: String): String? = try {
        val dir = context.getExternalFilesDir(null) ?: context.filesDir
        val file = File(dir, "diagnostics.txt")
        file.writeText(report, Charsets.UTF_8)
        file.absolutePath
    } catch (e: IOException) {
        null
    }
}
