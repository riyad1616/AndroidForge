package com.geely.carreceiver

import android.content.Context
import android.os.Looper

/**
 * A second, completely different way to run this app's code - NOT through the normal Activity/Service
 * component system, and not installed anywhere special. This class is launched directly by Android's own
 * `app_process` binary from a root shell, as a brand-new standalone process (not the app's normal running
 * process), optionally under a different uid (`su 1000 app_process ...` runs it as uid=1000/"system",
 * the same identity car_service itself runs under inside system_server).
 *
 * The point: [VhalAccess] already reports real SecurityException/area failures when THIS app's normal,
 * unprivileged process tries to write most VHAL properties (see [CommandBackend]'s doc comment). The
 * question this class answers is narrow and concrete: does the exact same [VhalAccess] code, unchanged,
 * succeed when the OS-level uid making the call is 1000 instead of this app's own assigned uid? If yes,
 * every command that currently fails for the normal app process could instead be executed this way (via
 * root + `su 1000 app_process`) without ever modifying /system or installing anything as a privileged
 * system app. If no (still SecurityException even as uid=1000), that rules this path out cleanly and the
 * remaining options are the ones that *do* touch /system.
 *
 * Nothing here is wired into the phone-controlled command table; it only runs when someone with root
 * deliberately launches it from a shell. It changes two reversible things (dome light, mirror fold) and
 * always sets them back to off/unfolded at the end of the test, whatever the outcome of each step was.
 *
 * How to run (from a root shell, after installing this exact build of GeelyReceiver normally - this does
 * NOT need to be a system app for this test):
 *   pm path com.geely.carreceiver
 *   su 1000 app_process -Djava.class.path=<the apk path from the line above, without "package:"> /system/bin com.geely.carreceiver.VhalProbeMain
 */
object VhalProbeMain {

    @JvmStatic
    fun main(args: Array<String>) {
        println("== VhalProbeMain ==")
        try {
            println("uid=" + android.os.Process.myUid() + " pid=" + android.os.Process.myPid())

            if (Looper.myLooper() == null) Looper.prepareMainLooper()

            // android.app.ActivityThread is not public API - this app cannot compile against it directly,
            // only reach it via reflection, exactly like VhalAccess already does for android.car.
            val activityThreadClass = Class.forName("android.app.ActivityThread")
            val systemMain = activityThreadClass.getMethod("systemMain")
            val thread = systemMain.invoke(null)
            val getSystemContext = activityThreadClass.getMethod("getSystemContext")
            val context = getSystemContext.invoke(thread) as Context
            println("context ok: package=" + context.packageName)

            val mgr = VhalAccess.manager(context)
            if (mgr == null) {
                println("VHAL manager FAILED: " + (VhalAccess.lastError() ?: "unknown reason"))
                println("== done (no properties tested) ==")
                return
            }
            println("VHAL manager OK")

            probe("DOME_LIGHT (interior light)", mgr, 0x21402069, 0x0)
            probe("MIRROR_FOLD", mgr, 0x21402023, 0x0)

            println("== done ==")
        } catch (e: Throwable) {
            println("FATAL: " + e.javaClass.name + ": " + e.message)
        }
    }

    /** Reads, writes true, reads, writes false (back to the safe/original state), reads - for one property.
     *  Every step is printed as-is, success or failure, nothing is hidden or summarized. */
    private fun probe(label: String, mgr: Any, propId: Int, area: Int) {
        println("--- $label (prop=0x${propId.toString(16)} area=0x${area.toString(16)}) ---")
        println("before:      " + VhalAccess.describeValue(mgr, propId, area))
        val on = VhalAccess.setBool(mgr, propId, area, true)
        println("set true ->  ok=${on.ok}  ${on.message}")
        try { Thread.sleep(600) } catch (ignored: InterruptedException) {}
        println("after true:  " + VhalAccess.describeValue(mgr, propId, area))
        val off = VhalAccess.setBool(mgr, propId, area, false)
        println("set false -> ok=${off.ok}  ${off.message}")
        try { Thread.sleep(600) } catch (ignored: InterruptedException) {}
        println("after false: " + VhalAccess.describeValue(mgr, propId, area))
    }
}
