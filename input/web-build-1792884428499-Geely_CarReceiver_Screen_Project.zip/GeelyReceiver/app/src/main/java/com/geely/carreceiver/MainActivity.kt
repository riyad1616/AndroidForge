package com.geely.carreceiver

import android.content.Intent
import android.os.Build
import android.os.Bundle
import android.widget.Button
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity

class MainActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        val tvStatus = findViewById<TextView>(R.id.tvStatus)
        val btnStart = findViewById<Button>(R.id.btnStartService)
        val btnStop = findViewById<Button>(R.id.btnStopService)

        tvStatus.text = "الخدمة تعمل في الخلفية على المنفذ 8888"

        btnStart.setOnClickListener {
            val serviceIntent = Intent(this, CarSocketService::class.java)
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                startForegroundService(serviceIntent)
            } else {
                startService(serviceIntent)
            }
            tvStatus.text = "تم تشغيل الخدمة ✓"
        }

        btnStop.setOnClickListener {
            stopService(Intent(this, CarSocketService::class.java))
            tvStatus.text = "تم إيقاف الخدمة"
        }

        // Start service automatically when activity opens
        val serviceIntent = Intent(this, CarSocketService::class.java)
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            startForegroundService(serviceIntent)
        } else {
            startService(serviceIntent)
        }
    }
}
