package com.geely.carreceiver

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Intent
import android.os.Build
import android.os.IBinder
import android.util.Log
import androidx.core.app.NotificationCompat
import java.io.BufferedReader
import java.io.InputStreamReader
import java.net.ServerSocket
import kotlin.concurrent.thread

class CarSocketService : Service() {

    private var isRunning = false
    private val PORT = 8888
    private val TAG = "CarSocketService"

    override fun onCreate() {
        super.onCreate()
        startForegroundNotification()
        startSocketServer()
    }

    private fun startForegroundNotification() {
        val channelId = "CarSocketServiceChannel"
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                channelId,
                "Geely Car Socket Service",
                NotificationManager.IMPORTANCE_LOW
            )
            val manager = getSystemService(NotificationManager::class.java)
            manager?.createNotificationChannel(channel)
        }

        val notification: Notification = NotificationCompat.Builder(this, channelId)
            .setContentTitle("نظام تحكم جيلي نشط")
            .setContentText("جاري استقبال أوامر الهاتف عبر الشبكة المحلية...")
            .setSmallIcon(android.R.drawable.ic_menu_manage)
            .setOngoing(true)
            .build()

        startForeground(1, notification)
    }

    private fun startSocketServer() {
        isRunning = true
        thread {
            try {
                val serverSocket = ServerSocket(PORT)
                Log.i(TAG, "Socket server started on port $PORT")
                while (isRunning) {
                    val socket = serverSocket.accept()
                    val reader = BufferedReader(InputStreamReader(socket.getInputStream()))
                    val command = reader.readLine()

                    if (command != null) {
                        Log.i(TAG, "Received command: $command")
                        executeHardwareCommand(command)
                    }
                    socket.close()
                }
                serverSocket.close()
            } catch (e: Exception) {
                Log.e(TAG, "Socket server error", e)
            }
        }
    }

    private fun executeHardwareCommand(cmd: String) {
        val systemCommand = when (cmd) {
            "CMD_WINDOW_OPEN" -> "echo 'OPEN_WINDOWS' > /dev/car_control"
            "CMD_WINDOW_CLOSE" -> "echo 'CLOSE_WINDOWS' > /dev/car_control"
            "CMD_SUNROOF_OPEN" -> "echo 'OPEN_SUNROOF' > /dev/car_control"
            "CMD_SUNROOF_CLOSE" -> "echo 'CLOSE_SUNROOF' > /dev/car_control"
            "CMD_AC_ON" -> "echo 'AC_ON' > /dev/car_control"
            "CMD_AC_OFF" -> "echo 'AC_OFF' > /dev/car_control"
            "CMD_MIRROR_UNFOLD" -> "echo 'UNFOLD_MIRRORS' > /dev/car_control"
            "CMD_MIRROR_FOLD" -> "echo 'FOLD_MIRRORS' > /dev/car_control"
            // الإضاءة
            "CMD_HEADLIGHTS_ON" -> "echo 'HEADLIGHTS_ON' > /dev/car_control"
            "CMD_HEADLIGHTS_OFF" -> "echo 'HEADLIGHTS_OFF' > /dev/car_control"
            "CMD_HIGHBEAM_ON" -> "echo 'HIGHBEAM_ON' > /dev/car_control"
            "CMD_HIGHBEAM_OFF" -> "echo 'HIGHBEAM_OFF' > /dev/car_control"
            "CMD_INTERIOR_ON" -> "echo 'INTERIOR_ON' > /dev/car_control"
            "CMD_INTERIOR_OFF" -> "echo 'INTERIOR_OFF' > /dev/car_control"
            "CMD_FOG_ON" -> "echo 'FOG_ON' > /dev/car_control"
            "CMD_FOG_OFF" -> "echo 'FOG_OFF' > /dev/car_control"
            // الأبواب والصندوق
            "CMD_DOOR_UNLOCK" -> "echo 'DOOR_UNLOCK' > /dev/car_control"
            "CMD_DOOR_LOCK" -> "echo 'DOOR_LOCK' > /dev/car_control"
            "CMD_TRUNK_OPEN" -> "echo 'TRUNK_OPEN' > /dev/car_control"
            "CMD_TRUNK_CLOSE" -> "echo 'TRUNK_CLOSE' > /dev/car_control"
            // المنبه والراديو
            "CMD_HORN" -> "echo 'HORN' > /dev/car_control"
            "CMD_RADIO_ON" -> "echo 'RADIO_ON' > /dev/car_control"
            "CMD_RADIO_OFF" -> "echo 'RADIO_OFF' > /dev/car_control"
            // المقاعد وأضواء الطوارئ
            "CMD_SEAT_HEAT_ON" -> "echo 'SEAT_HEAT_ON' > /dev/car_control"
            "CMD_SEAT_HEAT_OFF" -> "echo 'SEAT_HEAT_OFF' > /dev/car_control"
            "CMD_HAZARD_ON" -> "echo 'HAZARD_ON' > /dev/car_control"
            "CMD_HAZARD_OFF" -> "echo 'HAZARD_OFF' > /dev/car_control"
            "CMD_REBOOT" -> "reboot"
            else -> null
        }

        systemCommand?.let {
            try {
                Log.i(TAG, "Executing: $it")
                val process = Runtime.getRuntime().exec(arrayOf("sh", "-c", it))
                process.waitFor()
            } catch (e: Exception) {
                Log.e(TAG, "Failed to execute command", e)
            }
        }
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        return START_STICKY
    }

    override fun onDestroy() {
        super.onDestroy()
        isRunning = false
    }

    override fun onBind(intent: Intent?): IBinder? = null
}
