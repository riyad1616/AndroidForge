package com.coolray.vradiofavorites;

import android.app.AppOpsManager;
import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.app.usage.UsageStats;
import android.app.usage.UsageStatsManager;
import android.content.ComponentName;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Bitmap;
import android.graphics.PixelFormat;
import android.media.AudioManager;
import android.media.browse.MediaBrowser;
import android.media.session.MediaSession;
import android.os.Build;
import android.os.Handler;
import android.os.IBinder;
import android.os.Looper;
import android.os.Process;
import android.view.Gravity;
import android.view.KeyEvent;
import android.view.WindowManager;
import android.widget.Toast;

import androidx.core.app.NotificationCompat;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import java.util.SortedMap;
import java.util.TreeMap;

public class FloatService extends Service implements RadioBarView.Listener {
    public static final String ACTION_STOP = "STOP";
    private static final String PREFS = "vradio_float";
    private static final String CH = "vradio_float_ch";
    private static final int NID = 42;

    private WindowManager wm;
    private WindowManager.LayoutParams params;
    private RadioBarView bar;
    private RadioClient client;
    private RadioClient statusClient;
    private MediaSession mediaSession;
    private final Handler handler = new Handler(Looper.getMainLooper());
    private final List<MediaBrowser.MediaItem> stations = new ArrayList<>();
    private int currentIndex = -1;
    private boolean hiddenForApp = true;
    private final Runnable pollFg = this::checkForeground;
    private final Runnable refreshFav = this::loadStations;

    @Override
    public void onCreate() {
        super.onCreate();
        wm = (WindowManager) getSystemService(WINDOW_SERVICE);
        createChannel();
        setupMediaSession();
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        if (intent != null && ACTION_STOP.equals(intent.getAction())) {
            stopAll();
            return START_NOT_STICKY;
        }
        SharedPreferences p = getSharedPreferences(PREFS, MODE_PRIVATE);
        if (!p.getBoolean("on", false)) {
            stopSelf();
            return START_NOT_STICKY;
        }
        startForeground(NID, notif());
        if (bar == null) show();
        return START_STICKY;
    }

    private void setupMediaSession() {
        try {
            mediaSession = new MediaSession(this, "VRadioFloat");
            mediaSession.setFlags(
                    MediaSession.FLAG_HANDLES_MEDIA_BUTTONS
                            | MediaSession.FLAG_HANDLES_TRANSPORT_CONTROLS);
            mediaSession.setCallback(new MediaSession.Callback() {
                @Override public void onPlay() {
                    playIndex(currentIndex >= 0 ? currentIndex : 0);
                }
                @Override public void onPause() {
                    onStop();
                }
                @Override public void onStop() {
                    FloatService.this.onStop();
                }
                @Override public void onSkipToNext() {
                    playNext();
                }
                @Override public void onSkipToPrevious() {
                    playPrev();
                }
                @Override public boolean onMediaButtonEvent(Intent mediaButtonIntent) {
                    KeyEvent ke = mediaButtonIntent.getParcelableExtra(Intent.EXTRA_KEY_EVENT);
                    if (ke != null && ke.getAction() == KeyEvent.ACTION_DOWN) {
                        switch (ke.getKeyCode()) {
                            case KeyEvent.KEYCODE_MEDIA_PLAY:
                            case KeyEvent.KEYCODE_MEDIA_PLAY_PAUSE:
                                if (currentIndex >= 0) playIndex(currentIndex);
                                else playIndex(0);
                                return true;
                            case KeyEvent.KEYCODE_MEDIA_PAUSE:
                            case KeyEvent.KEYCODE_MEDIA_STOP:
                                FloatService.this.onStop();
                                return true;
                            case KeyEvent.KEYCODE_MEDIA_NEXT:
                                playNext();
                                return true;
                            case KeyEvent.KEYCODE_MEDIA_PREVIOUS:
                                playPrev();
                                return true;
                        }
                    }
                    return super.onMediaButtonEvent(mediaButtonIntent);
                }
            });
            mediaSession.setActive(true);
            try {
                AudioManager am = (AudioManager) getSystemService(AUDIO_SERVICE);
                if (am != null) {
                    am.registerMediaButtonEventReceiver(
                            new ComponentName(this, BootReceiver.class));
                }
            } catch (Exception ignored) {}
        } catch (Exception ignored) {}
    }

    private void show() {
        bar = new RadioBarView(this);
        bar.setListener(this);
        SharedPreferences p = getSharedPreferences(PREFS, MODE_PRIVATE);
        bar.setThemeIndex(p.getInt("theme", 0));

        int type = Build.VERSION.SDK_INT >= 26
                ? WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
                : WindowManager.LayoutParams.TYPE_PHONE;
        float density = getResources().getDisplayMetrics().density;
        int screenW = getResources().getDisplayMetrics().widthPixels;
        int w = Math.min(screenW - (int) (8 * density), (int) (920 * density));
        int h = (int) (72 * density);
        params = new WindowManager.LayoutParams(w, h, type,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE
                        | WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
                PixelFormat.TRANSLUCENT);
        params.gravity = Gravity.BOTTOM | Gravity.CENTER_HORIZONTAL;
        params.y = p.getInt("pos_y", (int) (88 * density));
        params.x = p.getInt("pos_x", 0);
        applyAlpha();
        try {
            wm.addView(bar, params);
            // Start hidden until home confirmed
            bar.setVisibility(android.view.View.GONE);
            hiddenForApp = true;
        } catch (Exception e) {
            Toast.makeText(this, R.string.need_overlay, Toast.LENGTH_LONG).show();
            stopSelf();
            return;
        }
        loadStations();
        listenStatus();
        handler.post(pollFg);
        handler.postDelayed(refreshFav, 8000);
        // Auto-play last station after boot / service start
        handler.postDelayed(this::autoPlayLast, 2500);
    }

    private void loadStations() {
        if (client != null) client.disconnect();
        client = new RadioClient();
        client.load(this, new RadioClient.Callback() {
            @Override public void favorites(List<MediaBrowser.MediaItem> list) {
                stations.clear();
                if (list != null) stations.addAll(list);
                Bitmap[] logos = new Bitmap[RadioBarView.MAX];
                String[] names = new String[RadioBarView.MAX];
                for (int i = 0; i < stations.size() && i < RadioBarView.MAX; i++) {
                    MediaBrowser.MediaItem item = stations.get(i);
                    if (item.getDescription() != null) {
                        CharSequence t = item.getDescription().getTitle();
                        if (t != null) names[i] = t.toString();
                        logos[i] = LogoLoader.load(FloatService.this, item.getDescription());
                    }
                }
                if (bar != null) bar.setStations(stations, logos, names);
            }
            @Override public void error(String msg) {
                if (bar != null) bar.setStatus(msg, false);
            }
        });
        handler.removeCallbacks(refreshFav);
        handler.postDelayed(refreshFav, 10000);
    }

    private void autoPlayLast() {
        SharedPreferences p = getSharedPreferences(PREFS, MODE_PRIVATE);
        if (!p.getBoolean("on", false)) return;
        String lastId = p.getString("last_media_id", null);
        if (lastId == null || lastId.isEmpty()) return;
        if (stations.isEmpty()) {
            handler.postDelayed(this::autoPlayLast, 2000);
            return;
        }
        for (int i = 0; i < stations.size(); i++) {
            if (lastId.equals(stations.get(i).getMediaId())) {
                playIndex(i);
                return;
            }
        }
        // fallback first favorite
        playIndex(0);
    }

    private void listenStatus() {
        if (statusClient != null) statusClient.disconnect();
        statusClient = new RadioClient();
        statusClient.listenStatus(this, (text, playing) -> {
            if (bar != null) bar.setStatus(text, playing);
        });
    }

    private void playIndex(int index) {
        if (stations.isEmpty()) {
            loadStations();
            return;
        }
        if (index < 0) index = 0;
        if (index >= stations.size()) index = 0;
        currentIndex = index;
        MediaBrowser.MediaItem item = stations.get(index);
        if (client == null) client = new RadioClient();
        client.play(this, item);
        if (item.getMediaId() != null) {
            getSharedPreferences(PREFS, MODE_PRIVATE).edit()
                    .putString("last_media_id", item.getMediaId())
                    .putInt("last_index", index)
                    .apply();
        }
        if (bar != null) bar.setStatus("", true);
    }

    private void playNext() {
        if (stations.isEmpty()) return;
        int n = (currentIndex + 1) % stations.size();
        playIndex(n);
    }

    private void playPrev() {
        if (stations.isEmpty()) return;
        int n = currentIndex <= 0 ? stations.size() - 1 : currentIndex - 1;
        playIndex(n);
    }

    @Override public void onStation(int index) {
        playIndex(index);
    }

    @Override public void onStop() {
        if (client == null) client = new RadioClient();
        client.stop(this);
        if (bar != null) bar.setStatus("", false);
    }

    @Override public void onThemeCycle() {
        if (bar == null) return;
        bar.nextTheme();
        getSharedPreferences(PREFS, MODE_PRIVATE).edit()
                .putInt("theme", bar.getThemeIndex()).apply();
    }

    @Override public void onDrag(float dx, float dy) {
        if (params == null || bar == null) return;
        params.x += (int) dx;
        params.y -= (int) dy;
        try { wm.updateViewLayout(bar, params); } catch (Exception ignored) {}
    }

    @Override public void onDragEnd() {
        if (params == null) return;
        getSharedPreferences(PREFS, MODE_PRIVATE).edit()
                .putInt("pos_x", params.x).putInt("pos_y", params.y).apply();
    }

    private void applyAlpha() {
        if (bar == null) return;
        float a = getSharedPreferences(PREFS, MODE_PRIVATE).getFloat("alpha", 1f);
        if (a < 0.2f) a = 0.2f;
        if (a > 1f) a = 1f;
        bar.setAlpha(a);
    }

    private void checkForeground() {
        try {
            SharedPreferences prefs = getSharedPreferences(PREFS, MODE_PRIVATE);
            boolean homeOnly = prefs.getBoolean("home_only", true);
            applyAlpha();
            if (!homeOnly) {
                applyHide(false);
            } else {
                String[] pa = foregroundPkgAndActivity();
                if (pa == null) {
                    applyHide(true);
                } else {
                    applyHide(!isHomeScreen(pa[0], pa[1] != null ? pa[1] : ""));
                }
            }
        } catch (Throwable ignored) {}
        handler.postDelayed(pollFg, 200); // faster hide
    }

    private void applyHide(boolean hide) {
        if (hide == hiddenForApp) return;
        hiddenForApp = hide;
        if (bar != null) {
            bar.setVisibility(hide ? android.view.View.GONE : android.view.View.VISIBLE);
        }
    }

    private String[] foregroundPkgAndActivity() {
        try {
            android.app.ActivityManager am =
                    (android.app.ActivityManager) getSystemService(ACTIVITY_SERVICE);
            if (am != null) {
                List<android.app.ActivityManager.RunningTaskInfo> tasks = am.getRunningTasks(1);
                if (tasks != null && !tasks.isEmpty() && tasks.get(0).topActivity != null) {
                    android.content.ComponentName cn = tasks.get(0).topActivity;
                    return new String[]{cn.getPackageName(),
                            cn.getClassName() != null ? cn.getClassName() : ""};
                }
            }
        } catch (Throwable ignored) {}
        if (!hasUsageAccess()) return null;
        try {
            UsageStatsManager usm = (UsageStatsManager) getSystemService(USAGE_STATS_SERVICE);
            long now = System.currentTimeMillis();
            List<UsageStats> stats = usm.queryUsageStats(UsageStatsManager.INTERVAL_DAILY, now - 6000, now);
            if (stats == null || stats.isEmpty()) return null;
            SortedMap<Long, UsageStats> sorted = new TreeMap<>();
            for (UsageStats u : stats) if (u.getLastTimeUsed() > 0) sorted.put(u.getLastTimeUsed(), u);
            if (sorted.isEmpty()) return null;
            return new String[]{sorted.get(sorted.lastKey()).getPackageName(), ""};
        } catch (Throwable t) {
            return null;
        }
    }

    private boolean hasUsageAccess() {
        try {
            AppOpsManager ops = (AppOpsManager) getSystemService(APP_OPS_SERVICE);
            int mode = ops.checkOpNoThrow(AppOpsManager.OPSTR_GET_USAGE_STATS,
                    Process.myUid(), getPackageName());
            return mode == AppOpsManager.MODE_ALLOWED;
        } catch (Throwable t) {
            return false;
        }
    }

    /** Same strict logic as OneHub Float v6.9.1 homehide */
    private boolean isHomeScreen(String fg, String activity) {
        if (fg == null || fg.isEmpty() || fg.equals(getPackageName())) return false;
        String act = activity != null ? activity.toLowerCase() : "";
        String low = fg.toLowerCase();
        if (act.contains("allapps") || act.contains("all_apps") || act.contains("allapp")
                || act.contains("appdrawer") || act.contains("app_drawer")
                || act.contains("appscustomize") || act.contains("launcherapps")
                || act.contains("applist") || act.contains("app_list")
                || act.contains("appscreen") || act.contains("app_screen")
                || act.contains("secondary") || act.contains("drawer")
                || act.contains("appsview") || act.contains("grid")
                || act.contains("settings") || act.contains("application")) {
            return false;
        }
        if (launcherPackages().contains(fg)) {
            return act.isEmpty() || act.contains("workspace") || act.contains("desktop")
                    || act.contains("homescreen") || act.contains("home_screen")
                    || act.contains("homeactivity") || act.contains("home_activity")
                    || act.contains("mainactivity") || act.contains("main_activity")
                    || act.contains("launcheractivity") || act.contains("idle")
                    || act.contains("portal") || act.contains("cockpit")
                    || act.contains("dashboard") || act.contains("accueil")
                    || (act.contains("home") && !act.contains("all"))
                    || (act.contains("launcher") && !act.contains("app"));
        }
        // limited package-name fallback (no broad contains)
        return low.contains("carlauncher") || low.endsWith(".home")
                || low.contains("android.car.home") || low.contains("flyme.auto.launcher");
    }

    private Set<String> launcherPackages() {
        Set<String> set = new HashSet<>();
        try {
            android.content.pm.PackageManager pm = getPackageManager();
            Intent home = new Intent(Intent.ACTION_MAIN);
            home.addCategory(Intent.CATEGORY_HOME);
            List<android.content.pm.ResolveInfo> list = pm.queryIntentActivities(home, 0);
            if (list != null) {
                for (android.content.pm.ResolveInfo ri : list) {
                    if (ri.activityInfo != null) set.add(ri.activityInfo.packageName);
                }
            }
        } catch (Throwable ignored) {}
        set.add("com.android.launcher");
        set.add("com.android.launcher3");
        set.add("com.google.android.apps.nexuslauncher");
        set.add("com.android.car.carlauncher");
        set.add("com.geely.launcher");
        set.add("com.geely.auto.launcher");
        set.add("com.flyme.auto.launcher");
        set.add("com.autolink.launcher");
        set.add("com.ecarx.launcher");
        set.add("com.sgmw.launcher");
        set.add("com.banma.launcher");
        return set;
    }

    private void stopAll() {
        handler.removeCallbacksAndMessages(null);
        if (mediaSession != null) {
            try { mediaSession.setActive(false); mediaSession.release(); } catch (Exception ignored) {}
            mediaSession = null;
        }
        if (client != null) { client.disconnect(); client = null; }
        if (statusClient != null) { statusClient.disconnect(); statusClient = null; }
        if (bar != null) {
            try { wm.removeView(bar); } catch (Exception ignored) {}
            bar = null;
        }
        stopForeground(true);
        stopSelf();
    }

    private void createChannel() {
        if (Build.VERSION.SDK_INT >= 26) {
            NotificationChannel ch = new NotificationChannel(CH, getString(R.string.channel_name),
                    NotificationManager.IMPORTANCE_LOW);
            NotificationManager nm = getSystemService(NotificationManager.class);
            if (nm != null) nm.createNotificationChannel(ch);
        }
    }

    private Notification notif() {
        Intent stop = new Intent(this, FloatService.class).setAction(ACTION_STOP);
        PendingIntent pi = PendingIntent.getService(this, 1, stop,
                PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
        Intent open = new Intent(this, MainActivity.class);
        PendingIntent oi = PendingIntent.getActivity(this, 2, open,
                PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
        return new NotificationCompat.Builder(this, CH)
                .setContentTitle(getString(R.string.app_name))
                .setContentText(getString(R.string.status_on))
                .setSmallIcon(android.R.drawable.ic_media_play)
                .setContentIntent(oi)
                .addAction(0, "Stop", pi)
                .setOngoing(true)
                .build();
    }

    @Override public IBinder onBind(Intent intent) { return null; }

    @Override public void onDestroy() {
        handler.removeCallbacksAndMessages(null);
        if (mediaSession != null) {
            try { mediaSession.setActive(false); mediaSession.release(); } catch (Exception ignored) {}
        }
        if (client != null) client.disconnect();
        if (statusClient != null) statusClient.disconnect();
        if (bar != null) {
            try { wm.removeView(bar); } catch (Exception ignored) {}
            bar = null;
        }
        super.onDestroy();
    }
}
