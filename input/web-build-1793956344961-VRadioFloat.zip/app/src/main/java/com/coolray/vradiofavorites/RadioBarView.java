package com.coolray.vradiofavorites;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.RectF;
import android.media.browse.MediaBrowser;
import android.os.Handler;
import android.os.Looper;
import android.util.AttributeSet;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewConfiguration;

import java.util.ArrayList;
import java.util.List;

public class RadioBarView extends View {
    public static final int MAX = 10;

    public interface Listener {
        void onStation(int index);
        void onStop();
        void onThemeCycle();
        void onDrag(float dx, float dy);
        void onDragEnd();
    }

    private final Paint paint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final RectF tmp = new RectF();
    private final List<MediaBrowser.MediaItem> stations = new ArrayList<>();
    private final Bitmap[] logos = new Bitmap[MAX];
    private final String[] titles = new String[MAX];
    private boolean playing;
    private int themeIndex;
    private Listener listener;
    private final Handler handler = new Handler(Looper.getMainLooper());
    private boolean dragging, longPressArmed;
    private float downX, downY, lastX, lastY;
    private final int touchSlop;
    private final Runnable waveAnim = new Runnable() {
        @Override public void run() {
            if (playing) {
                invalidate();
                handler.postDelayed(this, 33);
            }
        }
    };
    private final Runnable longPress = () -> {
        longPressArmed = false;
        dragging = true;
        if (listener != null) listener.onDrag(0, 0);
    };

    public RadioBarView(Context c) {
        super(c);
        touchSlop = ViewConfiguration.get(c).getScaledTouchSlop();
    }
    public RadioBarView(Context c, AttributeSet a) {
        super(c, a);
        touchSlop = ViewConfiguration.get(c).getScaledTouchSlop();
    }

    public void setListener(Listener l) { listener = l; }
    public void setThemeIndex(int i) {
        themeIndex = ((i % ThemeColors.ALL.length) + ThemeColors.ALL.length) % ThemeColors.ALL.length;
        invalidate();
    }
    public int getThemeIndex() { return themeIndex; }
    public void nextTheme() { setThemeIndex(themeIndex + 1); }

    public void setStations(List<MediaBrowser.MediaItem> list, Bitmap[] logosIn, String[] names) {
        stations.clear();
        if (list != null) stations.addAll(list);
        for (int i = 0; i < MAX; i++) {
            logos[i] = (logosIn != null && i < logosIn.length) ? logosIn[i] : null;
            titles[i] = (names != null && i < names.length) ? names[i] : null;
        }
        invalidate();
    }

    /** Status text ignored — only waves shown. */
    public void setStatus(String ignored, boolean play) {
        boolean was = playing;
        playing = play;
        if (playing && !was) handler.post(waveAnim);
        if (!playing) handler.removeCallbacks(waveAnim);
        invalidate();
    }

    @Override
    protected void onDraw(Canvas canvas) {
        float w = getWidth();
        float h = getHeight();
        if (w < 4 || h < 4) return;
        ThemeColors th = ThemeColors.ALL[themeIndex];

        paint.setStyle(Paint.Style.FILL);
        paint.setColor(th.bg);
        tmp.set(0, 0, w, h);
        float radius = h * 0.32f;
        canvas.drawRoundRect(tmp, radius, radius, paint);
        paint.setStyle(Paint.Style.STROKE);
        paint.setStrokeWidth(Math.max(2f, h * 0.035f));
        paint.setColor(th.accent);
        canvas.drawRoundRect(tmp, radius, radius, paint);

        float pad = h * 0.10f;
        float tile = h - pad * 2f;
        float gap = tile * 0.18f;
        float x = pad;

        for (int i = 0; i < MAX; i++) {
            drawTile(canvas, th, x, pad, tile, i);
            x += tile + gap;
        }
        x += gap * 0.5f;

        // Stop
        float stopR = tile * 0.48f;
        float stopCx = x + stopR;
        float stopCy = h / 2f;
        paint.setStyle(Paint.Style.FILL);
        paint.setColor(th.tile);
        canvas.drawCircle(stopCx, stopCy, stopR, paint);
        paint.setStyle(Paint.Style.STROKE);
        paint.setStrokeWidth(Math.max(2f, h * 0.04f));
        paint.setColor(th.accent);
        canvas.drawCircle(stopCx, stopCy, stopR, paint);
        paint.setStyle(Paint.Style.FILL);
        paint.setColor(Color.WHITE);
        float sq = stopR * 0.55f;
        canvas.drawRect(stopCx - sq / 2f, stopCy - sq / 2f, stopCx + sq / 2f, stopCy + sq / 2f, paint);

        x = stopCx + stopR + gap * 1.2f;
        float statusRight = w - pad;
        if (statusRight > x + 20) {
            paint.setStyle(Paint.Style.FILL);
            paint.setColor(th.tile);
            tmp.set(x, pad, statusRight, h - pad);
            canvas.drawRoundRect(tmp, h * 0.22f, h * 0.22f, paint);
            paint.setStyle(Paint.Style.STROKE);
            paint.setStrokeWidth(Math.max(1.5f, h * 0.03f));
            paint.setColor(th.accent);
            canvas.drawRoundRect(tmp, h * 0.22f, h * 0.22f, paint);

            // Waves only (no ARRET / LECTURE text)
            int[] cols = {th.accent, th.accent2, 0xFF27DCB3, 0xFF84EF43};
            float mid = h / 2f;
            long t = System.currentTimeMillis();
            float ampBase = playing ? h * 0.22f : h * 0.06f;
            for (int wave = 0; wave < 4; wave++) {
                paint.setStyle(Paint.Style.STROKE);
                paint.setStrokeWidth(wave == 0 ? 2.6f : 1.6f);
                paint.setColor(cols[wave % cols.length]);
                paint.setAlpha(playing ? 220 : 120);
                Path path = new Path();
                boolean first = true;
                float left = x + 10;
                float right = statusRight - 10;
                int steps = 42;
                for (int i = 0; i < steps; i++) {
                    float px = left + i * (right - left) / (steps - 1f);
                    float amp = ampBase * (1f - wave * 0.14f);
                    double phase = i * 0.42 + t / (playing ? 140.0 : 800.0) + wave * 0.7;
                    float py = mid + (float) (Math.sin(phase) * amp);
                    if (first) { path.moveTo(px, py); first = false; }
                    else path.lineTo(px, py);
                }
                canvas.drawPath(path, paint);
            }
            paint.setAlpha(255);
        }
    }

    private void drawTile(Canvas c, ThemeColors th, float left, float top, float size, int i) {
        paint.setStyle(Paint.Style.FILL);
        paint.setColor(Color.rgb(245, 248, 250));
        tmp.set(left, top, left + size, top + size);
        c.drawRoundRect(tmp, size * 0.22f, size * 0.22f, paint);
        Bitmap logo = logos[i];
        if (logo != null && !logo.isRecycled()) {
            float max = Math.max(size * 0.88f / logo.getWidth(), size * 0.88f / logo.getHeight());
            float bw = logo.getWidth() * max;
            float bh = logo.getHeight() * max;
            float bx = left + (size - bw) / 2f;
            float by = top + (size - bh) / 2f;
            Path clip = new Path();
            clip.addRoundRect(tmp, size * 0.22f, size * 0.22f, Path.Direction.CW);
            c.save();
            c.clipPath(clip);
            c.drawBitmap(logo, null, new RectF(bx, by, bx + bw, by + bh), paint);
            c.restore();
        } else if (titles[i] != null && titles[i].length() > 0) {
            paint.setColor(th.tile);
            c.drawRoundRect(tmp, size * 0.22f, size * 0.22f, paint);
            paint.setColor(th.accent);
            paint.setTextSize(size * 0.22f);
            paint.setTextAlign(Paint.Align.CENTER);
            paint.setFakeBoldText(true);
            String shortT = titles[i].length() > 6 ? titles[i].substring(0, 6) : titles[i];
            c.drawText(shortT, left + size / 2f, top + size * 0.58f, paint);
            paint.setFakeBoldText(false);
        } else {
            paint.setColor(th.tile);
            c.drawRoundRect(tmp, size * 0.22f, size * 0.22f, paint);
            paint.setColor(th.accent);
            paint.setTextSize(size * 0.42f);
            paint.setTextAlign(Paint.Align.CENTER);
            paint.setFakeBoldText(true);
            c.drawText(String.valueOf(i + 1), left + size / 2f, top + size * 0.64f, paint);
            paint.setFakeBoldText(false);
        }
        paint.setStyle(Paint.Style.STROKE);
        paint.setStrokeWidth(Math.max(1.5f, size * 0.04f));
        paint.setColor(th.accent);
        c.drawRoundRect(tmp, size * 0.22f, size * 0.22f, paint);
        paint.setStyle(Paint.Style.FILL);
    }

    @Override
    public boolean onTouchEvent(MotionEvent e) {
        switch (e.getActionMasked()) {
            case MotionEvent.ACTION_DOWN:
                downX = lastX = e.getRawX();
                downY = lastY = e.getRawY();
                dragging = false;
                longPressArmed = true;
                handler.postDelayed(longPress, ViewConfiguration.getLongPressTimeout());
                return true;
            case MotionEvent.ACTION_MOVE:
                if (longPressArmed) {
                    if (Math.abs(e.getRawX() - downX) > touchSlop || Math.abs(e.getRawY() - downY) > touchSlop) {
                        longPressArmed = false;
                        handler.removeCallbacks(longPress);
                    }
                }
                if (dragging && listener != null) {
                    listener.onDrag(e.getRawX() - lastX, e.getRawY() - lastY);
                    lastX = e.getRawX();
                    lastY = e.getRawY();
                }
                return true;
            case MotionEvent.ACTION_UP:
            case MotionEvent.ACTION_CANCEL:
                handler.removeCallbacks(longPress);
                if (dragging) {
                    dragging = false;
                    if (listener != null) listener.onDragEnd();
                    return true;
                }
                if (e.getActionMasked() == MotionEvent.ACTION_UP) handleTap(e.getX());
                return true;
        }
        return true;
    }

    private void handleTap(float x) {
        if (listener == null) return;
        float h = getHeight();
        float pad = h * 0.10f;
        float tile = h - pad * 2f;
        float gap = tile * 0.18f;
        float cursor = pad;
        for (int i = 0; i < MAX; i++) {
            if (x >= cursor && x <= cursor + tile) {
                listener.onStation(i);
                return;
            }
            cursor += tile + gap;
        }
        cursor += gap * 0.5f;
        float stopR = tile * 0.48f;
        float stopCx = cursor + stopR;
        if (x >= stopCx - stopR && x <= stopCx + stopR) {
            listener.onStop();
            return;
        }
        listener.onThemeCycle();
    }
}
