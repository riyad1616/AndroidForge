package com.coolray.vradiofavorites;

/** Palettes aligned with OneHub Float themes for visual consistency. */
public final class ThemeColors {
    public final int bg;
    public final int accent;
    public final int accent2;
    public final int text;
    public final int muted;
    public final int tile;

    public ThemeColors(int bg, int accent, int accent2, int text, int muted, int tile) {
        this.bg = bg; this.accent = accent; this.accent2 = accent2;
        this.text = text; this.muted = muted; this.tile = tile;
    }

    public static final ThemeColors[] ALL = {
        new ThemeColors(0xE0101A33, 0xFF00E5FF, 0xFF2F6BFF, 0xFFFFFFFF, 0xFF7FA8D8, 0xFF2A3A66),
        new ThemeColors(0xE02A0D0D, 0xFFFFB020, 0xFFFF2A2A, 0xFFFFFFFF, 0xFFD89080, 0xFF5A1F1F),
        new ThemeColors(0xE00D2416, 0xFFD4FF3A, 0xFF00D26A, 0xFFFFFFFF, 0xFF86C79C, 0xFF1F4A2E),
        new ThemeColors(0xE024123A, 0xFFFF5AD8, 0xFF8B5CFF, 0xFFFFFFFF, 0xFFB09AD8, 0xFF46286E),
        new ThemeColors(0xE0262014, 0xFFFFF1A8, 0xFFD4A017, 0xFFFFF4D6, 0xFFC9B07A, 0xFF6B5525),
        new ThemeColors(0xE0B8C0D0, 0xFF34C3FF, 0xFF2353FF, 0xFF141A2A, 0xFF5D6780, 0xFF90A0B8),
        new ThemeColors(0xE02B2D31, 0xFFFFFFFF, 0xFF9AA3AD, 0xFFFFFFFF, 0xFF9AA0A8, 0xFF55595F),
        new ThemeColors(0xE03A1730, 0xFFFFD23F, 0xFFFF3D7F, 0xFFFFFFFF, 0xFFE09AB8, 0xFF6A2A4A),
    };
}
