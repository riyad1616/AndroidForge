package com.car.videooverlay

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.graphics.PixelFormat
import android.net.Uri
import android.os.Build
import android.os.IBinder
import android.provider.Settings
import android.view.Gravity
import android.view.WindowManager
import android.widget.FrameLayout
import android.widget.VideoView
import androidx.core.app.NotificationCompat

/** Displays a small, fixed, non-touchable video window above other apps. */
class VideoOverlayService : Service() {

    private var windowManager: WindowManager? = null
    private var overlayView: FrameLayout? = null
    private var videoView: VideoView? = null

    override fun onCreate() {
        super.onCreate()
        createNotificationChannel()
        startForeground(NOTIFICATION_ID, buildNotification())
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        val uriText = intent?.getStringExtra(EXTRA_VIDEO_URI)
        if (uriText.isNullOrBlank()) {
            stopSelf()
            return START_NOT_STICKY
        }

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M && !Settings.canDrawOverlays(this)) {
            stopSelf()
            return START_NOT_STICKY
        }

        val uri = try {
            Uri.parse(uriText)
        } catch (_: Exception) {
            stopSelf()
            return START_NOT_STICKY
        }
        val opacity = (intent.getFloatExtra(EXTRA_OPACITY, 1f)).coerceIn(0.1f, 1f)
        val muted = intent.getBooleanExtra(EXTRA_MUTED, true)

        removeOverlay()
        try {
            showOverlay(uri, opacity, muted)
        } catch (_: Exception) {
            removeOverlay()
            stopSelf()
            return START_NOT_STICKY
        }
        return START_NOT_STICKY
    }

    private fun showOverlay(uri: Uri, opacity: Float, muted: Boolean) {
        val wm = getSystemService(Context.WINDOW_SERVICE) as WindowManager
        windowManager = wm

        val container = FrameLayout(this).apply {
            alpha = opacity
            setBackgroundColor(android.graphics.Color.BLACK)
        }
        val player = VideoView(this).apply {
            setVideoURI(uri)
            setOnPreparedListener { mediaPlayer ->
                mediaPlayer.isLooping = true
                mediaPlayer.setVolume(if (muted) 0f else 1f, if (muted) 0f else 1f)
                start()
            }
            setOnErrorListener { _, _, _ -> true }
        }
        container.addView(
            player,
            FrameLayout.LayoutParams(
                FrameLayout.LayoutParams.MATCH_PARENT,
                FrameLayout.LayoutParams.MATCH_PARENT
            )
        )

        val windowType = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
        } else {
            @Suppress("DEPRECATION")
            WindowManager.LayoutParams.TYPE_PHONE
        }
        val params = WindowManager.LayoutParams(
            dp(320),
            dp(180),
            windowType,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE or
                WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.END
            x = dp(16)
            y = dp(48)
        }

        wm.addView(container, params)
        overlayView = container
        videoView = player
    }

    private fun removeOverlay() {
        videoView?.let { player ->
            try { player.stopPlayback() } catch (_: Exception) { }
        }
        videoView = null
        overlayView?.let { view ->
            try { windowManager?.removeView(view) } catch (_: Exception) { }
        }
        overlayView = null
        windowManager = null
    }

    private fun dp(value: Int): Int = (value * resources.displayMetrics.density).toInt()

    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                CHANNEL_ID,
                "Video Overlay playback",
                NotificationManager.IMPORTANCE_LOW
            ).apply { description = "Keeps the floating video service running" }
            getSystemService(NotificationManager::class.java).createNotificationChannel(channel)
        }
    }

    private fun buildNotification(): Notification {
        val openAppIntent = Intent(this, MainActivity::class.java)
        val pendingIntent = PendingIntent.getActivity(
            this,
            0,
            openAppIntent,
            PendingIntent.FLAG_UPDATE_CURRENT or
                (if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) PendingIntent.FLAG_IMMUTABLE else 0)
        )
        return NotificationCompat.Builder(this, CHANNEL_ID)
            .setSmallIcon(android.R.drawable.ic_media_play)
            .setContentTitle("Video Overlay")
            .setContentText("تشغيل الفيديو في نافذة عائمة")
            .setContentIntent(pendingIntent)
            .setOngoing(true)
            .setPriority(NotificationCompat.PRIORITY_LOW)
            .build()
    }

    override fun onDestroy() {
        removeOverlay()
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.N) {
            stopForeground(STOP_FOREGROUND_REMOVE)
        } else {
            @Suppress("DEPRECATION")
            stopForeground(true)
        }
        super.onDestroy()
    }

    override fun onBind(intent: Intent?): IBinder? = null

    companion object {
        const val EXTRA_VIDEO_URI = "video_uri"
        const val EXTRA_OPACITY = "opacity"
        const val EXTRA_MUTED = "muted"
        private const val CHANNEL_ID = "video_overlay_playback"
        private const val NOTIFICATION_ID = 4102
    }
}
