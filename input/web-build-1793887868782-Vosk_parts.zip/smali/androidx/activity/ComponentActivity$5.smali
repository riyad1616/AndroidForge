.class Landroidx/activity/ComponentActivity$5;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Landroidx/lifecycle/i;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Landroidx/activity/ComponentActivity;-><init>()V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x1
    name = null
.end annotation


# instance fields
.field public final synthetic a:Landroidx/activity/ComponentActivity;


# direct methods
.method public constructor <init>(Landroidx/activity/ComponentActivity;)V
    .locals 0

    iput-object p1, p0, Landroidx/activity/ComponentActivity$5;->a:Landroidx/activity/ComponentActivity;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public final f(Landroidx/lifecycle/k;Landroidx/lifecycle/g$b;)V
    .locals 0

    iget-object p1, p0, Landroidx/activity/ComponentActivity$5;->a:Landroidx/activity/ComponentActivity;

    iget-object p2, p1, Landroidx/activity/ComponentActivity;->g:Landroidx/lifecycle/d0;

    if-nez p2, :cond_1

    invoke-virtual {p1}, Landroid/app/Activity;->getLastNonConfigurationInstance()Ljava/lang/Object;

    move-result-object p2

    check-cast p2, Landroidx/activity/ComponentActivity$c;

    if-eqz p2, :cond_0

    iget-object p2, p2, Landroidx/activity/ComponentActivity$c;->a:Landroidx/lifecycle/d0;

    iput-object p2, p1, Landroidx/activity/ComponentActivity;->g:Landroidx/lifecycle/d0;

    :cond_0
    iget-object p2, p1, Landroidx/activity/ComponentActivity;->g:Landroidx/lifecycle/d0;

    if-nez p2, :cond_1

    new-instance p2, Landroidx/lifecycle/d0;

    invoke-direct {p2}, Landroidx/lifecycle/d0;-><init>()V

    iput-object p2, p1, Landroidx/activity/ComponentActivity;->g:Landroidx/lifecycle/d0;

    :cond_1
    iget-object p1, p1, Landroidx/activity/ComponentActivity;->e:Landroidx/lifecycle/l;

    invoke-virtual {p1, p0}, Landroidx/lifecycle/l;->b(Landroidx/lifecycle/j;)V

    return-void
.end method
