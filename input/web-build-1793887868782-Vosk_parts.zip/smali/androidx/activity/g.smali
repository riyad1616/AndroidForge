.class public final synthetic Landroidx/activity/g;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Ljava/lang/Runnable;


# instance fields
.field public final synthetic b:I

.field public final synthetic c:Ljava/lang/Object;


# direct methods
.method public synthetic constructor <init>(ILjava/lang/Object;)V
    .locals 0

    iput p1, p0, Landroidx/activity/g;->b:I

    iput-object p2, p0, Landroidx/activity/g;->c:Ljava/lang/Object;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public final run()V
    .locals 3

    iget v0, p0, Landroidx/activity/g;->b:I

    iget-object p0, p0, Landroidx/activity/g;->c:Ljava/lang/Object;

    packed-switch v0, :pswitch_data_0

    :pswitch_0
    goto :goto_1

    :pswitch_1
    check-cast p0, Lg2/m;

    iget-object v0, p0, Lg2/m;->h:Landroid/widget/AutoCompleteTextView;

    invoke-virtual {v0}, Landroid/widget/AutoCompleteTextView;->isPopupShowing()Z

    move-result v0

    invoke-virtual {p0, v0}, Lg2/m;->t(Z)V

    iput-boolean v0, p0, Lg2/m;->m:Z

    return-void

    :pswitch_2
    check-cast p0, Lcom/google/android/material/sidesheet/SideSheetBehavior$c;

    const/4 v0, 0x0

    iput-boolean v0, p0, Lcom/google/android/material/sidesheet/SideSheetBehavior$c;->b:Z

    iget-object v0, p0, Lcom/google/android/material/sidesheet/SideSheetBehavior$c;->d:Lcom/google/android/material/sidesheet/SideSheetBehavior;

    iget-object v1, v0, Lcom/google/android/material/sidesheet/SideSheetBehavior;->i:Ll0/c;

    if-eqz v1, :cond_0

    invoke-virtual {v1}, Ll0/c;->g()Z

    move-result v1

    if-eqz v1, :cond_0

    iget v0, p0, Lcom/google/android/material/sidesheet/SideSheetBehavior$c;->a:I

    invoke-virtual {p0, v0}, Lcom/google/android/material/sidesheet/SideSheetBehavior$c;->a(I)V

    goto :goto_0

    :cond_0
    iget v1, v0, Lcom/google/android/material/sidesheet/SideSheetBehavior;->h:I

    const/4 v2, 0x2

    if-ne v1, v2, :cond_1

    iget p0, p0, Lcom/google/android/material/sidesheet/SideSheetBehavior$c;->a:I

    invoke-virtual {v0, p0}, Lcom/google/android/material/sidesheet/SideSheetBehavior;->s(I)V

    :cond_1
    :goto_0
    return-void

    :pswitch_3
    check-cast p0, Landroidx/emoji2/text/l$b;

    invoke-virtual {p0}, Landroidx/emoji2/text/l$b;->c()V

    return-void

    :pswitch_4
    check-cast p0, Landroidx/appcompat/widget/f1;

    invoke-virtual {p0}, Landroidx/appcompat/widget/f1;->a()V

    const/4 p0, 0x0

    throw p0

    :pswitch_5
    check-cast p0, Landroidx/appcompat/widget/Toolbar;

    invoke-virtual {p0}, Landroidx/appcompat/widget/Toolbar;->l()V

    return-void

    :pswitch_6
    check-cast p0, Landroidx/activity/h;

    invoke-static {p0}, Landroidx/activity/h;->e(Landroidx/activity/h;)V

    return-void

    :goto_1
    check-cast p0, Lorg/vrecognizer/ListeningOverlayActivity;

    invoke-virtual {p0}, Landroid/app/Activity;->finish()V

    return-void

    nop

    :pswitch_data_0
    .packed-switch 0x0
        :pswitch_6
        :pswitch_5
        :pswitch_4
        :pswitch_0
        :pswitch_3
        :pswitch_0
        :pswitch_2
        :pswitch_1
    .end packed-switch
.end method
