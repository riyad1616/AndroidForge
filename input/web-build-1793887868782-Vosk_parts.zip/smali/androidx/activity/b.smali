.class public final synthetic Landroidx/activity/b;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Ljava/lang/Runnable;


# instance fields
.field public final synthetic b:I

.field public final synthetic c:Ljava/lang/Object;


# direct methods
.method public synthetic constructor <init>(ILjava/lang/Object;)V
    .locals 0

    iput p1, p0, Landroidx/activity/b;->b:I

    iput-object p2, p0, Landroidx/activity/b;->c:Ljava/lang/Object;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public final run()V
    .locals 6

    iget v0, p0, Landroidx/activity/b;->b:I

    const/4 v1, 0x1

    const/4 v2, 0x0

    packed-switch v0, :pswitch_data_0

    :pswitch_0
    goto/16 :goto_2

    :pswitch_1
    iget-object p0, p0, Landroidx/activity/b;->c:Ljava/lang/Object;

    check-cast p0, Lg2/f;

    invoke-virtual {p0, v1}, Lg2/f;->t(Z)V

    return-void

    :pswitch_2
    iget-object p0, p0, Landroidx/activity/b;->c:Ljava/lang/Object;

    check-cast p0, Landroidx/emoji2/text/l$b;

    const-string v0, "fetchFonts result is not OK. ("

    iget-object v3, p0, Landroidx/emoji2/text/l$b;->d:Ljava/lang/Object;

    monitor-enter v3

    :try_start_0
    iget-object v4, p0, Landroidx/emoji2/text/l$b;->h:Landroidx/emoji2/text/f$h;

    if-nez v4, :cond_0

    monitor-exit v3

    goto/16 :goto_1

    :cond_0
    monitor-exit v3
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_6

    :try_start_1
    invoke-virtual {p0}, Landroidx/emoji2/text/l$b;->d()Lb0/m;

    move-result-object v3

    iget v4, v3, Lb0/m;->e:I

    const/4 v5, 0x2

    if-ne v4, v5, :cond_1

    iget-object v5, p0, Landroidx/emoji2/text/l$b;->d:Ljava/lang/Object;

    monitor-enter v5
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_4

    :try_start_2
    monitor-exit v5

    goto :goto_0

    :catchall_0
    move-exception v0

    monitor-exit v5
    :try_end_2
    .catchall {:try_start_2 .. :try_end_2} :catchall_0

    :try_start_3
    throw v0
    :try_end_3
    .catchall {:try_start_3 .. :try_end_3} :catchall_4

    :cond_1
    :goto_0
    if-nez v4, :cond_4

    :try_start_4
    const-string v0, "EmojiCompat.FontRequestEmojiCompatConfig.buildTypeface"

    invoke-static {v0}, La0/d;->a(Ljava/lang/String;)V

    iget-object v0, p0, Landroidx/emoji2/text/l$b;->c:Landroidx/emoji2/text/l$a;

    iget-object v4, p0, Landroidx/emoji2/text/l$b;->a:Landroid/content/Context;

    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    new-array v0, v1, [Lb0/m;

    aput-object v3, v0, v2

    invoke-static {v4, v0, v2}, Lx/e;->a(Landroid/content/Context;[Lb0/m;I)Landroid/graphics/Typeface;

    move-result-object v0

    iget-object v1, p0, Landroidx/emoji2/text/l$b;->a:Landroid/content/Context;

    iget-object v2, v3, Lb0/m;->a:Landroid/net/Uri;

    invoke-static {v1, v2}, Lx/h;->a(Landroid/content/Context;Landroid/net/Uri;)Ljava/nio/MappedByteBuffer;

    move-result-object v1
    :try_end_4
    .catchall {:try_start_4 .. :try_end_4} :catchall_3

    if-eqz v1, :cond_3

    if-eqz v0, :cond_3

    :try_start_5
    const-string v2, "EmojiCompat.MetadataRepo.create"

    invoke-static {v2}, La0/d;->a(Ljava/lang/String;)V

    new-instance v2, Landroidx/emoji2/text/n;

    invoke-static {v1}, Landroidx/emoji2/text/m;->a(Ljava/nio/MappedByteBuffer;)Lm0/b;

    move-result-object v1

    invoke-direct {v2, v0, v1}, Landroidx/emoji2/text/n;-><init>(Landroid/graphics/Typeface;Lm0/b;)V
    :try_end_5
    .catchall {:try_start_5 .. :try_end_5} :catchall_2

    :try_start_6
    invoke-static {}, La0/d;->b()V
    :try_end_6
    .catchall {:try_start_6 .. :try_end_6} :catchall_3

    :try_start_7
    invoke-static {}, La0/d;->b()V

    iget-object v0, p0, Landroidx/emoji2/text/l$b;->d:Ljava/lang/Object;

    monitor-enter v0
    :try_end_7
    .catchall {:try_start_7 .. :try_end_7} :catchall_4

    :try_start_8
    iget-object v1, p0, Landroidx/emoji2/text/l$b;->h:Landroidx/emoji2/text/f$h;

    if-eqz v1, :cond_2

    invoke-virtual {v1, v2}, Landroidx/emoji2/text/f$h;->b(Landroidx/emoji2/text/n;)V

    :cond_2
    monitor-exit v0
    :try_end_8
    .catchall {:try_start_8 .. :try_end_8} :catchall_1

    :try_start_9
    invoke-virtual {p0}, Landroidx/emoji2/text/l$b;->b()V
    :try_end_9
    .catchall {:try_start_9 .. :try_end_9} :catchall_4

    goto :goto_1

    :catchall_1
    move-exception v1

    :try_start_a
    monitor-exit v0
    :try_end_a
    .catchall {:try_start_a .. :try_end_a} :catchall_1

    :try_start_b
    throw v1
    :try_end_b
    .catchall {:try_start_b .. :try_end_b} :catchall_4

    :catchall_2
    move-exception v0

    :try_start_c
    invoke-static {}, La0/d;->b()V

    throw v0

    :cond_3
    new-instance v0, Ljava/lang/RuntimeException;

    const-string v1, "Unable to open file."

    invoke-direct {v0, v1}, Ljava/lang/RuntimeException;-><init>(Ljava/lang/String;)V

    throw v0
    :try_end_c
    .catchall {:try_start_c .. :try_end_c} :catchall_3

    :catchall_3
    move-exception v0

    :try_start_d
    invoke-static {}, La0/d;->b()V

    throw v0

    :cond_4
    new-instance v1, Ljava/lang/RuntimeException;

    new-instance v2, Ljava/lang/StringBuilder;

    invoke-direct {v2, v0}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-virtual {v2, v4}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const-string v0, ")"

    invoke-virtual {v2, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    invoke-direct {v1, v0}, Ljava/lang/RuntimeException;-><init>(Ljava/lang/String;)V

    throw v1
    :try_end_d
    .catchall {:try_start_d .. :try_end_d} :catchall_4

    :catchall_4
    move-exception v0

    iget-object v1, p0, Landroidx/emoji2/text/l$b;->d:Ljava/lang/Object;

    monitor-enter v1

    :try_start_e
    iget-object v2, p0, Landroidx/emoji2/text/l$b;->h:Landroidx/emoji2/text/f$h;

    if-eqz v2, :cond_5

    invoke-virtual {v2, v0}, Landroidx/emoji2/text/f$h;->a(Ljava/lang/Throwable;)V

    :cond_5
    monitor-exit v1
    :try_end_e
    .catchall {:try_start_e .. :try_end_e} :catchall_5

    invoke-virtual {p0}, Landroidx/emoji2/text/l$b;->b()V

    :goto_1
    return-void

    :catchall_5
    move-exception p0

    :try_start_f
    monitor-exit v1
    :try_end_f
    .catchall {:try_start_f .. :try_end_f} :catchall_5

    throw p0

    :catchall_6
    move-exception p0

    :try_start_10
    monitor-exit v3
    :try_end_10
    .catchall {:try_start_10 .. :try_end_10} :catchall_6

    throw p0

    :pswitch_3
    iget-object p0, p0, Landroidx/activity/b;->c:Ljava/lang/Object;

    check-cast p0, Landroidx/appcompat/widget/f1;

    invoke-virtual {p0, v2}, Landroidx/appcompat/widget/f1;->b(Z)V

    return-void

    :pswitch_4
    iget-object p0, p0, Landroidx/activity/b;->c:Ljava/lang/Object;

    check-cast p0, Landroidx/activity/ComponentActivity;

    invoke-virtual {p0}, Landroid/app/Activity;->invalidateOptionsMenu()V

    return-void

    :goto_2
    iget-object p0, p0, Landroidx/activity/b;->c:Ljava/lang/Object;

    check-cast p0, Lorg/vrecognizer/VoskActivity$b;

    iget-object p0, p0, Lorg/vrecognizer/VoskActivity$b;->a:Lorg/vrecognizer/VoskActivity;

    invoke-virtual {p0}, Lorg/vrecognizer/VoskActivity;->b()V

    return-void

    :pswitch_data_0
    .packed-switch 0x0
        :pswitch_4
        :pswitch_3
        :pswitch_2
        :pswitch_0
        :pswitch_1
    .end packed-switch
.end method
