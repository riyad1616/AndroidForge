.class public interface abstract Landroidx/activity/j;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Landroidx/lifecycle/k;


# virtual methods
.method public abstract a()Landroidx/activity/OnBackPressedDispatcher;
.end method
