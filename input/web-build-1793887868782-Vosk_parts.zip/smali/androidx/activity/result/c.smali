.class public abstract Landroidx/activity/result/c;
.super Ljava/lang/Object;
.source "SourceFile"


# static fields
.field public static volatile b:Ls2/a$a;

.field public static final c:Lv2/o;

.field public static final d:Lv2/o;

.field public static final e:Lv2/o;


# direct methods
.method static synthetic constructor <clinit>()V
    .locals 2

    new-instance v0, Lv2/o;

    const-string v1, "image-destination"

    invoke-direct {v0, v1}, Lv2/o;-><init>(Ljava/lang/String;)V

    sput-object v0, Landroidx/activity/result/c;->c:Lv2/o;

    new-instance v0, Lv2/o;

    const-string v1, "image-replacement-text-is-link"

    invoke-direct {v0, v1}, Lv2/o;-><init>(Ljava/lang/String;)V

    sput-object v0, Landroidx/activity/result/c;->d:Lv2/o;

    new-instance v0, Lv2/o;

    const-string v1, "image-size"

    invoke-direct {v0, v1}, Lv2/o;-><init>(Ljava/lang/String;)V

    sput-object v0, Landroidx/activity/result/c;->e:Lv2/o;

    return-void
.end method

.method public synthetic constructor <init>()V
    .locals 0

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public abstract e(FFFF)Landroid/graphics/Path;
.end method

.method public abstract f(I)Landroid/view/View;
.end method

.method public abstract g(Ll1/a;Landroid/view/View;)Lcom/google/android/material/carousel/a;
.end method

.method public abstract j(I)V
.end method

.method public abstract l(Landroid/graphics/Typeface;Z)V
.end method

.method public abstract m()Z
.end method
