.class public final Landroidx/activity/result/e;
.super Landroidx/activity/result/c;
.source "SourceFile"


# annotations
.annotation system Ldalvik/annotation/Signature;
    value = {
        "Landroidx/activity/result/c;"
    }
.end annotation


# instance fields
.field public final synthetic f:Ljava/lang/String;

.field public final synthetic g:Lb/a;

.field public final synthetic h:Landroidx/activity/result/f;


# direct methods
.method public constructor <init>(Landroidx/activity/result/f;Ljava/lang/String;Lb/a;)V
    .locals 0

    iput-object p1, p0, Landroidx/activity/result/e;->h:Landroidx/activity/result/f;

    iput-object p2, p0, Landroidx/activity/result/e;->f:Ljava/lang/String;

    iput-object p3, p0, Landroidx/activity/result/e;->g:Lb/a;

    invoke-direct {p0}, Landroidx/activity/result/c;-><init>()V

    return-void
.end method
