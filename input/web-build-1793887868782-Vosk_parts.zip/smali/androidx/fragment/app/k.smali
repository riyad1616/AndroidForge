.class public final Landroidx/fragment/app/k;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Ljava/lang/Runnable;


# instance fields
.field public final synthetic b:Landroidx/fragment/app/l$c;


# direct methods
.method public constructor <init>(Landroidx/fragment/app/l$c;)V
    .locals 0

    iput-object p1, p0, Landroidx/fragment/app/k;->b:Landroidx/fragment/app/l$c;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public final run()V
    .locals 0

    iget-object p0, p0, Landroidx/fragment/app/k;->b:Landroidx/fragment/app/l$c;

    invoke-virtual {p0}, Landroidx/fragment/app/l$b;->a()V

    return-void
.end method
