.class public final Landroidx/fragment/app/h;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Ljava/lang/Runnable;


# instance fields
.field public final synthetic b:Landroidx/fragment/app/q0$b;

.field public final synthetic c:Landroidx/fragment/app/q0$b;

.field public final synthetic d:Z


# direct methods
.method public constructor <init>(Landroidx/fragment/app/q0$b;Landroidx/fragment/app/q0$b;ZLl/b;)V
    .locals 0

    iput-object p1, p0, Landroidx/fragment/app/h;->b:Landroidx/fragment/app/q0$b;

    iput-object p2, p0, Landroidx/fragment/app/h;->c:Landroidx/fragment/app/q0$b;

    iput-boolean p3, p0, Landroidx/fragment/app/h;->d:Z

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public final run()V
    .locals 2

    iget-object v0, p0, Landroidx/fragment/app/h;->b:Landroidx/fragment/app/q0$b;

    iget-object v0, v0, Landroidx/fragment/app/q0$b;->c:Landroidx/fragment/app/n;

    iget-object v1, p0, Landroidx/fragment/app/h;->c:Landroidx/fragment/app/q0$b;

    iget-object v1, v1, Landroidx/fragment/app/q0$b;->c:Landroidx/fragment/app/n;

    iget-boolean p0, p0, Landroidx/fragment/app/h;->d:Z

    invoke-static {v0, v1, p0}, Landroidx/fragment/app/g0;->a(Landroidx/fragment/app/n;Landroidx/fragment/app/n;Z)V

    return-void
.end method
