.class public final Landroidx/fragment/app/i;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Ljava/lang/Runnable;


# instance fields
.field public final synthetic b:Landroidx/fragment/app/l0;

.field public final synthetic c:Landroid/view/View;

.field public final synthetic d:Landroid/graphics/Rect;


# direct methods
.method public constructor <init>(Landroidx/fragment/app/l0;Landroid/view/View;Landroid/graphics/Rect;)V
    .locals 0

    iput-object p1, p0, Landroidx/fragment/app/i;->b:Landroidx/fragment/app/l0;

    iput-object p2, p0, Landroidx/fragment/app/i;->c:Landroid/view/View;

    iput-object p3, p0, Landroidx/fragment/app/i;->d:Landroid/graphics/Rect;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public final run()V
    .locals 1

    iget-object v0, p0, Landroidx/fragment/app/i;->b:Landroidx/fragment/app/l0;

    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    iget-object v0, p0, Landroidx/fragment/app/i;->c:Landroid/view/View;

    iget-object p0, p0, Landroidx/fragment/app/i;->d:Landroid/graphics/Rect;

    invoke-static {v0, p0}, Landroidx/fragment/app/l0;->g(Landroid/view/View;Landroid/graphics/Rect;)V

    return-void
.end method
