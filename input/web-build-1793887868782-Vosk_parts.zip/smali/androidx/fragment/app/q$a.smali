.class public final Landroidx/fragment/app/q$a;
.super Landroidx/fragment/app/u;
.source "SourceFile"

# interfaces
.implements Landroidx/lifecycle/e0;
.implements Landroidx/activity/j;
.implements Landroidx/activity/result/g;
.implements Landroidx/fragment/app/b0;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Landroidx/fragment/app/q;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x1
    name = "a"
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "Landroidx/fragment/app/u<",
        "Landroidx/fragment/app/q;",
        ">;",
        "Landroidx/lifecycle/e0;",
        "Landroidx/activity/j;",
        "Landroidx/activity/result/g;",
        "Landroidx/fragment/app/b0;"
    }
.end annotation


# instance fields
.field public final synthetic j:Landroidx/fragment/app/q;


# direct methods
.method public constructor <init>(Landroidx/fragment/app/q;)V
    .locals 0

    iput-object p1, p0, Landroidx/fragment/app/q$a;->j:Landroidx/fragment/app/q;

    invoke-direct {p0, p1}, Landroidx/fragment/app/u;-><init>(Landroidx/fragment/app/q;)V

    return-void
.end method


# virtual methods
.method public final a()Landroidx/activity/OnBackPressedDispatcher;
    .locals 0

    iget-object p0, p0, Landroidx/fragment/app/q$a;->j:Landroidx/fragment/app/q;

    iget-object p0, p0, Landroidx/activity/ComponentActivity;->h:Landroidx/activity/OnBackPressedDispatcher;

    return-object p0
.end method

.method public final c()V
    .locals 0

    iget-object p0, p0, Landroidx/fragment/app/q$a;->j:Landroidx/fragment/app/q;

    invoke-virtual {p0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    return-void
.end method

.method public final f(I)Landroid/view/View;
    .locals 0

    iget-object p0, p0, Landroidx/fragment/app/q$a;->j:Landroidx/fragment/app/q;

    invoke-virtual {p0, p1}, Landroid/app/Activity;->findViewById(I)Landroid/view/View;

    move-result-object p0

    return-object p0
.end method

.method public final h()Landroidx/activity/result/f;
    .locals 0

    iget-object p0, p0, Landroidx/fragment/app/q$a;->j:Landroidx/fragment/app/q;

    iget-object p0, p0, Landroidx/activity/ComponentActivity;->i:Landroidx/activity/ComponentActivity$b;

    return-object p0
.end method

.method public final i()Landroidx/lifecycle/d0;
    .locals 0

    iget-object p0, p0, Landroidx/fragment/app/q$a;->j:Landroidx/fragment/app/q;

    invoke-virtual {p0}, Landroidx/activity/ComponentActivity;->i()Landroidx/lifecycle/d0;

    move-result-object p0

    return-object p0
.end method

.method public final k()Landroidx/lifecycle/l;
    .locals 0

    iget-object p0, p0, Landroidx/fragment/app/q$a;->j:Landroidx/fragment/app/q;

    iget-object p0, p0, Landroidx/fragment/app/q;->p:Landroidx/lifecycle/l;

    return-object p0
.end method

.method public final m()Z
    .locals 0

    iget-object p0, p0, Landroidx/fragment/app/q$a;->j:Landroidx/fragment/app/q;

    invoke-virtual {p0}, Landroid/app/Activity;->getWindow()Landroid/view/Window;

    move-result-object p0

    if-eqz p0, :cond_0

    invoke-virtual {p0}, Landroid/view/Window;->peekDecorView()Landroid/view/View;

    move-result-object p0

    if-eqz p0, :cond_0

    const/4 p0, 0x1

    goto :goto_0

    :cond_0
    const/4 p0, 0x0

    :goto_0
    return p0
.end method

.method public final n(Ljava/io/PrintWriter;[Ljava/lang/String;)V
    .locals 2

    const/4 v0, 0x0

    iget-object p0, p0, Landroidx/fragment/app/q$a;->j:Landroidx/fragment/app/q;

    const-string v1, "  "

    invoke-virtual {p0, v1, v0, p1, p2}, Landroidx/fragment/app/q;->dump(Ljava/lang/String;Ljava/io/FileDescriptor;Ljava/io/PrintWriter;[Ljava/lang/String;)V

    return-void
.end method

.method public final o()Landroidx/fragment/app/q;
    .locals 0

    iget-object p0, p0, Landroidx/fragment/app/q$a;->j:Landroidx/fragment/app/q;

    return-object p0
.end method

.method public final p()Landroid/view/LayoutInflater;
    .locals 1

    iget-object p0, p0, Landroidx/fragment/app/q$a;->j:Landroidx/fragment/app/q;

    invoke-virtual {p0}, Landroid/app/Activity;->getLayoutInflater()Landroid/view/LayoutInflater;

    move-result-object v0

    invoke-virtual {v0, p0}, Landroid/view/LayoutInflater;->cloneInContext(Landroid/content/Context;)Landroid/view/LayoutInflater;

    move-result-object p0

    return-object p0
.end method

.method public final q()V
    .locals 0

    iget-object p0, p0, Landroidx/fragment/app/q$a;->j:Landroidx/fragment/app/q;

    invoke-virtual {p0}, Landroidx/fragment/app/q;->q()V

    return-void
.end method
