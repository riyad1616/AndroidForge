.class public Landroidx/fragment/app/q;
.super Landroidx/activity/ComponentActivity;
.source "SourceFile"

# interfaces
.implements Lu/a$c;


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Landroidx/fragment/app/q$a;
    }
.end annotation


# instance fields
.field public final o:Landroidx/fragment/app/s;

.field public final p:Landroidx/lifecycle/l;

.field public q:Z

.field public r:Z

.field public s:Z


# direct methods
.method public constructor <init>()V
    .locals 3

    invoke-direct {p0}, Landroidx/activity/ComponentActivity;-><init>()V

    new-instance v0, Landroidx/fragment/app/q$a;

    invoke-direct {v0, p0}, Landroidx/fragment/app/q$a;-><init>(Landroidx/fragment/app/q;)V

    new-instance v1, Landroidx/fragment/app/s;

    invoke-direct {v1, v0}, Landroidx/fragment/app/s;-><init>(Landroidx/fragment/app/q$a;)V

    iput-object v1, p0, Landroidx/fragment/app/q;->o:Landroidx/fragment/app/s;

    new-instance v0, Landroidx/lifecycle/l;

    invoke-direct {v0, p0}, Landroidx/lifecycle/l;-><init>(Landroidx/lifecycle/k;)V

    iput-object v0, p0, Landroidx/fragment/app/q;->p:Landroidx/lifecycle/l;

    const/4 v0, 0x1

    iput-boolean v0, p0, Landroidx/fragment/app/q;->s:Z

    iget-object v0, p0, Landroidx/activity/ComponentActivity;->f:Lt0/c;

    iget-object v0, v0, Lt0/c;->b:Lt0/b;

    new-instance v1, Landroidx/fragment/app/o;

    invoke-direct {v1, p0}, Landroidx/fragment/app/o;-><init>(Landroidx/fragment/app/q;)V

    const-string v2, "android:support:fragments"

    invoke-virtual {v0, v2, v1}, Lt0/b;->b(Ljava/lang/String;Lt0/b$b;)V

    new-instance v0, Landroidx/fragment/app/p;

    invoke-direct {v0, p0}, Landroidx/fragment/app/p;-><init>(Landroidx/fragment/app/q;)V

    invoke-virtual {p0, v0}, Landroidx/activity/ComponentActivity;->n(La/b;)V

    return-void
.end method

.method public static p(Landroidx/fragment/app/x;)Z
    .locals 7

    iget-object p0, p0, Landroidx/fragment/app/x;->c:Landroidx/fragment/app/e0;

    invoke-virtual {p0}, Landroidx/fragment/app/e0;->h()Ljava/util/List;

    move-result-object p0

    invoke-interface {p0}, Ljava/util/Collection;->iterator()Ljava/util/Iterator;

    move-result-object p0

    const/4 v0, 0x0

    :cond_0
    :goto_0
    invoke-interface {p0}, Ljava/util/Iterator;->hasNext()Z

    move-result v1

    if-eqz v1, :cond_5

    invoke-interface {p0}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Landroidx/fragment/app/n;

    if-nez v1, :cond_1

    goto :goto_0

    :cond_1
    iget-object v2, v1, Landroidx/fragment/app/n;->t:Landroidx/fragment/app/u;

    if-nez v2, :cond_2

    const/4 v2, 0x0

    goto :goto_1

    :cond_2
    invoke-virtual {v2}, Landroidx/fragment/app/u;->o()Landroidx/fragment/app/q;

    move-result-object v2

    :goto_1
    if-eqz v2, :cond_3

    invoke-virtual {v1}, Landroidx/fragment/app/n;->j()Landroidx/fragment/app/x;

    move-result-object v2

    invoke-static {v2}, Landroidx/fragment/app/q;->p(Landroidx/fragment/app/x;)Z

    move-result v2

    or-int/2addr v0, v2

    :cond_3
    iget-object v2, v1, Landroidx/fragment/app/n;->N:Landroidx/fragment/app/m0;

    sget-object v3, Landroidx/lifecycle/g$c;->e:Landroidx/lifecycle/g$c;

    const-string v4, "setCurrentState"

    sget-object v5, Landroidx/lifecycle/g$c;->d:Landroidx/lifecycle/g$c;

    const/4 v6, 0x1

    if-eqz v2, :cond_4

    invoke-virtual {v2}, Landroidx/fragment/app/m0;->e()V

    iget-object v2, v2, Landroidx/fragment/app/m0;->c:Landroidx/lifecycle/l;

    iget-object v2, v2, Landroidx/lifecycle/l;->b:Landroidx/lifecycle/g$c;

    invoke-virtual {v2, v3}, Landroidx/lifecycle/g$c;->a(Landroidx/lifecycle/g$c;)Z

    move-result v2

    if-eqz v2, :cond_4

    iget-object v0, v1, Landroidx/fragment/app/n;->N:Landroidx/fragment/app/m0;

    iget-object v0, v0, Landroidx/fragment/app/m0;->c:Landroidx/lifecycle/l;

    invoke-virtual {v0, v4}, Landroidx/lifecycle/l;->d(Ljava/lang/String;)V

    invoke-virtual {v0, v5}, Landroidx/lifecycle/l;->f(Landroidx/lifecycle/g$c;)V

    move v0, v6

    :cond_4
    iget-object v2, v1, Landroidx/fragment/app/n;->M:Landroidx/lifecycle/l;

    iget-object v2, v2, Landroidx/lifecycle/l;->b:Landroidx/lifecycle/g$c;

    invoke-virtual {v2, v3}, Landroidx/lifecycle/g$c;->a(Landroidx/lifecycle/g$c;)Z

    move-result v2

    if-eqz v2, :cond_0

    iget-object v0, v1, Landroidx/fragment/app/n;->M:Landroidx/lifecycle/l;

    invoke-virtual {v0, v4}, Landroidx/lifecycle/l;->d(Ljava/lang/String;)V

    invoke-virtual {v0, v5}, Landroidx/lifecycle/l;->f(Landroidx/lifecycle/g$c;)V

    move v0, v6

    goto :goto_0

    :cond_5
    return v0
.end method


# virtual methods
.method public final dump(Ljava/lang/String;Ljava/io/FileDescriptor;Ljava/io/PrintWriter;[Ljava/lang/String;)V
    .locals 3

    invoke-super {p0, p1, p2, p3, p4}, Landroid/app/Activity;->dump(Ljava/lang/String;Ljava/io/FileDescriptor;Ljava/io/PrintWriter;[Ljava/lang/String;)V

    invoke-virtual {p3, p1}, Ljava/io/PrintWriter;->print(Ljava/lang/String;)V

    const-string v0, "Local FragmentActivity "

    invoke-virtual {p3, v0}, Ljava/io/PrintWriter;->print(Ljava/lang/String;)V

    invoke-static {p0}, Ljava/lang/System;->identityHashCode(Ljava/lang/Object;)I

    move-result v0

    invoke-static {v0}, Ljava/lang/Integer;->toHexString(I)Ljava/lang/String;

    move-result-object v0

    invoke-virtual {p3, v0}, Ljava/io/PrintWriter;->print(Ljava/lang/String;)V

    const-string v0, " State:"

    invoke-virtual {p3, v0}, Ljava/io/PrintWriter;->println(Ljava/lang/String;)V

    new-instance v0, Ljava/lang/StringBuilder;

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v0, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string v1, "  "

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    invoke-virtual {p3, v0}, Ljava/io/PrintWriter;->print(Ljava/lang/String;)V

    const-string v1, "mCreated="

    invoke-virtual {p3, v1}, Ljava/io/PrintWriter;->print(Ljava/lang/String;)V

    iget-boolean v1, p0, Landroidx/fragment/app/q;->q:Z

    invoke-virtual {p3, v1}, Ljava/io/PrintWriter;->print(Z)V

    const-string v1, " mResumed="

    invoke-virtual {p3, v1}, Ljava/io/PrintWriter;->print(Ljava/lang/String;)V

    iget-boolean v1, p0, Landroidx/fragment/app/q;->r:Z

    invoke-virtual {p3, v1}, Ljava/io/PrintWriter;->print(Z)V

    const-string v1, " mStopped="

    invoke-virtual {p3, v1}, Ljava/io/PrintWriter;->print(Ljava/lang/String;)V

    iget-boolean v1, p0, Landroidx/fragment/app/q;->s:Z

    invoke-virtual {p3, v1}, Ljava/io/PrintWriter;->print(Z)V

    invoke-virtual {p0}, Landroid/app/Activity;->getApplication()Landroid/app/Application;

    move-result-object v1

    if-eqz v1, :cond_0

    new-instance v1, Lr0/a;

    invoke-interface {p0}, Landroidx/lifecycle/e0;->i()Landroidx/lifecycle/d0;

    move-result-object v2

    invoke-direct {v1, p0, v2}, Lr0/a;-><init>(Landroidx/lifecycle/k;Landroidx/lifecycle/d0;)V

    invoke-virtual {v1, v0, p3}, Lr0/a;->n(Ljava/lang/String;Ljava/io/PrintWriter;)V

    :cond_0
    iget-object p0, p0, Landroidx/fragment/app/q;->o:Landroidx/fragment/app/s;

    iget-object p0, p0, Landroidx/fragment/app/s;->a:Landroidx/fragment/app/u;

    iget-object p0, p0, Landroidx/fragment/app/u;->i:Landroidx/fragment/app/y;

    invoke-virtual {p0, p1, p2, p3, p4}, Landroidx/fragment/app/x;->u(Ljava/lang/String;Ljava/io/FileDescriptor;Ljava/io/PrintWriter;[Ljava/lang/String;)V

    return-void
.end method

.method public final e()V
    .locals 0
    .annotation runtime Ljava/lang/Deprecated;
    .end annotation

    return-void
.end method

.method public onActivityResult(IILandroid/content/Intent;)V
    .locals 1

    iget-object v0, p0, Landroidx/fragment/app/q;->o:Landroidx/fragment/app/s;

    invoke-virtual {v0}, Landroidx/fragment/app/s;->a()V

    invoke-super {p0, p1, p2, p3}, Landroidx/activity/ComponentActivity;->onActivityResult(IILandroid/content/Intent;)V

    return-void
.end method

.method public onConfigurationChanged(Landroid/content/res/Configuration;)V
    .locals 1

    iget-object v0, p0, Landroidx/fragment/app/q;->o:Landroidx/fragment/app/s;

    invoke-virtual {v0}, Landroidx/fragment/app/s;->a()V

    invoke-super {p0, p1}, Landroidx/activity/ComponentActivity;->onConfigurationChanged(Landroid/content/res/Configuration;)V

    iget-object p0, v0, Landroidx/fragment/app/s;->a:Landroidx/fragment/app/u;

    iget-object p0, p0, Landroidx/fragment/app/u;->i:Landroidx/fragment/app/y;

    invoke-virtual {p0, p1}, Landroidx/fragment/app/x;->i(Landroid/content/res/Configuration;)V

    return-void
.end method

.method public onCreate(Landroid/os/Bundle;)V
    .locals 1

    invoke-super {p0, p1}, Landroidx/activity/ComponentActivity;->onCreate(Landroid/os/Bundle;)V

    iget-object p1, p0, Landroidx/fragment/app/q;->p:Landroidx/lifecycle/l;

    sget-object v0, Landroidx/lifecycle/g$b;->ON_CREATE:Landroidx/lifecycle/g$b;

    invoke-virtual {p1, v0}, Landroidx/lifecycle/l;->e(Landroidx/lifecycle/g$b;)V

    iget-object p0, p0, Landroidx/fragment/app/q;->o:Landroidx/fragment/app/s;

    iget-object p0, p0, Landroidx/fragment/app/s;->a:Landroidx/fragment/app/u;

    iget-object p0, p0, Landroidx/fragment/app/u;->i:Landroidx/fragment/app/y;

    const/4 p1, 0x0

    iput-boolean p1, p0, Landroidx/fragment/app/x;->y:Z

    iput-boolean p1, p0, Landroidx/fragment/app/x;->z:Z

    iget-object v0, p0, Landroidx/fragment/app/x;->F:Landroidx/fragment/app/a0;

    iput-boolean p1, v0, Landroidx/fragment/app/a0;->h:Z

    const/4 p1, 0x1

    invoke-virtual {p0, p1}, Landroidx/fragment/app/x;->t(I)V

    return-void
.end method

.method public final onCreatePanelMenu(ILandroid/view/Menu;)Z
    .locals 0

    if-nez p1, :cond_0

    invoke-super {p0, p1, p2}, Landroid/app/Activity;->onCreatePanelMenu(ILandroid/view/Menu;)Z

    move-result p1

    invoke-virtual {p0}, Landroid/app/Activity;->getMenuInflater()Landroid/view/MenuInflater;

    iget-object p0, p0, Landroidx/fragment/app/q;->o:Landroidx/fragment/app/s;

    iget-object p0, p0, Landroidx/fragment/app/s;->a:Landroidx/fragment/app/u;

    iget-object p0, p0, Landroidx/fragment/app/u;->i:Landroidx/fragment/app/y;

    invoke-virtual {p0}, Landroidx/fragment/app/x;->k()Z

    move-result p0

    or-int/2addr p0, p1

    return p0

    :cond_0
    invoke-super {p0, p1, p2}, Landroid/app/Activity;->onCreatePanelMenu(ILandroid/view/Menu;)Z

    move-result p0

    return p0
.end method

.method public final onCreateView(Landroid/view/View;Ljava/lang/String;Landroid/content/Context;Landroid/util/AttributeSet;)Landroid/view/View;
    .locals 1

    .line 1
    iget-object v0, p0, Landroidx/fragment/app/q;->o:Landroidx/fragment/app/s;

    iget-object v0, v0, Landroidx/fragment/app/s;->a:Landroidx/fragment/app/u;

    .line 2
    iget-object v0, v0, Landroidx/fragment/app/u;->i:Landroidx/fragment/app/y;

    .line 3
    iget-object v0, v0, Landroidx/fragment/app/x;->f:Landroidx/fragment/app/v;

    .line 4
    invoke-virtual {v0, p1, p2, p3, p4}, Landroidx/fragment/app/v;->onCreateView(Landroid/view/View;Ljava/lang/String;Landroid/content/Context;Landroid/util/AttributeSet;)Landroid/view/View;

    move-result-object v0

    if-nez v0, :cond_0

    .line 5
    invoke-super {p0, p1, p2, p3, p4}, Landroid/app/Activity;->onCreateView(Landroid/view/View;Ljava/lang/String;Landroid/content/Context;Landroid/util/AttributeSet;)Landroid/view/View;

    move-result-object p0

    return-object p0

    :cond_0
    return-object v0
.end method

.method public final onCreateView(Ljava/lang/String;Landroid/content/Context;Landroid/util/AttributeSet;)Landroid/view/View;
    .locals 2

    .line 6
    iget-object v0, p0, Landroidx/fragment/app/q;->o:Landroidx/fragment/app/s;

    iget-object v0, v0, Landroidx/fragment/app/s;->a:Landroidx/fragment/app/u;

    .line 7
    iget-object v0, v0, Landroidx/fragment/app/u;->i:Landroidx/fragment/app/y;

    .line 8
    iget-object v0, v0, Landroidx/fragment/app/x;->f:Landroidx/fragment/app/v;

    const/4 v1, 0x0

    .line 9
    invoke-virtual {v0, v1, p1, p2, p3}, Landroidx/fragment/app/v;->onCreateView(Landroid/view/View;Ljava/lang/String;Landroid/content/Context;Landroid/util/AttributeSet;)Landroid/view/View;

    move-result-object v0

    if-nez v0, :cond_0

    .line 10
    invoke-super {p0, p1, p2, p3}, Landroid/app/Activity;->onCreateView(Ljava/lang/String;Landroid/content/Context;Landroid/util/AttributeSet;)Landroid/view/View;

    move-result-object p0

    return-object p0

    :cond_0
    return-object v0
.end method

.method public onDestroy()V
    .locals 1

    invoke-super {p0}, Landroid/app/Activity;->onDestroy()V

    iget-object v0, p0, Landroidx/fragment/app/q;->o:Landroidx/fragment/app/s;

    iget-object v0, v0, Landroidx/fragment/app/s;->a:Landroidx/fragment/app/u;

    iget-object v0, v0, Landroidx/fragment/app/u;->i:Landroidx/fragment/app/y;

    invoke-virtual {v0}, Landroidx/fragment/app/x;->l()V

    iget-object p0, p0, Landroidx/fragment/app/q;->p:Landroidx/lifecycle/l;

    sget-object v0, Landroidx/lifecycle/g$b;->ON_DESTROY:Landroidx/lifecycle/g$b;

    invoke-virtual {p0, v0}, Landroidx/lifecycle/l;->e(Landroidx/lifecycle/g$b;)V

    return-void
.end method

.method public final onLowMemory()V
    .locals 0

    invoke-super {p0}, Landroid/app/Activity;->onLowMemory()V

    iget-object p0, p0, Landroidx/fragment/app/q;->o:Landroidx/fragment/app/s;

    iget-object p0, p0, Landroidx/fragment/app/s;->a:Landroidx/fragment/app/u;

    iget-object p0, p0, Landroidx/fragment/app/u;->i:Landroidx/fragment/app/y;

    invoke-virtual {p0}, Landroidx/fragment/app/x;->m()V

    return-void
.end method

.method public onMenuItemSelected(ILandroid/view/MenuItem;)Z
    .locals 0

    invoke-super {p0, p1, p2}, Landroid/app/Activity;->onMenuItemSelected(ILandroid/view/MenuItem;)Z

    move-result p2

    if-eqz p2, :cond_0

    const/4 p0, 0x1

    return p0

    :cond_0
    iget-object p0, p0, Landroidx/fragment/app/q;->o:Landroidx/fragment/app/s;

    if-eqz p1, :cond_2

    const/4 p2, 0x6

    if-eq p1, p2, :cond_1

    const/4 p0, 0x0

    return p0

    :cond_1
    iget-object p0, p0, Landroidx/fragment/app/s;->a:Landroidx/fragment/app/u;

    iget-object p0, p0, Landroidx/fragment/app/u;->i:Landroidx/fragment/app/y;

    invoke-virtual {p0}, Landroidx/fragment/app/x;->j()Z

    move-result p0

    return p0

    :cond_2
    iget-object p0, p0, Landroidx/fragment/app/s;->a:Landroidx/fragment/app/u;

    iget-object p0, p0, Landroidx/fragment/app/u;->i:Landroidx/fragment/app/y;

    invoke-virtual {p0}, Landroidx/fragment/app/x;->o()Z

    move-result p0

    return p0
.end method

.method public final onMultiWindowModeChanged(Z)V
    .locals 0

    iget-object p0, p0, Landroidx/fragment/app/q;->o:Landroidx/fragment/app/s;

    iget-object p0, p0, Landroidx/fragment/app/s;->a:Landroidx/fragment/app/u;

    iget-object p0, p0, Landroidx/fragment/app/u;->i:Landroidx/fragment/app/y;

    invoke-virtual {p0, p1}, Landroidx/fragment/app/x;->n(Z)V

    return-void
.end method

.method public final onNewIntent(Landroid/content/Intent;)V
    .locals 1
    .param p1    # Landroid/content/Intent;
        .annotation build Landroid/annotation/SuppressLint;
            value = {
                "UnknownNullness"
            }
        .end annotation
    .end param

    iget-object v0, p0, Landroidx/fragment/app/q;->o:Landroidx/fragment/app/s;

    invoke-virtual {v0}, Landroidx/fragment/app/s;->a()V

    invoke-super {p0, p1}, Landroidx/activity/ComponentActivity;->onNewIntent(Landroid/content/Intent;)V

    return-void
.end method

.method public onPanelClosed(ILandroid/view/Menu;)V
    .locals 1

    if-nez p1, :cond_0

    iget-object v0, p0, Landroidx/fragment/app/q;->o:Landroidx/fragment/app/s;

    iget-object v0, v0, Landroidx/fragment/app/s;->a:Landroidx/fragment/app/u;

    iget-object v0, v0, Landroidx/fragment/app/u;->i:Landroidx/fragment/app/y;

    invoke-virtual {v0}, Landroidx/fragment/app/x;->p()V

    :cond_0
    invoke-super {p0, p1, p2}, Landroidx/activity/ComponentActivity;->onPanelClosed(ILandroid/view/Menu;)V

    return-void
.end method

.method public final onPause()V
    .locals 2

    invoke-super {p0}, Landroid/app/Activity;->onPause()V

    const/4 v0, 0x0

    iput-boolean v0, p0, Landroidx/fragment/app/q;->r:Z

    iget-object v0, p0, Landroidx/fragment/app/q;->o:Landroidx/fragment/app/s;

    iget-object v0, v0, Landroidx/fragment/app/s;->a:Landroidx/fragment/app/u;

    iget-object v0, v0, Landroidx/fragment/app/u;->i:Landroidx/fragment/app/y;

    const/4 v1, 0x5

    invoke-virtual {v0, v1}, Landroidx/fragment/app/x;->t(I)V

    iget-object p0, p0, Landroidx/fragment/app/q;->p:Landroidx/lifecycle/l;

    sget-object v0, Landroidx/lifecycle/g$b;->ON_PAUSE:Landroidx/lifecycle/g$b;

    invoke-virtual {p0, v0}, Landroidx/lifecycle/l;->e(Landroidx/lifecycle/g$b;)V

    return-void
.end method

.method public final onPictureInPictureModeChanged(Z)V
    .locals 0

    iget-object p0, p0, Landroidx/fragment/app/q;->o:Landroidx/fragment/app/s;

    iget-object p0, p0, Landroidx/fragment/app/s;->a:Landroidx/fragment/app/u;

    iget-object p0, p0, Landroidx/fragment/app/u;->i:Landroidx/fragment/app/y;

    invoke-virtual {p0, p1}, Landroidx/fragment/app/x;->r(Z)V

    return-void
.end method

.method public onPostResume()V
    .locals 2

    invoke-super {p0}, Landroid/app/Activity;->onPostResume()V

    iget-object v0, p0, Landroidx/fragment/app/q;->p:Landroidx/lifecycle/l;

    sget-object v1, Landroidx/lifecycle/g$b;->ON_RESUME:Landroidx/lifecycle/g$b;

    invoke-virtual {v0, v1}, Landroidx/lifecycle/l;->e(Landroidx/lifecycle/g$b;)V

    iget-object p0, p0, Landroidx/fragment/app/q;->o:Landroidx/fragment/app/s;

    iget-object p0, p0, Landroidx/fragment/app/s;->a:Landroidx/fragment/app/u;

    iget-object p0, p0, Landroidx/fragment/app/u;->i:Landroidx/fragment/app/y;

    const/4 v0, 0x0

    iput-boolean v0, p0, Landroidx/fragment/app/x;->y:Z

    iput-boolean v0, p0, Landroidx/fragment/app/x;->z:Z

    iget-object v1, p0, Landroidx/fragment/app/x;->F:Landroidx/fragment/app/a0;

    iput-boolean v0, v1, Landroidx/fragment/app/a0;->h:Z

    const/4 v0, 0x7

    invoke-virtual {p0, v0}, Landroidx/fragment/app/x;->t(I)V

    return-void
.end method

.method public final onPreparePanel(ILandroid/view/View;Landroid/view/Menu;)Z
    .locals 0

    if-nez p1, :cond_0

    const/4 p1, 0x0

    invoke-super {p0, p1, p2, p3}, Landroid/app/Activity;->onPreparePanel(ILandroid/view/View;Landroid/view/Menu;)Z

    move-result p1

    iget-object p0, p0, Landroidx/fragment/app/q;->o:Landroidx/fragment/app/s;

    iget-object p0, p0, Landroidx/fragment/app/s;->a:Landroidx/fragment/app/u;

    iget-object p0, p0, Landroidx/fragment/app/u;->i:Landroidx/fragment/app/y;

    invoke-virtual {p0}, Landroidx/fragment/app/x;->s()Z

    move-result p0

    or-int/2addr p0, p1

    return p0

    :cond_0
    invoke-super {p0, p1, p2, p3}, Landroid/app/Activity;->onPreparePanel(ILandroid/view/View;Landroid/view/Menu;)Z

    move-result p0

    return p0
.end method

.method public final onRequestPermissionsResult(I[Ljava/lang/String;[I)V
    .locals 1

    iget-object v0, p0, Landroidx/fragment/app/q;->o:Landroidx/fragment/app/s;

    invoke-virtual {v0}, Landroidx/fragment/app/s;->a()V

    invoke-super {p0, p1, p2, p3}, Landroidx/activity/ComponentActivity;->onRequestPermissionsResult(I[Ljava/lang/String;[I)V

    return-void
.end method

.method public final onResume()V
    .locals 2

    iget-object v0, p0, Landroidx/fragment/app/q;->o:Landroidx/fragment/app/s;

    invoke-virtual {v0}, Landroidx/fragment/app/s;->a()V

    invoke-super {p0}, Landroid/app/Activity;->onResume()V

    const/4 v1, 0x1

    iput-boolean v1, p0, Landroidx/fragment/app/q;->r:Z

    iget-object p0, v0, Landroidx/fragment/app/s;->a:Landroidx/fragment/app/u;

    iget-object p0, p0, Landroidx/fragment/app/u;->i:Landroidx/fragment/app/y;

    invoke-virtual {p0, v1}, Landroidx/fragment/app/x;->x(Z)Z

    return-void
.end method

.method public onStart()V
    .locals 5

    iget-object v0, p0, Landroidx/fragment/app/q;->o:Landroidx/fragment/app/s;

    invoke-virtual {v0}, Landroidx/fragment/app/s;->a()V

    invoke-super {p0}, Landroid/app/Activity;->onStart()V

    const/4 v1, 0x0

    iput-boolean v1, p0, Landroidx/fragment/app/q;->s:Z

    iget-boolean v2, p0, Landroidx/fragment/app/q;->q:Z

    const/4 v3, 0x1

    iget-object v0, v0, Landroidx/fragment/app/s;->a:Landroidx/fragment/app/u;

    if-nez v2, :cond_0

    iput-boolean v3, p0, Landroidx/fragment/app/q;->q:Z

    iget-object v2, v0, Landroidx/fragment/app/u;->i:Landroidx/fragment/app/y;

    iput-boolean v1, v2, Landroidx/fragment/app/x;->y:Z

    iput-boolean v1, v2, Landroidx/fragment/app/x;->z:Z

    iget-object v4, v2, Landroidx/fragment/app/x;->F:Landroidx/fragment/app/a0;

    iput-boolean v1, v4, Landroidx/fragment/app/a0;->h:Z

    const/4 v4, 0x4

    invoke-virtual {v2, v4}, Landroidx/fragment/app/x;->t(I)V

    :cond_0
    iget-object v2, v0, Landroidx/fragment/app/u;->i:Landroidx/fragment/app/y;

    invoke-virtual {v2, v3}, Landroidx/fragment/app/x;->x(Z)Z

    iget-object p0, p0, Landroidx/fragment/app/q;->p:Landroidx/lifecycle/l;

    sget-object v2, Landroidx/lifecycle/g$b;->ON_START:Landroidx/lifecycle/g$b;

    invoke-virtual {p0, v2}, Landroidx/lifecycle/l;->e(Landroidx/lifecycle/g$b;)V

    iget-object p0, v0, Landroidx/fragment/app/u;->i:Landroidx/fragment/app/y;

    iput-boolean v1, p0, Landroidx/fragment/app/x;->y:Z

    iput-boolean v1, p0, Landroidx/fragment/app/x;->z:Z

    iget-object v0, p0, Landroidx/fragment/app/x;->F:Landroidx/fragment/app/a0;

    iput-boolean v1, v0, Landroidx/fragment/app/a0;->h:Z

    const/4 v0, 0x5

    invoke-virtual {p0, v0}, Landroidx/fragment/app/x;->t(I)V

    return-void
.end method

.method public final onStateNotSaved()V
    .locals 0

    iget-object p0, p0, Landroidx/fragment/app/q;->o:Landroidx/fragment/app/s;

    invoke-virtual {p0}, Landroidx/fragment/app/s;->a()V

    return-void
.end method

.method public onStop()V
    .locals 3

    invoke-super {p0}, Landroid/app/Activity;->onStop()V

    const/4 v0, 0x1

    iput-boolean v0, p0, Landroidx/fragment/app/q;->s:Z

    :cond_0
    iget-object v1, p0, Landroidx/fragment/app/q;->o:Landroidx/fragment/app/s;

    iget-object v2, v1, Landroidx/fragment/app/s;->a:Landroidx/fragment/app/u;

    iget-object v2, v2, Landroidx/fragment/app/u;->i:Landroidx/fragment/app/y;

    invoke-static {v2}, Landroidx/fragment/app/q;->p(Landroidx/fragment/app/x;)Z

    move-result v2

    if-nez v2, :cond_0

    iget-object v1, v1, Landroidx/fragment/app/s;->a:Landroidx/fragment/app/u;

    iget-object v1, v1, Landroidx/fragment/app/u;->i:Landroidx/fragment/app/y;

    iput-boolean v0, v1, Landroidx/fragment/app/x;->z:Z

    iget-object v2, v1, Landroidx/fragment/app/x;->F:Landroidx/fragment/app/a0;

    iput-boolean v0, v2, Landroidx/fragment/app/a0;->h:Z

    const/4 v0, 0x4

    invoke-virtual {v1, v0}, Landroidx/fragment/app/x;->t(I)V

    iget-object p0, p0, Landroidx/fragment/app/q;->p:Landroidx/lifecycle/l;

    sget-object v0, Landroidx/lifecycle/g$b;->ON_STOP:Landroidx/lifecycle/g$b;

    invoke-virtual {p0, v0}, Landroidx/lifecycle/l;->e(Landroidx/lifecycle/g$b;)V

    return-void
.end method

.method public q()V
    .locals 0
    .annotation runtime Ljava/lang/Deprecated;
    .end annotation

    invoke-virtual {p0}, Landroid/app/Activity;->invalidateOptionsMenu()V

    return-void
.end method
