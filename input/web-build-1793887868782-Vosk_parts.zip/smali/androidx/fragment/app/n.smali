.class public Landroidx/fragment/app/n;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Landroid/content/ComponentCallbacks;
.implements Landroid/view/View$OnCreateContextMenuListener;
.implements Landroidx/lifecycle/k;
.implements Landroidx/lifecycle/e0;
.implements Landroidx/lifecycle/f;
.implements Lt0/d;


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Landroidx/fragment/app/n$b;,
        Landroidx/fragment/app/n$c;,
        Landroidx/fragment/app/n$e;,
        Landroidx/fragment/app/n$d;
    }
.end annotation


# static fields
.field public static final R:Ljava/lang/Object;


# instance fields
.field public A:Z

.field public B:Z

.field public C:Z

.field public D:Z

.field public E:Landroid/view/ViewGroup;

.field public F:Landroid/view/View;

.field public G:Z

.field public H:Z

.field public I:Landroidx/fragment/app/n$b;

.field public J:Z

.field public K:Z

.field public L:Landroidx/lifecycle/g$c;

.field public M:Landroidx/lifecycle/l;

.field public N:Landroidx/fragment/app/m0;

.field public final O:Landroidx/lifecycle/p;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Landroidx/lifecycle/p<",
            "Landroidx/lifecycle/k;",
            ">;"
        }
    .end annotation
.end field

.field public P:Lt0/c;

.field public final Q:Ljava/util/ArrayList;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/ArrayList<",
            "Landroidx/fragment/app/n$d;",
            ">;"
        }
    .end annotation
.end field

.field public b:I

.field public c:Landroid/os/Bundle;

.field public d:Landroid/util/SparseArray;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Landroid/util/SparseArray<",
            "Landroid/os/Parcelable;",
            ">;"
        }
    .end annotation
.end field

.field public e:Landroid/os/Bundle;

.field public f:Ljava/lang/String;

.field public g:Landroid/os/Bundle;

.field public h:Landroidx/fragment/app/n;

.field public i:Ljava/lang/String;

.field public j:I

.field public k:Ljava/lang/Boolean;

.field public l:Z

.field public m:Z

.field public n:Z

.field public o:Z

.field public p:Z

.field public q:Z

.field public r:I

.field public s:Landroidx/fragment/app/x;

.field public t:Landroidx/fragment/app/u;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Landroidx/fragment/app/u<",
            "*>;"
        }
    .end annotation
.end field

.field public u:Landroidx/fragment/app/y;

.field public v:Landroidx/fragment/app/n;

.field public w:I

.field public x:I

.field public y:Ljava/lang/String;

.field public z:Z


# direct methods
.method static constructor <clinit>()V
    .locals 1

    new-instance v0, Ljava/lang/Object;

    invoke-direct {v0}, Ljava/lang/Object;-><init>()V

    sput-object v0, Landroidx/fragment/app/n;->R:Ljava/lang/Object;

    return-void
.end method

.method public constructor <init>()V
    .locals 1

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v0, -0x1

    iput v0, p0, Landroidx/fragment/app/n;->b:I

    invoke-static {}, Ljava/util/UUID;->randomUUID()Ljava/util/UUID;

    move-result-object v0

    invoke-virtual {v0}, Ljava/util/UUID;->toString()Ljava/lang/String;

    move-result-object v0

    iput-object v0, p0, Landroidx/fragment/app/n;->f:Ljava/lang/String;

    const/4 v0, 0x0

    iput-object v0, p0, Landroidx/fragment/app/n;->i:Ljava/lang/String;

    iput-object v0, p0, Landroidx/fragment/app/n;->k:Ljava/lang/Boolean;

    new-instance v0, Landroidx/fragment/app/y;

    invoke-direct {v0}, Landroidx/fragment/app/y;-><init>()V

    iput-object v0, p0, Landroidx/fragment/app/n;->u:Landroidx/fragment/app/y;

    const/4 v0, 0x1

    iput-boolean v0, p0, Landroidx/fragment/app/n;->C:Z

    iput-boolean v0, p0, Landroidx/fragment/app/n;->H:Z

    sget-object v0, Landroidx/lifecycle/g$c;->f:Landroidx/lifecycle/g$c;

    iput-object v0, p0, Landroidx/fragment/app/n;->L:Landroidx/lifecycle/g$c;

    new-instance v0, Landroidx/lifecycle/p;

    invoke-direct {v0}, Landroidx/lifecycle/p;-><init>()V

    iput-object v0, p0, Landroidx/fragment/app/n;->O:Landroidx/lifecycle/p;

    new-instance v0, Ljava/util/concurrent/atomic/AtomicInteger;

    invoke-direct {v0}, Ljava/util/concurrent/atomic/AtomicInteger;-><init>()V

    new-instance v0, Ljava/util/ArrayList;

    invoke-direct {v0}, Ljava/util/ArrayList;-><init>()V

    iput-object v0, p0, Landroidx/fragment/app/n;->Q:Ljava/util/ArrayList;

    new-instance v0, Landroidx/lifecycle/l;

    invoke-direct {v0, p0}, Landroidx/lifecycle/l;-><init>(Landroidx/lifecycle/k;)V

    iput-object v0, p0, Landroidx/fragment/app/n;->M:Landroidx/lifecycle/l;

    new-instance v0, Lt0/c;

    invoke-direct {v0, p0}, Lt0/c;-><init>(Lt0/d;)V

    iput-object v0, p0, Landroidx/fragment/app/n;->P:Lt0/c;

    return-void
.end method


# virtual methods
.method public A(Landroid/os/Bundle;)Landroid/view/LayoutInflater;
    .locals 0

    iget-object p1, p0, Landroidx/fragment/app/n;->t:Landroidx/fragment/app/u;

    if-eqz p1, :cond_0

    invoke-virtual {p1}, Landroidx/fragment/app/u;->p()Landroid/view/LayoutInflater;

    move-result-object p1

    iget-object p0, p0, Landroidx/fragment/app/n;->u:Landroidx/fragment/app/y;

    iget-object p0, p0, Landroidx/fragment/app/x;->f:Landroidx/fragment/app/v;

    invoke-virtual {p1, p0}, Landroid/view/LayoutInflater;->setFactory2(Landroid/view/LayoutInflater$Factory2;)V

    return-object p1

    :cond_0
    new-instance p0, Ljava/lang/IllegalStateException;

    const-string p1, "onGetLayoutInflater() cannot be executed until the Fragment is attached to the FragmentManager."

    invoke-direct {p0, p1}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    throw p0
.end method

.method public B(Landroid/os/Bundle;)V
    .locals 0

    return-void
.end method

.method public C()V
    .locals 1

    const/4 v0, 0x1

    iput-boolean v0, p0, Landroidx/fragment/app/n;->D:Z

    return-void
.end method

.method public D()V
    .locals 1

    const/4 v0, 0x1

    iput-boolean v0, p0, Landroidx/fragment/app/n;->D:Z

    return-void
.end method

.method public E(Landroid/os/Bundle;)V
    .locals 0

    const/4 p1, 0x1

    iput-boolean p1, p0, Landroidx/fragment/app/n;->D:Z

    return-void
.end method

.method public F(Landroid/view/LayoutInflater;Landroid/view/ViewGroup;Landroid/os/Bundle;)V
    .locals 3

    iget-object v0, p0, Landroidx/fragment/app/n;->u:Landroidx/fragment/app/y;

    invoke-virtual {v0}, Landroidx/fragment/app/x;->N()V

    const/4 v0, 0x1

    iput-boolean v0, p0, Landroidx/fragment/app/n;->q:Z

    new-instance v1, Landroidx/fragment/app/m0;

    invoke-virtual {p0}, Landroidx/fragment/app/n;->i()Landroidx/lifecycle/d0;

    move-result-object v2

    invoke-direct {v1, v2}, Landroidx/fragment/app/m0;-><init>(Landroidx/lifecycle/d0;)V

    iput-object v1, p0, Landroidx/fragment/app/n;->N:Landroidx/fragment/app/m0;

    invoke-virtual {p0, p1, p2, p3}, Landroidx/fragment/app/n;->x(Landroid/view/LayoutInflater;Landroid/view/ViewGroup;Landroid/os/Bundle;)Landroid/view/View;

    move-result-object p1

    iput-object p1, p0, Landroidx/fragment/app/n;->F:Landroid/view/View;

    if-eqz p1, :cond_0

    iget-object p1, p0, Landroidx/fragment/app/n;->N:Landroidx/fragment/app/m0;

    invoke-virtual {p1}, Landroidx/fragment/app/m0;->e()V

    iget-object p1, p0, Landroidx/fragment/app/n;->F:Landroid/view/View;

    iget-object p2, p0, Landroidx/fragment/app/n;->N:Landroidx/fragment/app/m0;

    const p3, 0x7f0801e2

    invoke-virtual {p1, p3, p2}, Landroid/view/View;->setTag(ILjava/lang/Object;)V

    iget-object p1, p0, Landroidx/fragment/app/n;->F:Landroid/view/View;

    iget-object p2, p0, Landroidx/fragment/app/n;->N:Landroidx/fragment/app/m0;

    const p3, 0x7f0801e5

    invoke-virtual {p1, p3, p2}, Landroid/view/View;->setTag(ILjava/lang/Object;)V

    iget-object p1, p0, Landroidx/fragment/app/n;->F:Landroid/view/View;

    iget-object p2, p0, Landroidx/fragment/app/n;->N:Landroidx/fragment/app/m0;

    const-string p3, "<this>"

    invoke-static {p3, p1}, Lj3/c;->d(Ljava/lang/String;Ljava/lang/Object;)V

    const p3, 0x7f0801e4

    invoke-virtual {p1, p3, p2}, Landroid/view/View;->setTag(ILjava/lang/Object;)V

    iget-object p1, p0, Landroidx/fragment/app/n;->O:Landroidx/lifecycle/p;

    iget-object p0, p0, Landroidx/fragment/app/n;->N:Landroidx/fragment/app/m0;

    invoke-virtual {p1, p0}, Landroidx/lifecycle/p;->h(Ljava/lang/Object;)V

    goto :goto_1

    :cond_0
    iget-object p1, p0, Landroidx/fragment/app/n;->N:Landroidx/fragment/app/m0;

    iget-object p1, p1, Landroidx/fragment/app/m0;->c:Landroidx/lifecycle/l;

    if-eqz p1, :cond_1

    goto :goto_0

    :cond_1
    const/4 v0, 0x0

    :goto_0
    if-nez v0, :cond_2

    const/4 p1, 0x0

    iput-object p1, p0, Landroidx/fragment/app/n;->N:Landroidx/fragment/app/m0;

    :goto_1
    return-void

    :cond_2
    new-instance p0, Ljava/lang/IllegalStateException;

    const-string p1, "Called getViewLifecycleOwner() but onCreateView() returned null"

    invoke-direct {p0, p1}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    throw p0
.end method

.method public final G()V
    .locals 5

    iget-object v0, p0, Landroidx/fragment/app/n;->u:Landroidx/fragment/app/y;

    const/4 v1, 0x1

    invoke-virtual {v0, v1}, Landroidx/fragment/app/x;->t(I)V

    iget-object v0, p0, Landroidx/fragment/app/n;->F:Landroid/view/View;

    if-eqz v0, :cond_0

    iget-object v0, p0, Landroidx/fragment/app/n;->N:Landroidx/fragment/app/m0;

    invoke-virtual {v0}, Landroidx/fragment/app/m0;->e()V

    iget-object v0, v0, Landroidx/fragment/app/m0;->c:Landroidx/lifecycle/l;

    iget-object v0, v0, Landroidx/lifecycle/l;->b:Landroidx/lifecycle/g$c;

    sget-object v2, Landroidx/lifecycle/g$c;->d:Landroidx/lifecycle/g$c;

    invoke-virtual {v0, v2}, Landroidx/lifecycle/g$c;->a(Landroidx/lifecycle/g$c;)Z

    move-result v0

    if-eqz v0, :cond_0

    iget-object v0, p0, Landroidx/fragment/app/n;->N:Landroidx/fragment/app/m0;

    sget-object v2, Landroidx/lifecycle/g$b;->ON_DESTROY:Landroidx/lifecycle/g$b;

    invoke-virtual {v0, v2}, Landroidx/fragment/app/m0;->c(Landroidx/lifecycle/g$b;)V

    :cond_0
    iput v1, p0, Landroidx/fragment/app/n;->b:I

    const/4 v0, 0x0

    iput-boolean v0, p0, Landroidx/fragment/app/n;->D:Z

    invoke-virtual {p0}, Landroidx/fragment/app/n;->y()V

    iget-boolean v1, p0, Landroidx/fragment/app/n;->D:Z

    if-eqz v1, :cond_2

    new-instance v1, Lr0/a;

    invoke-interface {p0}, Landroidx/lifecycle/e0;->i()Landroidx/lifecycle/d0;

    move-result-object v2

    invoke-direct {v1, p0, v2}, Lr0/a;-><init>(Landroidx/lifecycle/k;Landroidx/lifecycle/d0;)V

    iget-object v1, v1, Lr0/a;->g:Lr0/a$b;

    iget-object v1, v1, Lr0/a$b;->c:Ll/i;

    iget v2, v1, Ll/i;->d:I

    move v3, v0

    :goto_0
    if-ge v3, v2, :cond_1

    iget-object v4, v1, Ll/i;->c:[Ljava/lang/Object;

    aget-object v4, v4, v3

    check-cast v4, Lr0/a$a;

    invoke-virtual {v4}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    add-int/lit8 v3, v3, 0x1

    goto :goto_0

    :cond_1
    iput-boolean v0, p0, Landroidx/fragment/app/n;->q:Z

    return-void

    :cond_2
    new-instance v0, Landroidx/fragment/app/t0;

    new-instance v1, Ljava/lang/StringBuilder;

    const-string v2, "Fragment "

    invoke-direct {v1, v2}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-virtual {v1, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    const-string p0, " did not call through to super.onDestroyView()"

    invoke-virtual {v1, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p0

    invoke-direct {v0, p0}, Landroidx/fragment/app/t0;-><init>(Ljava/lang/String;)V

    throw v0
.end method

.method public final H()V
    .locals 0

    invoke-virtual {p0}, Landroidx/fragment/app/n;->onLowMemory()V

    iget-object p0, p0, Landroidx/fragment/app/n;->u:Landroidx/fragment/app/y;

    invoke-virtual {p0}, Landroidx/fragment/app/x;->m()V

    return-void
.end method

.method public final I(Z)V
    .locals 0

    iget-object p0, p0, Landroidx/fragment/app/n;->u:Landroidx/fragment/app/y;

    invoke-virtual {p0, p1}, Landroidx/fragment/app/x;->n(Z)V

    return-void
.end method

.method public final J(Z)V
    .locals 0

    iget-object p0, p0, Landroidx/fragment/app/n;->u:Landroidx/fragment/app/y;

    invoke-virtual {p0, p1}, Landroidx/fragment/app/x;->r(Z)V

    return-void
.end method

.method public final K()Z
    .locals 2

    iget-boolean v0, p0, Landroidx/fragment/app/n;->z:Z

    const/4 v1, 0x0

    if-nez v0, :cond_0

    iget-object p0, p0, Landroidx/fragment/app/n;->u:Landroidx/fragment/app/y;

    invoke-virtual {p0}, Landroidx/fragment/app/x;->s()Z

    move-result p0

    or-int/2addr v1, p0

    :cond_0
    return v1
.end method

.method public final L()Landroidx/fragment/app/q;
    .locals 3

    invoke-virtual {p0}, Landroidx/fragment/app/n;->h()Landroidx/fragment/app/q;

    move-result-object v0

    if-eqz v0, :cond_0

    return-object v0

    :cond_0
    new-instance v0, Ljava/lang/IllegalStateException;

    new-instance v1, Ljava/lang/StringBuilder;

    const-string v2, "Fragment "

    invoke-direct {v1, v2}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-virtual {v1, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    const-string p0, " not attached to an activity."

    invoke-virtual {v1, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p0

    invoke-direct {v0, p0}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    throw v0
.end method

.method public final M()Landroid/content/Context;
    .locals 3

    invoke-virtual {p0}, Landroidx/fragment/app/n;->l()Landroid/content/Context;

    move-result-object v0

    if-eqz v0, :cond_0

    return-object v0

    :cond_0
    new-instance v0, Ljava/lang/IllegalStateException;

    new-instance v1, Ljava/lang/StringBuilder;

    const-string v2, "Fragment "

    invoke-direct {v1, v2}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-virtual {v1, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    const-string p0, " not attached to a context."

    invoke-virtual {v1, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p0

    invoke-direct {v0, p0}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    throw v0
.end method

.method public final N()Landroid/view/View;
    .locals 3

    iget-object v0, p0, Landroidx/fragment/app/n;->F:Landroid/view/View;

    if-eqz v0, :cond_0

    return-object v0

    :cond_0
    new-instance v0, Ljava/lang/IllegalStateException;

    new-instance v1, Ljava/lang/StringBuilder;

    const-string v2, "Fragment "

    invoke-direct {v1, v2}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-virtual {v1, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    const-string p0, " did not return a View from onCreateView() or this was called before onCreateView()."

    invoke-virtual {v1, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p0

    invoke-direct {v0, p0}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    throw v0
.end method

.method public final O(IIII)V
    .locals 1

    iget-object v0, p0, Landroidx/fragment/app/n;->I:Landroidx/fragment/app/n$b;

    if-nez v0, :cond_0

    if-nez p1, :cond_0

    if-nez p2, :cond_0

    if-nez p3, :cond_0

    if-nez p4, :cond_0

    return-void

    :cond_0
    invoke-virtual {p0}, Landroidx/fragment/app/n;->g()Landroidx/fragment/app/n$b;

    move-result-object v0

    iput p1, v0, Landroidx/fragment/app/n$b;->b:I

    invoke-virtual {p0}, Landroidx/fragment/app/n;->g()Landroidx/fragment/app/n$b;

    move-result-object p1

    iput p2, p1, Landroidx/fragment/app/n$b;->c:I

    invoke-virtual {p0}, Landroidx/fragment/app/n;->g()Landroidx/fragment/app/n$b;

    move-result-object p1

    iput p3, p1, Landroidx/fragment/app/n$b;->d:I

    invoke-virtual {p0}, Landroidx/fragment/app/n;->g()Landroidx/fragment/app/n$b;

    move-result-object p0

    iput p4, p0, Landroidx/fragment/app/n$b;->e:I

    return-void
.end method

.method public final P(Landroid/os/Bundle;)V
    .locals 1

    iget-object v0, p0, Landroidx/fragment/app/n;->s:Landroidx/fragment/app/x;

    if-eqz v0, :cond_2

    if-nez v0, :cond_0

    const/4 v0, 0x0

    goto :goto_0

    :cond_0
    invoke-virtual {v0}, Landroidx/fragment/app/x;->L()Z

    move-result v0

    :goto_0
    if-nez v0, :cond_1

    goto :goto_1

    :cond_1
    new-instance p0, Ljava/lang/IllegalStateException;

    const-string p1, "Fragment already added and state has been saved"

    invoke-direct {p0, p1}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    throw p0

    :cond_2
    :goto_1
    iput-object p1, p0, Landroidx/fragment/app/n;->g:Landroid/os/Bundle;

    return-void
.end method

.method public final Q(Landroid/content/Intent;I)V
    .locals 12
    .param p1    # Landroid/content/Intent;
        .annotation build Landroid/annotation/SuppressLint;
            value = {
                "UnknownNullness"
            }
        .end annotation
    .end param
    .annotation runtime Ljava/lang/Deprecated;
    .end annotation

    iget-object v0, p0, Landroidx/fragment/app/n;->t:Landroidx/fragment/app/u;

    if-eqz v0, :cond_9

    invoke-virtual {p0}, Landroidx/fragment/app/n;->n()Landroidx/fragment/app/x;

    move-result-object v0

    iget-object v1, v0, Landroidx/fragment/app/x;->t:Landroidx/activity/result/e;

    const/4 v2, 0x0

    if-eqz v1, :cond_7

    new-instance v1, Landroidx/fragment/app/x$l;

    iget-object p0, p0, Landroidx/fragment/app/n;->f:Ljava/lang/String;

    invoke-direct {v1, p0, p2}, Landroidx/fragment/app/x$l;-><init>(Ljava/lang/String;I)V

    iget-object p0, v0, Landroidx/fragment/app/x;->w:Ljava/util/ArrayDeque;

    invoke-virtual {p0, v1}, Ljava/util/ArrayDeque;->addLast(Ljava/lang/Object;)V

    iget-object p0, v0, Landroidx/fragment/app/x;->t:Landroidx/activity/result/e;

    invoke-virtual {p0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    iget-object p2, p0, Landroidx/activity/result/e;->h:Landroidx/activity/result/f;

    iget-object v0, p2, Landroidx/activity/result/f;->c:Ljava/util/HashMap;

    iget-object v1, p0, Landroidx/activity/result/e;->f:Ljava/lang/String;

    invoke-virtual {v0, v1}, Ljava/util/HashMap;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Ljava/lang/Integer;

    iget-object p0, p0, Landroidx/activity/result/e;->g:Lb/a;

    if-eqz v0, :cond_6

    iget-object v3, p2, Landroidx/activity/result/f;->e:Ljava/util/ArrayList;

    invoke-virtual {v3, v1}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    invoke-virtual {v0}, Ljava/lang/Integer;->intValue()I

    move-result v0

    check-cast p2, Landroidx/activity/ComponentActivity$b;

    iget-object v4, p2, Landroidx/activity/ComponentActivity$b;->i:Landroidx/activity/ComponentActivity;

    invoke-virtual {p0, v4, p1}, Lb/a;->b(Landroidx/activity/ComponentActivity;Landroid/content/Intent;)Lb/a$a;

    move-result-object v1

    if-eqz v1, :cond_0

    new-instance p0, Landroid/os/Handler;

    invoke-static {}, Landroid/os/Looper;->getMainLooper()Landroid/os/Looper;

    move-result-object p1

    invoke-direct {p0, p1}, Landroid/os/Handler;-><init>(Landroid/os/Looper;)V

    new-instance p1, Landroidx/activity/e;

    invoke-direct {p1, p2, v0, v1}, Landroidx/activity/e;-><init>(Landroidx/activity/ComponentActivity$b;ILb/a$a;)V

    invoke-virtual {p0, p1}, Landroid/os/Handler;->post(Ljava/lang/Runnable;)Z

    goto/16 :goto_0

    :cond_0
    invoke-virtual {p0, v4, p1}, Lb/a;->a(Landroidx/activity/ComponentActivity;Landroid/content/Intent;)Landroid/content/Intent;

    move-result-object p0

    invoke-virtual {p0}, Landroid/content/Intent;->getExtras()Landroid/os/Bundle;

    move-result-object p1

    if-eqz p1, :cond_1

    invoke-virtual {p0}, Landroid/content/Intent;->getExtras()Landroid/os/Bundle;

    move-result-object p1

    invoke-virtual {p1}, Landroid/os/Bundle;->getClassLoader()Ljava/lang/ClassLoader;

    move-result-object p1

    if-nez p1, :cond_1

    invoke-virtual {v4}, Landroid/content/Context;->getClassLoader()Ljava/lang/ClassLoader;

    move-result-object p1

    invoke-virtual {p0, p1}, Landroid/content/Intent;->setExtrasClassLoader(Ljava/lang/ClassLoader;)V

    :cond_1
    const-string p1, "androidx.activity.result.contract.extra.ACTIVITY_OPTIONS_BUNDLE"

    invoke-virtual {p0, p1}, Landroid/content/Intent;->hasExtra(Ljava/lang/String;)Z

    move-result v1

    if-eqz v1, :cond_2

    invoke-virtual {p0, p1}, Landroid/content/Intent;->getBundleExtra(Ljava/lang/String;)Landroid/os/Bundle;

    move-result-object v2

    invoke-virtual {p0, p1}, Landroid/content/Intent;->removeExtra(Ljava/lang/String;)V

    :cond_2
    move-object v11, v2

    const-string p1, "androidx.activity.result.contract.action.REQUEST_PERMISSIONS"

    invoke-virtual {p0}, Landroid/content/Intent;->getAction()Ljava/lang/String;

    move-result-object v1

    invoke-virtual {p1, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result p1

    if-eqz p1, :cond_4

    const-string p1, "androidx.activity.result.contract.extra.PERMISSIONS"

    invoke-virtual {p0, p1}, Landroid/content/Intent;->getStringArrayExtra(Ljava/lang/String;)[Ljava/lang/String;

    move-result-object p0

    if-nez p0, :cond_3

    const/4 p0, 0x0

    new-array p0, p0, [Ljava/lang/String;

    :cond_3
    invoke-static {v4, p0, v0}, Lu/a;->c(Landroid/app/Activity;[Ljava/lang/String;I)V

    goto :goto_0

    :cond_4
    const-string p1, "androidx.activity.result.contract.action.INTENT_SENDER_REQUEST"

    invoke-virtual {p0}, Landroid/content/Intent;->getAction()Ljava/lang/String;

    move-result-object v1

    invoke-virtual {p1, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result p1

    if-eqz p1, :cond_5

    const-string p1, "androidx.activity.result.contract.extra.INTENT_SENDER_REQUEST"

    invoke-virtual {p0, p1}, Landroid/content/Intent;->getParcelableExtra(Ljava/lang/String;)Landroid/os/Parcelable;

    move-result-object p0

    check-cast p0, Landroidx/activity/result/h;

    :try_start_0
    iget-object v5, p0, Landroidx/activity/result/h;->b:Landroid/content/IntentSender;

    iget-object v7, p0, Landroidx/activity/result/h;->c:Landroid/content/Intent;

    iget v8, p0, Landroidx/activity/result/h;->d:I

    iget v9, p0, Landroidx/activity/result/h;->e:I

    const/4 v10, 0x0

    sget p0, Lu/a;->b:I

    move v6, v0

    invoke-static/range {v4 .. v11}, Lu/a$a;->c(Landroid/app/Activity;Landroid/content/IntentSender;ILandroid/content/Intent;IIILandroid/os/Bundle;)V
    :try_end_0
    .catch Landroid/content/IntentSender$SendIntentException; {:try_start_0 .. :try_end_0} :catch_0

    goto :goto_0

    :catch_0
    move-exception p0

    new-instance p1, Landroid/os/Handler;

    invoke-static {}, Landroid/os/Looper;->getMainLooper()Landroid/os/Looper;

    move-result-object v1

    invoke-direct {p1, v1}, Landroid/os/Handler;-><init>(Landroid/os/Looper;)V

    new-instance v1, Landroidx/activity/f;

    invoke-direct {v1, p2, v0, p0}, Landroidx/activity/f;-><init>(Landroidx/activity/ComponentActivity$b;ILandroid/content/IntentSender$SendIntentException;)V

    invoke-virtual {p1, v1}, Landroid/os/Handler;->post(Ljava/lang/Runnable;)Z

    goto :goto_0

    :cond_5
    sget p1, Lu/a;->b:I

    invoke-static {v4, p0, v0, v11}, Lu/a$a;->b(Landroid/app/Activity;Landroid/content/Intent;ILandroid/os/Bundle;)V

    goto :goto_0

    :cond_6
    new-instance p2, Ljava/lang/IllegalStateException;

    new-instance v0, Ljava/lang/StringBuilder;

    const-string v1, "Attempting to launch an unregistered ActivityResultLauncher with contract "

    invoke-direct {v0, v1}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-virtual {v0, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    const-string p0, " and input "

    invoke-virtual {v0, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v0, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    const-string p0, ". You must ensure the ActivityResultLauncher is registered before calling launch()."

    invoke-virtual {v0, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p0

    invoke-direct {p2, p0}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    throw p2

    :cond_7
    iget-object p0, v0, Landroidx/fragment/app/x;->n:Landroidx/fragment/app/u;

    invoke-virtual {p0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    const/4 v0, -0x1

    if-ne p2, v0, :cond_8

    sget-object p2, Lv/a;->a:Ljava/lang/Object;

    iget-object p0, p0, Landroidx/fragment/app/u;->g:Landroid/content/Context;

    invoke-static {p0, p1, v2}, Lv/a$a;->b(Landroid/content/Context;Landroid/content/Intent;Landroid/os/Bundle;)V

    :goto_0
    return-void

    :cond_8
    new-instance p0, Ljava/lang/IllegalStateException;

    const-string p1, "Starting activity with a requestCode requires a FragmentActivity host"

    invoke-direct {p0, p1}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    throw p0

    :cond_9
    new-instance p1, Ljava/lang/IllegalStateException;

    new-instance p2, Ljava/lang/StringBuilder;

    const-string v0, "Fragment "

    invoke-direct {p2, v0}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-virtual {p2, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    const-string p0, " not attached to Activity"

    invoke-virtual {p2, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {p2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p0

    invoke-direct {p1, p0}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    throw p1
.end method

.method public final b()Lt0/b;
    .locals 0

    iget-object p0, p0, Landroidx/fragment/app/n;->P:Lt0/c;

    iget-object p0, p0, Lt0/c;->b:Lt0/b;

    return-object p0
.end method

.method public e()Landroidx/activity/result/c;
    .locals 1

    new-instance v0, Landroidx/fragment/app/n$a;

    invoke-direct {v0, p0}, Landroidx/fragment/app/n$a;-><init>(Landroidx/fragment/app/n;)V

    return-object v0
.end method

.method public final equals(Ljava/lang/Object;)Z
    .locals 0

    invoke-super {p0, p1}, Ljava/lang/Object;->equals(Ljava/lang/Object;)Z

    move-result p0

    return p0
.end method

.method public final g()Landroidx/fragment/app/n$b;
    .locals 1

    iget-object v0, p0, Landroidx/fragment/app/n;->I:Landroidx/fragment/app/n$b;

    if-nez v0, :cond_0

    new-instance v0, Landroidx/fragment/app/n$b;

    invoke-direct {v0}, Landroidx/fragment/app/n$b;-><init>()V

    iput-object v0, p0, Landroidx/fragment/app/n;->I:Landroidx/fragment/app/n$b;

    :cond_0
    iget-object p0, p0, Landroidx/fragment/app/n;->I:Landroidx/fragment/app/n$b;

    return-object p0
.end method

.method public final h()Landroidx/fragment/app/q;
    .locals 0

    iget-object p0, p0, Landroidx/fragment/app/n;->t:Landroidx/fragment/app/u;

    if-nez p0, :cond_0

    const/4 p0, 0x0

    goto :goto_0

    :cond_0
    iget-object p0, p0, Landroidx/fragment/app/u;->f:Landroid/app/Activity;

    check-cast p0, Landroidx/fragment/app/q;

    :goto_0
    return-object p0
.end method

.method public final hashCode()I
    .locals 0

    invoke-super {p0}, Ljava/lang/Object;->hashCode()I

    move-result p0

    return p0
.end method

.method public final i()Landroidx/lifecycle/d0;
    .locals 2

    iget-object v0, p0, Landroidx/fragment/app/n;->s:Landroidx/fragment/app/x;

    if-eqz v0, :cond_2

    invoke-virtual {p0}, Landroidx/fragment/app/n;->m()I

    move-result v0

    const/4 v1, 0x1

    if-eq v0, v1, :cond_1

    iget-object v0, p0, Landroidx/fragment/app/n;->s:Landroidx/fragment/app/x;

    iget-object v0, v0, Landroidx/fragment/app/x;->F:Landroidx/fragment/app/a0;

    iget-object v0, v0, Landroidx/fragment/app/a0;->e:Ljava/util/HashMap;

    iget-object v1, p0, Landroidx/fragment/app/n;->f:Ljava/lang/String;

    invoke-virtual {v0, v1}, Ljava/util/HashMap;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Landroidx/lifecycle/d0;

    if-nez v1, :cond_0

    new-instance v1, Landroidx/lifecycle/d0;

    invoke-direct {v1}, Landroidx/lifecycle/d0;-><init>()V

    iget-object p0, p0, Landroidx/fragment/app/n;->f:Ljava/lang/String;

    invoke-virtual {v0, p0, v1}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    :cond_0
    return-object v1

    :cond_1
    new-instance p0, Ljava/lang/IllegalStateException;

    const-string v0, "Calling getViewModelStore() before a Fragment reaches onCreate() when using setMaxLifecycle(INITIALIZED) is not supported"

    invoke-direct {p0, v0}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    throw p0

    :cond_2
    new-instance p0, Ljava/lang/IllegalStateException;

    const-string v0, "Can\'t access ViewModels from detached fragment"

    invoke-direct {p0, v0}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    throw p0
.end method

.method public final j()Landroidx/fragment/app/x;
    .locals 3

    iget-object v0, p0, Landroidx/fragment/app/n;->t:Landroidx/fragment/app/u;

    if-eqz v0, :cond_0

    iget-object p0, p0, Landroidx/fragment/app/n;->u:Landroidx/fragment/app/y;

    return-object p0

    :cond_0
    new-instance v0, Ljava/lang/IllegalStateException;

    new-instance v1, Ljava/lang/StringBuilder;

    const-string v2, "Fragment "

    invoke-direct {v1, v2}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-virtual {v1, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    const-string p0, " has not been attached yet."

    invoke-virtual {v1, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p0

    invoke-direct {v0, p0}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    throw v0
.end method

.method public final k()Landroidx/lifecycle/l;
    .locals 0

    iget-object p0, p0, Landroidx/fragment/app/n;->M:Landroidx/lifecycle/l;

    return-object p0
.end method

.method public final l()Landroid/content/Context;
    .locals 0

    iget-object p0, p0, Landroidx/fragment/app/n;->t:Landroidx/fragment/app/u;

    if-nez p0, :cond_0

    const/4 p0, 0x0

    goto :goto_0

    :cond_0
    iget-object p0, p0, Landroidx/fragment/app/u;->g:Landroid/content/Context;

    :goto_0
    return-object p0
.end method

.method public final m()I
    .locals 2

    iget-object v0, p0, Landroidx/fragment/app/n;->L:Landroidx/lifecycle/g$c;

    sget-object v1, Landroidx/lifecycle/g$c;->c:Landroidx/lifecycle/g$c;

    if-eq v0, v1, :cond_1

    iget-object v1, p0, Landroidx/fragment/app/n;->v:Landroidx/fragment/app/n;

    if-nez v1, :cond_0

    goto :goto_0

    :cond_0
    invoke-virtual {v0}, Ljava/lang/Enum;->ordinal()I

    move-result v0

    iget-object p0, p0, Landroidx/fragment/app/n;->v:Landroidx/fragment/app/n;

    invoke-virtual {p0}, Landroidx/fragment/app/n;->m()I

    move-result p0

    invoke-static {v0, p0}, Ljava/lang/Math;->min(II)I

    move-result p0

    return p0

    :cond_1
    :goto_0
    invoke-virtual {v0}, Ljava/lang/Enum;->ordinal()I

    move-result p0

    return p0
.end method

.method public final n()Landroidx/fragment/app/x;
    .locals 3

    iget-object v0, p0, Landroidx/fragment/app/n;->s:Landroidx/fragment/app/x;

    if-eqz v0, :cond_0

    return-object v0

    :cond_0
    new-instance v0, Ljava/lang/IllegalStateException;

    new-instance v1, Ljava/lang/StringBuilder;

    const-string v2, "Fragment "

    invoke-direct {v1, v2}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-virtual {v1, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    const-string p0, " not associated with a fragment manager."

    invoke-virtual {v1, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p0

    invoke-direct {v0, p0}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    throw v0
.end method

.method public final o()Ljava/lang/Object;
    .locals 2

    iget-object p0, p0, Landroidx/fragment/app/n;->I:Landroidx/fragment/app/n$b;

    const/4 v0, 0x0

    if-nez p0, :cond_0

    return-object v0

    :cond_0
    iget-object p0, p0, Landroidx/fragment/app/n$b;->j:Ljava/lang/Object;

    sget-object v1, Landroidx/fragment/app/n;->R:Ljava/lang/Object;

    if-ne p0, v1, :cond_1

    goto :goto_0

    :cond_1
    move-object v0, p0

    :goto_0
    return-object v0
.end method

.method public final onConfigurationChanged(Landroid/content/res/Configuration;)V
    .locals 0

    const/4 p1, 0x1

    iput-boolean p1, p0, Landroidx/fragment/app/n;->D:Z

    return-void
.end method

.method public final onCreateContextMenu(Landroid/view/ContextMenu;Landroid/view/View;Landroid/view/ContextMenu$ContextMenuInfo;)V
    .locals 0

    invoke-virtual {p0}, Landroidx/fragment/app/n;->L()Landroidx/fragment/app/q;

    move-result-object p0

    invoke-virtual {p0, p1, p2, p3}, Landroid/app/Activity;->onCreateContextMenu(Landroid/view/ContextMenu;Landroid/view/View;Landroid/view/ContextMenu$ContextMenuInfo;)V

    return-void
.end method

.method public final onLowMemory()V
    .locals 1

    const/4 v0, 0x1

    iput-boolean v0, p0, Landroidx/fragment/app/n;->D:Z

    return-void
.end method

.method public final p()Ljava/lang/Object;
    .locals 2

    iget-object p0, p0, Landroidx/fragment/app/n;->I:Landroidx/fragment/app/n$b;

    const/4 v0, 0x0

    if-nez p0, :cond_0

    return-object v0

    :cond_0
    iget-object p0, p0, Landroidx/fragment/app/n$b;->i:Ljava/lang/Object;

    sget-object v1, Landroidx/fragment/app/n;->R:Ljava/lang/Object;

    if-ne p0, v1, :cond_1

    goto :goto_0

    :cond_1
    move-object v0, p0

    :goto_0
    return-object v0
.end method

.method public final q()Ljava/lang/Object;
    .locals 2

    iget-object p0, p0, Landroidx/fragment/app/n;->I:Landroidx/fragment/app/n$b;

    const/4 v0, 0x0

    if-nez p0, :cond_0

    return-object v0

    :cond_0
    iget-object p0, p0, Landroidx/fragment/app/n$b;->k:Ljava/lang/Object;

    sget-object v1, Landroidx/fragment/app/n;->R:Ljava/lang/Object;

    if-ne p0, v1, :cond_1

    goto :goto_0

    :cond_1
    move-object v0, p0

    :goto_0
    return-object v0
.end method

.method public final r(I)Ljava/lang/String;
    .locals 0

    invoke-virtual {p0}, Landroidx/fragment/app/n;->M()Landroid/content/Context;

    move-result-object p0

    invoke-virtual {p0}, Landroid/content/Context;->getResources()Landroid/content/res/Resources;

    move-result-object p0

    invoke-virtual {p0, p1}, Landroid/content/res/Resources;->getString(I)Ljava/lang/String;

    move-result-object p0

    return-object p0
.end method

.method public final s()Z
    .locals 1

    iget-object v0, p0, Landroidx/fragment/app/n;->t:Landroidx/fragment/app/u;

    if-eqz v0, :cond_0

    iget-boolean p0, p0, Landroidx/fragment/app/n;->l:Z

    if-eqz p0, :cond_0

    const/4 p0, 0x1

    goto :goto_0

    :cond_0
    const/4 p0, 0x0

    :goto_0
    return p0
.end method

.method public final t()Z
    .locals 1

    invoke-virtual {p0}, Landroidx/fragment/app/n;->s()Z

    move-result v0

    if-eqz v0, :cond_0

    iget-boolean v0, p0, Landroidx/fragment/app/n;->z:Z

    if-nez v0, :cond_0

    iget-object v0, p0, Landroidx/fragment/app/n;->F:Landroid/view/View;

    if-eqz v0, :cond_0

    invoke-virtual {v0}, Landroid/view/View;->getWindowToken()Landroid/os/IBinder;

    move-result-object v0

    if-eqz v0, :cond_0

    iget-object p0, p0, Landroidx/fragment/app/n;->F:Landroid/view/View;

    invoke-virtual {p0}, Landroid/view/View;->getVisibility()I

    move-result p0

    if-nez p0, :cond_0

    const/4 p0, 0x1

    goto :goto_0

    :cond_0
    const/4 p0, 0x0

    :goto_0
    return p0
.end method

.method public final toString()Ljava/lang/String;
    .locals 2

    new-instance v0, Ljava/lang/StringBuilder;

    const/16 v1, 0x80

    invoke-direct {v0, v1}, Ljava/lang/StringBuilder;-><init>(I)V

    invoke-virtual {p0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    move-result-object v1

    invoke-virtual {v1}, Ljava/lang/Class;->getSimpleName()Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string v1, "{"

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-static {p0}, Ljava/lang/System;->identityHashCode(Ljava/lang/Object;)I

    move-result v1

    invoke-static {v1}, Ljava/lang/Integer;->toHexString(I)Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string v1, "} ("

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    iget-object v1, p0, Landroidx/fragment/app/n;->f:Ljava/lang/String;

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    iget v1, p0, Landroidx/fragment/app/n;->w:I

    if-eqz v1, :cond_0

    const-string v1, " id=0x"

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    iget v1, p0, Landroidx/fragment/app/n;->w:I

    invoke-static {v1}, Ljava/lang/Integer;->toHexString(I)Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    :cond_0
    iget-object v1, p0, Landroidx/fragment/app/n;->y:Ljava/lang/String;

    if-eqz v1, :cond_1

    const-string v1, " tag="

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    iget-object p0, p0, Landroidx/fragment/app/n;->y:Ljava/lang/String;

    invoke-virtual {v0, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    :cond_1
    const-string p0, ")"

    invoke-virtual {v0, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p0

    return-object p0
.end method

.method public u(IILandroid/content/Intent;)V
    .locals 2
    .annotation runtime Ljava/lang/Deprecated;
    .end annotation

    const/4 v0, 0x2

    invoke-static {v0}, Landroidx/fragment/app/x;->H(I)Z

    move-result v0

    if-eqz v0, :cond_0

    new-instance v0, Ljava/lang/StringBuilder;

    const-string v1, "Fragment "

    invoke-direct {v0, v1}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-virtual {v0, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    const-string p0, " received the following in onActivityResult(): requestCode: "

    invoke-virtual {v0, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v0, p1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const-string p0, " resultCode: "

    invoke-virtual {v0, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v0, p2}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const-string p0, " data: "

    invoke-virtual {v0, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v0, p3}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p0

    const-string p1, "FragmentManager"

    invoke-static {p1, p0}, Landroid/util/Log;->v(Ljava/lang/String;Ljava/lang/String;)I

    :cond_0
    return-void
.end method

.method public v(Landroid/content/Context;)V
    .locals 1

    const/4 p1, 0x1

    iput-boolean p1, p0, Landroidx/fragment/app/n;->D:Z

    iget-object v0, p0, Landroidx/fragment/app/n;->t:Landroidx/fragment/app/u;

    if-nez v0, :cond_0

    const/4 v0, 0x0

    goto :goto_0

    :cond_0
    iget-object v0, v0, Landroidx/fragment/app/u;->f:Landroid/app/Activity;

    :goto_0
    if-eqz v0, :cond_1

    iput-boolean p1, p0, Landroidx/fragment/app/n;->D:Z

    :cond_1
    return-void
.end method

.method public w(Landroid/os/Bundle;)V
    .locals 3

    const/4 v0, 0x1

    iput-boolean v0, p0, Landroidx/fragment/app/n;->D:Z

    const/4 v1, 0x0

    if-eqz p1, :cond_0

    const-string v2, "android:support:fragments"

    invoke-virtual {p1, v2}, Landroid/os/Bundle;->getParcelable(Ljava/lang/String;)Landroid/os/Parcelable;

    move-result-object p1

    if-eqz p1, :cond_0

    iget-object v2, p0, Landroidx/fragment/app/n;->u:Landroidx/fragment/app/y;

    invoke-virtual {v2, p1}, Landroidx/fragment/app/x;->S(Landroid/os/Parcelable;)V

    iget-object p1, p0, Landroidx/fragment/app/n;->u:Landroidx/fragment/app/y;

    iput-boolean v1, p1, Landroidx/fragment/app/x;->y:Z

    iput-boolean v1, p1, Landroidx/fragment/app/x;->z:Z

    iget-object v2, p1, Landroidx/fragment/app/x;->F:Landroidx/fragment/app/a0;

    iput-boolean v1, v2, Landroidx/fragment/app/a0;->h:Z

    invoke-virtual {p1, v0}, Landroidx/fragment/app/x;->t(I)V

    :cond_0
    iget-object p0, p0, Landroidx/fragment/app/n;->u:Landroidx/fragment/app/y;

    iget p1, p0, Landroidx/fragment/app/x;->m:I

    if-lt p1, v0, :cond_1

    move p1, v0

    goto :goto_0

    :cond_1
    move p1, v1

    :goto_0
    if-nez p1, :cond_2

    iput-boolean v1, p0, Landroidx/fragment/app/x;->y:Z

    iput-boolean v1, p0, Landroidx/fragment/app/x;->z:Z

    iget-object p1, p0, Landroidx/fragment/app/x;->F:Landroidx/fragment/app/a0;

    iput-boolean v1, p1, Landroidx/fragment/app/a0;->h:Z

    invoke-virtual {p0, v0}, Landroidx/fragment/app/x;->t(I)V

    :cond_2
    return-void
.end method

.method public x(Landroid/view/LayoutInflater;Landroid/view/ViewGroup;Landroid/os/Bundle;)Landroid/view/View;
    .locals 0

    const/4 p0, 0x0

    return-object p0
.end method

.method public y()V
    .locals 1

    const/4 v0, 0x1

    iput-boolean v0, p0, Landroidx/fragment/app/n;->D:Z

    return-void
.end method

.method public z()V
    .locals 1

    const/4 v0, 0x1

    iput-boolean v0, p0, Landroidx/fragment/app/n;->D:Z

    return-void
.end method
