.class public Landroidx/fragment/app/l$b;
.super Ljava/lang/Object;
.source "SourceFile"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Landroidx/fragment/app/l;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x9
    name = "b"
.end annotation


# instance fields
.field public final a:Landroidx/fragment/app/q0$b;

.field public final b:La0/c;


# direct methods
.method public constructor <init>(Landroidx/fragment/app/q0$b;La0/c;)V
    .locals 0

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Landroidx/fragment/app/l$b;->a:Landroidx/fragment/app/q0$b;

    iput-object p2, p0, Landroidx/fragment/app/l$b;->b:La0/c;

    return-void
.end method


# virtual methods
.method public final a()V
    .locals 2

    iget-object v0, p0, Landroidx/fragment/app/l$b;->a:Landroidx/fragment/app/q0$b;

    iget-object v1, v0, Landroidx/fragment/app/q0$b;->e:Ljava/util/HashSet;

    iget-object p0, p0, Landroidx/fragment/app/l$b;->b:La0/c;

    invoke-virtual {v1, p0}, Ljava/util/HashSet;->remove(Ljava/lang/Object;)Z

    move-result p0

    if-eqz p0, :cond_0

    invoke-virtual {v1}, Ljava/util/HashSet;->isEmpty()Z

    move-result p0

    if-eqz p0, :cond_0

    invoke-virtual {v0}, Landroidx/fragment/app/q0$b;->b()V

    :cond_0
    return-void
.end method

.method public final b()Z
    .locals 2

    iget-object p0, p0, Landroidx/fragment/app/l$b;->a:Landroidx/fragment/app/q0$b;

    iget-object v0, p0, Landroidx/fragment/app/q0$b;->c:Landroidx/fragment/app/n;

    iget-object v0, v0, Landroidx/fragment/app/n;->F:Landroid/view/View;

    invoke-static {v0}, Landroidx/activity/result/d;->c(Landroid/view/View;)I

    move-result v0

    iget p0, p0, Landroidx/fragment/app/q0$b;->a:I

    if-eq v0, p0, :cond_1

    const/4 v1, 0x2

    if-eq v0, v1, :cond_0

    if-eq p0, v1, :cond_0

    goto :goto_0

    :cond_0
    const/4 p0, 0x0

    goto :goto_1

    :cond_1
    :goto_0
    const/4 p0, 0x1

    :goto_1
    return p0
.end method
