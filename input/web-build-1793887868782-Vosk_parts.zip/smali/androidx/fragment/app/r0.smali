.class public final Landroidx/fragment/app/r0;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements La0/c$a;


# instance fields
.field public final synthetic a:Landroidx/fragment/app/q0$b;


# direct methods
.method public constructor <init>(Landroidx/fragment/app/q0$b;)V
    .locals 0

    iput-object p1, p0, Landroidx/fragment/app/r0;->a:Landroidx/fragment/app/q0$b;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public final onCancel()V
    .locals 0

    iget-object p0, p0, Landroidx/fragment/app/r0;->a:Landroidx/fragment/app/q0$b;

    invoke-virtual {p0}, Landroidx/fragment/app/q0$b;->a()V

    return-void
.end method
