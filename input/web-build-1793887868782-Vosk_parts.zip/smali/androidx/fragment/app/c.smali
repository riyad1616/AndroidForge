.class public final Landroidx/fragment/app/c;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Ljava/lang/Runnable;


# instance fields
.field public final synthetic b:Ljava/util/List;

.field public final synthetic c:Landroidx/fragment/app/q0$b;

.field public final synthetic d:Landroidx/fragment/app/l;


# direct methods
.method public constructor <init>(Landroidx/fragment/app/l;Ljava/util/ArrayList;Landroidx/fragment/app/q0$b;)V
    .locals 0

    iput-object p1, p0, Landroidx/fragment/app/c;->d:Landroidx/fragment/app/l;

    iput-object p2, p0, Landroidx/fragment/app/c;->b:Ljava/util/List;

    iput-object p3, p0, Landroidx/fragment/app/c;->c:Landroidx/fragment/app/q0$b;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public final run()V
    .locals 3

    iget-object v0, p0, Landroidx/fragment/app/c;->b:Ljava/util/List;

    iget-object v1, p0, Landroidx/fragment/app/c;->c:Landroidx/fragment/app/q0$b;

    invoke-interface {v0, v1}, Ljava/util/List;->contains(Ljava/lang/Object;)Z

    move-result v2

    if-eqz v2, :cond_0

    invoke-interface {v0, v1}, Ljava/util/List;->remove(Ljava/lang/Object;)Z

    iget-object p0, p0, Landroidx/fragment/app/c;->d:Landroidx/fragment/app/l;

    invoke-virtual {p0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    iget-object p0, v1, Landroidx/fragment/app/q0$b;->c:Landroidx/fragment/app/n;

    iget-object p0, p0, Landroidx/fragment/app/n;->F:Landroid/view/View;

    iget v0, v1, Landroidx/fragment/app/q0$b;->a:I

    invoke-static {v0, p0}, Landroidx/activity/result/d;->a(ILandroid/view/View;)V

    :cond_0
    return-void
.end method
