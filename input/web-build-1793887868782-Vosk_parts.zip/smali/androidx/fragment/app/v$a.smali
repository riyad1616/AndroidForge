.class public final Landroidx/fragment/app/v$a;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Landroid/view/View$OnAttachStateChangeListener;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Landroidx/fragment/app/v;->onCreateView(Landroid/view/View;Ljava/lang/String;Landroid/content/Context;Landroid/util/AttributeSet;)Landroid/view/View;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x1
    name = null
.end annotation


# instance fields
.field public final synthetic b:Landroidx/fragment/app/d0;

.field public final synthetic c:Landroidx/fragment/app/v;


# direct methods
.method public constructor <init>(Landroidx/fragment/app/v;Landroidx/fragment/app/d0;)V
    .locals 0

    iput-object p1, p0, Landroidx/fragment/app/v$a;->c:Landroidx/fragment/app/v;

    iput-object p2, p0, Landroidx/fragment/app/v$a;->b:Landroidx/fragment/app/d0;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public final onViewAttachedToWindow(Landroid/view/View;)V
    .locals 1

    iget-object p1, p0, Landroidx/fragment/app/v$a;->b:Landroidx/fragment/app/d0;

    iget-object v0, p1, Landroidx/fragment/app/d0;->c:Landroidx/fragment/app/n;

    invoke-virtual {p1}, Landroidx/fragment/app/d0;->k()V

    iget-object p1, v0, Landroidx/fragment/app/n;->F:Landroid/view/View;

    invoke-virtual {p1}, Landroid/view/View;->getParent()Landroid/view/ViewParent;

    move-result-object p1

    check-cast p1, Landroid/view/ViewGroup;

    iget-object p0, p0, Landroidx/fragment/app/v$a;->c:Landroidx/fragment/app/v;

    iget-object p0, p0, Landroidx/fragment/app/v;->b:Landroidx/fragment/app/x;

    invoke-virtual {p0}, Landroidx/fragment/app/x;->F()Landroidx/fragment/app/s0;

    move-result-object p0

    invoke-static {p1, p0}, Landroidx/fragment/app/q0;->f(Landroid/view/ViewGroup;Landroidx/fragment/app/s0;)Landroidx/fragment/app/q0;

    move-result-object p0

    invoke-virtual {p0}, Landroidx/fragment/app/q0;->e()V

    return-void
.end method

.method public final onViewDetachedFromWindow(Landroid/view/View;)V
    .locals 0

    return-void
.end method
