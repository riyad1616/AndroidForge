.class public final Landroidx/fragment/app/x$c;
.super Landroidx/activity/i;
.source "SourceFile"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Landroidx/fragment/app/x;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x1
    name = null
.end annotation


# instance fields
.field public final synthetic c:Landroidx/fragment/app/x;


# direct methods
.method public constructor <init>(Landroidx/fragment/app/x;)V
    .locals 0

    iput-object p1, p0, Landroidx/fragment/app/x$c;->c:Landroidx/fragment/app/x;

    invoke-direct {p0}, Landroidx/activity/i;-><init>()V

    return-void
.end method


# virtual methods
.method public final a()V
    .locals 1

    iget-object p0, p0, Landroidx/fragment/app/x$c;->c:Landroidx/fragment/app/x;

    const/4 v0, 0x1

    invoke-virtual {p0, v0}, Landroidx/fragment/app/x;->x(Z)Z

    iget-object v0, p0, Landroidx/fragment/app/x;->h:Landroidx/fragment/app/x$c;

    iget-boolean v0, v0, Landroidx/activity/i;->a:Z

    if-eqz v0, :cond_0

    invoke-virtual {p0}, Landroidx/fragment/app/x;->O()Z

    goto :goto_0

    :cond_0
    iget-object p0, p0, Landroidx/fragment/app/x;->g:Landroidx/activity/OnBackPressedDispatcher;

    invoke-virtual {p0}, Landroidx/activity/OnBackPressedDispatcher;->b()V

    :goto_0
    return-void
.end method
