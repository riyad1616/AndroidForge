.class public abstract Landroidx/fragment/app/u;
.super Landroidx/activity/result/c;
.source "SourceFile"


# annotations
.annotation system Ldalvik/annotation/Signature;
    value = {
        "<E:",
        "Ljava/lang/Object;",
        ">",
        "Landroidx/activity/result/c;"
    }
.end annotation


# instance fields
.field public final f:Landroid/app/Activity;

.field public final g:Landroid/content/Context;

.field public final h:Landroid/os/Handler;

.field public final i:Landroidx/fragment/app/y;


# direct methods
.method public constructor <init>(Landroidx/fragment/app/q;)V
    .locals 2

    new-instance v0, Landroid/os/Handler;

    invoke-direct {v0}, Landroid/os/Handler;-><init>()V

    invoke-direct {p0}, Landroidx/activity/result/c;-><init>()V

    new-instance v1, Landroidx/fragment/app/y;

    invoke-direct {v1}, Landroidx/fragment/app/y;-><init>()V

    iput-object v1, p0, Landroidx/fragment/app/u;->i:Landroidx/fragment/app/y;

    iput-object p1, p0, Landroidx/fragment/app/u;->f:Landroid/app/Activity;

    if-eqz p1, :cond_0

    iput-object p1, p0, Landroidx/fragment/app/u;->g:Landroid/content/Context;

    iput-object v0, p0, Landroidx/fragment/app/u;->h:Landroid/os/Handler;

    return-void

    :cond_0
    new-instance p0, Ljava/lang/NullPointerException;

    const-string p1, "context == null"

    invoke-direct {p0, p1}, Ljava/lang/NullPointerException;-><init>(Ljava/lang/String;)V

    throw p0
.end method


# virtual methods
.method public abstract n(Ljava/io/PrintWriter;[Ljava/lang/String;)V
.end method

.method public abstract o()Landroidx/fragment/app/q;
.end method

.method public abstract p()Landroid/view/LayoutInflater;
.end method

.method public abstract q()V
.end method
