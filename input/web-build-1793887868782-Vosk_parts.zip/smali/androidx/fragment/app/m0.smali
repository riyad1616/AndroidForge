.class public final Landroidx/fragment/app/m0;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Landroidx/lifecycle/f;
.implements Lt0/d;
.implements Landroidx/lifecycle/e0;


# instance fields
.field public final b:Landroidx/lifecycle/d0;

.field public c:Landroidx/lifecycle/l;

.field public d:Lt0/c;


# direct methods
.method public constructor <init>(Landroidx/lifecycle/d0;)V
    .locals 1

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v0, 0x0

    iput-object v0, p0, Landroidx/fragment/app/m0;->c:Landroidx/lifecycle/l;

    iput-object v0, p0, Landroidx/fragment/app/m0;->d:Lt0/c;

    iput-object p1, p0, Landroidx/fragment/app/m0;->b:Landroidx/lifecycle/d0;

    return-void
.end method


# virtual methods
.method public final b()Lt0/b;
    .locals 0

    invoke-virtual {p0}, Landroidx/fragment/app/m0;->e()V

    iget-object p0, p0, Landroidx/fragment/app/m0;->d:Lt0/c;

    iget-object p0, p0, Lt0/c;->b:Lt0/b;

    return-object p0
.end method

.method public final c(Landroidx/lifecycle/g$b;)V
    .locals 0

    iget-object p0, p0, Landroidx/fragment/app/m0;->c:Landroidx/lifecycle/l;

    invoke-virtual {p0, p1}, Landroidx/lifecycle/l;->e(Landroidx/lifecycle/g$b;)V

    return-void
.end method

.method public final e()V
    .locals 1

    iget-object v0, p0, Landroidx/fragment/app/m0;->c:Landroidx/lifecycle/l;

    if-nez v0, :cond_0

    new-instance v0, Landroidx/lifecycle/l;

    invoke-direct {v0, p0}, Landroidx/lifecycle/l;-><init>(Landroidx/lifecycle/k;)V

    iput-object v0, p0, Landroidx/fragment/app/m0;->c:Landroidx/lifecycle/l;

    new-instance v0, Lt0/c;

    invoke-direct {v0, p0}, Lt0/c;-><init>(Lt0/d;)V

    iput-object v0, p0, Landroidx/fragment/app/m0;->d:Lt0/c;

    :cond_0
    return-void
.end method

.method public final i()Landroidx/lifecycle/d0;
    .locals 0

    invoke-virtual {p0}, Landroidx/fragment/app/m0;->e()V

    iget-object p0, p0, Landroidx/fragment/app/m0;->b:Landroidx/lifecycle/d0;

    return-object p0
.end method

.method public final k()Landroidx/lifecycle/l;
    .locals 0

    invoke-virtual {p0}, Landroidx/fragment/app/m0;->e()V

    iget-object p0, p0, Landroidx/fragment/app/m0;->c:Landroidx/lifecycle/l;

    return-object p0
.end method
