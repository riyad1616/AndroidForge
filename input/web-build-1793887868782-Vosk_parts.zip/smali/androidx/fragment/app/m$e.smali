.class public final Landroidx/fragment/app/m$e;
.super Landroidx/activity/result/c;
.source "SourceFile"


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Landroidx/fragment/app/m;->e()Landroidx/activity/result/c;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x1
    name = null
.end annotation


# instance fields
.field public final synthetic f:Landroidx/activity/result/c;

.field public final synthetic g:Landroidx/fragment/app/m;


# direct methods
.method public constructor <init>(Landroidx/fragment/app/m;Landroidx/fragment/app/n$a;)V
    .locals 0

    iput-object p1, p0, Landroidx/fragment/app/m$e;->g:Landroidx/fragment/app/m;

    iput-object p2, p0, Landroidx/fragment/app/m$e;->f:Landroidx/activity/result/c;

    invoke-direct {p0}, Landroidx/activity/result/c;-><init>()V

    return-void
.end method


# virtual methods
.method public final f(I)Landroid/view/View;
    .locals 2

    iget-object v0, p0, Landroidx/fragment/app/m$e;->f:Landroidx/activity/result/c;

    invoke-virtual {v0}, Landroidx/activity/result/c;->m()Z

    move-result v1

    if-eqz v1, :cond_0

    invoke-virtual {v0, p1}, Landroidx/activity/result/c;->f(I)Landroid/view/View;

    move-result-object p0

    return-object p0

    :cond_0
    iget-object p0, p0, Landroidx/fragment/app/m$e;->g:Landroidx/fragment/app/m;

    iget-object p0, p0, Landroidx/fragment/app/m;->d0:Landroid/app/Dialog;

    if-eqz p0, :cond_1

    invoke-virtual {p0, p1}, Landroid/app/Dialog;->findViewById(I)Landroid/view/View;

    move-result-object p0

    goto :goto_0

    :cond_1
    const/4 p0, 0x0

    :goto_0
    return-object p0
.end method

.method public final m()Z
    .locals 1

    iget-object v0, p0, Landroidx/fragment/app/m$e;->f:Landroidx/activity/result/c;

    invoke-virtual {v0}, Landroidx/activity/result/c;->m()Z

    move-result v0

    if-nez v0, :cond_1

    iget-object p0, p0, Landroidx/fragment/app/m$e;->g:Landroidx/fragment/app/m;

    iget-boolean p0, p0, Landroidx/fragment/app/m;->g0:Z

    if-eqz p0, :cond_0

    goto :goto_0

    :cond_0
    const/4 p0, 0x0

    goto :goto_1

    :cond_1
    :goto_0
    const/4 p0, 0x1

    :goto_1
    return p0
.end method
