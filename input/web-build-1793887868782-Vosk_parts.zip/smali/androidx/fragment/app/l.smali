.class public final Landroidx/fragment/app/l;
.super Landroidx/fragment/app/q0;
.source "SourceFile"


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Landroidx/fragment/app/l$c;,
        Landroidx/fragment/app/l$a;,
        Landroidx/fragment/app/l$b;
    }
.end annotation


# direct methods
.method public constructor <init>(Landroid/view/ViewGroup;)V
    .locals 0

    invoke-direct {p0, p1}, Landroidx/fragment/app/q0;-><init>(Landroid/view/ViewGroup;)V

    return-void
.end method

.method public static i(Ljava/util/ArrayList;Landroid/view/View;)V
    .locals 4

    instance-of v0, p1, Landroid/view/ViewGroup;

    if-eqz v0, :cond_2

    move-object v0, p1

    check-cast v0, Landroid/view/ViewGroup;

    invoke-static {v0}, Le0/e0;->b(Landroid/view/ViewGroup;)Z

    move-result v1

    if-eqz v1, :cond_0

    invoke-virtual {p0, p1}, Ljava/util/ArrayList;->contains(Ljava/lang/Object;)Z

    move-result p1

    if-nez p1, :cond_3

    invoke-virtual {p0, v0}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    goto :goto_1

    :cond_0
    invoke-virtual {v0}, Landroid/view/ViewGroup;->getChildCount()I

    move-result p1

    const/4 v1, 0x0

    :goto_0
    if-ge v1, p1, :cond_3

    invoke-virtual {v0, v1}, Landroid/view/ViewGroup;->getChildAt(I)Landroid/view/View;

    move-result-object v2

    invoke-virtual {v2}, Landroid/view/View;->getVisibility()I

    move-result v3

    if-nez v3, :cond_1

    invoke-static {p0, v2}, Landroidx/fragment/app/l;->i(Ljava/util/ArrayList;Landroid/view/View;)V

    :cond_1
    add-int/lit8 v1, v1, 0x1

    goto :goto_0

    :cond_2
    invoke-virtual {p0, p1}, Ljava/util/ArrayList;->contains(Ljava/lang/Object;)Z

    move-result v0

    if-nez v0, :cond_3

    invoke-virtual {p0, p1}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    :cond_3
    :goto_1
    return-void
.end method

.method public static j(Ll/b;Landroid/view/View;)V
    .locals 4

    sget-object v0, Le0/a0;->a:Ljava/util/WeakHashMap;

    invoke-static {p1}, Le0/a0$i;->k(Landroid/view/View;)Ljava/lang/String;

    move-result-object v0

    if-eqz v0, :cond_0

    invoke-virtual {p0, v0, p1}, Ll/h;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    :cond_0
    instance-of v0, p1, Landroid/view/ViewGroup;

    if-eqz v0, :cond_2

    check-cast p1, Landroid/view/ViewGroup;

    invoke-virtual {p1}, Landroid/view/ViewGroup;->getChildCount()I

    move-result v0

    const/4 v1, 0x0

    :goto_0
    if-ge v1, v0, :cond_2

    invoke-virtual {p1, v1}, Landroid/view/ViewGroup;->getChildAt(I)Landroid/view/View;

    move-result-object v2

    invoke-virtual {v2}, Landroid/view/View;->getVisibility()I

    move-result v3

    if-nez v3, :cond_1

    invoke-static {p0, v2}, Landroidx/fragment/app/l;->j(Ll/b;Landroid/view/View;)V

    :cond_1
    add-int/lit8 v1, v1, 0x1

    goto :goto_0

    :cond_2
    return-void
.end method

.method public static k(Ll/b;Ljava/util/Collection;)V
    .locals 3

    invoke-virtual {p0}, Ll/b;->entrySet()Ljava/util/Set;

    move-result-object p0

    check-cast p0, Ll/g$b;

    invoke-virtual {p0}, Ll/g$b;->iterator()Ljava/util/Iterator;

    move-result-object p0

    :cond_0
    :goto_0
    move-object v0, p0

    check-cast v0, Ll/g$d;

    invoke-virtual {v0}, Ll/g$d;->hasNext()Z

    move-result v1

    if-eqz v1, :cond_1

    invoke-virtual {v0}, Ll/g$d;->next()Ljava/lang/Object;

    move-object v1, v0

    check-cast v1, Ljava/util/Map$Entry;

    invoke-interface {v1}, Ljava/util/Map$Entry;->getValue()Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Landroid/view/View;

    sget-object v2, Le0/a0;->a:Ljava/util/WeakHashMap;

    invoke-static {v1}, Le0/a0$i;->k(Landroid/view/View;)Ljava/lang/String;

    move-result-object v1

    invoke-interface {p1, v1}, Ljava/util/Collection;->contains(Ljava/lang/Object;)Z

    move-result v1

    if-nez v1, :cond_0

    invoke-virtual {v0}, Ll/g$d;->remove()V

    goto :goto_0

    :cond_1
    return-void
.end method


# virtual methods
.method public final b(Ljava/util/ArrayList;Z)V
    .locals 32

    move-object/from16 v0, p0

    move/from16 v1, p2

    invoke-virtual/range {p1 .. p1}, Ljava/util/ArrayList;->iterator()Ljava/util/Iterator;

    move-result-object v2

    const/4 v4, 0x0

    const/4 v5, 0x0

    :cond_0
    :goto_0
    invoke-interface {v2}, Ljava/util/Iterator;->hasNext()Z

    move-result v6

    const/4 v7, 0x3

    const/4 v8, 0x2

    const/4 v9, 0x1

    if-eqz v6, :cond_3

    invoke-interface {v2}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v6

    check-cast v6, Landroidx/fragment/app/q0$b;

    iget-object v10, v6, Landroidx/fragment/app/q0$b;->c:Landroidx/fragment/app/n;

    iget-object v10, v10, Landroidx/fragment/app/n;->F:Landroid/view/View;

    invoke-static {v10}, Landroidx/activity/result/d;->c(Landroid/view/View;)I

    move-result v10

    iget v11, v6, Landroidx/fragment/app/q0$b;->a:I

    invoke-static {v11}, Ln/g;->c(I)I

    move-result v11

    if-eqz v11, :cond_2

    if-eq v11, v9, :cond_1

    if-eq v11, v8, :cond_2

    if-eq v11, v7, :cond_2

    goto :goto_0

    :cond_1
    if-eq v10, v8, :cond_0

    move-object v5, v6

    goto :goto_0

    :cond_2
    if-ne v10, v8, :cond_0

    if-nez v4, :cond_0

    move-object v4, v6

    goto :goto_0

    :cond_3
    new-instance v2, Ljava/util/ArrayList;

    invoke-direct {v2}, Ljava/util/ArrayList;-><init>()V

    new-instance v6, Ljava/util/ArrayList;

    invoke-direct {v6}, Ljava/util/ArrayList;-><init>()V

    new-instance v10, Ljava/util/ArrayList;

    move-object/from16 v11, p1

    invoke-direct {v10, v11}, Ljava/util/ArrayList;-><init>(Ljava/util/Collection;)V

    invoke-virtual/range {p1 .. p1}, Ljava/util/ArrayList;->iterator()Ljava/util/Iterator;

    move-result-object v11

    :goto_1
    invoke-interface {v11}, Ljava/util/Iterator;->hasNext()Z

    move-result v12

    if-eqz v12, :cond_6

    invoke-interface {v11}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v12

    check-cast v12, Landroidx/fragment/app/q0$b;

    new-instance v14, La0/c;

    invoke-direct {v14}, La0/c;-><init>()V

    invoke-virtual {v12}, Landroidx/fragment/app/q0$b;->d()V

    iget-object v15, v12, Landroidx/fragment/app/q0$b;->e:Ljava/util/HashSet;

    invoke-virtual {v15, v14}, Ljava/util/HashSet;->add(Ljava/lang/Object;)Z

    new-instance v15, Landroidx/fragment/app/l$a;

    invoke-direct {v15, v12, v14, v1}, Landroidx/fragment/app/l$a;-><init>(Landroidx/fragment/app/q0$b;La0/c;Z)V

    invoke-virtual {v2, v15}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    new-instance v14, La0/c;

    invoke-direct {v14}, La0/c;-><init>()V

    invoke-virtual {v12}, Landroidx/fragment/app/q0$b;->d()V

    iget-object v15, v12, Landroidx/fragment/app/q0$b;->e:Ljava/util/HashSet;

    invoke-virtual {v15, v14}, Ljava/util/HashSet;->add(Ljava/lang/Object;)Z

    new-instance v15, Landroidx/fragment/app/l$c;

    if-eqz v1, :cond_4

    if-ne v12, v4, :cond_5

    goto :goto_2

    :cond_4
    if-ne v12, v5, :cond_5

    :goto_2
    move v13, v9

    goto :goto_3

    :cond_5
    const/4 v13, 0x0

    :goto_3
    invoke-direct {v15, v12, v14, v1, v13}, Landroidx/fragment/app/l$c;-><init>(Landroidx/fragment/app/q0$b;La0/c;ZZ)V

    invoke-virtual {v6, v15}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    new-instance v13, Landroidx/fragment/app/c;

    invoke-direct {v13, v0, v10, v12}, Landroidx/fragment/app/c;-><init>(Landroidx/fragment/app/l;Ljava/util/ArrayList;Landroidx/fragment/app/q0$b;)V

    iget-object v12, v12, Landroidx/fragment/app/q0$b;->d:Ljava/util/ArrayList;

    invoke-virtual {v12, v13}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    goto :goto_1

    :cond_6
    new-instance v11, Ljava/util/HashMap;

    invoke-direct {v11}, Ljava/util/HashMap;-><init>()V

    invoke-virtual {v6}, Ljava/util/ArrayList;->iterator()Ljava/util/Iterator;

    move-result-object v12

    const/4 v15, 0x0

    :goto_4
    invoke-interface {v12}, Ljava/util/Iterator;->hasNext()Z

    move-result v14

    if-eqz v14, :cond_e

    invoke-interface {v12}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v14

    check-cast v14, Landroidx/fragment/app/l$c;

    invoke-virtual {v14}, Landroidx/fragment/app/l$b;->b()Z

    move-result v16

    if-eqz v16, :cond_7

    move-object/from16 v16, v12

    goto/16 :goto_7

    :cond_7
    iget-object v9, v14, Landroidx/fragment/app/l$c;->c:Ljava/lang/Object;

    invoke-virtual {v14, v9}, Landroidx/fragment/app/l$c;->c(Ljava/lang/Object;)Landroidx/fragment/app/l0;

    move-result-object v8

    iget-object v7, v14, Landroidx/fragment/app/l$c;->e:Ljava/lang/Object;

    invoke-virtual {v14, v7}, Landroidx/fragment/app/l$c;->c(Ljava/lang/Object;)Landroidx/fragment/app/l0;

    move-result-object v3

    const-string v13, " returned Transition "

    move-object/from16 v16, v12

    const-string v12, "Mixing framework transitions and AndroidX transitions is not allowed. Fragment "

    iget-object v14, v14, Landroidx/fragment/app/l$b;->a:Landroidx/fragment/app/q0$b;

    if-eqz v8, :cond_9

    if-eqz v3, :cond_9

    if-ne v8, v3, :cond_8

    goto :goto_5

    :cond_8
    new-instance v0, Ljava/lang/IllegalArgumentException;

    new-instance v1, Ljava/lang/StringBuilder;

    invoke-direct {v1, v12}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    iget-object v2, v14, Landroidx/fragment/app/q0$b;->c:Landroidx/fragment/app/n;

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    invoke-virtual {v1, v13}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v1, v9}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    const-string v2, " which uses a different Transition  type than its shared element transition "

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v1, v7}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    invoke-direct {v0, v1}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    throw v0

    :cond_9
    :goto_5
    if-eqz v8, :cond_a

    goto :goto_6

    :cond_a
    move-object v8, v3

    :goto_6
    if-nez v15, :cond_b

    move-object v15, v8

    goto :goto_7

    :cond_b
    if-eqz v8, :cond_d

    if-ne v15, v8, :cond_c

    goto :goto_7

    :cond_c
    new-instance v0, Ljava/lang/IllegalArgumentException;

    new-instance v1, Ljava/lang/StringBuilder;

    invoke-direct {v1, v12}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    iget-object v2, v14, Landroidx/fragment/app/q0$b;->c:Landroidx/fragment/app/n;

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    invoke-virtual {v1, v13}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v1, v9}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    const-string v2, " which uses a different Transition  type than other Fragments."

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    invoke-direct {v0, v1}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    throw v0

    :cond_d
    :goto_7
    move-object/from16 v12, v16

    const/4 v7, 0x3

    const/4 v8, 0x2

    const/4 v9, 0x1

    goto/16 :goto_4

    :cond_e
    iget-object v0, v0, Landroidx/fragment/app/q0;->a:Landroid/view/ViewGroup;

    const-string v8, "FragmentManager"

    if-nez v15, :cond_10

    invoke-virtual {v6}, Ljava/util/ArrayList;->iterator()Ljava/util/Iterator;

    move-result-object v1

    :goto_8
    invoke-interface {v1}, Ljava/util/Iterator;->hasNext()Z

    move-result v3

    if-eqz v3, :cond_f

    invoke-interface {v1}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v3

    check-cast v3, Landroidx/fragment/app/l$c;

    iget-object v4, v3, Landroidx/fragment/app/l$b;->a:Landroidx/fragment/app/q0$b;

    sget-object v5, Ljava/lang/Boolean;->FALSE:Ljava/lang/Boolean;

    invoke-virtual {v11, v4, v5}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    invoke-virtual {v3}, Landroidx/fragment/app/l$b;->a()V

    goto :goto_8

    :cond_f
    move-object/from16 v23, v2

    move-object v9, v8

    move-object/from16 v26, v10

    :goto_9
    const/4 v8, 0x0

    goto/16 :goto_1f

    :cond_10
    new-instance v3, Landroid/view/View;

    invoke-virtual {v0}, Landroid/view/View;->getContext()Landroid/content/Context;

    move-result-object v7

    invoke-direct {v3, v7}, Landroid/view/View;-><init>(Landroid/content/Context;)V

    new-instance v7, Landroid/graphics/Rect;

    invoke-direct {v7}, Landroid/graphics/Rect;-><init>()V

    new-instance v9, Ljava/util/ArrayList;

    invoke-direct {v9}, Ljava/util/ArrayList;-><init>()V

    new-instance v12, Ljava/util/ArrayList;

    invoke-direct {v12}, Ljava/util/ArrayList;-><init>()V

    new-instance v13, Ll/b;

    invoke-direct {v13}, Ll/b;-><init>()V

    invoke-virtual {v6}, Ljava/util/ArrayList;->iterator()Ljava/util/Iterator;

    move-result-object v22

    move-object/from16 v23, v2

    move-object v2, v4

    move-object v14, v5

    move-object/from16 v24, v8

    const/16 p0, 0x0

    const/4 v8, 0x0

    const/16 v25, 0x0

    :goto_a
    invoke-interface/range {v22 .. v22}, Ljava/util/Iterator;->hasNext()Z

    move-result v16

    if-eqz v16, :cond_23

    invoke-interface/range {v22 .. v22}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v16

    move-object/from16 v26, v10

    move-object/from16 v10, v16

    check-cast v10, Landroidx/fragment/app/l$c;

    iget-object v10, v10, Landroidx/fragment/app/l$c;->e:Ljava/lang/Object;

    if-eqz v10, :cond_11

    const/16 v16, 0x1

    goto :goto_b

    :cond_11
    const/16 v16, 0x0

    :goto_b
    if-eqz v16, :cond_22

    if-eqz v2, :cond_22

    if-eqz v14, :cond_22

    invoke-virtual {v15, v10}, Landroidx/fragment/app/l0;->f(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v8

    invoke-virtual {v15, v8}, Landroidx/fragment/app/l0;->t(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v8

    iget-object v10, v14, Landroidx/fragment/app/q0$b;->c:Landroidx/fragment/app/n;

    iget-object v14, v10, Landroidx/fragment/app/n;->I:Landroidx/fragment/app/n$b;

    if-eqz v14, :cond_12

    iget-object v14, v14, Landroidx/fragment/app/n$b;->g:Ljava/util/ArrayList;

    if-nez v14, :cond_13

    :cond_12
    new-instance v14, Ljava/util/ArrayList;

    invoke-direct {v14}, Ljava/util/ArrayList;-><init>()V

    :cond_13
    iget-object v2, v2, Landroidx/fragment/app/q0$b;->c:Landroidx/fragment/app/n;

    move-object/from16 v27, v6

    iget-object v6, v2, Landroidx/fragment/app/n;->I:Landroidx/fragment/app/n$b;

    if-eqz v6, :cond_14

    iget-object v6, v6, Landroidx/fragment/app/n$b;->g:Ljava/util/ArrayList;

    if-nez v6, :cond_15

    :cond_14
    new-instance v6, Ljava/util/ArrayList;

    invoke-direct {v6}, Ljava/util/ArrayList;-><init>()V

    :cond_15
    move-object/from16 v28, v11

    iget-object v11, v2, Landroidx/fragment/app/n;->I:Landroidx/fragment/app/n$b;

    if-eqz v11, :cond_16

    iget-object v11, v11, Landroidx/fragment/app/n$b;->h:Ljava/util/ArrayList;

    if-nez v11, :cond_17

    :cond_16
    new-instance v11, Ljava/util/ArrayList;

    invoke-direct {v11}, Ljava/util/ArrayList;-><init>()V

    :cond_17
    move-object/from16 v29, v3

    move-object/from16 v30, v7

    const/4 v3, 0x0

    :goto_c
    invoke-virtual {v11}, Ljava/util/ArrayList;->size()I

    move-result v7

    move-object/from16 v31, v8

    const/4 v8, -0x1

    if-ge v3, v7, :cond_19

    invoke-virtual {v11, v3}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v7

    invoke-virtual {v14, v7}, Ljava/util/ArrayList;->indexOf(Ljava/lang/Object;)I

    move-result v7

    if-eq v7, v8, :cond_18

    invoke-virtual {v6, v3}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v8

    invoke-virtual {v14, v7, v8}, Ljava/util/ArrayList;->set(ILjava/lang/Object;)Ljava/lang/Object;

    :cond_18
    add-int/lit8 v3, v3, 0x1

    move-object/from16 v8, v31

    goto :goto_c

    :cond_19
    iget-object v3, v10, Landroidx/fragment/app/n;->I:Landroidx/fragment/app/n$b;

    if-eqz v3, :cond_1a

    iget-object v3, v3, Landroidx/fragment/app/n$b;->h:Ljava/util/ArrayList;

    if-nez v3, :cond_1b

    :cond_1a
    new-instance v3, Ljava/util/ArrayList;

    invoke-direct {v3}, Ljava/util/ArrayList;-><init>()V

    :cond_1b
    invoke-virtual {v14}, Ljava/util/ArrayList;->size()I

    move-result v6

    const/4 v7, 0x0

    :goto_d
    if-ge v7, v6, :cond_1c

    invoke-virtual {v14, v7}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v11

    check-cast v11, Ljava/lang/String;

    invoke-virtual {v3, v7}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v16

    move-object/from16 v8, v16

    check-cast v8, Ljava/lang/String;

    invoke-virtual {v13, v11, v8}, Ll/h;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    add-int/lit8 v7, v7, 0x1

    const/4 v8, -0x1

    goto :goto_d

    :cond_1c
    new-instance v6, Ll/b;

    invoke-direct {v6}, Ll/b;-><init>()V

    iget-object v7, v2, Landroidx/fragment/app/n;->F:Landroid/view/View;

    invoke-static {v6, v7}, Landroidx/fragment/app/l;->j(Ll/b;Landroid/view/View;)V

    invoke-static {v6, v14}, Ll/g;->k(Ljava/util/Map;Ljava/util/Collection;)Z

    invoke-virtual {v6}, Ll/b;->keySet()Ljava/util/Set;

    move-result-object v7

    invoke-static {v13, v7}, Ll/g;->k(Ljava/util/Map;Ljava/util/Collection;)Z

    new-instance v7, Ll/b;

    invoke-direct {v7}, Ll/b;-><init>()V

    iget-object v8, v10, Landroidx/fragment/app/n;->F:Landroid/view/View;

    invoke-static {v7, v8}, Landroidx/fragment/app/l;->j(Ll/b;Landroid/view/View;)V

    invoke-static {v7, v3}, Ll/g;->k(Ljava/util/Map;Ljava/util/Collection;)Z

    invoke-virtual {v13}, Ll/b;->values()Ljava/util/Collection;

    move-result-object v8

    invoke-static {v7, v8}, Ll/g;->k(Ljava/util/Map;Ljava/util/Collection;)Z

    sget-object v8, Landroidx/fragment/app/g0;->a:Landroidx/fragment/app/i0;

    iget v8, v13, Ll/h;->d:I

    :cond_1d
    :goto_e
    const/4 v11, -0x1

    add-int/2addr v8, v11

    if-ltz v8, :cond_1e

    invoke-virtual {v13, v8}, Ll/h;->j(I)Ljava/lang/Object;

    move-result-object v16

    move-object/from16 v11, v16

    check-cast v11, Ljava/lang/String;

    invoke-virtual {v7, v11}, Ll/h;->containsKey(Ljava/lang/Object;)Z

    move-result v11

    if-nez v11, :cond_1d

    invoke-virtual {v13, v8}, Ll/h;->i(I)Ljava/lang/Object;

    goto :goto_e

    :cond_1e
    invoke-virtual {v13}, Ll/b;->keySet()Ljava/util/Set;

    move-result-object v8

    invoke-static {v6, v8}, Landroidx/fragment/app/l;->k(Ll/b;Ljava/util/Collection;)V

    invoke-virtual {v13}, Ll/b;->values()Ljava/util/Collection;

    move-result-object v8

    invoke-static {v7, v8}, Landroidx/fragment/app/l;->k(Ll/b;Ljava/util/Collection;)V

    invoke-virtual {v13}, Ll/h;->isEmpty()Z

    move-result v8

    if-eqz v8, :cond_1f

    invoke-virtual {v9}, Ljava/util/ArrayList;->clear()V

    invoke-virtual {v12}, Ljava/util/ArrayList;->clear()V

    move-object/from16 v8, p0

    move-object v2, v4

    move-object v14, v5

    move-object v10, v15

    move-object/from16 v11, v28

    move-object/from16 v3, v29

    move-object/from16 v7, v30

    const/4 v6, 0x0

    goto/16 :goto_11

    :cond_1f
    invoke-static {v10, v2, v1}, Landroidx/fragment/app/g0;->a(Landroidx/fragment/app/n;Landroidx/fragment/app/n;Z)V

    new-instance v2, Landroidx/fragment/app/h;

    invoke-direct {v2, v5, v4, v1, v7}, Landroidx/fragment/app/h;-><init>(Landroidx/fragment/app/q0$b;Landroidx/fragment/app/q0$b;ZLl/b;)V

    invoke-static {v0, v2}, Le0/t;->a(Landroid/view/View;Ljava/lang/Runnable;)V

    invoke-virtual {v6}, Ll/b;->values()Ljava/util/Collection;

    move-result-object v2

    invoke-virtual {v9, v2}, Ljava/util/ArrayList;->addAll(Ljava/util/Collection;)Z

    invoke-virtual {v14}, Ljava/util/ArrayList;->isEmpty()Z

    move-result v2

    if-nez v2, :cond_20

    const/4 v2, 0x0

    invoke-virtual {v14, v2}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v8

    check-cast v8, Ljava/lang/String;

    const/4 v10, 0x0

    invoke-virtual {v6, v8, v10}, Ll/h;->getOrDefault(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v6

    move-object v14, v6

    check-cast v14, Landroid/view/View;

    move-object/from16 v6, v31

    invoke-virtual {v15, v14, v6}, Landroidx/fragment/app/l0;->n(Landroid/view/View;Ljava/lang/Object;)V

    move-object v8, v14

    goto :goto_f

    :cond_20
    move-object/from16 v6, v31

    const/4 v2, 0x0

    const/4 v10, 0x0

    move-object/from16 v8, p0

    :goto_f
    invoke-virtual {v7}, Ll/b;->values()Ljava/util/Collection;

    move-result-object v11

    invoke-virtual {v12, v11}, Ljava/util/ArrayList;->addAll(Ljava/util/Collection;)Z

    invoke-virtual {v3}, Ljava/util/ArrayList;->isEmpty()Z

    move-result v11

    if-nez v11, :cond_21

    invoke-virtual {v3, v2}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v3

    check-cast v3, Ljava/lang/String;

    invoke-virtual {v7, v3, v10}, Ll/h;->getOrDefault(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v2

    check-cast v2, Landroid/view/View;

    if-eqz v2, :cond_21

    new-instance v3, Landroidx/fragment/app/i;

    move-object/from16 v7, v30

    invoke-direct {v3, v15, v2, v7}, Landroidx/fragment/app/i;-><init>(Landroidx/fragment/app/l0;Landroid/view/View;Landroid/graphics/Rect;)V

    invoke-static {v0, v3}, Le0/t;->a(Landroid/view/View;Ljava/lang/Runnable;)V

    move-object/from16 v3, v29

    const/16 v25, 0x1

    goto :goto_10

    :cond_21
    move-object/from16 v7, v30

    move-object/from16 v3, v29

    :goto_10
    invoke-virtual {v15, v6, v3, v9}, Landroidx/fragment/app/l0;->r(Ljava/lang/Object;Landroid/view/View;Ljava/util/ArrayList;)V

    const/16 v16, 0x0

    const/16 v17, 0x0

    const/16 v18, 0x0

    const/16 v19, 0x0

    move-object v14, v15

    move-object v10, v15

    move-object v15, v6

    move-object/from16 v20, v6

    move-object/from16 v21, v12

    invoke-virtual/range {v14 .. v21}, Landroidx/fragment/app/l0;->m(Ljava/lang/Object;Ljava/lang/Object;Ljava/util/ArrayList;Ljava/lang/Object;Ljava/util/ArrayList;Ljava/lang/Object;Ljava/util/ArrayList;)V

    sget-object v2, Ljava/lang/Boolean;->TRUE:Ljava/lang/Boolean;

    move-object/from16 v11, v28

    invoke-virtual {v11, v4, v2}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    invoke-virtual {v11, v5, v2}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    move-object v2, v4

    move-object v14, v5

    goto :goto_11

    :cond_22
    move-object/from16 v27, v6

    move-object v10, v15

    move-object v6, v8

    move-object/from16 v8, p0

    :goto_11
    move-object/from16 p0, v8

    move-object v15, v10

    move-object/from16 v10, v26

    move-object v8, v6

    move-object/from16 v6, v27

    goto/16 :goto_a

    :cond_23
    move-object/from16 v27, v6

    move-object/from16 v26, v10

    move-object v10, v15

    new-instance v1, Ljava/util/ArrayList;

    invoke-direct {v1}, Ljava/util/ArrayList;-><init>()V

    invoke-virtual/range {v27 .. v27}, Ljava/util/ArrayList;->iterator()Ljava/util/Iterator;

    move-result-object v4

    const/4 v6, 0x0

    const/4 v15, 0x0

    :goto_12
    invoke-interface {v4}, Ljava/util/Iterator;->hasNext()Z

    move-result v16

    if-eqz v16, :cond_30

    invoke-interface {v4}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v16

    move-object/from16 p2, v4

    move-object/from16 v4, v16

    check-cast v4, Landroidx/fragment/app/l$c;

    invoke-virtual {v4}, Landroidx/fragment/app/l$b;->b()Z

    move-result v16

    move-object/from16 v22, v13

    iget-object v13, v4, Landroidx/fragment/app/l$b;->a:Landroidx/fragment/app/q0$b;

    if-eqz v16, :cond_24

    move-object/from16 v16, v15

    sget-object v15, Ljava/lang/Boolean;->FALSE:Ljava/lang/Boolean;

    invoke-virtual {v11, v13, v15}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    invoke-virtual {v4}, Landroidx/fragment/app/l$b;->a()V

    move-object/from16 v30, v3

    move-object/from16 v28, v5

    move-object/from16 v29, v8

    move-object/from16 v15, v16

    const/4 v4, 0x0

    move-object/from16 v8, p0

    move-object/from16 v16, v9

    goto/16 :goto_19

    :cond_24
    move-object/from16 v16, v15

    iget-object v15, v4, Landroidx/fragment/app/l$c;->c:Ljava/lang/Object;

    invoke-virtual {v10, v15}, Landroidx/fragment/app/l0;->f(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v15

    if-eqz v8, :cond_26

    if-eq v13, v2, :cond_25

    if-ne v13, v14, :cond_26

    :cond_25
    const/4 v14, 0x1

    goto :goto_13

    :cond_26
    const/4 v14, 0x0

    :goto_13
    if-nez v15, :cond_28

    if-nez v14, :cond_27

    sget-object v14, Ljava/lang/Boolean;->FALSE:Ljava/lang/Boolean;

    invoke-virtual {v11, v13, v14}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    invoke-virtual {v4}, Landroidx/fragment/app/l$b;->a()V

    :cond_27
    move-object/from16 v30, v3

    move-object/from16 v28, v5

    move-object/from16 v29, v8

    move-object/from16 v15, v16

    const/4 v4, 0x0

    move-object/from16 v8, p0

    move-object/from16 v16, v9

    goto/16 :goto_18

    :cond_28
    move-object/from16 v28, v5

    new-instance v5, Ljava/util/ArrayList;

    invoke-direct {v5}, Ljava/util/ArrayList;-><init>()V

    move-object/from16 v29, v8

    iget-object v8, v13, Landroidx/fragment/app/q0$b;->c:Landroidx/fragment/app/n;

    iget-object v8, v8, Landroidx/fragment/app/n;->F:Landroid/view/View;

    invoke-static {v5, v8}, Landroidx/fragment/app/l;->i(Ljava/util/ArrayList;Landroid/view/View;)V

    if-eqz v14, :cond_2a

    if-ne v13, v2, :cond_29

    invoke-virtual {v5, v9}, Ljava/util/ArrayList;->removeAll(Ljava/util/Collection;)Z

    goto :goto_14

    :cond_29
    invoke-virtual {v5, v12}, Ljava/util/ArrayList;->removeAll(Ljava/util/Collection;)Z

    :cond_2a
    :goto_14
    invoke-virtual {v5}, Ljava/util/ArrayList;->isEmpty()Z

    move-result v8

    if-eqz v8, :cond_2b

    invoke-virtual {v10, v3, v15}, Landroidx/fragment/app/l0;->a(Landroid/view/View;Ljava/lang/Object;)V

    move-object/from16 v8, p0

    move-object/from16 v30, v3

    move-object v14, v15

    move-object/from16 v3, v16

    :goto_15
    move-object/from16 v16, v9

    goto :goto_16

    :cond_2b
    invoke-virtual {v10, v15, v5}, Landroidx/fragment/app/l0;->b(Ljava/lang/Object;Ljava/util/ArrayList;)V

    const/16 v18, 0x0

    const/16 v19, 0x0

    const/16 v20, 0x0

    const/16 v21, 0x0

    move-object/from16 v8, p0

    move-object v14, v10

    move-object/from16 v30, v3

    move-object/from16 p0, v15

    move-object/from16 v3, v16

    move-object/from16 v16, p0

    move-object/from16 v17, v5

    invoke-virtual/range {v14 .. v21}, Landroidx/fragment/app/l0;->m(Ljava/lang/Object;Ljava/lang/Object;Ljava/util/ArrayList;Ljava/lang/Object;Ljava/util/ArrayList;Ljava/lang/Object;Ljava/util/ArrayList;)V

    iget v14, v13, Landroidx/fragment/app/q0$b;->a:I

    const/4 v15, 0x3

    if-ne v14, v15, :cond_2c

    move-object/from16 v14, v26

    invoke-virtual {v14, v13}, Ljava/util/ArrayList;->remove(Ljava/lang/Object;)Z

    new-instance v15, Ljava/util/ArrayList;

    invoke-direct {v15, v5}, Ljava/util/ArrayList;-><init>(Ljava/util/Collection;)V

    iget-object v14, v13, Landroidx/fragment/app/q0$b;->c:Landroidx/fragment/app/n;

    move-object/from16 v16, v9

    iget-object v9, v14, Landroidx/fragment/app/n;->F:Landroid/view/View;

    invoke-virtual {v15, v9}, Ljava/util/ArrayList;->remove(Ljava/lang/Object;)Z

    iget-object v9, v14, Landroidx/fragment/app/n;->F:Landroid/view/View;

    move-object/from16 v14, p0

    invoke-virtual {v10, v14, v9, v15}, Landroidx/fragment/app/l0;->l(Ljava/lang/Object;Landroid/view/View;Ljava/util/ArrayList;)V

    new-instance v9, Landroidx/fragment/app/j;

    invoke-direct {v9, v5}, Landroidx/fragment/app/j;-><init>(Ljava/util/ArrayList;)V

    invoke-static {v0, v9}, Le0/t;->a(Landroid/view/View;Ljava/lang/Runnable;)V

    goto :goto_16

    :cond_2c
    move-object/from16 v14, p0

    goto :goto_15

    :goto_16
    iget v9, v13, Landroidx/fragment/app/q0$b;->a:I

    const/4 v15, 0x2

    if-ne v9, v15, :cond_2d

    invoke-virtual {v1, v5}, Ljava/util/ArrayList;->addAll(Ljava/util/Collection;)Z

    if-eqz v25, :cond_2e

    invoke-virtual {v10, v14, v7}, Landroidx/fragment/app/l0;->o(Ljava/lang/Object;Landroid/graphics/Rect;)V

    goto :goto_17

    :cond_2d
    invoke-virtual {v10, v8, v14}, Landroidx/fragment/app/l0;->n(Landroid/view/View;Ljava/lang/Object;)V

    :cond_2e
    :goto_17
    sget-object v5, Ljava/lang/Boolean;->TRUE:Ljava/lang/Boolean;

    invoke-virtual {v11, v13, v5}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    iget-boolean v4, v4, Landroidx/fragment/app/l$c;->d:Z

    if-eqz v4, :cond_2f

    const/4 v4, 0x0

    invoke-virtual {v10, v3, v14, v4}, Landroidx/fragment/app/l0;->j(Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v15

    goto :goto_18

    :cond_2f
    const/4 v4, 0x0

    invoke-virtual {v10, v6, v14, v4}, Landroidx/fragment/app/l0;->j(Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v6

    move-object v15, v3

    :goto_18
    move-object/from16 v14, v28

    :goto_19
    move-object/from16 v4, p2

    move-object/from16 p0, v8

    move-object/from16 v9, v16

    move-object/from16 v13, v22

    move-object/from16 v5, v28

    move-object/from16 v8, v29

    move-object/from16 v3, v30

    goto/16 :goto_12

    :cond_30
    move-object/from16 v28, v5

    move-object v5, v8

    move-object/from16 v16, v9

    move-object/from16 v22, v13

    move-object v3, v15

    invoke-virtual {v10, v3, v6, v5}, Landroidx/fragment/app/l0;->i(Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v3

    invoke-virtual/range {v27 .. v27}, Ljava/util/ArrayList;->iterator()Ljava/util/Iterator;

    move-result-object v4

    :goto_1a
    invoke-interface {v4}, Ljava/util/Iterator;->hasNext()Z

    move-result v6

    if-eqz v6, :cond_38

    invoke-interface {v4}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v6

    check-cast v6, Landroidx/fragment/app/l$c;

    invoke-virtual {v6}, Landroidx/fragment/app/l$b;->b()Z

    move-result v7

    if-eqz v7, :cond_31

    goto :goto_1a

    :cond_31
    iget-object v7, v6, Landroidx/fragment/app/l$b;->a:Landroidx/fragment/app/q0$b;

    move-object/from16 v8, v28

    if-eqz v5, :cond_33

    if-eq v7, v2, :cond_32

    if-ne v7, v8, :cond_33

    :cond_32
    const/4 v9, 0x1

    goto :goto_1b

    :cond_33
    const/4 v9, 0x0

    :goto_1b
    iget-object v13, v6, Landroidx/fragment/app/l$c;->c:Ljava/lang/Object;

    if-nez v13, :cond_35

    if-eqz v9, :cond_34

    goto :goto_1c

    :cond_34
    move-object/from16 v9, v24

    goto :goto_1e

    :cond_35
    :goto_1c
    sget-object v9, Le0/a0;->a:Ljava/util/WeakHashMap;

    invoke-static {v0}, Le0/a0$g;->c(Landroid/view/View;)Z

    move-result v9

    if-nez v9, :cond_37

    const/4 v9, 0x2

    invoke-static {v9}, Landroidx/fragment/app/x;->H(I)Z

    move-result v13

    if-eqz v13, :cond_36

    new-instance v9, Ljava/lang/StringBuilder;

    const-string v13, "SpecialEffectsController: Container "

    invoke-direct {v9, v13}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-virtual {v9, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    const-string v13, " has not been laid out. Completing operation "

    invoke-virtual {v9, v13}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v9, v7}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    invoke-virtual {v9}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v7

    move-object/from16 v9, v24

    invoke-static {v9, v7}, Landroid/util/Log;->v(Ljava/lang/String;Ljava/lang/String;)I

    goto :goto_1d

    :cond_36
    move-object/from16 v9, v24

    :goto_1d
    invoke-virtual {v6}, Landroidx/fragment/app/l$b;->a()V

    goto :goto_1e

    :cond_37
    move-object/from16 v9, v24

    iget-object v7, v7, Landroidx/fragment/app/q0$b;->c:Landroidx/fragment/app/n;

    new-instance v7, Landroidx/fragment/app/k;

    invoke-direct {v7, v6}, Landroidx/fragment/app/k;-><init>(Landroidx/fragment/app/l$c;)V

    invoke-virtual {v10, v3, v7}, Landroidx/fragment/app/l0;->p(Ljava/lang/Object;Ljava/lang/Runnable;)V

    :goto_1e
    move-object/from16 v28, v8

    move-object/from16 v24, v9

    goto :goto_1a

    :cond_38
    move-object/from16 v9, v24

    sget-object v2, Le0/a0;->a:Ljava/util/WeakHashMap;

    invoke-static {v0}, Le0/a0$g;->c(Landroid/view/View;)Z

    move-result v2

    if-nez v2, :cond_39

    goto/16 :goto_9

    :cond_39
    const/4 v2, 0x4

    invoke-static {v1, v2}, Landroidx/fragment/app/g0;->b(Ljava/util/ArrayList;I)V

    invoke-static {v12}, Landroidx/fragment/app/l0;->k(Ljava/util/ArrayList;)Ljava/util/ArrayList;

    move-result-object v2

    invoke-virtual {v10, v0, v3}, Landroidx/fragment/app/l0;->c(Landroid/view/ViewGroup;Ljava/lang/Object;)V

    move-object/from16 v3, v16

    move-object/from16 v4, v22

    invoke-static {v0, v3, v12, v2, v4}, Landroidx/fragment/app/l0;->q(Landroid/view/ViewGroup;Ljava/util/ArrayList;Ljava/util/ArrayList;Ljava/util/ArrayList;Ll/b;)V

    const/4 v8, 0x0

    invoke-static {v1, v8}, Landroidx/fragment/app/g0;->b(Ljava/util/ArrayList;I)V

    invoke-virtual {v10, v5, v3, v12}, Landroidx/fragment/app/l0;->s(Ljava/lang/Object;Ljava/util/ArrayList;Ljava/util/ArrayList;)V

    :goto_1f
    sget-object v1, Ljava/lang/Boolean;->TRUE:Ljava/lang/Boolean;

    invoke-virtual {v11, v1}, Ljava/util/HashMap;->containsValue(Ljava/lang/Object;)Z

    move-result v1

    invoke-virtual {v0}, Landroid/view/View;->getContext()Landroid/content/Context;

    move-result-object v10

    new-instance v12, Ljava/util/ArrayList;

    invoke-direct {v12}, Ljava/util/ArrayList;-><init>()V

    invoke-virtual/range {v23 .. v23}, Ljava/util/ArrayList;->iterator()Ljava/util/Iterator;

    move-result-object v13

    move v2, v8

    :goto_20
    invoke-interface {v13}, Ljava/util/Iterator;->hasNext()Z

    move-result v3

    if-eqz v3, :cond_41

    invoke-interface {v13}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v3

    move-object v14, v3

    check-cast v14, Landroidx/fragment/app/l$a;

    invoke-virtual {v14}, Landroidx/fragment/app/l$b;->b()Z

    move-result v3

    if-eqz v3, :cond_3a

    goto :goto_21

    :cond_3a
    invoke-virtual {v14, v10}, Landroidx/fragment/app/l$a;->c(Landroid/content/Context;)Landroidx/fragment/app/r$a;

    move-result-object v3

    if-nez v3, :cond_3c

    :cond_3b
    :goto_21
    invoke-virtual {v14}, Landroidx/fragment/app/l$b;->a()V

    goto :goto_20

    :cond_3c
    iget-object v15, v3, Landroidx/fragment/app/r$a;->b:Landroid/animation/Animator;

    if-nez v15, :cond_3d

    invoke-virtual {v12, v14}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    goto :goto_20

    :cond_3d
    iget-object v6, v14, Landroidx/fragment/app/l$b;->a:Landroidx/fragment/app/q0$b;

    iget-object v3, v6, Landroidx/fragment/app/q0$b;->c:Landroidx/fragment/app/n;

    sget-object v4, Ljava/lang/Boolean;->TRUE:Ljava/lang/Boolean;

    invoke-virtual {v11, v6}, Ljava/util/HashMap;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v5

    invoke-virtual {v4, v5}, Ljava/lang/Boolean;->equals(Ljava/lang/Object;)Z

    move-result v4

    if-eqz v4, :cond_3e

    const/4 v4, 0x2

    invoke-static {v4}, Landroidx/fragment/app/x;->H(I)Z

    move-result v5

    if-eqz v5, :cond_3b

    new-instance v4, Ljava/lang/StringBuilder;

    const-string v5, "Ignoring Animator set on "

    invoke-direct {v4, v5}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-virtual {v4, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    const-string v3, " as this Fragment was involved in a Transition."

    invoke-virtual {v4, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v4}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v3

    invoke-static {v9, v3}, Landroid/util/Log;->v(Ljava/lang/String;Ljava/lang/String;)I

    goto :goto_21

    :cond_3e
    iget v2, v6, Landroidx/fragment/app/q0$b;->a:I

    const/4 v7, 0x3

    if-ne v2, v7, :cond_3f

    const/4 v5, 0x1

    goto :goto_22

    :cond_3f
    move v5, v8

    :goto_22
    if-eqz v5, :cond_40

    move-object/from16 v4, v26

    invoke-virtual {v4, v6}, Ljava/util/ArrayList;->remove(Ljava/lang/Object;)Z

    goto :goto_23

    :cond_40
    move-object/from16 v4, v26

    :goto_23
    iget-object v3, v3, Landroidx/fragment/app/n;->F:Landroid/view/View;

    invoke-virtual {v0, v3}, Landroid/view/ViewGroup;->startViewTransition(Landroid/view/View;)V

    new-instance v2, Landroidx/fragment/app/d;

    move-object/from16 p0, v2

    move-object/from16 p1, v3

    move-object v3, v0

    move-object/from16 v16, v4

    move-object/from16 v4, p1

    move/from16 v17, v7

    move-object v7, v14

    invoke-direct/range {v2 .. v7}, Landroidx/fragment/app/d;-><init>(Landroid/view/ViewGroup;Landroid/view/View;ZLandroidx/fragment/app/q0$b;Landroidx/fragment/app/l$a;)V

    invoke-virtual {v15, v2}, Landroid/animation/Animator;->addListener(Landroid/animation/Animator$AnimatorListener;)V

    move-object/from16 v2, p1

    invoke-virtual {v15, v2}, Landroid/animation/Animator;->setTarget(Ljava/lang/Object;)V

    invoke-virtual {v15}, Landroid/animation/Animator;->start()V

    new-instance v2, Landroidx/fragment/app/e;

    invoke-direct {v2, v15}, Landroidx/fragment/app/e;-><init>(Landroid/animation/Animator;)V

    iget-object v3, v14, Landroidx/fragment/app/l$b;->b:La0/c;

    invoke-virtual {v3, v2}, La0/c;->b(La0/c$a;)V

    move-object/from16 v26, v16

    const/4 v2, 0x1

    goto/16 :goto_20

    :cond_41
    move-object/from16 v16, v26

    invoke-virtual {v12}, Ljava/util/ArrayList;->iterator()Ljava/util/Iterator;

    move-result-object v3

    :goto_24
    invoke-interface {v3}, Ljava/util/Iterator;->hasNext()Z

    move-result v4

    if-eqz v4, :cond_46

    invoke-interface {v3}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v4

    check-cast v4, Landroidx/fragment/app/l$a;

    iget-object v5, v4, Landroidx/fragment/app/l$b;->a:Landroidx/fragment/app/q0$b;

    iget-object v6, v5, Landroidx/fragment/app/q0$b;->c:Landroidx/fragment/app/n;

    const-string v7, "Ignoring Animation set on "

    if-eqz v1, :cond_42

    const/4 v8, 0x2

    invoke-static {v8}, Landroidx/fragment/app/x;->H(I)Z

    move-result v5

    if-eqz v5, :cond_43

    new-instance v5, Ljava/lang/StringBuilder;

    invoke-direct {v5, v7}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-virtual {v5, v6}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    const-string v6, " as Animations cannot run alongside Transitions."

    goto :goto_25

    :cond_42
    const/4 v8, 0x2

    if-eqz v2, :cond_44

    invoke-static {v8}, Landroidx/fragment/app/x;->H(I)Z

    move-result v5

    if-eqz v5, :cond_43

    new-instance v5, Ljava/lang/StringBuilder;

    invoke-direct {v5, v7}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-virtual {v5, v6}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    const-string v6, " as Animations cannot run alongside Animators."

    :goto_25
    invoke-virtual {v5, v6}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v5}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v5

    invoke-static {v9, v5}, Landroid/util/Log;->v(Ljava/lang/String;Ljava/lang/String;)I

    :cond_43
    invoke-virtual {v4}, Landroidx/fragment/app/l$b;->a()V

    goto :goto_24

    :cond_44
    iget-object v6, v6, Landroidx/fragment/app/n;->F:Landroid/view/View;

    invoke-virtual {v4, v10}, Landroidx/fragment/app/l$a;->c(Landroid/content/Context;)Landroidx/fragment/app/r$a;

    move-result-object v7

    invoke-virtual {v7}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    iget-object v7, v7, Landroidx/fragment/app/r$a;->a:Landroid/view/animation/Animation;

    invoke-virtual {v7}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    iget v5, v5, Landroidx/fragment/app/q0$b;->a:I

    const/4 v11, 0x1

    if-eq v5, v11, :cond_45

    invoke-virtual {v6, v7}, Landroid/view/View;->startAnimation(Landroid/view/animation/Animation;)V

    invoke-virtual {v4}, Landroidx/fragment/app/l$b;->a()V

    goto :goto_26

    :cond_45
    invoke-virtual {v0, v6}, Landroid/view/ViewGroup;->startViewTransition(Landroid/view/View;)V

    new-instance v5, Landroidx/fragment/app/r$b;

    invoke-direct {v5, v7, v0, v6}, Landroidx/fragment/app/r$b;-><init>(Landroid/view/animation/Animation;Landroid/view/ViewGroup;Landroid/view/View;)V

    new-instance v7, Landroidx/fragment/app/f;

    invoke-direct {v7, v6, v0, v4}, Landroidx/fragment/app/f;-><init>(Landroid/view/View;Landroid/view/ViewGroup;Landroidx/fragment/app/l$a;)V

    invoke-virtual {v5, v7}, Landroid/view/animation/Animation;->setAnimationListener(Landroid/view/animation/Animation$AnimationListener;)V

    invoke-virtual {v6, v5}, Landroid/view/View;->startAnimation(Landroid/view/animation/Animation;)V

    :goto_26
    new-instance v5, Landroidx/fragment/app/g;

    invoke-direct {v5, v6, v0, v4}, Landroidx/fragment/app/g;-><init>(Landroid/view/View;Landroid/view/ViewGroup;Landroidx/fragment/app/l$a;)V

    iget-object v4, v4, Landroidx/fragment/app/l$b;->b:La0/c;

    invoke-virtual {v4, v5}, La0/c;->b(La0/c$a;)V

    goto :goto_24

    :cond_46
    invoke-virtual/range {v16 .. v16}, Ljava/util/ArrayList;->iterator()Ljava/util/Iterator;

    move-result-object v0

    :goto_27
    invoke-interface {v0}, Ljava/util/Iterator;->hasNext()Z

    move-result v1

    if-eqz v1, :cond_47

    invoke-interface {v0}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Landroidx/fragment/app/q0$b;

    iget-object v2, v1, Landroidx/fragment/app/q0$b;->c:Landroidx/fragment/app/n;

    iget-object v2, v2, Landroidx/fragment/app/n;->F:Landroid/view/View;

    iget v1, v1, Landroidx/fragment/app/q0$b;->a:I

    invoke-static {v1, v2}, Landroidx/activity/result/d;->a(ILandroid/view/View;)V

    goto :goto_27

    :cond_47
    invoke-virtual/range {v16 .. v16}, Ljava/util/ArrayList;->clear()V

    return-void
.end method
