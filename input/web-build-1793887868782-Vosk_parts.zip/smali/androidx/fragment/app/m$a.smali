.class public final Landroidx/fragment/app/m$a;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Ljava/lang/Runnable;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Landroidx/fragment/app/m;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x1
    name = null
.end annotation


# instance fields
.field public final synthetic b:Landroidx/fragment/app/m;


# direct methods
.method public constructor <init>(Landroidx/fragment/app/m;)V
    .locals 0

    iput-object p1, p0, Landroidx/fragment/app/m$a;->b:Landroidx/fragment/app/m;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public final run()V
    .locals 1
    .annotation build Landroid/annotation/SuppressLint;
        value = {
            "SyntheticAccessor"
        }
    .end annotation

    iget-object p0, p0, Landroidx/fragment/app/m$a;->b:Landroidx/fragment/app/m;

    iget-object v0, p0, Landroidx/fragment/app/m;->V:Landroidx/fragment/app/m$c;

    iget-object p0, p0, Landroidx/fragment/app/m;->d0:Landroid/app/Dialog;

    invoke-virtual {v0, p0}, Landroidx/fragment/app/m$c;->onDismiss(Landroid/content/DialogInterface;)V

    return-void
.end method
