.class public final Landroidx/fragment/app/q0$a;
.super Landroidx/fragment/app/q0$b;
.source "SourceFile"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Landroidx/fragment/app/q0;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x9
    name = "a"
.end annotation


# instance fields
.field public final h:Landroidx/fragment/app/d0;


# direct methods
.method public constructor <init>(IILandroidx/fragment/app/d0;La0/c;)V
    .locals 1

    iget-object v0, p3, Landroidx/fragment/app/d0;->c:Landroidx/fragment/app/n;

    invoke-direct {p0, p1, p2, v0, p4}, Landroidx/fragment/app/q0$b;-><init>(IILandroidx/fragment/app/n;La0/c;)V

    iput-object p3, p0, Landroidx/fragment/app/q0$a;->h:Landroidx/fragment/app/d0;

    return-void
.end method


# virtual methods
.method public final b()V
    .locals 0

    invoke-super {p0}, Landroidx/fragment/app/q0$b;->b()V

    iget-object p0, p0, Landroidx/fragment/app/q0$a;->h:Landroidx/fragment/app/d0;

    invoke-virtual {p0}, Landroidx/fragment/app/d0;->k()V

    return-void
.end method

.method public final d()V
    .locals 5

    iget v0, p0, Landroidx/fragment/app/q0$b;->b:I

    const/4 v1, 0x2

    if-ne v0, v1, :cond_4

    iget-object v0, p0, Landroidx/fragment/app/q0$a;->h:Landroidx/fragment/app/d0;

    iget-object v2, v0, Landroidx/fragment/app/d0;->c:Landroidx/fragment/app/n;

    iget-object v3, v2, Landroidx/fragment/app/n;->F:Landroid/view/View;

    invoke-virtual {v3}, Landroid/view/View;->findFocus()Landroid/view/View;

    move-result-object v3

    if-eqz v3, :cond_0

    invoke-virtual {v2}, Landroidx/fragment/app/n;->g()Landroidx/fragment/app/n$b;

    move-result-object v4

    iput-object v3, v4, Landroidx/fragment/app/n$b;->m:Landroid/view/View;

    invoke-static {v1}, Landroidx/fragment/app/x;->H(I)Z

    move-result v1

    if-eqz v1, :cond_0

    new-instance v1, Ljava/lang/StringBuilder;

    const-string v4, "requestFocus: Saved focused view "

    invoke-direct {v1, v4}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-virtual {v1, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    const-string v3, " for Fragment "

    invoke-virtual {v1, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    const-string v3, "FragmentManager"

    invoke-static {v3, v1}, Landroid/util/Log;->v(Ljava/lang/String;Ljava/lang/String;)I

    :cond_0
    iget-object p0, p0, Landroidx/fragment/app/q0$b;->c:Landroidx/fragment/app/n;

    invoke-virtual {p0}, Landroidx/fragment/app/n;->N()Landroid/view/View;

    move-result-object p0

    invoke-virtual {p0}, Landroid/view/View;->getParent()Landroid/view/ViewParent;

    move-result-object v1

    const/4 v3, 0x0

    if-nez v1, :cond_1

    invoke-virtual {v0}, Landroidx/fragment/app/d0;->b()V

    invoke-virtual {p0, v3}, Landroid/view/View;->setAlpha(F)V

    :cond_1
    invoke-virtual {p0}, Landroid/view/View;->getAlpha()F

    move-result v0

    cmpl-float v0, v0, v3

    if-nez v0, :cond_2

    invoke-virtual {p0}, Landroid/view/View;->getVisibility()I

    move-result v0

    if-nez v0, :cond_2

    const/4 v0, 0x4

    invoke-virtual {p0, v0}, Landroid/view/View;->setVisibility(I)V

    :cond_2
    iget-object v0, v2, Landroidx/fragment/app/n;->I:Landroidx/fragment/app/n$b;

    if-nez v0, :cond_3

    const/high16 v0, 0x3f800000    # 1.0f

    goto :goto_0

    :cond_3
    iget v0, v0, Landroidx/fragment/app/n$b;->l:F

    :goto_0
    invoke-virtual {p0, v0}, Landroid/view/View;->setAlpha(F)V

    :cond_4
    return-void
.end method
