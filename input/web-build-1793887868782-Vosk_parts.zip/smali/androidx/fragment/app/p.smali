.class public final Landroidx/fragment/app/p;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements La/b;


# instance fields
.field public final synthetic a:Landroidx/fragment/app/q;


# direct methods
.method public constructor <init>(Landroidx/fragment/app/q;)V
    .locals 0

    iput-object p1, p0, Landroidx/fragment/app/p;->a:Landroidx/fragment/app/q;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public final a()V
    .locals 3

    iget-object p0, p0, Landroidx/fragment/app/p;->a:Landroidx/fragment/app/q;

    iget-object v0, p0, Landroidx/fragment/app/q;->o:Landroidx/fragment/app/s;

    iget-object v0, v0, Landroidx/fragment/app/s;->a:Landroidx/fragment/app/u;

    iget-object v1, v0, Landroidx/fragment/app/u;->i:Landroidx/fragment/app/y;

    const/4 v2, 0x0

    invoke-virtual {v1, v0, v0, v2}, Landroidx/fragment/app/x;->c(Landroidx/fragment/app/u;Landroidx/activity/result/c;Landroidx/fragment/app/n;)V

    iget-object v0, p0, Landroidx/activity/ComponentActivity;->f:Lt0/c;

    iget-object v0, v0, Lt0/c;->b:Lt0/b;

    const-string v1, "android:support:fragments"

    invoke-virtual {v0, v1}, Lt0/b;->a(Ljava/lang/String;)Landroid/os/Bundle;

    move-result-object v0

    if-eqz v0, :cond_1

    invoke-virtual {v0, v1}, Landroid/os/Bundle;->getParcelable(Ljava/lang/String;)Landroid/os/Parcelable;

    move-result-object v0

    iget-object p0, p0, Landroidx/fragment/app/q;->o:Landroidx/fragment/app/s;

    iget-object p0, p0, Landroidx/fragment/app/s;->a:Landroidx/fragment/app/u;

    instance-of v1, p0, Landroidx/lifecycle/e0;

    if-eqz v1, :cond_0

    iget-object p0, p0, Landroidx/fragment/app/u;->i:Landroidx/fragment/app/y;

    invoke-virtual {p0, v0}, Landroidx/fragment/app/x;->S(Landroid/os/Parcelable;)V

    goto :goto_0

    :cond_0
    new-instance p0, Ljava/lang/IllegalStateException;

    const-string v0, "Your FragmentHostCallback must implement ViewModelStoreOwner to call restoreSaveState(). Call restoreAllState()  if you\'re still using retainNestedNonConfig()."

    invoke-direct {p0, v0}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    throw p0

    :cond_1
    :goto_0
    return-void
.end method
