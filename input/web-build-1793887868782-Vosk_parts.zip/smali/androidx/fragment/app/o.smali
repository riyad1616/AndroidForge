.class public final Landroidx/fragment/app/o;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Lt0/b$b;


# instance fields
.field public final synthetic a:Landroidx/fragment/app/q;


# direct methods
.method public constructor <init>(Landroidx/fragment/app/q;)V
    .locals 0

    iput-object p1, p0, Landroidx/fragment/app/o;->a:Landroidx/fragment/app/q;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public final a()Landroid/os/Bundle;
    .locals 3

    new-instance v0, Landroid/os/Bundle;

    invoke-direct {v0}, Landroid/os/Bundle;-><init>()V

    :cond_0
    iget-object v1, p0, Landroidx/fragment/app/o;->a:Landroidx/fragment/app/q;

    iget-object v2, v1, Landroidx/fragment/app/q;->o:Landroidx/fragment/app/s;

    iget-object v2, v2, Landroidx/fragment/app/s;->a:Landroidx/fragment/app/u;

    iget-object v2, v2, Landroidx/fragment/app/u;->i:Landroidx/fragment/app/y;

    invoke-static {v2}, Landroidx/fragment/app/q;->p(Landroidx/fragment/app/x;)Z

    move-result v2

    if-nez v2, :cond_0

    iget-object p0, v1, Landroidx/fragment/app/q;->p:Landroidx/lifecycle/l;

    sget-object v2, Landroidx/lifecycle/g$b;->ON_STOP:Landroidx/lifecycle/g$b;

    invoke-virtual {p0, v2}, Landroidx/lifecycle/l;->e(Landroidx/lifecycle/g$b;)V

    iget-object p0, v1, Landroidx/fragment/app/q;->o:Landroidx/fragment/app/s;

    iget-object p0, p0, Landroidx/fragment/app/s;->a:Landroidx/fragment/app/u;

    iget-object p0, p0, Landroidx/fragment/app/u;->i:Landroidx/fragment/app/y;

    invoke-virtual {p0}, Landroidx/fragment/app/x;->T()Landroidx/fragment/app/z;

    move-result-object p0

    if-eqz p0, :cond_1

    const-string v1, "android:support:fragments"

    invoke-virtual {v0, v1, p0}, Landroid/os/Bundle;->putParcelable(Ljava/lang/String;Landroid/os/Parcelable;)V

    :cond_1
    return-object v0
.end method
