.class public final Landroidx/fragment/app/l$a;
.super Landroidx/fragment/app/l$b;
.source "SourceFile"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Landroidx/fragment/app/l;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x9
    name = "a"
.end annotation


# instance fields
.field public final c:Z

.field public d:Z

.field public e:Landroidx/fragment/app/r$a;


# direct methods
.method public constructor <init>(Landroidx/fragment/app/q0$b;La0/c;Z)V
    .locals 0

    invoke-direct {p0, p1, p2}, Landroidx/fragment/app/l$b;-><init>(Landroidx/fragment/app/q0$b;La0/c;)V

    const/4 p1, 0x0

    iput-boolean p1, p0, Landroidx/fragment/app/l$a;->d:Z

    iput-boolean p3, p0, Landroidx/fragment/app/l$a;->c:Z

    return-void
.end method


# virtual methods
.method public final c(Landroid/content/Context;)Landroidx/fragment/app/r$a;
    .locals 4

    iget-boolean v0, p0, Landroidx/fragment/app/l$a;->d:Z

    if-eqz v0, :cond_0

    iget-object p0, p0, Landroidx/fragment/app/l$a;->e:Landroidx/fragment/app/r$a;

    return-object p0

    :cond_0
    iget-object v0, p0, Landroidx/fragment/app/l$b;->a:Landroidx/fragment/app/q0$b;

    iget-object v1, v0, Landroidx/fragment/app/q0$b;->c:Landroidx/fragment/app/n;

    iget v0, v0, Landroidx/fragment/app/q0$b;->a:I

    const/4 v2, 0x2

    const/4 v3, 0x1

    if-ne v0, v2, :cond_1

    move v0, v3

    goto :goto_0

    :cond_1
    const/4 v0, 0x0

    :goto_0
    iget-boolean v2, p0, Landroidx/fragment/app/l$a;->c:Z

    invoke-static {p1, v1, v0, v2}, Landroidx/fragment/app/r;->a(Landroid/content/Context;Landroidx/fragment/app/n;ZZ)Landroidx/fragment/app/r$a;

    move-result-object p1

    iput-object p1, p0, Landroidx/fragment/app/l$a;->e:Landroidx/fragment/app/r$a;

    iput-boolean v3, p0, Landroidx/fragment/app/l$a;->d:Z

    return-object p1
.end method
