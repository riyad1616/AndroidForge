.class public final Landroidx/appcompat/widget/d1$a;
.super La1/a;
.source "SourceFile"


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Landroidx/appcompat/widget/d1;->r(IJ)Le0/i0;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x1
    name = null
.end annotation


# instance fields
.field public P0:Z

.field public final synthetic Q0:I

.field public final synthetic R0:Landroidx/appcompat/widget/d1;


# direct methods
.method public constructor <init>(Landroidx/appcompat/widget/d1;I)V
    .locals 0

    iput-object p1, p0, Landroidx/appcompat/widget/d1$a;->R0:Landroidx/appcompat/widget/d1;

    iput p2, p0, Landroidx/appcompat/widget/d1$a;->Q0:I

    invoke-direct {p0}, La1/a;-><init>()V

    const/4 p1, 0x0

    iput-boolean p1, p0, Landroidx/appcompat/widget/d1$a;->P0:Z

    return-void
.end method


# virtual methods
.method public final a()V
    .locals 1

    iget-boolean v0, p0, Landroidx/appcompat/widget/d1$a;->P0:Z

    if-nez v0, :cond_0

    iget-object v0, p0, Landroidx/appcompat/widget/d1$a;->R0:Landroidx/appcompat/widget/d1;

    iget-object v0, v0, Landroidx/appcompat/widget/d1;->a:Landroidx/appcompat/widget/Toolbar;

    iget p0, p0, Landroidx/appcompat/widget/d1$a;->Q0:I

    invoke-virtual {v0, p0}, Landroid/view/View;->setVisibility(I)V

    :cond_0
    return-void
.end method

.method public final b(Landroid/view/View;)V
    .locals 0

    const/4 p1, 0x1

    iput-boolean p1, p0, Landroidx/appcompat/widget/d1$a;->P0:Z

    return-void
.end method

.method public final c()V
    .locals 1

    iget-object p0, p0, Landroidx/appcompat/widget/d1$a;->R0:Landroidx/appcompat/widget/d1;

    iget-object p0, p0, Landroidx/appcompat/widget/d1;->a:Landroidx/appcompat/widget/Toolbar;

    const/4 v0, 0x0

    invoke-virtual {p0, v0}, Landroid/view/View;->setVisibility(I)V

    return-void
.end method
