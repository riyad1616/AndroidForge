.class public final Landroidx/appcompat/widget/z;
.super Landroidx/appcompat/widget/l0;
.source "SourceFile"


# instance fields
.field public final synthetic k:Landroidx/appcompat/widget/a0$g;

.field public final synthetic l:Landroidx/appcompat/widget/a0;


# direct methods
.method public constructor <init>(Landroidx/appcompat/widget/a0;Landroid/view/View;Landroidx/appcompat/widget/a0$g;)V
    .locals 0

    iput-object p1, p0, Landroidx/appcompat/widget/z;->l:Landroidx/appcompat/widget/a0;

    iput-object p3, p0, Landroidx/appcompat/widget/z;->k:Landroidx/appcompat/widget/a0$g;

    invoke-direct {p0, p2}, Landroidx/appcompat/widget/l0;-><init>(Landroid/view/View;)V

    return-void
.end method


# virtual methods
.method public final b()Lh/f;
    .locals 0

    iget-object p0, p0, Landroidx/appcompat/widget/z;->k:Landroidx/appcompat/widget/a0$g;

    return-object p0
.end method

.method public final c()Z
    .locals 2
    .annotation build Landroid/annotation/SuppressLint;
        value = {
            "SyntheticAccessor"
        }
    .end annotation

    iget-object p0, p0, Landroidx/appcompat/widget/z;->l:Landroidx/appcompat/widget/a0;

    invoke-virtual {p0}, Landroidx/appcompat/widget/a0;->getInternalPopup()Landroidx/appcompat/widget/a0$i;

    move-result-object v0

    invoke-interface {v0}, Landroidx/appcompat/widget/a0$i;->b()Z

    move-result v0

    if-nez v0, :cond_0

    invoke-static {p0}, Landroidx/appcompat/widget/a0$c;->b(Landroid/view/View;)I

    move-result v0

    invoke-static {p0}, Landroidx/appcompat/widget/a0$c;->a(Landroid/view/View;)I

    move-result v1

    iget-object p0, p0, Landroidx/appcompat/widget/a0;->g:Landroidx/appcompat/widget/a0$i;

    invoke-interface {p0, v0, v1}, Landroidx/appcompat/widget/a0$i;->m(II)V

    :cond_0
    const/4 p0, 0x1

    return p0
.end method
