.class public final Landroidx/appcompat/widget/q0;
.super Landroidx/appcompat/widget/o0;
.source "SourceFile"

# interfaces
.implements Landroidx/appcompat/widget/p0;


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Landroidx/appcompat/widget/q0$b;,
        Landroidx/appcompat/widget/q0$a;,
        Landroidx/appcompat/widget/q0$c;
    }
.end annotation


# instance fields
.field public B:Landroidx/appcompat/widget/p0;


# direct methods
.method public constructor <init>(Landroid/content/Context;II)V
    .locals 1

    const/4 v0, 0x0

    invoke-direct {p0, p1, v0, p2, p3}, Landroidx/appcompat/widget/o0;-><init>(Landroid/content/Context;Landroid/util/AttributeSet;II)V

    return-void
.end method


# virtual methods
.method public final a(Landroidx/appcompat/view/menu/f;Landroid/view/MenuItem;)V
    .locals 0

    iget-object p0, p0, Landroidx/appcompat/widget/q0;->B:Landroidx/appcompat/widget/p0;

    if-eqz p0, :cond_0

    invoke-interface {p0, p1, p2}, Landroidx/appcompat/widget/p0;->a(Landroidx/appcompat/view/menu/f;Landroid/view/MenuItem;)V

    :cond_0
    return-void
.end method

.method public final e(Landroidx/appcompat/view/menu/f;Landroidx/appcompat/view/menu/h;)V
    .locals 0

    iget-object p0, p0, Landroidx/appcompat/widget/q0;->B:Landroidx/appcompat/widget/p0;

    if-eqz p0, :cond_0

    invoke-interface {p0, p1, p2}, Landroidx/appcompat/widget/p0;->e(Landroidx/appcompat/view/menu/f;Landroidx/appcompat/view/menu/h;)V

    :cond_0
    return-void
.end method

.method public final q(Landroid/content/Context;Z)Landroidx/appcompat/widget/j0;
    .locals 1

    new-instance v0, Landroidx/appcompat/widget/q0$c;

    invoke-direct {v0, p1, p2}, Landroidx/appcompat/widget/q0$c;-><init>(Landroid/content/Context;Z)V

    invoke-virtual {v0, p0}, Landroidx/appcompat/widget/q0$c;->setHoverListener(Landroidx/appcompat/widget/p0;)V

    return-object v0
.end method
