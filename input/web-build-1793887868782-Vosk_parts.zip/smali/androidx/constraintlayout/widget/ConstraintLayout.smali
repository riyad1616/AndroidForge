.class public Landroidx/constraintlayout/widget/ConstraintLayout;
.super Landroid/view/ViewGroup;
.source "SourceFile"


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Landroidx/constraintlayout/widget/ConstraintLayout$a;,
        Landroidx/constraintlayout/widget/ConstraintLayout$b;
    }
.end annotation


# static fields
.field public static final synthetic q:I


# instance fields
.field public final b:Landroid/util/SparseArray;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Landroid/util/SparseArray<",
            "Landroid/view/View;",
            ">;"
        }
    .end annotation
.end field

.field public final c:Ljava/util/ArrayList;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/ArrayList<",
            "Landroidx/constraintlayout/widget/a;",
            ">;"
        }
    .end annotation
.end field

.field public final d:Lo/e;

.field public e:I

.field public f:I

.field public g:I

.field public h:I

.field public i:Z

.field public j:I

.field public k:Landroidx/constraintlayout/widget/b;

.field public l:Lq/b;

.field public m:I

.field public n:Ljava/util/HashMap;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/HashMap<",
            "Ljava/lang/String;",
            "Ljava/lang/Integer;",
            ">;"
        }
    .end annotation
.end field

.field public final o:Landroid/util/SparseArray;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Landroid/util/SparseArray<",
            "Lo/d;",
            ">;"
        }
    .end annotation
.end field

.field public final p:Landroidx/constraintlayout/widget/ConstraintLayout$b;


# direct methods
.method public constructor <init>(Landroid/content/Context;Landroid/util/AttributeSet;)V
    .locals 1

    invoke-direct {p0, p1, p2}, Landroid/view/ViewGroup;-><init>(Landroid/content/Context;Landroid/util/AttributeSet;)V

    new-instance p1, Landroid/util/SparseArray;

    invoke-direct {p1}, Landroid/util/SparseArray;-><init>()V

    iput-object p1, p0, Landroidx/constraintlayout/widget/ConstraintLayout;->b:Landroid/util/SparseArray;

    new-instance p1, Ljava/util/ArrayList;

    const/4 v0, 0x4

    invoke-direct {p1, v0}, Ljava/util/ArrayList;-><init>(I)V

    iput-object p1, p0, Landroidx/constraintlayout/widget/ConstraintLayout;->c:Ljava/util/ArrayList;

    new-instance p1, Lo/e;

    invoke-direct {p1}, Lo/e;-><init>()V

    iput-object p1, p0, Landroidx/constraintlayout/widget/ConstraintLayout;->d:Lo/e;

    const/4 p1, 0x0

    iput p1, p0, Landroidx/constraintlayout/widget/ConstraintLayout;->e:I

    iput p1, p0, Landroidx/constraintlayout/widget/ConstraintLayout;->f:I

    const v0, 0x7fffffff

    iput v0, p0, Landroidx/constraintlayout/widget/ConstraintLayout;->g:I

    iput v0, p0, Landroidx/constraintlayout/widget/ConstraintLayout;->h:I

    const/4 v0, 0x1

    iput-boolean v0, p0, Landroidx/constraintlayout/widget/ConstraintLayout;->i:Z

    const/16 v0, 0x107

    iput v0, p0, Landroidx/constraintlayout/widget/ConstraintLayout;->j:I

    const/4 v0, 0x0

    iput-object v0, p0, Landroidx/constraintlayout/widget/ConstraintLayout;->k:Landroidx/constraintlayout/widget/b;

    iput-object v0, p0, Landroidx/constraintlayout/widget/ConstraintLayout;->l:Lq/b;

    const/4 v0, -0x1

    iput v0, p0, Landroidx/constraintlayout/widget/ConstraintLayout;->m:I

    new-instance v0, Ljava/util/HashMap;

    invoke-direct {v0}, Ljava/util/HashMap;-><init>()V

    iput-object v0, p0, Landroidx/constraintlayout/widget/ConstraintLayout;->n:Ljava/util/HashMap;

    new-instance v0, Landroid/util/SparseArray;

    invoke-direct {v0}, Landroid/util/SparseArray;-><init>()V

    iput-object v0, p0, Landroidx/constraintlayout/widget/ConstraintLayout;->o:Landroid/util/SparseArray;

    new-instance v0, Landroidx/constraintlayout/widget/ConstraintLayout$b;

    invoke-direct {v0, p0}, Landroidx/constraintlayout/widget/ConstraintLayout$b;-><init>(Landroidx/constraintlayout/widget/ConstraintLayout;)V

    iput-object v0, p0, Landroidx/constraintlayout/widget/ConstraintLayout;->p:Landroidx/constraintlayout/widget/ConstraintLayout$b;

    invoke-virtual {p0, p2, p1}, Landroidx/constraintlayout/widget/ConstraintLayout;->c(Landroid/util/AttributeSet;I)V

    return-void
.end method

.method public constructor <init>(Landroid/content/Context;Landroid/util/AttributeSet;I)V
    .locals 1

    invoke-direct {p0, p1, p2, p3}, Landroid/view/ViewGroup;-><init>(Landroid/content/Context;Landroid/util/AttributeSet;I)V

    new-instance p1, Landroid/util/SparseArray;

    invoke-direct {p1}, Landroid/util/SparseArray;-><init>()V

    iput-object p1, p0, Landroidx/constraintlayout/widget/ConstraintLayout;->b:Landroid/util/SparseArray;

    new-instance p1, Ljava/util/ArrayList;

    const/4 v0, 0x4

    invoke-direct {p1, v0}, Ljava/util/ArrayList;-><init>(I)V

    iput-object p1, p0, Landroidx/constraintlayout/widget/ConstraintLayout;->c:Ljava/util/ArrayList;

    new-instance p1, Lo/e;

    invoke-direct {p1}, Lo/e;-><init>()V

    iput-object p1, p0, Landroidx/constraintlayout/widget/ConstraintLayout;->d:Lo/e;

    const/4 p1, 0x0

    iput p1, p0, Landroidx/constraintlayout/widget/ConstraintLayout;->e:I

    iput p1, p0, Landroidx/constraintlayout/widget/ConstraintLayout;->f:I

    const p1, 0x7fffffff

    iput p1, p0, Landroidx/constraintlayout/widget/ConstraintLayout;->g:I

    iput p1, p0, Landroidx/constraintlayout/widget/ConstraintLayout;->h:I

    const/4 p1, 0x1

    iput-boolean p1, p0, Landroidx/constraintlayout/widget/ConstraintLayout;->i:Z

    const/16 p1, 0x107

    iput p1, p0, Landroidx/constraintlayout/widget/ConstraintLayout;->j:I

    const/4 p1, 0x0

    iput-object p1, p0, Landroidx/constraintlayout/widget/ConstraintLayout;->k:Landroidx/constraintlayout/widget/b;

    iput-object p1, p0, Landroidx/constraintlayout/widget/ConstraintLayout;->l:Lq/b;

    const/4 p1, -0x1

    iput p1, p0, Landroidx/constraintlayout/widget/ConstraintLayout;->m:I

    new-instance p1, Ljava/util/HashMap;

    invoke-direct {p1}, Ljava/util/HashMap;-><init>()V

    iput-object p1, p0, Landroidx/constraintlayout/widget/ConstraintLayout;->n:Ljava/util/HashMap;

    new-instance p1, Landroid/util/SparseArray;

    invoke-direct {p1}, Landroid/util/SparseArray;-><init>()V

    iput-object p1, p0, Landroidx/constraintlayout/widget/ConstraintLayout;->o:Landroid/util/SparseArray;

    new-instance p1, Landroidx/constraintlayout/widget/ConstraintLayout$b;

    invoke-direct {p1, p0}, Landroidx/constraintlayout/widget/ConstraintLayout$b;-><init>(Landroidx/constraintlayout/widget/ConstraintLayout;)V

    iput-object p1, p0, Landroidx/constraintlayout/widget/ConstraintLayout;->p:Landroidx/constraintlayout/widget/ConstraintLayout$b;

    invoke-virtual {p0, p2, p3}, Landroidx/constraintlayout/widget/ConstraintLayout;->c(Landroid/util/AttributeSet;I)V

    return-void
.end method

.method private getPaddingWidth()I
    .locals 3

    invoke-virtual {p0}, Landroid/view/View;->getPaddingLeft()I

    move-result v0

    const/4 v1, 0x0

    invoke-static {v1, v0}, Ljava/lang/Math;->max(II)I

    move-result v0

    invoke-virtual {p0}, Landroid/view/View;->getPaddingRight()I

    move-result v2

    invoke-static {v1, v2}, Ljava/lang/Math;->max(II)I

    move-result v2

    add-int/2addr v2, v0

    invoke-virtual {p0}, Landroid/view/View;->getPaddingStart()I

    move-result v0

    invoke-static {v1, v0}, Ljava/lang/Math;->max(II)I

    move-result v0

    invoke-virtual {p0}, Landroid/view/View;->getPaddingEnd()I

    move-result p0

    invoke-static {v1, p0}, Ljava/lang/Math;->max(II)I

    move-result p0

    add-int/2addr p0, v0

    if-lez p0, :cond_0

    move v2, p0

    :cond_0
    return v2
.end method


# virtual methods
.method public addView(Landroid/view/View;ILandroid/view/ViewGroup$LayoutParams;)V
    .locals 0

    invoke-super {p0, p1, p2, p3}, Landroid/view/ViewGroup;->addView(Landroid/view/View;ILandroid/view/ViewGroup$LayoutParams;)V

    return-void
.end method

.method public final b(Landroid/view/View;)Lo/d;
    .locals 0

    if-ne p1, p0, :cond_0

    iget-object p0, p0, Landroidx/constraintlayout/widget/ConstraintLayout;->d:Lo/e;

    return-object p0

    :cond_0
    if-nez p1, :cond_1

    const/4 p0, 0x0

    goto :goto_0

    :cond_1
    invoke-virtual {p1}, Landroid/view/View;->getLayoutParams()Landroid/view/ViewGroup$LayoutParams;

    move-result-object p0

    check-cast p0, Landroidx/constraintlayout/widget/ConstraintLayout$a;

    iget-object p0, p0, Landroidx/constraintlayout/widget/ConstraintLayout$a;->l0:Lo/d;

    :goto_0
    return-object p0
.end method

.method public final c(Landroid/util/AttributeSet;I)V
    .locals 7

    iget-object v0, p0, Landroidx/constraintlayout/widget/ConstraintLayout;->d:Lo/e;

    iput-object p0, v0, Lo/d;->W:Ljava/lang/Object;

    iget-object v1, p0, Landroidx/constraintlayout/widget/ConstraintLayout;->p:Landroidx/constraintlayout/widget/ConstraintLayout$b;

    iput-object v1, v0, Lo/e;->h0:Lp/b$b;

    iget-object v2, v0, Lo/e;->g0:Lp/e;

    iput-object v1, v2, Lp/e;->f:Lp/b$b;

    iget-object v1, p0, Landroidx/constraintlayout/widget/ConstraintLayout;->b:Landroid/util/SparseArray;

    invoke-virtual {p0}, Landroid/view/View;->getId()I

    move-result v2

    invoke-virtual {v1, v2, p0}, Landroid/util/SparseArray;->put(ILjava/lang/Object;)V

    const/4 v1, 0x0

    iput-object v1, p0, Landroidx/constraintlayout/widget/ConstraintLayout;->k:Landroidx/constraintlayout/widget/b;

    const/4 v2, 0x0

    if-eqz p1, :cond_8

    invoke-virtual {p0}, Landroid/view/View;->getContext()Landroid/content/Context;

    move-result-object v3

    sget-object v4, La1/a;->r0:[I

    invoke-virtual {v3, p1, v4, p2, v2}, Landroid/content/Context;->obtainStyledAttributes(Landroid/util/AttributeSet;[III)Landroid/content/res/TypedArray;

    move-result-object p1

    invoke-virtual {p1}, Landroid/content/res/TypedArray;->getIndexCount()I

    move-result p2

    move v3, v2

    :goto_0
    if-ge v3, p2, :cond_7

    invoke-virtual {p1, v3}, Landroid/content/res/TypedArray;->getIndex(I)I

    move-result v4

    const/16 v5, 0x9

    if-ne v4, v5, :cond_0

    iget v5, p0, Landroidx/constraintlayout/widget/ConstraintLayout;->e:I

    invoke-virtual {p1, v4, v5}, Landroid/content/res/TypedArray;->getDimensionPixelOffset(II)I

    move-result v4

    iput v4, p0, Landroidx/constraintlayout/widget/ConstraintLayout;->e:I

    goto :goto_2

    :cond_0
    const/16 v5, 0xa

    if-ne v4, v5, :cond_1

    iget v5, p0, Landroidx/constraintlayout/widget/ConstraintLayout;->f:I

    invoke-virtual {p1, v4, v5}, Landroid/content/res/TypedArray;->getDimensionPixelOffset(II)I

    move-result v4

    iput v4, p0, Landroidx/constraintlayout/widget/ConstraintLayout;->f:I

    goto :goto_2

    :cond_1
    const/4 v5, 0x7

    if-ne v4, v5, :cond_2

    iget v5, p0, Landroidx/constraintlayout/widget/ConstraintLayout;->g:I

    invoke-virtual {p1, v4, v5}, Landroid/content/res/TypedArray;->getDimensionPixelOffset(II)I

    move-result v4

    iput v4, p0, Landroidx/constraintlayout/widget/ConstraintLayout;->g:I

    goto :goto_2

    :cond_2
    const/16 v5, 0x8

    if-ne v4, v5, :cond_3

    iget v5, p0, Landroidx/constraintlayout/widget/ConstraintLayout;->h:I

    invoke-virtual {p1, v4, v5}, Landroid/content/res/TypedArray;->getDimensionPixelOffset(II)I

    move-result v4

    iput v4, p0, Landroidx/constraintlayout/widget/ConstraintLayout;->h:I

    goto :goto_2

    :cond_3
    const/16 v5, 0x59

    if-ne v4, v5, :cond_4

    iget v5, p0, Landroidx/constraintlayout/widget/ConstraintLayout;->j:I

    invoke-virtual {p1, v4, v5}, Landroid/content/res/TypedArray;->getInt(II)I

    move-result v4

    iput v4, p0, Landroidx/constraintlayout/widget/ConstraintLayout;->j:I

    goto :goto_2

    :cond_4
    const/16 v5, 0x26

    if-ne v4, v5, :cond_5

    invoke-virtual {p1, v4, v2}, Landroid/content/res/TypedArray;->getResourceId(II)I

    move-result v4

    if-eqz v4, :cond_6

    :try_start_0
    new-instance v5, Lq/b;

    invoke-virtual {p0}, Landroid/view/View;->getContext()Landroid/content/Context;

    move-result-object v6

    invoke-direct {v5, v6, v4}, Lq/b;-><init>(Landroid/content/Context;I)V

    iput-object v5, p0, Landroidx/constraintlayout/widget/ConstraintLayout;->l:Lq/b;
    :try_end_0
    .catch Landroid/content/res/Resources$NotFoundException; {:try_start_0 .. :try_end_0} :catch_0

    goto :goto_2

    :catch_0
    iput-object v1, p0, Landroidx/constraintlayout/widget/ConstraintLayout;->l:Lq/b;

    goto :goto_2

    :cond_5
    const/16 v5, 0x12

    if-ne v4, v5, :cond_6

    invoke-virtual {p1, v4, v2}, Landroid/content/res/TypedArray;->getResourceId(II)I

    move-result v4

    :try_start_1
    new-instance v5, Landroidx/constraintlayout/widget/b;

    invoke-direct {v5}, Landroidx/constraintlayout/widget/b;-><init>()V

    iput-object v5, p0, Landroidx/constraintlayout/widget/ConstraintLayout;->k:Landroidx/constraintlayout/widget/b;

    invoke-virtual {p0}, Landroid/view/View;->getContext()Landroid/content/Context;

    move-result-object v6

    invoke-virtual {v5, v6, v4}, Landroidx/constraintlayout/widget/b;->e(Landroid/content/Context;I)V
    :try_end_1
    .catch Landroid/content/res/Resources$NotFoundException; {:try_start_1 .. :try_end_1} :catch_1

    goto :goto_1

    :catch_1
    iput-object v1, p0, Landroidx/constraintlayout/widget/ConstraintLayout;->k:Landroidx/constraintlayout/widget/b;

    :goto_1
    iput v4, p0, Landroidx/constraintlayout/widget/ConstraintLayout;->m:I

    :cond_6
    :goto_2
    add-int/lit8 v3, v3, 0x1

    goto :goto_0

    :cond_7
    invoke-virtual {p1}, Landroid/content/res/TypedArray;->recycle()V

    :cond_8
    iget p0, p0, Landroidx/constraintlayout/widget/ConstraintLayout;->j:I

    iput p0, v0, Lo/e;->q0:I

    const/16 p1, 0x100

    and-int/2addr p0, p1

    if-ne p0, p1, :cond_9

    const/4 v2, 0x1

    :cond_9
    sput-boolean v2, Ln/d;->p:Z

    return-void
.end method

.method public final checkLayoutParams(Landroid/view/ViewGroup$LayoutParams;)Z
    .locals 0

    instance-of p0, p1, Landroidx/constraintlayout/widget/ConstraintLayout$a;

    return p0
.end method

.method public final d()Z
    .locals 3

    invoke-virtual {p0}, Landroid/view/View;->getContext()Landroid/content/Context;

    move-result-object v0

    invoke-virtual {v0}, Landroid/content/Context;->getApplicationInfo()Landroid/content/pm/ApplicationInfo;

    move-result-object v0

    iget v0, v0, Landroid/content/pm/ApplicationInfo;->flags:I

    const/high16 v1, 0x400000

    and-int/2addr v0, v1

    const/4 v1, 0x0

    const/4 v2, 0x1

    if-eqz v0, :cond_0

    move v0, v2

    goto :goto_0

    :cond_0
    move v0, v1

    :goto_0
    if-eqz v0, :cond_1

    invoke-virtual {p0}, Landroid/view/View;->getLayoutDirection()I

    move-result p0

    if-ne v2, p0, :cond_1

    move v1, v2

    :cond_1
    return v1
.end method

.method public final dispatchDraw(Landroid/graphics/Canvas;)V
    .locals 18

    move-object/from16 v0, p0

    const/4 v1, 0x0

    iget-object v2, v0, Landroidx/constraintlayout/widget/ConstraintLayout;->c:Ljava/util/ArrayList;

    if-eqz v2, :cond_0

    invoke-virtual {v2}, Ljava/util/ArrayList;->size()I

    move-result v3

    if-lez v3, :cond_0

    move v4, v1

    :goto_0
    if-ge v4, v3, :cond_0

    invoke-virtual {v2, v4}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v5

    check-cast v5, Landroidx/constraintlayout/widget/a;

    invoke-virtual {v5}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    add-int/lit8 v4, v4, 0x1

    goto :goto_0

    :cond_0
    invoke-super/range {p0 .. p1}, Landroid/view/ViewGroup;->dispatchDraw(Landroid/graphics/Canvas;)V

    invoke-virtual/range {p0 .. p0}, Landroid/view/View;->isInEditMode()Z

    move-result v2

    if-eqz v2, :cond_3

    invoke-virtual/range {p0 .. p0}, Landroid/view/ViewGroup;->getChildCount()I

    move-result v2

    invoke-virtual/range {p0 .. p0}, Landroid/view/View;->getWidth()I

    move-result v3

    int-to-float v3, v3

    invoke-virtual/range {p0 .. p0}, Landroid/view/View;->getHeight()I

    move-result v4

    int-to-float v4, v4

    move v5, v1

    :goto_1
    if-ge v5, v2, :cond_3

    invoke-virtual {v0, v5}, Landroid/view/ViewGroup;->getChildAt(I)Landroid/view/View;

    move-result-object v6

    invoke-virtual {v6}, Landroid/view/View;->getVisibility()I

    move-result v7

    const/16 v8, 0x8

    if-ne v7, v8, :cond_1

    goto/16 :goto_2

    :cond_1
    invoke-virtual {v6}, Landroid/view/View;->getTag()Ljava/lang/Object;

    move-result-object v6

    if-eqz v6, :cond_2

    instance-of v7, v6, Ljava/lang/String;

    if-eqz v7, :cond_2

    check-cast v6, Ljava/lang/String;

    const-string v7, ","

    invoke-virtual {v6, v7}, Ljava/lang/String;->split(Ljava/lang/String;)[Ljava/lang/String;

    move-result-object v6

    array-length v7, v6

    const/4 v8, 0x4

    if-ne v7, v8, :cond_2

    aget-object v7, v6, v1

    invoke-static {v7}, Ljava/lang/Integer;->parseInt(Ljava/lang/String;)I

    move-result v7

    const/4 v8, 0x1

    aget-object v8, v6, v8

    invoke-static {v8}, Ljava/lang/Integer;->parseInt(Ljava/lang/String;)I

    move-result v8

    const/4 v9, 0x2

    aget-object v9, v6, v9

    invoke-static {v9}, Ljava/lang/Integer;->parseInt(Ljava/lang/String;)I

    move-result v9

    const/4 v10, 0x3

    aget-object v6, v6, v10

    invoke-static {v6}, Ljava/lang/Integer;->parseInt(Ljava/lang/String;)I

    move-result v6

    int-to-float v7, v7

    const/high16 v10, 0x44870000    # 1080.0f

    div-float/2addr v7, v10

    mul-float/2addr v7, v3

    float-to-int v7, v7

    int-to-float v8, v8

    const/high16 v11, 0x44f00000    # 1920.0f

    div-float/2addr v8, v11

    mul-float/2addr v8, v4

    float-to-int v8, v8

    int-to-float v9, v9

    div-float/2addr v9, v10

    mul-float/2addr v9, v3

    float-to-int v9, v9

    int-to-float v6, v6

    div-float/2addr v6, v11

    mul-float/2addr v6, v4

    float-to-int v6, v6

    new-instance v15, Landroid/graphics/Paint;

    invoke-direct {v15}, Landroid/graphics/Paint;-><init>()V

    const/high16 v10, -0x10000

    invoke-virtual {v15, v10}, Landroid/graphics/Paint;->setColor(I)V

    int-to-float v14, v7

    int-to-float v13, v8

    add-int/2addr v7, v9

    int-to-float v7, v7

    move-object/from16 v10, p1

    move v11, v14

    move v12, v13

    move v9, v13

    move v13, v7

    move/from16 v16, v14

    move v14, v9

    move-object/from16 v17, v15

    invoke-virtual/range {v10 .. v15}, Landroid/graphics/Canvas;->drawLine(FFFFLandroid/graphics/Paint;)V

    add-int/2addr v8, v6

    int-to-float v6, v8

    move v11, v7

    move v12, v9

    move v14, v6

    invoke-virtual/range {v10 .. v15}, Landroid/graphics/Canvas;->drawLine(FFFFLandroid/graphics/Paint;)V

    move v12, v6

    move/from16 v13, v16

    invoke-virtual/range {v10 .. v15}, Landroid/graphics/Canvas;->drawLine(FFFFLandroid/graphics/Paint;)V

    move/from16 v11, v16

    move v14, v9

    invoke-virtual/range {v10 .. v15}, Landroid/graphics/Canvas;->drawLine(FFFFLandroid/graphics/Paint;)V

    const v8, -0xff0100

    invoke-virtual {v15, v8}, Landroid/graphics/Paint;->setColor(I)V

    move v12, v9

    move v13, v7

    move v14, v6

    move-object v8, v15

    invoke-virtual/range {v10 .. v15}, Landroid/graphics/Canvas;->drawLine(FFFFLandroid/graphics/Paint;)V

    move v12, v6

    move v14, v9

    invoke-virtual/range {v10 .. v15}, Landroid/graphics/Canvas;->drawLine(FFFFLandroid/graphics/Paint;)V

    :cond_2
    :goto_2
    add-int/lit8 v5, v5, 0x1

    goto/16 :goto_1

    :cond_3
    return-void
.end method

.method public final e(Ljava/lang/String;Ljava/lang/Integer;)V
    .locals 2

    instance-of v0, p1, Ljava/lang/String;

    if-eqz v0, :cond_2

    instance-of v0, p2, Ljava/lang/Integer;

    if-eqz v0, :cond_2

    iget-object v0, p0, Landroidx/constraintlayout/widget/ConstraintLayout;->n:Ljava/util/HashMap;

    if-nez v0, :cond_0

    new-instance v0, Ljava/util/HashMap;

    invoke-direct {v0}, Ljava/util/HashMap;-><init>()V

    iput-object v0, p0, Landroidx/constraintlayout/widget/ConstraintLayout;->n:Ljava/util/HashMap;

    :cond_0
    const-string v0, "/"

    invoke-virtual {p1, v0}, Ljava/lang/String;->indexOf(Ljava/lang/String;)I

    move-result v0

    const/4 v1, -0x1

    if-eq v0, v1, :cond_1

    add-int/lit8 v0, v0, 0x1

    invoke-virtual {p1, v0}, Ljava/lang/String;->substring(I)Ljava/lang/String;

    move-result-object p1

    :cond_1
    invoke-virtual {p2}, Ljava/lang/Integer;->intValue()I

    move-result p2

    iget-object p0, p0, Landroidx/constraintlayout/widget/ConstraintLayout;->n:Ljava/util/HashMap;

    invoke-static {p2}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object p2

    invoke-virtual {p0, p1, p2}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    :cond_2
    return-void
.end method

.method public final f()Z
    .locals 25

    move-object/from16 v0, p0

    invoke-virtual/range {p0 .. p0}, Landroid/view/ViewGroup;->getChildCount()I

    move-result v1

    const/4 v2, 0x0

    move v3, v2

    :goto_0
    const/4 v4, 0x1

    if-ge v3, v1, :cond_1

    invoke-virtual {v0, v3}, Landroid/view/ViewGroup;->getChildAt(I)Landroid/view/View;

    move-result-object v5

    invoke-virtual {v5}, Landroid/view/View;->isLayoutRequested()Z

    move-result v5

    if-eqz v5, :cond_0

    move v1, v4

    goto :goto_1

    :cond_0
    add-int/lit8 v3, v3, 0x1

    goto :goto_0

    :cond_1
    move v1, v2

    :goto_1
    if-eqz v1, :cond_45

    invoke-virtual/range {p0 .. p0}, Landroid/view/View;->isInEditMode()Z

    move-result v3

    invoke-virtual/range {p0 .. p0}, Landroid/view/ViewGroup;->getChildCount()I

    move-result v5

    move v6, v2

    :goto_2
    if-ge v6, v5, :cond_3

    invoke-virtual {v0, v6}, Landroid/view/ViewGroup;->getChildAt(I)Landroid/view/View;

    move-result-object v7

    invoke-virtual {v0, v7}, Landroidx/constraintlayout/widget/ConstraintLayout;->b(Landroid/view/View;)Lo/d;

    move-result-object v7

    if-nez v7, :cond_2

    goto :goto_3

    :cond_2
    invoke-virtual {v7}, Lo/d;->s()V

    :goto_3
    add-int/lit8 v6, v6, 0x1

    goto :goto_2

    :cond_3
    iget-object v6, v0, Landroidx/constraintlayout/widget/ConstraintLayout;->b:Landroid/util/SparseArray;

    const/4 v7, 0x0

    const/4 v8, -0x1

    iget-object v9, v0, Landroidx/constraintlayout/widget/ConstraintLayout;->d:Lo/e;

    if-eqz v3, :cond_9

    move v10, v2

    :goto_4
    if-ge v10, v5, :cond_9

    invoke-virtual {v0, v10}, Landroid/view/ViewGroup;->getChildAt(I)Landroid/view/View;

    move-result-object v11

    :try_start_0
    invoke-virtual/range {p0 .. p0}, Landroid/view/View;->getResources()Landroid/content/res/Resources;

    move-result-object v12

    invoke-virtual {v11}, Landroid/view/View;->getId()I

    move-result v13

    invoke-virtual {v12, v13}, Landroid/content/res/Resources;->getResourceName(I)Ljava/lang/String;

    move-result-object v12

    invoke-virtual {v11}, Landroid/view/View;->getId()I

    move-result v13

    invoke-static {v13}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v13

    invoke-virtual {v0, v12, v13}, Landroidx/constraintlayout/widget/ConstraintLayout;->e(Ljava/lang/String;Ljava/lang/Integer;)V

    const/16 v13, 0x2f

    invoke-virtual {v12, v13}, Ljava/lang/String;->indexOf(I)I

    move-result v13

    if-eq v13, v8, :cond_4

    add-int/lit8 v13, v13, 0x1

    invoke-virtual {v12, v13}, Ljava/lang/String;->substring(I)Ljava/lang/String;

    move-result-object v12

    :cond_4
    invoke-virtual {v11}, Landroid/view/View;->getId()I

    move-result v11

    if-nez v11, :cond_5

    goto :goto_5

    :cond_5
    invoke-virtual {v6, v11}, Landroid/util/SparseArray;->get(I)Ljava/lang/Object;

    move-result-object v13

    check-cast v13, Landroid/view/View;

    if-nez v13, :cond_6

    invoke-virtual {v0, v11}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    move-result-object v13

    if-eqz v13, :cond_6

    if-eq v13, v0, :cond_6

    invoke-virtual {v13}, Landroid/view/View;->getParent()Landroid/view/ViewParent;

    move-result-object v11

    if-ne v11, v0, :cond_6

    invoke-virtual {v0, v13}, Landroidx/constraintlayout/widget/ConstraintLayout;->onViewAdded(Landroid/view/View;)V

    :cond_6
    if-ne v13, v0, :cond_7

    :goto_5
    move-object v11, v9

    goto :goto_6

    :cond_7
    if-nez v13, :cond_8

    move-object v11, v7

    goto :goto_6

    :cond_8
    invoke-virtual {v13}, Landroid/view/View;->getLayoutParams()Landroid/view/ViewGroup$LayoutParams;

    move-result-object v11

    check-cast v11, Landroidx/constraintlayout/widget/ConstraintLayout$a;

    iget-object v11, v11, Landroidx/constraintlayout/widget/ConstraintLayout$a;->l0:Lo/d;

    :goto_6
    iput-object v12, v11, Lo/d;->Y:Ljava/lang/String;
    :try_end_0
    .catch Landroid/content/res/Resources$NotFoundException; {:try_start_0 .. :try_end_0} :catch_0

    :catch_0
    add-int/lit8 v10, v10, 0x1

    goto :goto_4

    :cond_9
    iget v10, v0, Landroidx/constraintlayout/widget/ConstraintLayout;->m:I

    if-eq v10, v8, :cond_b

    move v10, v2

    :goto_7
    if-ge v10, v5, :cond_b

    invoke-virtual {v0, v10}, Landroid/view/ViewGroup;->getChildAt(I)Landroid/view/View;

    move-result-object v11

    invoke-virtual {v11}, Landroid/view/View;->getId()I

    move-result v12

    iget v13, v0, Landroidx/constraintlayout/widget/ConstraintLayout;->m:I

    if-ne v12, v13, :cond_a

    instance-of v12, v11, Landroidx/constraintlayout/widget/c;

    if-eqz v12, :cond_a

    check-cast v11, Landroidx/constraintlayout/widget/c;

    invoke-virtual {v11}, Landroidx/constraintlayout/widget/c;->getConstraintSet()Landroidx/constraintlayout/widget/b;

    move-result-object v11

    iput-object v11, v0, Landroidx/constraintlayout/widget/ConstraintLayout;->k:Landroidx/constraintlayout/widget/b;

    :cond_a
    add-int/lit8 v10, v10, 0x1

    goto :goto_7

    :cond_b
    iget-object v10, v0, Landroidx/constraintlayout/widget/ConstraintLayout;->k:Landroidx/constraintlayout/widget/b;

    if-eqz v10, :cond_c

    invoke-virtual {v10, v0}, Landroidx/constraintlayout/widget/b;->a(Landroidx/constraintlayout/widget/ConstraintLayout;)V

    :cond_c
    iget-object v10, v9, Lo/k;->e0:Ljava/util/ArrayList;

    invoke-virtual {v10}, Ljava/util/ArrayList;->clear()V

    iget-object v10, v0, Landroidx/constraintlayout/widget/ConstraintLayout;->c:Ljava/util/ArrayList;

    invoke-virtual {v10}, Ljava/util/ArrayList;->size()I

    move-result v11

    if-lez v11, :cond_14

    move v13, v2

    :goto_8
    if-ge v13, v11, :cond_14

    invoke-virtual {v10, v13}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v14

    check-cast v14, Landroidx/constraintlayout/widget/a;

    invoke-virtual {v14}, Landroid/view/View;->isInEditMode()Z

    move-result v15

    if-eqz v15, :cond_d

    iget-object v15, v14, Landroidx/constraintlayout/widget/a;->f:Ljava/lang/String;

    invoke-virtual {v14, v15}, Landroidx/constraintlayout/widget/a;->setIds(Ljava/lang/String;)V

    :cond_d
    iget-object v15, v14, Landroidx/constraintlayout/widget/a;->e:Lo/i;

    if-nez v15, :cond_e

    goto/16 :goto_b

    :cond_e
    iput v2, v15, Lo/i;->f0:I

    iget-object v15, v15, Lo/i;->e0:[Lo/d;

    invoke-static {v15, v7}, Ljava/util/Arrays;->fill([Ljava/lang/Object;Ljava/lang/Object;)V

    move v15, v2

    :goto_9
    iget v7, v14, Landroidx/constraintlayout/widget/a;->c:I

    if-ge v15, v7, :cond_13

    iget-object v7, v14, Landroidx/constraintlayout/widget/a;->b:[I

    aget v7, v7, v15

    invoke-virtual {v6, v7}, Landroid/util/SparseArray;->get(I)Ljava/lang/Object;

    move-result-object v17

    check-cast v17, Landroid/view/View;

    if-nez v17, :cond_f

    invoke-static {v7}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v7

    iget-object v2, v14, Landroidx/constraintlayout/widget/a;->g:Ljava/util/HashMap;

    invoke-virtual {v2, v7}, Ljava/util/HashMap;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v7

    check-cast v7, Ljava/lang/String;

    invoke-virtual {v14, v0, v7}, Landroidx/constraintlayout/widget/a;->d(Landroidx/constraintlayout/widget/ConstraintLayout;Ljava/lang/String;)I

    move-result v8

    if-eqz v8, :cond_f

    iget-object v12, v14, Landroidx/constraintlayout/widget/a;->b:[I

    aput v8, v12, v15

    invoke-static {v8}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v12

    invoke-virtual {v2, v12, v7}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    invoke-virtual {v6, v8}, Landroid/util/SparseArray;->get(I)Ljava/lang/Object;

    move-result-object v2

    move-object/from16 v17, v2

    check-cast v17, Landroid/view/View;

    :cond_f
    move-object/from16 v2, v17

    if-eqz v2, :cond_12

    iget-object v7, v14, Landroidx/constraintlayout/widget/a;->e:Lo/i;

    invoke-virtual {v0, v2}, Landroidx/constraintlayout/widget/ConstraintLayout;->b(Landroid/view/View;)Lo/d;

    move-result-object v2

    invoke-virtual {v7}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    if-eq v2, v7, :cond_12

    if-nez v2, :cond_10

    goto :goto_a

    :cond_10
    iget v8, v7, Lo/i;->f0:I

    add-int/2addr v8, v4

    iget-object v12, v7, Lo/i;->e0:[Lo/d;

    array-length v4, v12

    if-le v8, v4, :cond_11

    array-length v4, v12

    const/4 v8, 0x2

    mul-int/2addr v4, v8

    invoke-static {v12, v4}, Ljava/util/Arrays;->copyOf([Ljava/lang/Object;I)[Ljava/lang/Object;

    move-result-object v4

    check-cast v4, [Lo/d;

    iput-object v4, v7, Lo/i;->e0:[Lo/d;

    :cond_11
    iget-object v4, v7, Lo/i;->e0:[Lo/d;

    iget v8, v7, Lo/i;->f0:I

    aput-object v2, v4, v8

    const/4 v2, 0x1

    add-int/2addr v8, v2

    iput v8, v7, Lo/i;->f0:I

    :cond_12
    :goto_a
    add-int/lit8 v15, v15, 0x1

    const/4 v2, 0x0

    const/4 v4, 0x1

    const/4 v8, -0x1

    goto :goto_9

    :cond_13
    iget-object v2, v14, Landroidx/constraintlayout/widget/a;->e:Lo/i;

    invoke-interface {v2}, Lo/h;->a()V

    :goto_b
    add-int/lit8 v13, v13, 0x1

    const/4 v2, 0x0

    const/4 v4, 0x1

    const/4 v7, 0x0

    const/4 v8, -0x1

    goto/16 :goto_8

    :cond_14
    const/4 v2, 0x0

    :goto_c
    if-ge v2, v5, :cond_17

    invoke-virtual {v0, v2}, Landroid/view/ViewGroup;->getChildAt(I)Landroid/view/View;

    move-result-object v4

    instance-of v7, v4, Landroidx/constraintlayout/widget/e;

    if-eqz v7, :cond_16

    check-cast v4, Landroidx/constraintlayout/widget/e;

    iget v7, v4, Landroidx/constraintlayout/widget/e;->b:I

    const/4 v8, -0x1

    if-ne v7, v8, :cond_15

    invoke-virtual {v4}, Landroid/view/View;->isInEditMode()Z

    move-result v7

    if-nez v7, :cond_15

    iget v7, v4, Landroidx/constraintlayout/widget/e;->d:I

    invoke-virtual {v4, v7}, Landroid/view/View;->setVisibility(I)V

    :cond_15
    iget v7, v4, Landroidx/constraintlayout/widget/e;->b:I

    invoke-virtual {v0, v7}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    move-result-object v7

    iput-object v7, v4, Landroidx/constraintlayout/widget/e;->c:Landroid/view/View;

    if-eqz v7, :cond_16

    invoke-virtual {v7}, Landroid/view/View;->getLayoutParams()Landroid/view/ViewGroup$LayoutParams;

    move-result-object v7

    check-cast v7, Landroidx/constraintlayout/widget/ConstraintLayout$a;

    const/4 v8, 0x1

    iput-boolean v8, v7, Landroidx/constraintlayout/widget/ConstraintLayout$a;->a0:Z

    iget-object v7, v4, Landroidx/constraintlayout/widget/e;->c:Landroid/view/View;

    const/4 v8, 0x0

    invoke-virtual {v7, v8}, Landroid/view/View;->setVisibility(I)V

    invoke-virtual {v4, v8}, Landroid/view/View;->setVisibility(I)V

    goto :goto_d

    :cond_16
    const/4 v8, 0x0

    :goto_d
    add-int/lit8 v2, v2, 0x1

    goto :goto_c

    :cond_17
    const/4 v8, 0x0

    iget-object v2, v0, Landroidx/constraintlayout/widget/ConstraintLayout;->o:Landroid/util/SparseArray;

    invoke-virtual {v2}, Landroid/util/SparseArray;->clear()V

    invoke-virtual {v2, v8, v9}, Landroid/util/SparseArray;->put(ILjava/lang/Object;)V

    invoke-virtual/range {p0 .. p0}, Landroid/view/View;->getId()I

    move-result v4

    invoke-virtual {v2, v4, v9}, Landroid/util/SparseArray;->put(ILjava/lang/Object;)V

    const/4 v4, 0x0

    :goto_e
    if-ge v4, v5, :cond_18

    invoke-virtual {v0, v4}, Landroid/view/ViewGroup;->getChildAt(I)Landroid/view/View;

    move-result-object v7

    invoke-virtual {v0, v7}, Landroidx/constraintlayout/widget/ConstraintLayout;->b(Landroid/view/View;)Lo/d;

    move-result-object v8

    invoke-virtual {v7}, Landroid/view/View;->getId()I

    move-result v7

    invoke-virtual {v2, v7, v8}, Landroid/util/SparseArray;->put(ILjava/lang/Object;)V

    add-int/lit8 v4, v4, 0x1

    goto :goto_e

    :cond_18
    const/4 v8, 0x0

    :goto_f
    if-ge v8, v5, :cond_45

    invoke-virtual {v0, v8}, Landroid/view/ViewGroup;->getChildAt(I)Landroid/view/View;

    move-result-object v4

    invoke-virtual {v0, v4}, Landroidx/constraintlayout/widget/ConstraintLayout;->b(Landroid/view/View;)Lo/d;

    move-result-object v7

    if-nez v7, :cond_19

    const/4 v14, 0x0

    goto/16 :goto_11

    :cond_19
    invoke-virtual {v4}, Landroid/view/View;->getLayoutParams()Landroid/view/ViewGroup$LayoutParams;

    move-result-object v10

    move-object v15, v10

    check-cast v15, Landroidx/constraintlayout/widget/ConstraintLayout$a;

    iget-object v10, v9, Lo/k;->e0:Ljava/util/ArrayList;

    invoke-virtual {v10, v7}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    iget-object v10, v7, Lo/d;->K:Lo/d;

    if-eqz v10, :cond_1a

    check-cast v10, Lo/k;

    iget-object v10, v10, Lo/k;->e0:Ljava/util/ArrayList;

    invoke-virtual {v10, v7}, Ljava/util/ArrayList;->remove(Ljava/lang/Object;)Z

    const/4 v14, 0x0

    iput-object v14, v7, Lo/d;->K:Lo/d;

    goto :goto_10

    :cond_1a
    const/4 v14, 0x0

    :goto_10
    iput-object v9, v7, Lo/d;->K:Lo/d;

    invoke-virtual {v15}, Landroidx/constraintlayout/widget/ConstraintLayout$a;->a()V

    invoke-virtual {v4}, Landroid/view/View;->getVisibility()I

    move-result v10

    iput v10, v7, Lo/d;->X:I

    iget-boolean v10, v15, Landroidx/constraintlayout/widget/ConstraintLayout$a;->a0:Z

    if-eqz v10, :cond_1b

    const/4 v10, 0x1

    iput-boolean v10, v7, Lo/d;->x:Z

    const/16 v10, 0x8

    iput v10, v7, Lo/d;->X:I

    :cond_1b
    iput-object v4, v7, Lo/d;->W:Ljava/lang/Object;

    instance-of v10, v4, Landroidx/constraintlayout/widget/a;

    if-eqz v10, :cond_1c

    check-cast v4, Landroidx/constraintlayout/widget/a;

    iget-boolean v10, v9, Lo/e;->i0:Z

    invoke-virtual {v4, v7, v10}, Landroidx/constraintlayout/widget/a;->f(Lo/d;Z)V

    :cond_1c
    iget-boolean v4, v15, Landroidx/constraintlayout/widget/ConstraintLayout$a;->Y:Z

    if-eqz v4, :cond_20

    check-cast v7, Lo/g;

    iget v4, v15, Landroidx/constraintlayout/widget/ConstraintLayout$a;->i0:I

    iget v10, v15, Landroidx/constraintlayout/widget/ConstraintLayout$a;->j0:I

    iget v11, v15, Landroidx/constraintlayout/widget/ConstraintLayout$a;->k0:F

    const/high16 v12, -0x40800000    # -1.0f

    cmpl-float v13, v11, v12

    if-eqz v13, :cond_1d

    if-lez v13, :cond_1f

    iput v11, v7, Lo/g;->e0:F

    const/4 v11, -0x1

    iput v11, v7, Lo/g;->f0:I

    iput v11, v7, Lo/g;->g0:I

    goto :goto_11

    :cond_1d
    const/4 v11, -0x1

    if-eq v4, v11, :cond_1e

    if-le v4, v11, :cond_1f

    iput v12, v7, Lo/g;->e0:F

    iput v4, v7, Lo/g;->f0:I

    iput v11, v7, Lo/g;->g0:I

    goto :goto_11

    :cond_1e
    if-eq v10, v11, :cond_1f

    if-le v10, v11, :cond_1f

    iput v12, v7, Lo/g;->e0:F

    iput v11, v7, Lo/g;->f0:I

    iput v10, v7, Lo/g;->g0:I

    :cond_1f
    :goto_11
    move/from16 v19, v1

    move/from16 v21, v3

    move/from16 v16, v5

    move/from16 v20, v8

    move-object/from16 v18, v9

    const/4 v0, 0x2

    const/4 v3, 0x1

    const/4 v8, 0x0

    const/4 v9, -0x1

    goto/16 :goto_23

    :cond_20
    iget v4, v15, Landroidx/constraintlayout/widget/ConstraintLayout$a;->b0:I

    iget v10, v15, Landroidx/constraintlayout/widget/ConstraintLayout$a;->c0:I

    iget v13, v15, Landroidx/constraintlayout/widget/ConstraintLayout$a;->d0:I

    iget v12, v15, Landroidx/constraintlayout/widget/ConstraintLayout$a;->e0:I

    iget v11, v15, Landroidx/constraintlayout/widget/ConstraintLayout$a;->f0:I

    iget v0, v15, Landroidx/constraintlayout/widget/ConstraintLayout$a;->g0:I

    move/from16 v16, v5

    iget v5, v15, Landroidx/constraintlayout/widget/ConstraintLayout$a;->h0:F

    iget v14, v15, Landroidx/constraintlayout/widget/ConstraintLayout$a;->m:I

    move-object/from16 v18, v9

    sget-object v9, Lo/c$a;->d:Lo/c$a;

    move/from16 v19, v1

    sget-object v1, Lo/c$a;->b:Lo/c$a;

    move/from16 v20, v8

    sget-object v8, Lo/c$a;->e:Lo/c$a;

    move/from16 v21, v3

    sget-object v3, Lo/c$a;->c:Lo/c$a;

    move/from16 v22, v5

    const/4 v5, -0x1

    if-eq v14, v5, :cond_22

    invoke-virtual {v2, v14}, Landroid/util/SparseArray;->get(I)Ljava/lang/Object;

    move-result-object v0

    move-object v12, v0

    check-cast v12, Lo/d;

    if-eqz v12, :cond_21

    iget v0, v15, Landroidx/constraintlayout/widget/ConstraintLayout$a;->o:F

    iget v14, v15, Landroidx/constraintlayout/widget/ConstraintLayout$a;->n:I

    sget-object v13, Lo/c$a;->g:Lo/c$a;

    const/4 v4, 0x0

    move-object v10, v7

    move-object v11, v13

    const/4 v5, 0x0

    move-object v5, v15

    move v15, v4

    invoke-virtual/range {v10 .. v15}, Lo/d;->o(Lo/c$a;Lo/d;Lo/c$a;II)V

    iput v0, v7, Lo/d;->v:F

    goto :goto_12

    :cond_21
    move-object v5, v15

    :goto_12
    move-object/from16 v24, v1

    goto/16 :goto_19

    :cond_22
    move v14, v5

    move-object v5, v15

    if-eq v4, v14, :cond_23

    invoke-virtual {v2, v4}, Landroid/util/SparseArray;->get(I)Ljava/lang/Object;

    move-result-object v4

    check-cast v4, Lo/d;

    if-eqz v4, :cond_24

    iget v10, v5, Landroid/view/ViewGroup$MarginLayoutParams;->leftMargin:I

    move-object v14, v1

    :goto_13
    move v15, v10

    goto :goto_14

    :cond_23
    if-eq v10, v14, :cond_24

    invoke-virtual {v2, v10}, Landroid/util/SparseArray;->get(I)Ljava/lang/Object;

    move-result-object v4

    check-cast v4, Lo/d;

    if-eqz v4, :cond_24

    iget v10, v5, Landroid/view/ViewGroup$MarginLayoutParams;->leftMargin:I

    move-object v14, v9

    goto :goto_13

    :goto_14
    move-object v10, v7

    move/from16 v23, v11

    move-object v11, v1

    move-object/from16 v24, v1

    move v1, v12

    move-object v12, v4

    move v4, v13

    move-object v13, v14

    move v14, v15

    move/from16 v15, v23

    invoke-virtual/range {v10 .. v15}, Lo/d;->o(Lo/c$a;Lo/d;Lo/c$a;II)V

    goto :goto_15

    :cond_24
    move-object/from16 v24, v1

    move v1, v12

    move v4, v13

    :goto_15
    const/4 v10, -0x1

    if-eq v4, v10, :cond_25

    invoke-virtual {v2, v4}, Landroid/util/SparseArray;->get(I)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Lo/d;

    if-eqz v1, :cond_26

    iget v4, v5, Landroid/view/ViewGroup$MarginLayoutParams;->rightMargin:I

    move-object v12, v1

    move v14, v4

    move-object/from16 v13, v24

    goto :goto_16

    :cond_25
    if-eq v1, v10, :cond_26

    invoke-virtual {v2, v1}, Landroid/util/SparseArray;->get(I)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Lo/d;

    if-eqz v1, :cond_26

    iget v4, v5, Landroid/view/ViewGroup$MarginLayoutParams;->rightMargin:I

    move-object v12, v1

    move v14, v4

    move-object v13, v9

    :goto_16
    move-object v10, v7

    move-object v11, v9

    move v15, v0

    invoke-virtual/range {v10 .. v15}, Lo/d;->o(Lo/c$a;Lo/d;Lo/c$a;II)V

    :cond_26
    iget v0, v5, Landroidx/constraintlayout/widget/ConstraintLayout$a;->h:I

    const/4 v1, -0x1

    if-eq v0, v1, :cond_27

    invoke-virtual {v2, v0}, Landroid/util/SparseArray;->get(I)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Lo/d;

    if-eqz v0, :cond_28

    iget v4, v5, Landroid/view/ViewGroup$MarginLayoutParams;->topMargin:I

    iget v10, v5, Landroidx/constraintlayout/widget/ConstraintLayout$a;->u:I

    move-object v12, v0

    move-object v13, v3

    move v14, v4

    move v15, v10

    goto :goto_17

    :cond_27
    iget v0, v5, Landroidx/constraintlayout/widget/ConstraintLayout$a;->i:I

    if-eq v0, v1, :cond_28

    invoke-virtual {v2, v0}, Landroid/util/SparseArray;->get(I)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Lo/d;

    if-eqz v0, :cond_28

    iget v1, v5, Landroid/view/ViewGroup$MarginLayoutParams;->topMargin:I

    iget v4, v5, Landroidx/constraintlayout/widget/ConstraintLayout$a;->u:I

    move-object v12, v0

    move v14, v1

    move v15, v4

    move-object v13, v8

    :goto_17
    move-object v10, v7

    move-object v11, v3

    invoke-virtual/range {v10 .. v15}, Lo/d;->o(Lo/c$a;Lo/d;Lo/c$a;II)V

    :cond_28
    iget v0, v5, Landroidx/constraintlayout/widget/ConstraintLayout$a;->j:I

    const/4 v1, -0x1

    if-eq v0, v1, :cond_29

    invoke-virtual {v2, v0}, Landroid/util/SparseArray;->get(I)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Lo/d;

    if-eqz v0, :cond_2a

    iget v4, v5, Landroid/view/ViewGroup$MarginLayoutParams;->bottomMargin:I

    iget v10, v5, Landroidx/constraintlayout/widget/ConstraintLayout$a;->w:I

    move-object v12, v0

    move-object v13, v3

    move v14, v4

    move v15, v10

    goto :goto_18

    :cond_29
    iget v0, v5, Landroidx/constraintlayout/widget/ConstraintLayout$a;->k:I

    if-eq v0, v1, :cond_2a

    invoke-virtual {v2, v0}, Landroid/util/SparseArray;->get(I)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Lo/d;

    if-eqz v0, :cond_2a

    iget v1, v5, Landroid/view/ViewGroup$MarginLayoutParams;->bottomMargin:I

    iget v4, v5, Landroidx/constraintlayout/widget/ConstraintLayout$a;->w:I

    move-object v12, v0

    move v14, v1

    move v15, v4

    move-object v13, v8

    :goto_18
    move-object v10, v7

    move-object v11, v8

    invoke-virtual/range {v10 .. v15}, Lo/d;->o(Lo/c$a;Lo/d;Lo/c$a;II)V

    :cond_2a
    iget v0, v5, Landroidx/constraintlayout/widget/ConstraintLayout$a;->l:I

    const/4 v1, -0x1

    if-eq v0, v1, :cond_2b

    invoke-virtual {v6, v0}, Landroid/util/SparseArray;->get(I)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Landroid/view/View;

    iget v1, v5, Landroidx/constraintlayout/widget/ConstraintLayout$a;->l:I

    invoke-virtual {v2, v1}, Landroid/util/SparseArray;->get(I)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Lo/d;

    if-eqz v1, :cond_2b

    if-eqz v0, :cond_2b

    invoke-virtual {v0}, Landroid/view/View;->getLayoutParams()Landroid/view/ViewGroup$LayoutParams;

    move-result-object v4

    instance-of v4, v4, Landroidx/constraintlayout/widget/ConstraintLayout$a;

    if-eqz v4, :cond_2b

    invoke-virtual {v0}, Landroid/view/View;->getLayoutParams()Landroid/view/ViewGroup$LayoutParams;

    move-result-object v0

    check-cast v0, Landroidx/constraintlayout/widget/ConstraintLayout$a;

    const/4 v4, 0x1

    iput-boolean v4, v5, Landroidx/constraintlayout/widget/ConstraintLayout$a;->X:Z

    iput-boolean v4, v0, Landroidx/constraintlayout/widget/ConstraintLayout$a;->X:Z

    sget-object v10, Lo/c$a;->f:Lo/c$a;

    invoke-virtual {v7, v10}, Lo/d;->h(Lo/c$a;)Lo/c;

    move-result-object v11

    invoke-virtual {v1, v10}, Lo/d;->h(Lo/c$a;)Lo/c;

    move-result-object v1

    const/4 v10, -0x1

    const/4 v12, 0x0

    invoke-virtual {v11, v1, v12, v10, v4}, Lo/c;->b(Lo/c;IIZ)Z

    iput-boolean v4, v7, Lo/d;->w:Z

    iget-object v0, v0, Landroidx/constraintlayout/widget/ConstraintLayout$a;->l0:Lo/d;

    iput-boolean v4, v0, Lo/d;->w:Z

    invoke-virtual {v7, v3}, Lo/d;->h(Lo/c$a;)Lo/c;

    move-result-object v0

    invoke-virtual {v0}, Lo/c;->h()V

    invoke-virtual {v7, v8}, Lo/d;->h(Lo/c$a;)Lo/c;

    move-result-object v0

    invoke-virtual {v0}, Lo/c;->h()V

    :cond_2b
    const/4 v0, 0x0

    cmpl-float v1, v22, v0

    if-ltz v1, :cond_2c

    move/from16 v1, v22

    iput v1, v7, Lo/d;->U:F

    :cond_2c
    iget v1, v5, Landroidx/constraintlayout/widget/ConstraintLayout$a;->A:F

    cmpl-float v4, v1, v0

    if-ltz v4, :cond_2d

    iput v1, v7, Lo/d;->V:F

    :cond_2d
    :goto_19
    if-eqz v21, :cond_2f

    iget v0, v5, Landroidx/constraintlayout/widget/ConstraintLayout$a;->P:I

    const/4 v1, -0x1

    if-ne v0, v1, :cond_2e

    iget v4, v5, Landroidx/constraintlayout/widget/ConstraintLayout$a;->Q:I

    if-eq v4, v1, :cond_2f

    :cond_2e
    iget v1, v5, Landroidx/constraintlayout/widget/ConstraintLayout$a;->Q:I

    iput v0, v7, Lo/d;->P:I

    iput v1, v7, Lo/d;->Q:I

    :cond_2f
    iget-boolean v0, v5, Landroidx/constraintlayout/widget/ConstraintLayout$a;->V:Z

    const/4 v1, 0x4

    const/4 v4, 0x3

    const/4 v10, -0x2

    if-nez v0, :cond_32

    iget v0, v5, Landroid/view/ViewGroup$MarginLayoutParams;->width:I

    const/4 v11, -0x1

    if-ne v0, v11, :cond_31

    iget-boolean v0, v5, Landroidx/constraintlayout/widget/ConstraintLayout$a;->S:Z

    if-eqz v0, :cond_30

    invoke-virtual {v7, v4}, Lo/d;->w(I)V

    goto :goto_1a

    :cond_30
    invoke-virtual {v7, v1}, Lo/d;->w(I)V

    :goto_1a
    move-object/from16 v0, v24

    invoke-virtual {v7, v0}, Lo/d;->h(Lo/c$a;)Lo/c;

    move-result-object v0

    iget v11, v5, Landroid/view/ViewGroup$MarginLayoutParams;->leftMargin:I

    iput v11, v0, Lo/c;->e:I

    invoke-virtual {v7, v9}, Lo/d;->h(Lo/c$a;)Lo/c;

    move-result-object v0

    iget v9, v5, Landroid/view/ViewGroup$MarginLayoutParams;->rightMargin:I

    iput v9, v0, Lo/c;->e:I

    goto :goto_1b

    :cond_31
    invoke-virtual {v7, v4}, Lo/d;->w(I)V

    const/4 v0, 0x0

    invoke-virtual {v7, v0}, Lo/d;->y(I)V

    goto :goto_1b

    :cond_32
    const/4 v0, 0x1

    invoke-virtual {v7, v0}, Lo/d;->w(I)V

    iget v0, v5, Landroid/view/ViewGroup$MarginLayoutParams;->width:I

    invoke-virtual {v7, v0}, Lo/d;->y(I)V

    iget v0, v5, Landroid/view/ViewGroup$MarginLayoutParams;->width:I

    if-ne v0, v10, :cond_33

    const/4 v0, 0x2

    invoke-virtual {v7, v0}, Lo/d;->w(I)V

    :cond_33
    :goto_1b
    iget-boolean v0, v5, Landroidx/constraintlayout/widget/ConstraintLayout$a;->W:Z

    if-nez v0, :cond_36

    iget v0, v5, Landroid/view/ViewGroup$MarginLayoutParams;->height:I

    const/4 v9, -0x1

    if-ne v0, v9, :cond_35

    iget-boolean v0, v5, Landroidx/constraintlayout/widget/ConstraintLayout$a;->T:Z

    if-eqz v0, :cond_34

    invoke-virtual {v7, v4}, Lo/d;->x(I)V

    goto :goto_1c

    :cond_34
    invoke-virtual {v7, v1}, Lo/d;->x(I)V

    :goto_1c
    invoke-virtual {v7, v3}, Lo/d;->h(Lo/c$a;)Lo/c;

    move-result-object v0

    iget v1, v5, Landroid/view/ViewGroup$MarginLayoutParams;->topMargin:I

    iput v1, v0, Lo/c;->e:I

    invoke-virtual {v7, v8}, Lo/d;->h(Lo/c$a;)Lo/c;

    move-result-object v0

    iget v1, v5, Landroid/view/ViewGroup$MarginLayoutParams;->bottomMargin:I

    iput v1, v0, Lo/c;->e:I

    goto :goto_1d

    :cond_35
    invoke-virtual {v7, v4}, Lo/d;->x(I)V

    const/4 v0, 0x0

    invoke-virtual {v7, v0}, Lo/d;->v(I)V

    goto :goto_1d

    :cond_36
    const/4 v0, 0x1

    const/4 v9, -0x1

    invoke-virtual {v7, v0}, Lo/d;->x(I)V

    iget v0, v5, Landroid/view/ViewGroup$MarginLayoutParams;->height:I

    invoke-virtual {v7, v0}, Lo/d;->v(I)V

    iget v0, v5, Landroid/view/ViewGroup$MarginLayoutParams;->height:I

    if-ne v0, v10, :cond_37

    const/4 v0, 0x2

    invoke-virtual {v7, v0}, Lo/d;->x(I)V

    :cond_37
    :goto_1d
    iget-object v0, v5, Landroidx/constraintlayout/widget/ConstraintLayout$a;->B:Ljava/lang/String;

    if-eqz v0, :cond_3f

    invoke-virtual {v0}, Ljava/lang/String;->length()I

    move-result v1

    if-nez v1, :cond_38

    goto/16 :goto_21

    :cond_38
    invoke-virtual {v0}, Ljava/lang/String;->length()I

    move-result v1

    const/16 v3, 0x2c

    invoke-virtual {v0, v3}, Ljava/lang/String;->indexOf(I)I

    move-result v3

    if-lez v3, :cond_3b

    add-int/lit8 v4, v1, -0x1

    if-ge v3, v4, :cond_3b

    const/4 v4, 0x0

    invoke-virtual {v0, v4, v3}, Ljava/lang/String;->substring(II)Ljava/lang/String;

    move-result-object v8

    const-string v4, "W"

    invoke-virtual {v8, v4}, Ljava/lang/String;->equalsIgnoreCase(Ljava/lang/String;)Z

    move-result v4

    if-eqz v4, :cond_39

    const/4 v4, 0x0

    goto :goto_1e

    :cond_39
    const-string v4, "H"

    invoke-virtual {v8, v4}, Ljava/lang/String;->equalsIgnoreCase(Ljava/lang/String;)Z

    move-result v4

    if-eqz v4, :cond_3a

    const/4 v4, 0x1

    goto :goto_1e

    :cond_3a
    move v4, v9

    :goto_1e
    add-int/lit8 v8, v3, 0x1

    goto :goto_1f

    :cond_3b
    move v4, v9

    const/4 v8, 0x0

    :goto_1f
    const/16 v3, 0x3a

    invoke-virtual {v0, v3}, Ljava/lang/String;->indexOf(I)I

    move-result v3

    if-ltz v3, :cond_3d

    add-int/lit8 v1, v1, -0x1

    if-ge v3, v1, :cond_3d

    invoke-virtual {v0, v8, v3}, Ljava/lang/String;->substring(II)Ljava/lang/String;

    move-result-object v1

    add-int/lit8 v3, v3, 0x1

    invoke-virtual {v0, v3}, Ljava/lang/String;->substring(I)Ljava/lang/String;

    move-result-object v0

    invoke-virtual {v1}, Ljava/lang/String;->length()I

    move-result v3

    if-lez v3, :cond_3e

    invoke-virtual {v0}, Ljava/lang/String;->length()I

    move-result v3

    if-lez v3, :cond_3e

    :try_start_1
    invoke-static {v1}, Ljava/lang/Float;->parseFloat(Ljava/lang/String;)F

    move-result v1

    invoke-static {v0}, Ljava/lang/Float;->parseFloat(Ljava/lang/String;)F

    move-result v0

    const/4 v3, 0x0

    cmpl-float v8, v1, v3

    if-lez v8, :cond_3e

    cmpl-float v8, v0, v3

    if-lez v8, :cond_3e

    const/4 v3, 0x1

    if-ne v4, v3, :cond_3c

    div-float/2addr v0, v1

    invoke-static {v0}, Ljava/lang/Math;->abs(F)F

    move-result v0

    goto :goto_20

    :cond_3c
    div-float/2addr v1, v0

    invoke-static {v1}, Ljava/lang/Math;->abs(F)F

    move-result v0
    :try_end_1
    .catch Ljava/lang/NumberFormatException; {:try_start_1 .. :try_end_1} :catch_1

    goto :goto_20

    :cond_3d
    invoke-virtual {v0, v8}, Ljava/lang/String;->substring(I)Ljava/lang/String;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/String;->length()I

    move-result v1

    if-lez v1, :cond_3e

    :try_start_2
    invoke-static {v0}, Ljava/lang/Float;->parseFloat(Ljava/lang/String;)F

    move-result v0
    :try_end_2
    .catch Ljava/lang/NumberFormatException; {:try_start_2 .. :try_end_2} :catch_1

    goto :goto_20

    :catch_1
    :cond_3e
    const/4 v0, 0x0

    :goto_20
    const/4 v1, 0x0

    cmpl-float v3, v0, v1

    if-lez v3, :cond_40

    iput v0, v7, Lo/d;->N:F

    iput v4, v7, Lo/d;->O:I

    goto :goto_22

    :cond_3f
    :goto_21
    const/4 v1, 0x0

    iput v1, v7, Lo/d;->N:F

    :cond_40
    :goto_22
    iget v0, v5, Landroidx/constraintlayout/widget/ConstraintLayout$a;->D:F

    iget-object v1, v7, Lo/d;->b0:[F

    const/4 v8, 0x0

    aput v0, v1, v8

    iget v0, v5, Landroidx/constraintlayout/widget/ConstraintLayout$a;->E:F

    const/4 v3, 0x1

    aput v0, v1, v3

    iget v0, v5, Landroidx/constraintlayout/widget/ConstraintLayout$a;->F:I

    iput v0, v7, Lo/d;->Z:I

    iget v0, v5, Landroidx/constraintlayout/widget/ConstraintLayout$a;->G:I

    iput v0, v7, Lo/d;->a0:I

    iget v0, v5, Landroidx/constraintlayout/widget/ConstraintLayout$a;->H:I

    iget v1, v5, Landroidx/constraintlayout/widget/ConstraintLayout$a;->J:I

    iget v4, v5, Landroidx/constraintlayout/widget/ConstraintLayout$a;->L:I

    iget v10, v5, Landroidx/constraintlayout/widget/ConstraintLayout$a;->N:F

    iput v0, v7, Lo/d;->j:I

    iput v1, v7, Lo/d;->m:I

    const v1, 0x7fffffff

    if-ne v4, v1, :cond_41

    move v4, v8

    :cond_41
    iput v4, v7, Lo/d;->n:I

    iput v10, v7, Lo/d;->o:F

    const/4 v4, 0x0

    cmpl-float v11, v10, v4

    const/high16 v4, 0x3f800000    # 1.0f

    if-lez v11, :cond_42

    cmpg-float v10, v10, v4

    if-gez v10, :cond_42

    if-nez v0, :cond_42

    const/4 v0, 0x2

    iput v0, v7, Lo/d;->j:I

    :cond_42
    iget v0, v5, Landroidx/constraintlayout/widget/ConstraintLayout$a;->I:I

    iget v10, v5, Landroidx/constraintlayout/widget/ConstraintLayout$a;->K:I

    iget v11, v5, Landroidx/constraintlayout/widget/ConstraintLayout$a;->M:I

    iget v5, v5, Landroidx/constraintlayout/widget/ConstraintLayout$a;->O:F

    iput v0, v7, Lo/d;->k:I

    iput v10, v7, Lo/d;->p:I

    if-ne v11, v1, :cond_43

    move v11, v8

    :cond_43
    iput v11, v7, Lo/d;->q:I

    iput v5, v7, Lo/d;->r:F

    const/4 v1, 0x0

    cmpl-float v1, v5, v1

    if-lez v1, :cond_44

    cmpg-float v1, v5, v4

    if-gez v1, :cond_44

    if-nez v0, :cond_44

    const/4 v0, 0x2

    iput v0, v7, Lo/d;->k:I

    goto :goto_23

    :cond_44
    const/4 v0, 0x2

    :goto_23
    add-int/lit8 v1, v20, 0x1

    move-object/from16 v0, p0

    move v8, v1

    move/from16 v5, v16

    move-object/from16 v9, v18

    move/from16 v1, v19

    move/from16 v3, v21

    goto/16 :goto_f

    :cond_45
    move/from16 v19, v1

    return v19
.end method

.method public final forceLayout()V
    .locals 1

    const/4 v0, 0x1

    iput-boolean v0, p0, Landroidx/constraintlayout/widget/ConstraintLayout;->i:Z

    invoke-super {p0}, Landroid/view/View;->forceLayout()V

    return-void
.end method

.method public final generateDefaultLayoutParams()Landroid/view/ViewGroup$LayoutParams;
    .locals 0

    new-instance p0, Landroidx/constraintlayout/widget/ConstraintLayout$a;

    invoke-direct {p0}, Landroidx/constraintlayout/widget/ConstraintLayout$a;-><init>()V

    return-object p0
.end method

.method public final generateLayoutParams(Landroid/util/AttributeSet;)Landroid/view/ViewGroup$LayoutParams;
    .locals 1

    new-instance v0, Landroidx/constraintlayout/widget/ConstraintLayout$a;

    invoke-virtual {p0}, Landroid/view/View;->getContext()Landroid/content/Context;

    move-result-object p0

    invoke-direct {v0, p0, p1}, Landroidx/constraintlayout/widget/ConstraintLayout$a;-><init>(Landroid/content/Context;Landroid/util/AttributeSet;)V

    return-object v0
.end method

.method public final generateLayoutParams(Landroid/view/ViewGroup$LayoutParams;)Landroid/view/ViewGroup$LayoutParams;
    .locals 0

    new-instance p0, Landroidx/constraintlayout/widget/ConstraintLayout$a;

    invoke-direct {p0, p1}, Landroidx/constraintlayout/widget/ConstraintLayout$a;-><init>(Landroid/view/ViewGroup$LayoutParams;)V

    return-object p0
.end method

.method public getMaxHeight()I
    .locals 0

    iget p0, p0, Landroidx/constraintlayout/widget/ConstraintLayout;->h:I

    return p0
.end method

.method public getMaxWidth()I
    .locals 0

    iget p0, p0, Landroidx/constraintlayout/widget/ConstraintLayout;->g:I

    return p0
.end method

.method public getMinHeight()I
    .locals 0

    iget p0, p0, Landroidx/constraintlayout/widget/ConstraintLayout;->f:I

    return p0
.end method

.method public getMinWidth()I
    .locals 0

    iget p0, p0, Landroidx/constraintlayout/widget/ConstraintLayout;->e:I

    return p0
.end method

.method public getOptimizationLevel()I
    .locals 0

    iget-object p0, p0, Landroidx/constraintlayout/widget/ConstraintLayout;->d:Lo/e;

    iget p0, p0, Lo/e;->q0:I

    return p0
.end method

.method public onLayout(ZIIII)V
    .locals 5

    invoke-virtual {p0}, Landroid/view/ViewGroup;->getChildCount()I

    move-result p1

    invoke-virtual {p0}, Landroid/view/View;->isInEditMode()Z

    move-result p2

    const/4 p3, 0x0

    move p4, p3

    :goto_0
    if-ge p4, p1, :cond_3

    invoke-virtual {p0, p4}, Landroid/view/ViewGroup;->getChildAt(I)Landroid/view/View;

    move-result-object p5

    invoke-virtual {p5}, Landroid/view/View;->getLayoutParams()Landroid/view/ViewGroup$LayoutParams;

    move-result-object v0

    check-cast v0, Landroidx/constraintlayout/widget/ConstraintLayout$a;

    iget-object v1, v0, Landroidx/constraintlayout/widget/ConstraintLayout$a;->l0:Lo/d;

    invoke-virtual {p5}, Landroid/view/View;->getVisibility()I

    move-result v2

    const/16 v3, 0x8

    if-ne v2, v3, :cond_0

    iget-boolean v2, v0, Landroidx/constraintlayout/widget/ConstraintLayout$a;->Y:Z

    if-nez v2, :cond_0

    iget-boolean v2, v0, Landroidx/constraintlayout/widget/ConstraintLayout$a;->Z:Z

    if-nez v2, :cond_0

    if-nez p2, :cond_0

    goto :goto_1

    :cond_0
    iget-boolean v0, v0, Landroidx/constraintlayout/widget/ConstraintLayout$a;->a0:Z

    if-eqz v0, :cond_1

    goto :goto_1

    :cond_1
    invoke-virtual {v1}, Lo/d;->m()I

    move-result v0

    invoke-virtual {v1}, Lo/d;->n()I

    move-result v2

    invoke-virtual {v1}, Lo/d;->l()I

    move-result v3

    add-int/2addr v3, v0

    invoke-virtual {v1}, Lo/d;->j()I

    move-result v1

    add-int/2addr v1, v2

    invoke-virtual {p5, v0, v2, v3, v1}, Landroid/view/View;->layout(IIII)V

    instance-of v4, p5, Landroidx/constraintlayout/widget/e;

    if-eqz v4, :cond_2

    check-cast p5, Landroidx/constraintlayout/widget/e;

    invoke-virtual {p5}, Landroidx/constraintlayout/widget/e;->getContent()Landroid/view/View;

    move-result-object p5

    if-eqz p5, :cond_2

    invoke-virtual {p5, p3}, Landroid/view/View;->setVisibility(I)V

    invoke-virtual {p5, v0, v2, v3, v1}, Landroid/view/View;->layout(IIII)V

    :cond_2
    :goto_1
    add-int/lit8 p4, p4, 0x1

    goto :goto_0

    :cond_3
    iget-object p0, p0, Landroidx/constraintlayout/widget/ConstraintLayout;->c:Ljava/util/ArrayList;

    invoke-virtual {p0}, Ljava/util/ArrayList;->size()I

    move-result p1

    if-lez p1, :cond_4

    :goto_2
    if-ge p3, p1, :cond_4

    invoke-virtual {p0, p3}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object p2

    check-cast p2, Landroidx/constraintlayout/widget/a;

    invoke-virtual {p2}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    add-int/lit8 p3, p3, 0x1

    goto :goto_2

    :cond_4
    return-void
.end method

.method public onMeasure(II)V
    .locals 28

    move-object/from16 v0, p0

    move/from16 v1, p1

    move/from16 v2, p2

    invoke-virtual/range {p0 .. p0}, Landroidx/constraintlayout/widget/ConstraintLayout;->d()Z

    move-result v3

    iget-object v4, v0, Landroidx/constraintlayout/widget/ConstraintLayout;->d:Lo/e;

    iput-boolean v3, v4, Lo/e;->i0:Z

    iget-boolean v3, v0, Landroidx/constraintlayout/widget/ConstraintLayout;->i:Z

    iget-object v5, v4, Lo/e;->f0:Lp/b;

    iget-object v6, v4, Lo/e;->g0:Lp/e;

    const/4 v7, 0x4

    const/4 v8, 0x3

    const/4 v9, 0x1

    const/4 v10, 0x0

    if-eqz v3, :cond_3

    iput-boolean v10, v0, Landroidx/constraintlayout/widget/ConstraintLayout;->i:Z

    invoke-virtual/range {p0 .. p0}, Landroidx/constraintlayout/widget/ConstraintLayout;->f()Z

    move-result v3

    if-eqz v3, :cond_3

    iget-object v3, v5, Lp/b;->a:Ljava/util/ArrayList;

    invoke-virtual {v3}, Ljava/util/ArrayList;->clear()V

    iget-object v11, v4, Lo/k;->e0:Ljava/util/ArrayList;

    invoke-virtual {v11}, Ljava/util/ArrayList;->size()I

    move-result v11

    move v12, v10

    :goto_0
    if-ge v12, v11, :cond_2

    iget-object v13, v4, Lo/k;->e0:Ljava/util/ArrayList;

    invoke-virtual {v13, v12}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v13

    check-cast v13, Lo/d;

    iget-object v14, v13, Lo/d;->J:[I

    aget v15, v14, v10

    if-eq v15, v8, :cond_0

    if-eq v15, v7, :cond_0

    aget v14, v14, v9

    if-eq v14, v8, :cond_0

    if-ne v14, v7, :cond_1

    :cond_0
    invoke-virtual {v3, v13}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    :cond_1
    add-int/lit8 v12, v12, 0x1

    goto :goto_0

    :cond_2
    iput-boolean v9, v6, Lp/e;->b:Z

    :cond_3
    iget v3, v0, Landroidx/constraintlayout/widget/ConstraintLayout;->j:I

    invoke-static/range {p1 .. p1}, Landroid/view/View$MeasureSpec;->getMode(I)I

    move-result v11

    invoke-static/range {p1 .. p1}, Landroid/view/View$MeasureSpec;->getSize(I)I

    move-result v12

    invoke-static/range {p2 .. p2}, Landroid/view/View$MeasureSpec;->getMode(I)I

    move-result v13

    invoke-static/range {p2 .. p2}, Landroid/view/View$MeasureSpec;->getSize(I)I

    move-result v14

    invoke-virtual/range {p0 .. p0}, Landroid/view/View;->getPaddingTop()I

    move-result v15

    invoke-static {v10, v15}, Ljava/lang/Math;->max(II)I

    move-result v15

    invoke-virtual/range {p0 .. p0}, Landroid/view/View;->getPaddingBottom()I

    move-result v7

    invoke-static {v10, v7}, Ljava/lang/Math;->max(II)I

    move-result v7

    add-int v8, v15, v7

    invoke-direct/range {p0 .. p0}, Landroidx/constraintlayout/widget/ConstraintLayout;->getPaddingWidth()I

    move-result v9

    iget-object v10, v0, Landroidx/constraintlayout/widget/ConstraintLayout;->p:Landroidx/constraintlayout/widget/ConstraintLayout$b;

    iput v15, v10, Landroidx/constraintlayout/widget/ConstraintLayout$b;->b:I

    iput v7, v10, Landroidx/constraintlayout/widget/ConstraintLayout$b;->c:I

    iput v9, v10, Landroidx/constraintlayout/widget/ConstraintLayout$b;->d:I

    iput v8, v10, Landroidx/constraintlayout/widget/ConstraintLayout$b;->e:I

    iput v1, v10, Landroidx/constraintlayout/widget/ConstraintLayout$b;->f:I

    iput v2, v10, Landroidx/constraintlayout/widget/ConstraintLayout$b;->g:I

    invoke-virtual/range {p0 .. p0}, Landroid/view/View;->getPaddingStart()I

    move-result v7

    const/4 v2, 0x0

    invoke-static {v2, v7}, Ljava/lang/Math;->max(II)I

    move-result v7

    invoke-virtual/range {p0 .. p0}, Landroid/view/View;->getPaddingEnd()I

    move-result v1

    invoke-static {v2, v1}, Ljava/lang/Math;->max(II)I

    move-result v1

    if-gtz v7, :cond_5

    if-lez v1, :cond_4

    goto :goto_1

    :cond_4
    invoke-virtual/range {p0 .. p0}, Landroid/view/View;->getPaddingLeft()I

    move-result v1

    invoke-static {v2, v1}, Ljava/lang/Math;->max(II)I

    move-result v7

    goto :goto_2

    :cond_5
    :goto_1
    invoke-virtual/range {p0 .. p0}, Landroidx/constraintlayout/widget/ConstraintLayout;->d()Z

    move-result v2

    if-eqz v2, :cond_6

    move v7, v1

    :cond_6
    :goto_2
    sub-int/2addr v12, v9

    sub-int/2addr v14, v8

    iget v1, v10, Landroidx/constraintlayout/widget/ConstraintLayout$b;->e:I

    iget v2, v10, Landroidx/constraintlayout/widget/ConstraintLayout$b;->d:I

    invoke-virtual/range {p0 .. p0}, Landroid/view/ViewGroup;->getChildCount()I

    move-result v8

    const/high16 v9, -0x80000000

    move-object/from16 v19, v10

    const/high16 v10, 0x40000000    # 2.0f

    if-eq v11, v9, :cond_a

    if-eqz v11, :cond_8

    if-eq v11, v10, :cond_7

    const/4 v10, 0x1

    goto :goto_3

    :cond_7
    iget v10, v0, Landroidx/constraintlayout/widget/ConstraintLayout;->g:I

    sub-int/2addr v10, v2

    invoke-static {v10, v12}, Ljava/lang/Math;->min(II)I

    move-result v10

    move/from16 v21, v12

    move v12, v9

    move v9, v10

    const/4 v10, 0x1

    goto :goto_6

    :cond_8
    if-nez v8, :cond_9

    goto :goto_4

    :cond_9
    const/4 v10, 0x2

    :goto_3
    move/from16 v21, v12

    move v12, v9

    const/4 v9, 0x0

    goto :goto_6

    :cond_a
    if-nez v8, :cond_b

    :goto_4
    iget v10, v0, Landroidx/constraintlayout/widget/ConstraintLayout;->e:I

    const/4 v9, 0x0

    invoke-static {v9, v10}, Ljava/lang/Math;->max(II)I

    move-result v10

    goto :goto_5

    :cond_b
    move v10, v12

    :goto_5
    move v9, v10

    move/from16 v21, v12

    const/4 v10, 0x2

    const/high16 v12, -0x80000000

    :goto_6
    if-eq v13, v12, :cond_f

    if-eqz v13, :cond_d

    const/high16 v12, 0x40000000    # 2.0f

    if-eq v13, v12, :cond_c

    const/4 v8, 0x1

    goto :goto_7

    :cond_c
    iget v8, v0, Landroidx/constraintlayout/widget/ConstraintLayout;->h:I

    sub-int/2addr v8, v1

    invoke-static {v8, v14}, Ljava/lang/Math;->min(II)I

    move-result v8

    move v12, v8

    move/from16 v22, v14

    const/4 v8, 0x1

    goto :goto_a

    :cond_d
    if-nez v8, :cond_e

    goto :goto_8

    :cond_e
    const/4 v8, 0x2

    :goto_7
    move/from16 v22, v14

    const/4 v12, 0x0

    goto :goto_a

    :cond_f
    if-nez v8, :cond_10

    :goto_8
    iget v8, v0, Landroidx/constraintlayout/widget/ConstraintLayout;->f:I

    const/4 v12, 0x0

    invoke-static {v12, v8}, Ljava/lang/Math;->max(II)I

    move-result v8

    goto :goto_9

    :cond_10
    move v8, v14

    :goto_9
    move v12, v8

    move/from16 v22, v14

    const/4 v8, 0x2

    :goto_a
    invoke-virtual {v4}, Lo/d;->l()I

    move-result v14

    if-ne v9, v14, :cond_11

    invoke-virtual {v4}, Lo/d;->j()I

    move-result v14

    if-eq v12, v14, :cond_12

    :cond_11
    const/4 v14, 0x1

    iput-boolean v14, v6, Lp/e;->c:Z

    :cond_12
    const/4 v14, 0x0

    iput v14, v4, Lo/d;->P:I

    iput v14, v4, Lo/d;->Q:I

    iget v14, v0, Landroidx/constraintlayout/widget/ConstraintLayout;->g:I

    sub-int/2addr v14, v2

    move-object/from16 v23, v6

    iget-object v6, v4, Lo/d;->u:[I

    move/from16 v24, v13

    const/4 v13, 0x0

    aput v14, v6, v13

    iget v14, v0, Landroidx/constraintlayout/widget/ConstraintLayout;->h:I

    sub-int/2addr v14, v1

    const/16 v18, 0x1

    aput v14, v6, v18

    iput v13, v4, Lo/d;->S:I

    iput v13, v4, Lo/d;->T:I

    invoke-virtual {v4, v10}, Lo/d;->w(I)V

    invoke-virtual {v4, v9}, Lo/d;->y(I)V

    invoke-virtual {v4, v8}, Lo/d;->x(I)V

    invoke-virtual {v4, v12}, Lo/d;->v(I)V

    iget v8, v0, Landroidx/constraintlayout/widget/ConstraintLayout;->e:I

    sub-int v2, v8, v2

    if-gez v2, :cond_13

    const/4 v2, 0x0

    :cond_13
    iput v2, v4, Lo/d;->S:I

    iget v2, v0, Landroidx/constraintlayout/widget/ConstraintLayout;->f:I

    sub-int v1, v2, v1

    if-gez v1, :cond_14

    const/4 v1, 0x0

    :cond_14
    iput v1, v4, Lo/d;->T:I

    iput v7, v4, Lo/e;->k0:I

    iput v15, v4, Lo/e;->l0:I

    invoke-virtual {v5}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    iget-object v1, v4, Lo/e;->h0:Lp/b$b;

    iget-object v2, v4, Lo/k;->e0:Ljava/util/ArrayList;

    invoke-virtual {v2}, Ljava/util/ArrayList;->size()I

    move-result v2

    invoke-virtual {v4}, Lo/d;->l()I

    move-result v7

    invoke-virtual {v4}, Lo/d;->j()I

    move-result v8

    and-int/lit16 v9, v3, 0x80

    const/16 v10, 0x80

    if-ne v9, v10, :cond_15

    const/4 v9, 0x1

    goto :goto_b

    :cond_15
    const/4 v9, 0x0

    :goto_b
    if-nez v9, :cond_18

    const/16 v10, 0x40

    and-int/2addr v3, v10

    if-ne v3, v10, :cond_16

    const/4 v3, 0x1

    goto :goto_c

    :cond_16
    const/4 v3, 0x0

    :goto_c
    if-eqz v3, :cond_17

    goto :goto_d

    :cond_17
    const/4 v3, 0x0

    goto :goto_e

    :cond_18
    :goto_d
    const/4 v3, 0x1

    :goto_e
    if-eqz v3, :cond_21

    const/4 v10, 0x0

    :goto_f
    if-ge v10, v2, :cond_21

    iget-object v12, v4, Lo/k;->e0:Ljava/util/ArrayList;

    invoke-virtual {v12, v10}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v12

    check-cast v12, Lo/d;

    iget-object v13, v12, Lo/d;->J:[I

    const/4 v14, 0x0

    aget v15, v13, v14

    const/4 v14, 0x3

    if-ne v15, v14, :cond_19

    const/4 v15, 0x1

    goto :goto_10

    :cond_19
    const/4 v15, 0x0

    :goto_10
    const/16 v17, 0x1

    aget v13, v13, v17

    if-ne v13, v14, :cond_1a

    const/4 v13, 0x1

    goto :goto_11

    :cond_1a
    const/4 v13, 0x0

    :goto_11
    if-eqz v15, :cond_1b

    if-eqz v13, :cond_1b

    iget v13, v12, Lo/d;->N:F

    const/4 v14, 0x0

    cmpl-float v13, v13, v14

    if-lez v13, :cond_1b

    const/4 v13, 0x1

    goto :goto_12

    :cond_1b
    const/4 v13, 0x0

    :goto_12
    invoke-virtual {v12}, Lo/d;->q()Z

    move-result v14

    if-eqz v14, :cond_1c

    if-eqz v13, :cond_1c

    goto :goto_13

    :cond_1c
    invoke-virtual {v12}, Lo/d;->r()Z

    move-result v14

    if-eqz v14, :cond_1d

    if-eqz v13, :cond_1d

    goto :goto_13

    :cond_1d
    instance-of v13, v12, Lo/j;

    if-eqz v13, :cond_1e

    goto :goto_13

    :cond_1e
    invoke-virtual {v12}, Lo/d;->q()Z

    move-result v13

    if-nez v13, :cond_20

    invoke-virtual {v12}, Lo/d;->r()Z

    move-result v12

    if-eqz v12, :cond_1f

    goto :goto_13

    :cond_1f
    add-int/lit8 v10, v10, 0x1

    goto :goto_f

    :cond_20
    :goto_13
    const/4 v3, 0x0

    :cond_21
    const/high16 v10, 0x40000000    # 2.0f

    move/from16 v12, v24

    if-ne v11, v10, :cond_22

    if-eq v12, v10, :cond_23

    :cond_22
    if-eqz v9, :cond_24

    :cond_23
    const/4 v10, 0x1

    goto :goto_14

    :cond_24
    const/4 v10, 0x0

    :goto_14
    and-int/2addr v3, v10

    if-eqz v3, :cond_43

    const/4 v3, 0x0

    aget v10, v6, v3

    move/from16 v3, v21

    invoke-static {v10, v3}, Ljava/lang/Math;->min(II)I

    move-result v3

    const/4 v10, 0x1

    aget v6, v6, v10

    move/from16 v14, v22

    invoke-static {v6, v14}, Ljava/lang/Math;->min(II)I

    move-result v6

    const/high16 v13, 0x40000000    # 2.0f

    if-ne v11, v13, :cond_25

    invoke-virtual {v4}, Lo/d;->l()I

    move-result v14

    if-eq v14, v3, :cond_25

    invoke-virtual {v4, v3}, Lo/d;->y(I)V

    move-object/from16 v3, v23

    iput-boolean v10, v3, Lp/e;->b:Z

    goto :goto_15

    :cond_25
    move-object/from16 v3, v23

    :goto_15
    if-ne v12, v13, :cond_26

    invoke-virtual {v4}, Lo/d;->j()I

    move-result v14

    if-eq v14, v6, :cond_26

    invoke-virtual {v4, v6}, Lo/d;->v(I)V

    iput-boolean v10, v3, Lp/e;->b:Z

    :cond_26
    if-ne v11, v13, :cond_3c

    if-ne v12, v13, :cond_3c

    and-int/lit8 v6, v9, 0x1

    iget-boolean v9, v3, Lp/e;->b:Z

    iget-object v10, v3, Lp/e;->a:Lo/e;

    if-nez v9, :cond_28

    iget-boolean v9, v3, Lp/e;->c:Z

    if-eqz v9, :cond_27

    goto :goto_16

    :cond_27
    const/4 v14, 0x0

    goto :goto_18

    :cond_28
    :goto_16
    iget-object v9, v10, Lo/k;->e0:Ljava/util/ArrayList;

    invoke-virtual {v9}, Ljava/util/ArrayList;->iterator()Ljava/util/Iterator;

    move-result-object v9

    :goto_17
    invoke-interface {v9}, Ljava/util/Iterator;->hasNext()Z

    move-result v13

    if-eqz v13, :cond_29

    invoke-interface {v9}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v13

    check-cast v13, Lo/d;

    const/4 v14, 0x0

    iput-boolean v14, v13, Lo/d;->a:Z

    iget-object v15, v13, Lo/d;->d:Lp/j;

    invoke-virtual {v15}, Lp/j;->n()V

    iget-object v13, v13, Lo/d;->e:Lp/l;

    invoke-virtual {v13}, Lp/l;->m()V

    goto :goto_17

    :cond_29
    const/4 v14, 0x0

    iput-boolean v14, v10, Lo/d;->a:Z

    iget-object v9, v10, Lo/d;->d:Lp/j;

    invoke-virtual {v9}, Lp/j;->n()V

    iget-object v9, v10, Lo/d;->e:Lp/l;

    invoke-virtual {v9}, Lp/l;->m()V

    iput-boolean v14, v3, Lp/e;->c:Z

    :goto_18
    iget-object v9, v3, Lp/e;->d:Lo/e;

    invoke-virtual {v3, v9}, Lp/e;->b(Lo/e;)V

    iput v14, v10, Lo/d;->P:I

    iput v14, v10, Lo/d;->Q:I

    invoke-virtual {v10, v14}, Lo/d;->i(I)I

    move-result v9

    const/4 v13, 0x1

    invoke-virtual {v10, v13}, Lo/d;->i(I)I

    move-result v14

    iget-boolean v13, v3, Lp/e;->b:Z

    if-eqz v13, :cond_2a

    invoke-virtual {v3}, Lp/e;->c()V

    :cond_2a
    invoke-virtual {v10}, Lo/d;->m()I

    move-result v13

    invoke-virtual {v10}, Lo/d;->n()I

    move-result v15

    iget-object v0, v10, Lo/d;->d:Lp/j;

    move-object/from16 v21, v1

    iget-object v1, v0, Lp/m;->h:Lp/f;

    invoke-virtual {v1, v13}, Lp/f;->d(I)V

    iget-object v1, v10, Lo/d;->e:Lp/l;

    move/from16 v22, v7

    iget-object v7, v1, Lp/m;->h:Lp/f;

    invoke-virtual {v7, v15}, Lp/f;->d(I)V

    invoke-virtual {v3}, Lp/e;->g()V

    iget-object v7, v3, Lp/e;->e:Ljava/util/ArrayList;

    move/from16 v23, v8

    iget-object v8, v0, Lp/m;->e:Lp/g;

    move-object/from16 v24, v5

    iget-object v5, v1, Lp/m;->e:Lp/g;

    move/from16 v25, v2

    const/4 v2, 0x2

    if-eq v9, v2, :cond_2d

    if-ne v14, v2, :cond_2b

    goto :goto_19

    :cond_2b
    move/from16 v26, v12

    :cond_2c
    const/4 v2, 0x1

    goto :goto_1b

    :cond_2d
    :goto_19
    if-eqz v6, :cond_2f

    invoke-virtual {v7}, Ljava/util/ArrayList;->iterator()Ljava/util/Iterator;

    move-result-object v2

    :cond_2e
    invoke-interface {v2}, Ljava/util/Iterator;->hasNext()Z

    move-result v26

    if-eqz v26, :cond_2f

    invoke-interface {v2}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v26

    check-cast v26, Lp/m;

    invoke-virtual/range {v26 .. v26}, Lp/m;->k()Z

    move-result v26

    if-nez v26, :cond_2e

    const/4 v6, 0x0

    :cond_2f
    if-eqz v6, :cond_30

    const/4 v2, 0x2

    if-ne v9, v2, :cond_30

    const/4 v2, 0x1

    invoke-virtual {v10, v2}, Lo/d;->w(I)V

    move/from16 v26, v12

    const/4 v2, 0x0

    invoke-virtual {v3, v10, v2}, Lp/e;->d(Lo/e;I)I

    move-result v12

    invoke-virtual {v10, v12}, Lo/d;->y(I)V

    invoke-virtual {v10}, Lo/d;->l()I

    move-result v2

    invoke-virtual {v8, v2}, Lp/g;->d(I)V

    goto :goto_1a

    :cond_30
    move/from16 v26, v12

    :goto_1a
    if-eqz v6, :cond_2c

    const/4 v2, 0x2

    if-ne v14, v2, :cond_2c

    const/4 v2, 0x1

    invoke-virtual {v10, v2}, Lo/d;->x(I)V

    invoke-virtual {v3, v10, v2}, Lp/e;->d(Lo/e;I)I

    move-result v6

    invoke-virtual {v10, v6}, Lo/d;->v(I)V

    invoke-virtual {v10}, Lo/d;->j()I

    move-result v6

    invoke-virtual {v5, v6}, Lp/g;->d(I)V

    :goto_1b
    iget-object v6, v10, Lo/d;->J:[I

    move-object/from16 v27, v4

    const/4 v12, 0x0

    aget v4, v6, v12

    if-eq v4, v2, :cond_32

    const/4 v2, 0x4

    if-ne v4, v2, :cond_31

    goto :goto_1c

    :cond_31
    const/4 v0, 0x0

    goto :goto_1d

    :cond_32
    :goto_1c
    invoke-virtual {v10}, Lo/d;->l()I

    move-result v2

    add-int/2addr v2, v13

    iget-object v0, v0, Lp/m;->i:Lp/f;

    invoke-virtual {v0, v2}, Lp/f;->d(I)V

    sub-int/2addr v2, v13

    invoke-virtual {v8, v2}, Lp/g;->d(I)V

    invoke-virtual {v3}, Lp/e;->g()V

    const/4 v0, 0x1

    aget v2, v6, v0

    if-eq v2, v0, :cond_33

    const/4 v0, 0x4

    if-ne v2, v0, :cond_34

    :cond_33
    invoke-virtual {v10}, Lo/d;->j()I

    move-result v0

    add-int/2addr v0, v15

    iget-object v1, v1, Lp/m;->i:Lp/f;

    invoke-virtual {v1, v0}, Lp/f;->d(I)V

    sub-int/2addr v0, v15

    invoke-virtual {v5, v0}, Lp/g;->d(I)V

    :cond_34
    invoke-virtual {v3}, Lp/e;->g()V

    const/4 v0, 0x1

    :goto_1d
    invoke-virtual {v7}, Ljava/util/ArrayList;->iterator()Ljava/util/Iterator;

    move-result-object v1

    :goto_1e
    invoke-interface {v1}, Ljava/util/Iterator;->hasNext()Z

    move-result v2

    if-eqz v2, :cond_36

    invoke-interface {v1}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v2

    check-cast v2, Lp/m;

    iget-object v3, v2, Lp/m;->b:Lo/d;

    if-ne v3, v10, :cond_35

    iget-boolean v3, v2, Lp/m;->g:Z

    if-nez v3, :cond_35

    goto :goto_1e

    :cond_35
    invoke-virtual {v2}, Lp/m;->e()V

    goto :goto_1e

    :cond_36
    invoke-virtual {v7}, Ljava/util/ArrayList;->iterator()Ljava/util/Iterator;

    move-result-object v1

    :cond_37
    :goto_1f
    invoke-interface {v1}, Ljava/util/Iterator;->hasNext()Z

    move-result v2

    if-eqz v2, :cond_3b

    invoke-interface {v1}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v2

    check-cast v2, Lp/m;

    if-nez v0, :cond_38

    iget-object v3, v2, Lp/m;->b:Lo/d;

    if-ne v3, v10, :cond_38

    goto :goto_1f

    :cond_38
    iget-object v3, v2, Lp/m;->h:Lp/f;

    iget-boolean v3, v3, Lp/f;->j:Z

    if-nez v3, :cond_39

    goto :goto_20

    :cond_39
    iget-object v3, v2, Lp/m;->i:Lp/f;

    iget-boolean v3, v3, Lp/f;->j:Z

    if-nez v3, :cond_3a

    instance-of v3, v2, Lp/h;

    if-nez v3, :cond_3a

    goto :goto_20

    :cond_3a
    iget-object v3, v2, Lp/m;->e:Lp/g;

    iget-boolean v3, v3, Lp/f;->j:Z

    if-nez v3, :cond_37

    instance-of v3, v2, Lp/c;

    if-nez v3, :cond_37

    instance-of v2, v2, Lp/h;

    if-nez v2, :cond_37

    :goto_20
    const/4 v0, 0x0

    goto :goto_21

    :cond_3b
    const/4 v0, 0x1

    :goto_21
    invoke-virtual {v10, v9}, Lo/d;->w(I)V

    invoke-virtual {v10, v14}, Lo/d;->x(I)V

    move v2, v0

    move/from16 v5, v26

    move-object/from16 v1, v27

    const/high16 v0, 0x40000000    # 2.0f

    const/4 v4, 0x2

    goto/16 :goto_25

    :cond_3c
    move-object/from16 v21, v1

    move/from16 v25, v2

    move-object/from16 v27, v4

    move-object/from16 v24, v5

    move/from16 v22, v7

    move/from16 v23, v8

    move/from16 v26, v12

    iget-boolean v0, v3, Lp/e;->b:Z

    iget-object v1, v3, Lp/e;->a:Lo/e;

    if-eqz v0, :cond_3e

    iget-object v0, v1, Lo/k;->e0:Ljava/util/ArrayList;

    invoke-virtual {v0}, Ljava/util/ArrayList;->iterator()Ljava/util/Iterator;

    move-result-object v0

    :goto_22
    invoke-interface {v0}, Ljava/util/Iterator;->hasNext()Z

    move-result v2

    if-eqz v2, :cond_3d

    invoke-interface {v0}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v2

    check-cast v2, Lo/d;

    const/4 v4, 0x0

    iput-boolean v4, v2, Lo/d;->a:Z

    iget-object v5, v2, Lo/d;->d:Lp/j;

    iget-object v6, v5, Lp/m;->e:Lp/g;

    iput-boolean v4, v6, Lp/f;->j:Z

    iput-boolean v4, v5, Lp/m;->g:Z

    invoke-virtual {v5}, Lp/j;->n()V

    iget-object v2, v2, Lo/d;->e:Lp/l;

    iget-object v5, v2, Lp/m;->e:Lp/g;

    iput-boolean v4, v5, Lp/f;->j:Z

    iput-boolean v4, v2, Lp/m;->g:Z

    invoke-virtual {v2}, Lp/l;->m()V

    goto :goto_22

    :cond_3d
    const/4 v4, 0x0

    iput-boolean v4, v1, Lo/d;->a:Z

    iget-object v0, v1, Lo/d;->d:Lp/j;

    iget-object v2, v0, Lp/m;->e:Lp/g;

    iput-boolean v4, v2, Lp/f;->j:Z

    iput-boolean v4, v0, Lp/m;->g:Z

    invoke-virtual {v0}, Lp/j;->n()V

    iget-object v0, v1, Lo/d;->e:Lp/l;

    iget-object v2, v0, Lp/m;->e:Lp/g;

    iput-boolean v4, v2, Lp/f;->j:Z

    iput-boolean v4, v0, Lp/m;->g:Z

    invoke-virtual {v0}, Lp/l;->m()V

    invoke-virtual {v3}, Lp/e;->c()V

    goto :goto_23

    :cond_3e
    const/4 v4, 0x0

    :goto_23
    iget-object v0, v3, Lp/e;->d:Lo/e;

    invoke-virtual {v3, v0}, Lp/e;->b(Lo/e;)V

    iput v4, v1, Lo/d;->P:I

    iput v4, v1, Lo/d;->Q:I

    iget-object v0, v1, Lo/d;->d:Lp/j;

    iget-object v0, v0, Lp/m;->h:Lp/f;

    invoke-virtual {v0, v4}, Lp/f;->d(I)V

    iget-object v0, v1, Lo/d;->e:Lp/l;

    iget-object v0, v0, Lp/m;->h:Lp/f;

    invoke-virtual {v0, v4}, Lp/f;->d(I)V

    const/high16 v0, 0x40000000    # 2.0f

    if-ne v11, v0, :cond_3f

    move-object/from16 v1, v27

    invoke-virtual {v1, v4, v9}, Lo/e;->E(IZ)Z

    move-result v2

    const/4 v3, 0x1

    and-int/lit8 v18, v2, 0x1

    move v4, v3

    move/from16 v2, v18

    move/from16 v5, v26

    goto :goto_24

    :cond_3f
    move-object/from16 v1, v27

    const/4 v3, 0x1

    move v2, v3

    move/from16 v5, v26

    const/4 v4, 0x0

    :goto_24
    if-ne v5, v0, :cond_40

    invoke-virtual {v1, v3, v9}, Lo/e;->E(IZ)Z

    move-result v6

    and-int/2addr v2, v6

    add-int/lit8 v4, v4, 0x1

    :cond_40
    :goto_25
    if-eqz v2, :cond_44

    if-ne v11, v0, :cond_41

    const/4 v3, 0x1

    goto :goto_26

    :cond_41
    const/4 v3, 0x0

    :goto_26
    if-ne v5, v0, :cond_42

    const/4 v0, 0x1

    goto :goto_27

    :cond_42
    const/4 v0, 0x0

    :goto_27
    invoke-virtual {v1, v3, v0}, Lo/e;->z(ZZ)V

    goto :goto_28

    :cond_43
    move-object/from16 v21, v1

    move/from16 v25, v2

    move-object v1, v4

    move-object/from16 v24, v5

    move/from16 v22, v7

    move/from16 v23, v8

    const/4 v2, 0x0

    const/4 v4, 0x0

    :cond_44
    :goto_28
    if-eqz v2, :cond_46

    const/4 v0, 0x2

    if-eq v4, v0, :cond_45

    goto :goto_29

    :cond_45
    move-object v3, v1

    goto/16 :goto_3f

    :cond_46
    :goto_29
    const/16 v0, 0x8

    if-lez v25, :cond_51

    iget-object v2, v1, Lo/k;->e0:Ljava/util/ArrayList;

    invoke-virtual {v2}, Ljava/util/ArrayList;->size()I

    move-result v2

    iget-object v3, v1, Lo/e;->h0:Lp/b$b;

    const/4 v4, 0x0

    :goto_2a
    if-ge v4, v2, :cond_4b

    iget-object v5, v1, Lo/k;->e0:Ljava/util/ArrayList;

    invoke-virtual {v5, v4}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v5

    check-cast v5, Lo/d;

    instance-of v6, v5, Lo/g;

    if-eqz v6, :cond_47

    goto :goto_2b

    :cond_47
    iget-object v6, v5, Lo/d;->d:Lp/j;

    iget-object v6, v6, Lp/m;->e:Lp/g;

    iget-boolean v6, v6, Lp/f;->j:Z

    if-eqz v6, :cond_48

    iget-object v6, v5, Lo/d;->e:Lp/l;

    iget-object v6, v6, Lp/m;->e:Lp/g;

    iget-boolean v6, v6, Lp/f;->j:Z

    if-eqz v6, :cond_48

    :goto_2b
    move-object/from16 v6, v24

    const/4 v9, 0x3

    goto :goto_2d

    :cond_48
    const/4 v6, 0x0

    invoke-virtual {v5, v6}, Lo/d;->i(I)I

    move-result v7

    const/4 v6, 0x1

    invoke-virtual {v5, v6}, Lo/d;->i(I)I

    move-result v8

    const/4 v9, 0x3

    if-ne v7, v9, :cond_49

    iget v7, v5, Lo/d;->j:I

    if-eq v7, v6, :cond_49

    if-ne v8, v9, :cond_49

    iget v7, v5, Lo/d;->k:I

    if-eq v7, v6, :cond_49

    const/4 v6, 0x1

    goto :goto_2c

    :cond_49
    const/4 v6, 0x0

    :goto_2c
    if-eqz v6, :cond_4a

    move-object/from16 v6, v24

    goto :goto_2d

    :cond_4a
    move-object/from16 v6, v24

    const/4 v7, 0x0

    invoke-virtual {v6, v3, v5, v7}, Lp/b;->a(Lp/b$b;Lo/d;Z)Z

    :goto_2d
    add-int/lit8 v4, v4, 0x1

    move-object/from16 v24, v6

    goto :goto_2a

    :cond_4b
    move-object/from16 v6, v24

    check-cast v3, Landroidx/constraintlayout/widget/ConstraintLayout$b;

    iget-object v2, v3, Landroidx/constraintlayout/widget/ConstraintLayout$b;->a:Landroidx/constraintlayout/widget/ConstraintLayout;

    invoke-virtual {v2}, Landroid/view/ViewGroup;->getChildCount()I

    move-result v3

    const/4 v4, 0x0

    :goto_2e
    if-ge v4, v3, :cond_50

    invoke-virtual {v2, v4}, Landroid/view/ViewGroup;->getChildAt(I)Landroid/view/View;

    move-result-object v5

    instance-of v7, v5, Landroidx/constraintlayout/widget/e;

    if-eqz v7, :cond_4f

    check-cast v5, Landroidx/constraintlayout/widget/e;

    iget-object v7, v5, Landroidx/constraintlayout/widget/e;->c:Landroid/view/View;

    if-nez v7, :cond_4c

    goto :goto_2f

    :cond_4c
    invoke-virtual {v5}, Landroid/view/View;->getLayoutParams()Landroid/view/ViewGroup$LayoutParams;

    move-result-object v7

    check-cast v7, Landroidx/constraintlayout/widget/ConstraintLayout$a;

    iget-object v5, v5, Landroidx/constraintlayout/widget/e;->c:Landroid/view/View;

    invoke-virtual {v5}, Landroid/view/View;->getLayoutParams()Landroid/view/ViewGroup$LayoutParams;

    move-result-object v5

    check-cast v5, Landroidx/constraintlayout/widget/ConstraintLayout$a;

    iget-object v8, v5, Landroidx/constraintlayout/widget/ConstraintLayout$a;->l0:Lo/d;

    const/4 v9, 0x0

    iput v9, v8, Lo/d;->X:I

    iget-object v10, v7, Landroidx/constraintlayout/widget/ConstraintLayout$a;->l0:Lo/d;

    iget-object v11, v10, Lo/d;->J:[I

    aget v11, v11, v9

    const/4 v9, 0x1

    if-eq v11, v9, :cond_4d

    invoke-virtual {v8}, Lo/d;->l()I

    move-result v8

    invoke-virtual {v10, v8}, Lo/d;->y(I)V

    :cond_4d
    iget-object v7, v7, Landroidx/constraintlayout/widget/ConstraintLayout$a;->l0:Lo/d;

    iget-object v8, v7, Lo/d;->J:[I

    aget v8, v8, v9

    if-eq v8, v9, :cond_4e

    iget-object v8, v5, Landroidx/constraintlayout/widget/ConstraintLayout$a;->l0:Lo/d;

    invoke-virtual {v8}, Lo/d;->j()I

    move-result v8

    invoke-virtual {v7, v8}, Lo/d;->v(I)V

    :cond_4e
    iget-object v5, v5, Landroidx/constraintlayout/widget/ConstraintLayout$a;->l0:Lo/d;

    iput v0, v5, Lo/d;->X:I

    :cond_4f
    :goto_2f
    add-int/lit8 v4, v4, 0x1

    goto :goto_2e

    :cond_50
    iget-object v2, v2, Landroidx/constraintlayout/widget/ConstraintLayout;->c:Ljava/util/ArrayList;

    invoke-virtual {v2}, Ljava/util/ArrayList;->size()I

    move-result v3

    if-lez v3, :cond_52

    const/4 v4, 0x0

    :goto_30
    if-ge v4, v3, :cond_52

    invoke-virtual {v2, v4}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v5

    check-cast v5, Landroidx/constraintlayout/widget/a;

    invoke-virtual {v5}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    add-int/lit8 v4, v4, 0x1

    goto :goto_30

    :cond_51
    move-object/from16 v6, v24

    :cond_52
    iget v2, v1, Lo/e;->q0:I

    iget-object v3, v6, Lp/b;->a:Ljava/util/ArrayList;

    invoke-virtual {v3}, Ljava/util/ArrayList;->size()I

    move-result v4

    move/from16 v5, v22

    move/from16 v7, v23

    if-lez v25, :cond_53

    invoke-virtual {v6, v1, v5, v7}, Lp/b;->b(Lo/e;II)V

    :cond_53
    if-lez v4, :cond_6c

    iget-object v8, v1, Lo/d;->J:[I

    const/4 v9, 0x0

    aget v10, v8, v9

    const/4 v9, 0x2

    if-ne v10, v9, :cond_54

    const/4 v10, 0x1

    goto :goto_31

    :cond_54
    const/4 v10, 0x0

    :goto_31
    const/4 v11, 0x1

    aget v8, v8, v11

    if-ne v8, v9, :cond_55

    const/4 v8, 0x1

    goto :goto_32

    :cond_55
    const/4 v8, 0x0

    :goto_32
    invoke-virtual {v1}, Lo/d;->l()I

    move-result v9

    iget-object v11, v6, Lp/b;->c:Lo/e;

    iget v12, v11, Lo/d;->S:I

    invoke-static {v9, v12}, Ljava/lang/Math;->max(II)I

    move-result v9

    invoke-virtual {v1}, Lo/d;->j()I

    move-result v12

    iget v11, v11, Lo/d;->T:I

    invoke-static {v12, v11}, Ljava/lang/Math;->max(II)I

    move-result v11

    move v12, v9

    move v13, v11

    const/4 v9, 0x0

    const/4 v11, 0x0

    :goto_33
    sget-object v14, Lo/c$a;->e:Lo/c$a;

    sget-object v15, Lo/c$a;->d:Lo/c$a;

    if-ge v9, v4, :cond_5b

    invoke-virtual {v3, v9}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v16

    move-object/from16 v0, v16

    check-cast v0, Lo/d;

    move/from16 v16, v2

    instance-of v2, v0, Lo/j;

    if-nez v2, :cond_56

    move-object/from16 v27, v1

    move/from16 v22, v5

    move/from16 v23, v7

    move-object/from16 v5, v21

    goto/16 :goto_35

    :cond_56
    invoke-virtual {v0}, Lo/d;->l()I

    move-result v2

    move-object/from16 v27, v1

    invoke-virtual {v0}, Lo/d;->j()I

    move-result v1

    move/from16 v22, v5

    move/from16 v23, v7

    move-object/from16 v5, v21

    const/4 v7, 0x1

    invoke-virtual {v6, v5, v0, v7}, Lp/b;->a(Lp/b$b;Lo/d;Z)Z

    move-result v20

    or-int v7, v11, v20

    invoke-virtual {v0}, Lo/d;->l()I

    move-result v11

    move/from16 v20, v7

    invoke-virtual {v0}, Lo/d;->j()I

    move-result v7

    if-eq v11, v2, :cond_58

    invoke-virtual {v0, v11}, Lo/d;->y(I)V

    if-eqz v10, :cond_57

    invoke-virtual {v0}, Lo/d;->m()I

    move-result v2

    iget v11, v0, Lo/d;->L:I

    add-int/2addr v2, v11

    if-le v2, v12, :cond_57

    invoke-virtual {v0}, Lo/d;->m()I

    move-result v2

    iget v11, v0, Lo/d;->L:I

    add-int/2addr v2, v11

    invoke-virtual {v0, v15}, Lo/d;->h(Lo/c$a;)Lo/c;

    move-result-object v11

    invoke-virtual {v11}, Lo/c;->c()I

    move-result v11

    add-int/2addr v11, v2

    invoke-static {v12, v11}, Ljava/lang/Math;->max(II)I

    move-result v12

    :cond_57
    const/16 v20, 0x1

    :cond_58
    if-eq v7, v1, :cond_5a

    invoke-virtual {v0, v7}, Lo/d;->v(I)V

    if-eqz v8, :cond_59

    invoke-virtual {v0}, Lo/d;->n()I

    move-result v1

    iget v2, v0, Lo/d;->M:I

    add-int/2addr v1, v2

    if-le v1, v13, :cond_59

    invoke-virtual {v0}, Lo/d;->n()I

    move-result v1

    iget v2, v0, Lo/d;->M:I

    add-int/2addr v1, v2

    invoke-virtual {v0, v14}, Lo/d;->h(Lo/c$a;)Lo/c;

    move-result-object v2

    invoke-virtual {v2}, Lo/c;->c()I

    move-result v2

    add-int/2addr v2, v1

    invoke-static {v13, v2}, Ljava/lang/Math;->max(II)I

    move-result v1

    move v13, v1

    :cond_59
    const/4 v14, 0x1

    goto :goto_34

    :cond_5a
    move/from16 v14, v20

    :goto_34
    check-cast v0, Lo/j;

    iget-boolean v0, v0, Lo/j;->m0:Z

    or-int/2addr v0, v14

    move v11, v0

    :goto_35
    add-int/lit8 v9, v9, 0x1

    move-object/from16 v21, v5

    move/from16 v2, v16

    move/from16 v5, v22

    move/from16 v7, v23

    move-object/from16 v1, v27

    const/16 v0, 0x8

    goto/16 :goto_33

    :cond_5b
    move-object/from16 v27, v1

    move/from16 v16, v2

    move/from16 v22, v5

    move/from16 v23, v7

    move-object/from16 v5, v21

    const/4 v0, 0x2

    const/4 v2, 0x0

    :goto_36
    if-ge v2, v0, :cond_69

    const/4 v1, 0x0

    :goto_37
    if-ge v1, v4, :cond_67

    invoke-virtual {v3, v1}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v7

    check-cast v7, Lo/d;

    instance-of v9, v7, Lo/h;

    if-eqz v9, :cond_5c

    instance-of v9, v7, Lo/j;

    if-eqz v9, :cond_5d

    :cond_5c
    instance-of v9, v7, Lo/g;

    if-eqz v9, :cond_5e

    :cond_5d
    const/16 v0, 0x8

    goto :goto_38

    :cond_5e
    iget v9, v7, Lo/d;->X:I

    const/16 v0, 0x8

    if-ne v9, v0, :cond_5f

    goto :goto_38

    :cond_5f
    iget-object v9, v7, Lo/d;->d:Lp/j;

    iget-object v9, v9, Lp/m;->e:Lp/g;

    iget-boolean v9, v9, Lp/f;->j:Z

    if-eqz v9, :cond_60

    iget-object v9, v7, Lo/d;->e:Lp/l;

    iget-object v9, v9, Lp/m;->e:Lp/g;

    iget-boolean v9, v9, Lp/f;->j:Z

    if-eqz v9, :cond_60

    goto :goto_38

    :cond_60
    instance-of v9, v7, Lo/j;

    if-eqz v9, :cond_61

    :goto_38
    move-object/from16 v20, v3

    move/from16 v21, v4

    move-object/from16 v24, v5

    goto/16 :goto_39

    :cond_61
    invoke-virtual {v7}, Lo/d;->l()I

    move-result v9

    invoke-virtual {v7}, Lo/d;->j()I

    move-result v0

    move-object/from16 v20, v3

    iget v3, v7, Lo/d;->R:I

    move/from16 v21, v4

    const/4 v4, 0x1

    invoke-virtual {v6, v5, v7, v4}, Lp/b;->a(Lp/b$b;Lo/d;Z)Z

    move-result v18

    or-int v11, v11, v18

    invoke-virtual {v7}, Lo/d;->l()I

    move-result v4

    move-object/from16 v24, v5

    invoke-virtual {v7}, Lo/d;->j()I

    move-result v5

    if-eq v4, v9, :cond_63

    invoke-virtual {v7, v4}, Lo/d;->y(I)V

    if-eqz v10, :cond_62

    invoke-virtual {v7}, Lo/d;->m()I

    move-result v4

    iget v9, v7, Lo/d;->L:I

    add-int/2addr v4, v9

    if-le v4, v12, :cond_62

    invoke-virtual {v7}, Lo/d;->m()I

    move-result v4

    iget v9, v7, Lo/d;->L:I

    add-int/2addr v4, v9

    invoke-virtual {v7, v15}, Lo/d;->h(Lo/c$a;)Lo/c;

    move-result-object v9

    invoke-virtual {v9}, Lo/c;->c()I

    move-result v9

    add-int/2addr v9, v4

    invoke-static {v12, v9}, Ljava/lang/Math;->max(II)I

    move-result v12

    :cond_62
    const/4 v11, 0x1

    :cond_63
    if-eq v5, v0, :cond_65

    invoke-virtual {v7, v5}, Lo/d;->v(I)V

    if-eqz v8, :cond_64

    invoke-virtual {v7}, Lo/d;->n()I

    move-result v0

    iget v4, v7, Lo/d;->M:I

    add-int/2addr v0, v4

    if-le v0, v13, :cond_64

    invoke-virtual {v7}, Lo/d;->n()I

    move-result v0

    iget v4, v7, Lo/d;->M:I

    add-int/2addr v0, v4

    invoke-virtual {v7, v14}, Lo/d;->h(Lo/c$a;)Lo/c;

    move-result-object v4

    invoke-virtual {v4}, Lo/c;->c()I

    move-result v4

    add-int/2addr v4, v0

    invoke-static {v13, v4}, Ljava/lang/Math;->max(II)I

    move-result v0

    move v13, v0

    :cond_64
    const/4 v11, 0x1

    :cond_65
    iget-boolean v0, v7, Lo/d;->w:Z

    if-eqz v0, :cond_66

    iget v0, v7, Lo/d;->R:I

    if-eq v3, v0, :cond_66

    const/4 v11, 0x1

    :cond_66
    :goto_39
    add-int/lit8 v1, v1, 0x1

    move-object/from16 v3, v20

    move/from16 v4, v21

    move-object/from16 v5, v24

    const/4 v0, 0x2

    goto/16 :goto_37

    :cond_67
    move-object/from16 v20, v3

    move/from16 v21, v4

    move-object/from16 v24, v5

    if-eqz v11, :cond_68

    move/from16 v0, v22

    move/from16 v1, v23

    move-object/from16 v3, v27

    invoke-virtual {v6, v3, v0, v1}, Lp/b;->b(Lo/e;II)V

    const/4 v11, 0x0

    goto :goto_3a

    :cond_68
    move/from16 v0, v22

    move/from16 v1, v23

    move-object/from16 v3, v27

    :goto_3a
    add-int/lit8 v2, v2, 0x1

    move/from16 v22, v0

    move/from16 v23, v1

    move-object/from16 v27, v3

    move-object/from16 v3, v20

    move/from16 v4, v21

    move-object/from16 v5, v24

    const/4 v0, 0x2

    goto/16 :goto_36

    :cond_69
    move/from16 v0, v22

    move/from16 v1, v23

    move-object/from16 v3, v27

    if-eqz v11, :cond_6d

    invoke-virtual {v6, v3, v0, v1}, Lp/b;->b(Lo/e;II)V

    invoke-virtual {v3}, Lo/d;->l()I

    move-result v2

    if-ge v2, v12, :cond_6a

    invoke-virtual {v3, v12}, Lo/d;->y(I)V

    const/4 v2, 0x1

    goto :goto_3b

    :cond_6a
    const/4 v2, 0x0

    :goto_3b
    invoke-virtual {v3}, Lo/d;->j()I

    move-result v4

    if-ge v4, v13, :cond_6b

    invoke-virtual {v3, v13}, Lo/d;->v(I)V

    const/4 v14, 0x1

    goto :goto_3c

    :cond_6b
    move v14, v2

    :goto_3c
    if-eqz v14, :cond_6d

    invoke-virtual {v6, v3, v0, v1}, Lp/b;->b(Lo/e;II)V

    goto :goto_3d

    :cond_6c
    move-object v3, v1

    move/from16 v16, v2

    :cond_6d
    :goto_3d
    move/from16 v0, v16

    iput v0, v3, Lo/e;->q0:I

    const/16 v1, 0x100

    and-int/2addr v0, v1

    if-ne v0, v1, :cond_6e

    const/4 v9, 0x1

    goto :goto_3e

    :cond_6e
    const/4 v9, 0x0

    :goto_3e
    sput-boolean v9, Ln/d;->p:Z

    :goto_3f
    invoke-virtual {v3}, Lo/d;->l()I

    move-result v0

    invoke-virtual {v3}, Lo/d;->j()I

    move-result v1

    iget-boolean v2, v3, Lo/e;->r0:Z

    iget-boolean v3, v3, Lo/e;->s0:Z

    move-object/from16 v4, v19

    iget v5, v4, Landroidx/constraintlayout/widget/ConstraintLayout$b;->e:I

    iget v4, v4, Landroidx/constraintlayout/widget/ConstraintLayout$b;->d:I

    add-int/2addr v0, v4

    add-int/2addr v1, v5

    move/from16 v4, p1

    const/4 v5, 0x0

    invoke-static {v0, v4, v5}, Landroid/view/View;->resolveSizeAndState(III)I

    move-result v0

    move/from16 v4, p2

    invoke-static {v1, v4, v5}, Landroid/view/View;->resolveSizeAndState(III)I

    move-result v1

    const v4, 0xffffff

    and-int/2addr v0, v4

    and-int/2addr v1, v4

    move-object/from16 v4, p0

    iget v5, v4, Landroidx/constraintlayout/widget/ConstraintLayout;->g:I

    invoke-static {v5, v0}, Ljava/lang/Math;->min(II)I

    move-result v0

    iget v5, v4, Landroidx/constraintlayout/widget/ConstraintLayout;->h:I

    invoke-static {v5, v1}, Ljava/lang/Math;->min(II)I

    move-result v1

    const/high16 v5, 0x1000000

    if-eqz v2, :cond_6f

    or-int/2addr v0, v5

    :cond_6f
    if-eqz v3, :cond_70

    or-int/2addr v1, v5

    :cond_70
    invoke-virtual {v4, v0, v1}, Landroid/view/View;->setMeasuredDimension(II)V

    return-void
.end method

.method public final onViewAdded(Landroid/view/View;)V
    .locals 4

    invoke-super {p0, p1}, Landroid/view/ViewGroup;->onViewAdded(Landroid/view/View;)V

    invoke-virtual {p0, p1}, Landroidx/constraintlayout/widget/ConstraintLayout;->b(Landroid/view/View;)Lo/d;

    move-result-object v0

    instance-of v1, p1, Landroidx/constraintlayout/widget/d;

    const/4 v2, 0x1

    if-eqz v1, :cond_0

    instance-of v0, v0, Lo/g;

    if-nez v0, :cond_0

    invoke-virtual {p1}, Landroid/view/View;->getLayoutParams()Landroid/view/ViewGroup$LayoutParams;

    move-result-object v0

    check-cast v0, Landroidx/constraintlayout/widget/ConstraintLayout$a;

    new-instance v1, Lo/g;

    invoke-direct {v1}, Lo/g;-><init>()V

    iput-object v1, v0, Landroidx/constraintlayout/widget/ConstraintLayout$a;->l0:Lo/d;

    iput-boolean v2, v0, Landroidx/constraintlayout/widget/ConstraintLayout$a;->Y:Z

    iget v0, v0, Landroidx/constraintlayout/widget/ConstraintLayout$a;->R:I

    invoke-virtual {v1, v0}, Lo/g;->B(I)V

    :cond_0
    instance-of v0, p1, Landroidx/constraintlayout/widget/a;

    if-eqz v0, :cond_1

    move-object v0, p1

    check-cast v0, Landroidx/constraintlayout/widget/a;

    invoke-virtual {v0}, Landroidx/constraintlayout/widget/a;->g()V

    invoke-virtual {p1}, Landroid/view/View;->getLayoutParams()Landroid/view/ViewGroup$LayoutParams;

    move-result-object v1

    check-cast v1, Landroidx/constraintlayout/widget/ConstraintLayout$a;

    iput-boolean v2, v1, Landroidx/constraintlayout/widget/ConstraintLayout$a;->Z:Z

    iget-object v1, p0, Landroidx/constraintlayout/widget/ConstraintLayout;->c:Ljava/util/ArrayList;

    invoke-virtual {v1, v0}, Ljava/util/ArrayList;->contains(Ljava/lang/Object;)Z

    move-result v3

    if-nez v3, :cond_1

    invoke-virtual {v1, v0}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    :cond_1
    invoke-virtual {p1}, Landroid/view/View;->getId()I

    move-result v0

    iget-object v1, p0, Landroidx/constraintlayout/widget/ConstraintLayout;->b:Landroid/util/SparseArray;

    invoke-virtual {v1, v0, p1}, Landroid/util/SparseArray;->put(ILjava/lang/Object;)V

    iput-boolean v2, p0, Landroidx/constraintlayout/widget/ConstraintLayout;->i:Z

    return-void
.end method

.method public onViewRemoved(Landroid/view/View;)V
    .locals 2

    invoke-super {p0, p1}, Landroid/view/ViewGroup;->onViewRemoved(Landroid/view/View;)V

    invoke-virtual {p1}, Landroid/view/View;->getId()I

    move-result v0

    iget-object v1, p0, Landroidx/constraintlayout/widget/ConstraintLayout;->b:Landroid/util/SparseArray;

    invoke-virtual {v1, v0}, Landroid/util/SparseArray;->remove(I)V

    invoke-virtual {p0, p1}, Landroidx/constraintlayout/widget/ConstraintLayout;->b(Landroid/view/View;)Lo/d;

    move-result-object v0

    iget-object v1, p0, Landroidx/constraintlayout/widget/ConstraintLayout;->d:Lo/e;

    iget-object v1, v1, Lo/k;->e0:Ljava/util/ArrayList;

    invoke-virtual {v1, v0}, Ljava/util/ArrayList;->remove(Ljava/lang/Object;)Z

    const/4 v1, 0x0

    iput-object v1, v0, Lo/d;->K:Lo/d;

    iget-object v0, p0, Landroidx/constraintlayout/widget/ConstraintLayout;->c:Ljava/util/ArrayList;

    invoke-virtual {v0, p1}, Ljava/util/ArrayList;->remove(Ljava/lang/Object;)Z

    const/4 p1, 0x1

    iput-boolean p1, p0, Landroidx/constraintlayout/widget/ConstraintLayout;->i:Z

    return-void
.end method

.method public final removeView(Landroid/view/View;)V
    .locals 0

    invoke-super {p0, p1}, Landroid/view/ViewGroup;->removeView(Landroid/view/View;)V

    return-void
.end method

.method public final requestLayout()V
    .locals 1

    const/4 v0, 0x1

    iput-boolean v0, p0, Landroidx/constraintlayout/widget/ConstraintLayout;->i:Z

    invoke-super {p0}, Landroid/view/View;->requestLayout()V

    return-void
.end method

.method public setConstraintSet(Landroidx/constraintlayout/widget/b;)V
    .locals 0

    iput-object p1, p0, Landroidx/constraintlayout/widget/ConstraintLayout;->k:Landroidx/constraintlayout/widget/b;

    return-void
.end method

.method public setId(I)V
    .locals 2

    invoke-virtual {p0}, Landroid/view/View;->getId()I

    move-result v0

    iget-object v1, p0, Landroidx/constraintlayout/widget/ConstraintLayout;->b:Landroid/util/SparseArray;

    invoke-virtual {v1, v0}, Landroid/util/SparseArray;->remove(I)V

    invoke-super {p0, p1}, Landroid/view/View;->setId(I)V

    invoke-virtual {p0}, Landroid/view/View;->getId()I

    move-result p1

    invoke-virtual {v1, p1, p0}, Landroid/util/SparseArray;->put(ILjava/lang/Object;)V

    return-void
.end method

.method public setMaxHeight(I)V
    .locals 1

    iget v0, p0, Landroidx/constraintlayout/widget/ConstraintLayout;->h:I

    if-ne p1, v0, :cond_0

    return-void

    :cond_0
    iput p1, p0, Landroidx/constraintlayout/widget/ConstraintLayout;->h:I

    invoke-virtual {p0}, Landroidx/constraintlayout/widget/ConstraintLayout;->requestLayout()V

    return-void
.end method

.method public setMaxWidth(I)V
    .locals 1

    iget v0, p0, Landroidx/constraintlayout/widget/ConstraintLayout;->g:I

    if-ne p1, v0, :cond_0

    return-void

    :cond_0
    iput p1, p0, Landroidx/constraintlayout/widget/ConstraintLayout;->g:I

    invoke-virtual {p0}, Landroidx/constraintlayout/widget/ConstraintLayout;->requestLayout()V

    return-void
.end method

.method public setMinHeight(I)V
    .locals 1

    iget v0, p0, Landroidx/constraintlayout/widget/ConstraintLayout;->f:I

    if-ne p1, v0, :cond_0

    return-void

    :cond_0
    iput p1, p0, Landroidx/constraintlayout/widget/ConstraintLayout;->f:I

    invoke-virtual {p0}, Landroidx/constraintlayout/widget/ConstraintLayout;->requestLayout()V

    return-void
.end method

.method public setMinWidth(I)V
    .locals 1

    iget v0, p0, Landroidx/constraintlayout/widget/ConstraintLayout;->e:I

    if-ne p1, v0, :cond_0

    return-void

    :cond_0
    iput p1, p0, Landroidx/constraintlayout/widget/ConstraintLayout;->e:I

    invoke-virtual {p0}, Landroidx/constraintlayout/widget/ConstraintLayout;->requestLayout()V

    return-void
.end method

.method public setOnConstraintsChanged(Lq/c;)V
    .locals 0

    iget-object p0, p0, Landroidx/constraintlayout/widget/ConstraintLayout;->l:Lq/b;

    if-eqz p0, :cond_0

    invoke-virtual {p0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    :cond_0
    return-void
.end method

.method public setOptimizationLevel(I)V
    .locals 0

    iput p1, p0, Landroidx/constraintlayout/widget/ConstraintLayout;->j:I

    iget-object p0, p0, Landroidx/constraintlayout/widget/ConstraintLayout;->d:Lo/e;

    iput p1, p0, Lo/e;->q0:I

    const/16 p0, 0x100

    and-int/2addr p1, p0

    if-ne p1, p0, :cond_0

    const/4 p0, 0x1

    goto :goto_0

    :cond_0
    const/4 p0, 0x0

    :goto_0
    sput-boolean p0, Ln/d;->p:Z

    return-void
.end method

.method public final shouldDelayChildPressedState()Z
    .locals 0

    const/4 p0, 0x0

    return p0
.end method
