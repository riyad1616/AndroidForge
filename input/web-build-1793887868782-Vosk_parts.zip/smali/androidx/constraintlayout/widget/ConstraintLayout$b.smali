.class public final Landroidx/constraintlayout/widget/ConstraintLayout$b;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Lp/b$b;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Landroidx/constraintlayout/widget/ConstraintLayout;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x1
    name = "b"
.end annotation


# instance fields
.field public final a:Landroidx/constraintlayout/widget/ConstraintLayout;

.field public b:I

.field public c:I

.field public d:I

.field public e:I

.field public f:I

.field public g:I


# direct methods
.method public constructor <init>(Landroidx/constraintlayout/widget/ConstraintLayout;)V
    .locals 0

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Landroidx/constraintlayout/widget/ConstraintLayout$b;->a:Landroidx/constraintlayout/widget/ConstraintLayout;

    return-void
.end method


# virtual methods
.method public final a(Lo/d;Lp/b$a;)V
    .locals 17
    .annotation build Landroid/annotation/SuppressLint;
        value = {
            "WrongCall"
        }
    .end annotation

    move-object/from16 v0, p0

    move-object/from16 v1, p1

    move-object/from16 v2, p2

    if-nez v1, :cond_0

    return-void

    :cond_0
    iget v3, v1, Lo/d;->X:I

    const/16 v4, 0x8

    const/4 v5, 0x0

    if-ne v3, v4, :cond_1

    iget-boolean v3, v1, Lo/d;->x:Z

    if-nez v3, :cond_1

    iput v5, v2, Lp/b$a;->e:I

    iput v5, v2, Lp/b$a;->f:I

    iput v5, v2, Lp/b$a;->g:I

    return-void

    :cond_1
    iget v3, v2, Lp/b$a;->a:I

    iget v4, v2, Lp/b$a;->b:I

    iget v6, v2, Lp/b$a;->c:I

    iget v7, v2, Lp/b$a;->d:I

    iget v8, v0, Landroidx/constraintlayout/widget/ConstraintLayout$b;->b:I

    iget v9, v0, Landroidx/constraintlayout/widget/ConstraintLayout$b;->c:I

    add-int/2addr v8, v9

    iget v9, v0, Landroidx/constraintlayout/widget/ConstraintLayout$b;->d:I

    iget-object v10, v1, Lo/d;->W:Ljava/lang/Object;

    check-cast v10, Landroid/view/View;

    invoke-static {v3}, Ln/g;->c(I)I

    move-result v11

    const/4 v12, 0x2

    const/4 v14, 0x1

    iget-object v13, v1, Lo/d;->A:Lo/c;

    iget-object v5, v1, Lo/d;->y:Lo/c;

    iget-object v15, v1, Lo/d;->g:[I

    if-eqz v11, :cond_d

    if-eq v11, v14, :cond_c

    if-eq v11, v12, :cond_5

    const/4 v6, 0x3

    if-eq v11, v6, :cond_2

    const/4 v6, 0x0

    goto/16 :goto_4

    :cond_2
    iget v6, v0, Landroidx/constraintlayout/widget/ConstraintLayout$b;->f:I

    if-eqz v5, :cond_3

    iget v11, v5, Lo/c;->e:I

    const/16 v16, 0x0

    add-int/lit8 v11, v11, 0x0

    goto :goto_0

    :cond_3
    const/4 v11, 0x0

    :goto_0
    if-eqz v13, :cond_4

    iget v14, v13, Lo/c;->e:I

    add-int/2addr v11, v14

    :cond_4
    add-int/2addr v9, v11

    const/4 v11, -0x1

    invoke-static {v6, v9, v11}, Landroid/view/ViewGroup;->getChildMeasureSpec(III)I

    move-result v6

    aput v11, v15, v12

    goto :goto_4

    :cond_5
    iget v6, v0, Landroidx/constraintlayout/widget/ConstraintLayout$b;->f:I

    const/4 v11, -0x2

    invoke-static {v6, v9, v11}, Landroid/view/ViewGroup;->getChildMeasureSpec(III)I

    move-result v6

    iget v9, v1, Lo/d;->j:I

    const/4 v11, 0x1

    if-ne v9, v11, :cond_6

    const/4 v9, 0x1

    goto :goto_1

    :cond_6
    const/4 v9, 0x0

    :goto_1
    const/4 v11, 0x0

    aput v11, v15, v12

    iget-boolean v14, v2, Lp/b$a;->j:Z

    if-eqz v14, :cond_b

    if-eqz v9, :cond_7

    const/4 v14, 0x3

    aget v16, v15, v14

    if-eqz v16, :cond_7

    aget v14, v15, v11

    invoke-virtual/range {p1 .. p1}, Lo/d;->l()I

    move-result v11

    if-ne v14, v11, :cond_8

    :cond_7
    instance-of v11, v10, Landroidx/constraintlayout/widget/e;

    if-eqz v11, :cond_9

    :cond_8
    const/4 v11, 0x1

    goto :goto_2

    :cond_9
    const/4 v11, 0x0

    :goto_2
    if-eqz v9, :cond_a

    if-eqz v11, :cond_b

    :cond_a
    invoke-virtual/range {p1 .. p1}, Lo/d;->l()I

    move-result v6

    const/high16 v11, 0x40000000    # 2.0f

    invoke-static {v6, v11}, Landroid/view/View$MeasureSpec;->makeMeasureSpec(II)I

    move-result v6

    goto :goto_4

    :cond_b
    const/high16 v11, 0x40000000    # 2.0f

    goto :goto_3

    :cond_c
    const/high16 v11, 0x40000000    # 2.0f

    iget v6, v0, Landroidx/constraintlayout/widget/ConstraintLayout$b;->f:I

    const/4 v14, -0x2

    invoke-static {v6, v9, v14}, Landroid/view/ViewGroup;->getChildMeasureSpec(III)I

    move-result v6

    aput v14, v15, v12

    :goto_3
    const/4 v9, 0x1

    goto :goto_5

    :cond_d
    const/high16 v11, 0x40000000    # 2.0f

    invoke-static {v6, v11}, Landroid/view/View$MeasureSpec;->makeMeasureSpec(II)I

    move-result v9

    aput v6, v15, v12

    move v6, v9

    :goto_4
    const/4 v9, 0x0

    :goto_5
    invoke-static {v4}, Ln/g;->c(I)I

    move-result v11

    if-eqz v11, :cond_19

    const/4 v14, 0x1

    if-eq v11, v14, :cond_18

    const/4 v7, 0x3

    if-eq v11, v12, :cond_11

    if-eq v11, v7, :cond_e

    move v8, v7

    const/4 v0, 0x0

    const/4 v5, 0x0

    goto/16 :goto_b

    :cond_e
    iget v0, v0, Landroidx/constraintlayout/widget/ConstraintLayout$b;->g:I

    if-eqz v5, :cond_f

    iget-object v5, v1, Lo/d;->z:Lo/c;

    iget v5, v5, Lo/c;->e:I

    const/4 v7, 0x0

    add-int/2addr v5, v7

    goto :goto_6

    :cond_f
    const/4 v5, 0x0

    :goto_6
    if-eqz v13, :cond_10

    iget-object v7, v1, Lo/d;->B:Lo/c;

    iget v7, v7, Lo/c;->e:I

    add-int/2addr v5, v7

    :cond_10
    add-int/2addr v8, v5

    const/4 v5, -0x1

    invoke-static {v0, v8, v5}, Landroid/view/ViewGroup;->getChildMeasureSpec(III)I

    move-result v0

    const/4 v7, 0x3

    aput v5, v15, v7

    move v5, v0

    move v8, v7

    goto :goto_a

    :cond_11
    iget v0, v0, Landroidx/constraintlayout/widget/ConstraintLayout$b;->g:I

    const/4 v5, -0x2

    invoke-static {v0, v8, v5}, Landroid/view/ViewGroup;->getChildMeasureSpec(III)I

    move-result v0

    iget v5, v1, Lo/d;->k:I

    const/4 v8, 0x1

    if-ne v5, v8, :cond_12

    move v5, v8

    goto :goto_7

    :cond_12
    const/4 v5, 0x0

    :goto_7
    const/4 v11, 0x0

    aput v11, v15, v7

    iget-boolean v7, v2, Lp/b$a;->j:Z

    if-eqz v7, :cond_17

    if-eqz v5, :cond_13

    aget v7, v15, v12

    if-eqz v7, :cond_13

    aget v7, v15, v8

    invoke-virtual/range {p1 .. p1}, Lo/d;->j()I

    move-result v8

    if-ne v7, v8, :cond_14

    :cond_13
    instance-of v7, v10, Landroidx/constraintlayout/widget/e;

    if-eqz v7, :cond_15

    :cond_14
    const/4 v7, 0x1

    goto :goto_8

    :cond_15
    const/4 v7, 0x0

    :goto_8
    if-eqz v5, :cond_16

    if-eqz v7, :cond_17

    :cond_16
    invoke-virtual/range {p1 .. p1}, Lo/d;->j()I

    move-result v0

    const/high16 v5, 0x40000000    # 2.0f

    invoke-static {v0, v5}, Landroid/view/View$MeasureSpec;->makeMeasureSpec(II)I

    move-result v0

    move v5, v0

    const/4 v0, 0x0

    goto :goto_9

    :cond_17
    const/high16 v5, 0x40000000    # 2.0f

    move v5, v0

    const/4 v0, 0x1

    :goto_9
    const/4 v8, 0x3

    goto :goto_b

    :cond_18
    const/high16 v5, 0x40000000    # 2.0f

    iget v0, v0, Landroidx/constraintlayout/widget/ConstraintLayout$b;->g:I

    const/4 v7, -0x2

    invoke-static {v0, v8, v7}, Landroid/view/ViewGroup;->getChildMeasureSpec(III)I

    move-result v0

    const/4 v8, 0x3

    aput v7, v15, v8

    move v5, v0

    const/4 v0, 0x1

    goto :goto_b

    :cond_19
    const/high16 v5, 0x40000000    # 2.0f

    const/4 v8, 0x3

    invoke-static {v7, v5}, Landroid/view/View$MeasureSpec;->makeMeasureSpec(II)I

    move-result v0

    aput v7, v15, v8

    move v5, v0

    :goto_a
    const/4 v0, 0x0

    :goto_b
    if-ne v3, v8, :cond_1a

    const/4 v7, 0x1

    goto :goto_c

    :cond_1a
    const/4 v7, 0x0

    :goto_c
    if-ne v4, v8, :cond_1b

    const/4 v8, 0x1

    goto :goto_d

    :cond_1b
    const/4 v8, 0x0

    :goto_d
    const/4 v11, 0x4

    const/4 v13, 0x1

    if-eq v4, v11, :cond_1d

    if-ne v4, v13, :cond_1c

    goto :goto_e

    :cond_1c
    const/4 v4, 0x0

    goto :goto_f

    :cond_1d
    :goto_e
    move v4, v13

    :goto_f
    if-eq v3, v11, :cond_1f

    if-ne v3, v13, :cond_1e

    goto :goto_10

    :cond_1e
    const/4 v3, 0x0

    goto :goto_11

    :cond_1f
    :goto_10
    const/4 v3, 0x1

    :goto_11
    const/4 v11, 0x0

    if-eqz v7, :cond_20

    iget v13, v1, Lo/d;->N:F

    cmpl-float v13, v13, v11

    if-lez v13, :cond_20

    const/4 v13, 0x1

    goto :goto_12

    :cond_20
    const/4 v13, 0x0

    :goto_12
    if-eqz v8, :cond_21

    iget v14, v1, Lo/d;->N:F

    cmpl-float v11, v14, v11

    if-lez v11, :cond_21

    const/4 v11, 0x1

    goto :goto_13

    :cond_21
    const/4 v11, 0x0

    :goto_13
    invoke-virtual {v10}, Landroid/view/View;->getLayoutParams()Landroid/view/ViewGroup$LayoutParams;

    move-result-object v14

    check-cast v14, Landroidx/constraintlayout/widget/ConstraintLayout$a;

    iget-boolean v12, v2, Lp/b$a;->j:Z

    if-nez v12, :cond_23

    if-eqz v7, :cond_23

    iget v7, v1, Lo/d;->j:I

    if-nez v7, :cond_23

    if-eqz v8, :cond_23

    iget v7, v1, Lo/d;->k:I

    if-eqz v7, :cond_22

    goto :goto_14

    :cond_22
    const/4 v0, 0x0

    const/4 v3, 0x0

    const/4 v4, 0x0

    const/4 v5, -0x1

    const/16 v16, 0x0

    goto/16 :goto_1d

    :cond_23
    :goto_14
    instance-of v7, v10, Lq/e;

    if-eqz v7, :cond_24

    instance-of v7, v1, Lo/j;

    if-eqz v7, :cond_24

    move-object v7, v1

    check-cast v7, Lo/j;

    move-object v8, v10

    check-cast v8, Lq/e;

    invoke-virtual {v8, v7, v6, v5}, Lq/e;->h(Lo/j;II)V

    goto :goto_15

    :cond_24
    invoke-virtual {v10, v6, v5}, Landroid/view/View;->measure(II)V

    :goto_15
    invoke-virtual {v10}, Landroid/view/View;->getMeasuredWidth()I

    move-result v7

    invoke-virtual {v10}, Landroid/view/View;->getMeasuredHeight()I

    move-result v8

    invoke-virtual {v10}, Landroid/view/View;->getBaseline()I

    move-result v12

    if-eqz v9, :cond_25

    const/16 v16, 0x0

    aput v7, v15, v16

    const/4 v9, 0x2

    aput v8, v15, v9

    goto :goto_16

    :cond_25
    const/4 v9, 0x2

    const/16 v16, 0x0

    aput v16, v15, v16

    aput v16, v15, v9

    :goto_16
    if-eqz v0, :cond_26

    const/4 v0, 0x1

    aput v8, v15, v0

    const/4 v9, 0x3

    aput v7, v15, v9

    goto :goto_17

    :cond_26
    const/4 v0, 0x1

    const/4 v9, 0x3

    aput v16, v15, v0

    aput v16, v15, v9

    :goto_17
    iget v0, v1, Lo/d;->m:I

    if-lez v0, :cond_27

    invoke-static {v0, v7}, Ljava/lang/Math;->max(II)I

    move-result v0

    goto :goto_18

    :cond_27
    move v0, v7

    :goto_18
    iget v9, v1, Lo/d;->n:I

    if-lez v9, :cond_28

    invoke-static {v9, v0}, Ljava/lang/Math;->min(II)I

    move-result v0

    :cond_28
    iget v9, v1, Lo/d;->p:I

    if-lez v9, :cond_29

    invoke-static {v9, v8}, Ljava/lang/Math;->max(II)I

    move-result v9

    goto :goto_19

    :cond_29
    move v9, v8

    :goto_19
    iget v15, v1, Lo/d;->q:I

    if-lez v15, :cond_2a

    invoke-static {v15, v9}, Ljava/lang/Math;->min(II)I

    move-result v9

    :cond_2a
    const/high16 v15, 0x3f000000    # 0.5f

    if-eqz v13, :cond_2b

    if-eqz v4, :cond_2b

    iget v0, v1, Lo/d;->N:F

    int-to-float v3, v9

    mul-float/2addr v3, v0

    add-float/2addr v3, v15

    float-to-int v0, v3

    goto :goto_1a

    :cond_2b
    if-eqz v11, :cond_2c

    if-eqz v3, :cond_2c

    iget v3, v1, Lo/d;->N:F

    int-to-float v4, v0

    div-float/2addr v4, v3

    add-float/2addr v4, v15

    float-to-int v3, v4

    move v9, v3

    :cond_2c
    :goto_1a
    if-ne v7, v0, :cond_2e

    if-eq v8, v9, :cond_2d

    goto :goto_1c

    :cond_2d
    move v3, v9

    move v4, v12

    :goto_1b
    const/4 v5, -0x1

    goto :goto_1d

    :cond_2e
    :goto_1c
    const/high16 v3, 0x40000000    # 2.0f

    if-eq v7, v0, :cond_2f

    invoke-static {v0, v3}, Landroid/view/View$MeasureSpec;->makeMeasureSpec(II)I

    move-result v6

    :cond_2f
    if-eq v8, v9, :cond_30

    invoke-static {v9, v3}, Landroid/view/View$MeasureSpec;->makeMeasureSpec(II)I

    move-result v5

    :cond_30
    invoke-virtual {v10, v6, v5}, Landroid/view/View;->measure(II)V

    invoke-virtual {v10}, Landroid/view/View;->getMeasuredWidth()I

    move-result v0

    invoke-virtual {v10}, Landroid/view/View;->getMeasuredHeight()I

    move-result v3

    invoke-virtual {v10}, Landroid/view/View;->getBaseline()I

    move-result v4

    goto :goto_1b

    :goto_1d
    if-eq v4, v5, :cond_31

    const/4 v5, 0x1

    goto :goto_1e

    :cond_31
    move/from16 v5, v16

    :goto_1e
    iget v6, v2, Lp/b$a;->c:I

    if-ne v0, v6, :cond_33

    iget v6, v2, Lp/b$a;->d:I

    if-eq v3, v6, :cond_32

    goto :goto_1f

    :cond_32
    move/from16 v6, v16

    goto :goto_20

    :cond_33
    :goto_1f
    const/4 v6, 0x1

    :goto_20
    iput-boolean v6, v2, Lp/b$a;->i:Z

    iget-boolean v6, v14, Landroidx/constraintlayout/widget/ConstraintLayout$a;->X:Z

    if-eqz v6, :cond_34

    const/4 v11, 0x1

    goto :goto_21

    :cond_34
    move v11, v5

    :goto_21
    if-eqz v11, :cond_35

    const/4 v5, -0x1

    if-eq v4, v5, :cond_35

    iget v1, v1, Lo/d;->R:I

    if-eq v1, v4, :cond_35

    const/4 v1, 0x1

    iput-boolean v1, v2, Lp/b$a;->i:Z

    :cond_35
    iput v0, v2, Lp/b$a;->e:I

    iput v3, v2, Lp/b$a;->f:I

    iput-boolean v11, v2, Lp/b$a;->h:Z

    iput v4, v2, Lp/b$a;->g:I

    return-void
.end method
