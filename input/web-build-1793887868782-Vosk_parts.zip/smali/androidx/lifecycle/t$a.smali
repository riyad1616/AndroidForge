.class public final Landroidx/lifecycle/t$a;
.super Landroidx/lifecycle/c;
.source "SourceFile"


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Landroidx/lifecycle/t;->onActivityPreCreated(Landroid/app/Activity;Landroid/os/Bundle;)V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x1
    name = null
.end annotation


# instance fields
.field final synthetic this$1:Landroidx/lifecycle/t;


# direct methods
.method public constructor <init>(Landroidx/lifecycle/t;)V
    .locals 0

    iput-object p1, p0, Landroidx/lifecycle/t$a;->this$1:Landroidx/lifecycle/t;

    invoke-direct {p0}, Landroidx/lifecycle/c;-><init>()V

    return-void
.end method


# virtual methods
.method public onActivityPostResumed(Landroid/app/Activity;)V
    .locals 0

    iget-object p0, p0, Landroidx/lifecycle/t$a;->this$1:Landroidx/lifecycle/t;

    iget-object p0, p0, Landroidx/lifecycle/t;->this$0:Landroidx/lifecycle/s;

    invoke-virtual {p0}, Landroidx/lifecycle/s;->c()V

    return-void
.end method

.method public onActivityPostStarted(Landroid/app/Activity;)V
    .locals 1

    iget-object p0, p0, Landroidx/lifecycle/t$a;->this$1:Landroidx/lifecycle/t;

    iget-object p0, p0, Landroidx/lifecycle/t;->this$0:Landroidx/lifecycle/s;

    iget p1, p0, Landroidx/lifecycle/s;->b:I

    const/4 v0, 0x1

    add-int/2addr p1, v0

    iput p1, p0, Landroidx/lifecycle/s;->b:I

    if-ne p1, v0, :cond_0

    iget-boolean p1, p0, Landroidx/lifecycle/s;->e:Z

    if-eqz p1, :cond_0

    iget-object p1, p0, Landroidx/lifecycle/s;->g:Landroidx/lifecycle/l;

    sget-object v0, Landroidx/lifecycle/g$b;->ON_START:Landroidx/lifecycle/g$b;

    invoke-virtual {p1, v0}, Landroidx/lifecycle/l;->e(Landroidx/lifecycle/g$b;)V

    const/4 p1, 0x0

    iput-boolean p1, p0, Landroidx/lifecycle/s;->e:Z

    :cond_0
    return-void
.end method
