.class public interface abstract Landroidx/lifecycle/k;
.super Ljava/lang/Object;
.source "SourceFile"


# virtual methods
.method public abstract k()Landroidx/lifecycle/l;
.end method
