.class public final Landroidx/lifecycle/s$a;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Ljava/lang/Runnable;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Landroidx/lifecycle/s;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x1
    name = null
.end annotation


# instance fields
.field public final synthetic b:Landroidx/lifecycle/s;


# direct methods
.method public constructor <init>(Landroidx/lifecycle/s;)V
    .locals 0

    iput-object p1, p0, Landroidx/lifecycle/s$a;->b:Landroidx/lifecycle/s;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public final run()V
    .locals 3

    iget-object p0, p0, Landroidx/lifecycle/s$a;->b:Landroidx/lifecycle/s;

    iget v0, p0, Landroidx/lifecycle/s;->c:I

    const/4 v1, 0x1

    iget-object v2, p0, Landroidx/lifecycle/s;->g:Landroidx/lifecycle/l;

    if-nez v0, :cond_0

    iput-boolean v1, p0, Landroidx/lifecycle/s;->d:Z

    sget-object v0, Landroidx/lifecycle/g$b;->ON_PAUSE:Landroidx/lifecycle/g$b;

    invoke-virtual {v2, v0}, Landroidx/lifecycle/l;->e(Landroidx/lifecycle/g$b;)V

    :cond_0
    iget v0, p0, Landroidx/lifecycle/s;->b:I

    if-nez v0, :cond_1

    iget-boolean v0, p0, Landroidx/lifecycle/s;->d:Z

    if-eqz v0, :cond_1

    sget-object v0, Landroidx/lifecycle/g$b;->ON_STOP:Landroidx/lifecycle/g$b;

    invoke-virtual {v2, v0}, Landroidx/lifecycle/l;->e(Landroidx/lifecycle/g$b;)V

    iput-boolean v1, p0, Landroidx/lifecycle/s;->e:Z

    :cond_1
    return-void
.end method
