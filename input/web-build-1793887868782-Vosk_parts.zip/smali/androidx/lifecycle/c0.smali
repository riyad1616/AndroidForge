.class public final Landroidx/lifecycle/c0;
.super Ljava/lang/Object;
.source "SourceFile"


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Landroidx/lifecycle/c0$a;,
        Landroidx/lifecycle/c0$b;
    }
.end annotation


# instance fields
.field public final a:Landroidx/lifecycle/d0;

.field public final b:Landroidx/lifecycle/c0$a;

.field public final c:Lq0/a;


# direct methods
.method public constructor <init>(Landroidx/lifecycle/d0;Landroidx/lifecycle/c0$a;)V
    .locals 1

    const-string v0, "store"

    invoke-static {v0, p1}, Lj3/c;->d(Ljava/lang/String;Ljava/lang/Object;)V

    const-string v0, "factory"

    invoke-static {v0, p2}, Lj3/c;->d(Ljava/lang/String;Ljava/lang/Object;)V

    .line 1
    sget-object v0, Lq0/a$a;->b:Lq0/a$a;

    invoke-direct {p0, p1, p2, v0}, Landroidx/lifecycle/c0;-><init>(Landroidx/lifecycle/d0;Landroidx/lifecycle/c0$a;Lq0/a;)V

    return-void
.end method

.method public constructor <init>(Landroidx/lifecycle/d0;Landroidx/lifecycle/c0$a;Lq0/a;)V
    .locals 1

    const-string v0, "store"

    invoke-static {v0, p1}, Lj3/c;->d(Ljava/lang/String;Ljava/lang/Object;)V

    const-string v0, "factory"

    invoke-static {v0, p2}, Lj3/c;->d(Ljava/lang/String;Ljava/lang/Object;)V

    const-string v0, "defaultCreationExtras"

    invoke-static {v0, p3}, Lj3/c;->d(Ljava/lang/String;Ljava/lang/Object;)V

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Landroidx/lifecycle/c0;->a:Landroidx/lifecycle/d0;

    iput-object p2, p0, Landroidx/lifecycle/c0;->b:Landroidx/lifecycle/c0$a;

    iput-object p3, p0, Landroidx/lifecycle/c0;->c:Lq0/a;

    return-void
.end method


# virtual methods
.method public final a(Ljava/lang/Class;)Landroidx/lifecycle/b0;
    .locals 2
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "<T:",
            "Landroidx/lifecycle/b0;",
            ">(",
            "Ljava/lang/Class<",
            "TT;>;)TT;"
        }
    .end annotation

    invoke-virtual {p1}, Ljava/lang/Class;->getCanonicalName()Ljava/lang/String;

    move-result-object v0

    if-eqz v0, :cond_0

    const-string v1, "androidx.lifecycle.ViewModelProvider.DefaultKey:"

    invoke-virtual {v1, v0}, Ljava/lang/String;->concat(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    invoke-virtual {p0, p1, v0}, Landroidx/lifecycle/c0;->b(Ljava/lang/Class;Ljava/lang/String;)Landroidx/lifecycle/b0;

    move-result-object p0

    return-object p0

    :cond_0
    new-instance p0, Ljava/lang/IllegalArgumentException;

    const-string p1, "Local and anonymous classes can not be ViewModels"

    invoke-direct {p0, p1}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    throw p0
.end method

.method public final b(Ljava/lang/Class;Ljava/lang/String;)Landroidx/lifecycle/b0;
    .locals 4

    const-string v0, "key"

    invoke-static {v0, p2}, Lj3/c;->d(Ljava/lang/String;Ljava/lang/Object;)V

    iget-object v0, p0, Landroidx/lifecycle/c0;->a:Landroidx/lifecycle/d0;

    iget-object v1, v0, Landroidx/lifecycle/d0;->a:Ljava/util/HashMap;

    invoke-virtual {v1, p2}, Ljava/util/HashMap;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Landroidx/lifecycle/b0;

    invoke-virtual {p1, v1}, Ljava/lang/Class;->isInstance(Ljava/lang/Object;)Z

    move-result v2

    iget-object v3, p0, Landroidx/lifecycle/c0;->b:Landroidx/lifecycle/c0$a;

    if-eqz v2, :cond_3

    instance-of p0, v3, Landroidx/lifecycle/c0$b;

    if-eqz p0, :cond_0

    check-cast v3, Landroidx/lifecycle/c0$b;

    goto :goto_0

    :cond_0
    const/4 v3, 0x0

    :goto_0
    if-eqz v3, :cond_1

    const-string p0, "viewModel"

    invoke-static {p0, v1}, Lj3/c;->c(Ljava/lang/String;Ljava/lang/Object;)V

    :cond_1
    if-eqz v1, :cond_2

    return-object v1

    :cond_2
    new-instance p0, Ljava/lang/NullPointerException;

    const-string p1, "null cannot be cast to non-null type T of androidx.lifecycle.ViewModelProvider.get"

    invoke-direct {p0, p1}, Ljava/lang/NullPointerException;-><init>(Ljava/lang/String;)V

    throw p0

    :cond_3
    new-instance v1, Lq0/d;

    iget-object p0, p0, Landroidx/lifecycle/c0;->c:Lq0/a;

    invoke-direct {v1, p0}, Lq0/d;-><init>(Lq0/a;)V

    sget-object p0, La1/a;->c:La1/a;

    invoke-virtual {v1, p0, p2}, Lq0/d;->a(Lq0/a$b;Ljava/lang/Object;)V

    :try_start_0
    invoke-interface {v3, p1, v1}, Landroidx/lifecycle/c0$a;->b(Ljava/lang/Class;Lq0/d;)Landroidx/lifecycle/b0;

    move-result-object p0
    :try_end_0
    .catch Ljava/lang/AbstractMethodError; {:try_start_0 .. :try_end_0} :catch_0

    goto :goto_1

    :catch_0
    invoke-interface {v3, p1}, Landroidx/lifecycle/c0$a;->a(Ljava/lang/Class;)Landroidx/lifecycle/b0;

    move-result-object p0

    :goto_1
    iget-object p1, v0, Landroidx/lifecycle/d0;->a:Ljava/util/HashMap;

    invoke-virtual {p1, p2, p0}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p1

    check-cast p1, Landroidx/lifecycle/b0;

    if-eqz p1, :cond_4

    invoke-virtual {p1}, Landroidx/lifecycle/b0;->a()V

    :cond_4
    return-object p0
.end method
