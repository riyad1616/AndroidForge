.class Landroidx/lifecycle/Lifecycling$1;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Landroidx/lifecycle/i;


# virtual methods
.method public final f(Landroidx/lifecycle/k;Landroidx/lifecycle/g$b;)V
    .locals 0

    const/4 p0, 0x0

    throw p0
.end method
