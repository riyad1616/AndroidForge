.class public final Landroidx/lifecycle/t;
.super Landroidx/lifecycle/c;
.source "SourceFile"


# instance fields
.field final synthetic this$0:Landroidx/lifecycle/s;


# direct methods
.method public constructor <init>(Landroidx/lifecycle/s;)V
    .locals 0

    iput-object p1, p0, Landroidx/lifecycle/t;->this$0:Landroidx/lifecycle/s;

    invoke-direct {p0}, Landroidx/lifecycle/c;-><init>()V

    return-void
.end method


# virtual methods
.method public onActivityCreated(Landroid/app/Activity;Landroid/os/Bundle;)V
    .locals 0

    return-void
.end method

.method public onActivityPaused(Landroid/app/Activity;)V
    .locals 2

    iget-object p0, p0, Landroidx/lifecycle/t;->this$0:Landroidx/lifecycle/s;

    iget p1, p0, Landroidx/lifecycle/s;->c:I

    add-int/lit8 p1, p1, -0x1

    iput p1, p0, Landroidx/lifecycle/s;->c:I

    if-nez p1, :cond_0

    iget-object p1, p0, Landroidx/lifecycle/s;->f:Landroid/os/Handler;

    iget-object p0, p0, Landroidx/lifecycle/s;->h:Landroidx/lifecycle/s$a;

    const-wide/16 v0, 0x2bc

    invoke-virtual {p1, p0, v0, v1}, Landroid/os/Handler;->postDelayed(Ljava/lang/Runnable;J)Z

    :cond_0
    return-void
.end method

.method public onActivityPreCreated(Landroid/app/Activity;Landroid/os/Bundle;)V
    .locals 0

    new-instance p2, Landroidx/lifecycle/t$a;

    invoke-direct {p2, p0}, Landroidx/lifecycle/t$a;-><init>(Landroidx/lifecycle/t;)V

    invoke-virtual {p1, p2}, Landroid/app/Activity;->registerActivityLifecycleCallbacks(Landroid/app/Application$ActivityLifecycleCallbacks;)V

    return-void
.end method

.method public onActivityStopped(Landroid/app/Activity;)V
    .locals 1

    iget-object p0, p0, Landroidx/lifecycle/t;->this$0:Landroidx/lifecycle/s;

    iget p1, p0, Landroidx/lifecycle/s;->b:I

    add-int/lit8 p1, p1, -0x1

    iput p1, p0, Landroidx/lifecycle/s;->b:I

    if-nez p1, :cond_0

    iget-boolean p1, p0, Landroidx/lifecycle/s;->d:Z

    if-eqz p1, :cond_0

    iget-object p1, p0, Landroidx/lifecycle/s;->g:Landroidx/lifecycle/l;

    sget-object v0, Landroidx/lifecycle/g$b;->ON_STOP:Landroidx/lifecycle/g$b;

    invoke-virtual {p1, v0}, Landroidx/lifecycle/l;->e(Landroidx/lifecycle/g$b;)V

    const/4 p1, 0x1

    iput-boolean p1, p0, Landroidx/lifecycle/s;->e:Z

    :cond_0
    return-void
.end method
