.class public interface abstract Landroidx/lifecycle/f;
.super Ljava/lang/Object;
.source "SourceFile"


# virtual methods
.method public f()Lq0/a;
    .locals 0

    sget-object p0, Lq0/a$a;->b:Lq0/a$a;

    return-object p0
.end method
