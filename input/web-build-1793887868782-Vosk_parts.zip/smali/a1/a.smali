.class public La1/a;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Lq0/a$b;
.implements Le0/j0;


# static fields
.field public static final A:[I

.field public static A0:La1/a;

.field public static final B:[I

.field public static final B0:Lq0/c;

.field public static final C:[I

.field public static final C0:Lq0/c;

.field public static final D:[I

.field public static final D0:[I

.field public static final E:[I

.field public static final E0:[I

.field public static final F:[I

.field public static final F0:[I

.field public static final G:[I

.field public static final G0:[I

.field public static final H:[I

.field public static final H0:[I

.field public static final I:[I

.field public static final I0:[I

.field public static final J:[I

.field public static final J0:[I

.field public static final K:[I

.field public static final K0:[I

.field public static final L:[I

.field public static final L0:[[F

.field public static final M:[I

.field public static final M0:[[F

.field public static final N:[I

.field public static final N0:[F

.field public static final O:[I

.field public static final O0:[[F

.field public static final P:[I

.field public static final Q:[I

.field public static final R:[I

.field public static final S:[I

.field public static final T:[I

.field public static final U:[I

.field public static final V:[I

.field public static final W:[I

.field public static final X:[I

.field public static final Y:[I

.field public static final Z:[I

.field public static final a:[I

.field public static final a0:[I

.field public static final b:La1/a;

.field public static final b0:[I

.field public static final c:La1/a;

.field public static final c0:[I

.field public static final d:[I

.field public static final d0:[I

.field public static final e:[I

.field public static final e0:[I

.field public static final f:[I

.field public static final f0:[I

.field public static final g:[I

.field public static final g0:[I

.field public static final h:[I

.field public static final h0:[I

.field public static final i:[I

.field public static final i0:La1/a;

.field public static final j:[I

.field public static final j0:[Ljava/lang/Object;

.field public static final k:[I

.field public static final k0:[I

.field public static final l:[I

.field public static final l0:[Ljava/lang/Object;

.field public static final m:[I

.field public static final m0:[Ljava/lang/String;

.field public static final n:[I

.field public static final n0:[Z

.field public static final o:[I

.field public static final o0:[I

.field public static final p:[I

.field public static final p0:[I

.field public static final q:[I

.field public static final q0:[I

.field public static final r:[I

.field public static final r0:[I

.field public static final s:[I

.field public static final s0:[I

.field public static final t:[I

.field public static final t0:[I

.field public static final u:[I

.field public static final u0:[I

.field public static final v:[I

.field public static final v0:[I

.field public static final w:[I

.field public static final w0:[I

.field public static final x:[I

.field public static final x0:[I

.field public static final y:[I

.field public static final y0:[I

.field public static final z:[I

.field public static final z0:[I


# direct methods
.method static synthetic constructor <clinit>()V
    .locals 7

    const/4 v0, 0x1

    new-array v0, v0, [I

    const/4 v1, 0x0

    const v2, 0x10100c4

    aput v2, v0, v1

    sput-object v0, La1/a;->a:[I

    new-instance v0, La1/a;

    invoke-direct {v0}, La1/a;-><init>()V

    sput-object v0, La1/a;->b:La1/a;

    new-instance v0, La1/a;

    invoke-direct {v0}, La1/a;-><init>()V

    sput-object v0, La1/a;->c:La1/a;

    const/16 v0, 0x1d

    new-array v0, v0, [I

    fill-array-data v0, :array_0

    sput-object v0, La1/a;->d:[I

    const/4 v0, 0x1

    new-array v1, v0, [I

    const v2, 0x10100b3

    const/4 v3, 0x0

    aput v2, v1, v3

    sput-object v1, La1/a;->e:[I

    new-array v1, v0, [I

    const v2, 0x101013f

    aput v2, v1, v3

    sput-object v1, La1/a;->f:[I

    const/4 v1, 0x6

    new-array v2, v1, [I

    fill-array-data v2, :array_1

    sput-object v2, La1/a;->g:[I

    const/16 v2, 0x8

    new-array v2, v2, [I

    fill-array-data v2, :array_2

    sput-object v2, La1/a;->h:[I

    const/4 v2, 0x4

    new-array v4, v2, [I

    fill-array-data v4, :array_3

    sput-object v4, La1/a;->i:[I

    new-array v4, v2, [I

    fill-array-data v4, :array_4

    sput-object v4, La1/a;->j:[I

    const/4 v4, 0x7

    new-array v4, v4, [I

    fill-array-data v4, :array_5

    sput-object v4, La1/a;->k:[I

    const/16 v4, 0x16

    new-array v4, v4, [I

    fill-array-data v4, :array_6

    sput-object v4, La1/a;->l:[I

    const/16 v4, 0x7f

    new-array v4, v4, [I

    fill-array-data v4, :array_7

    sput-object v4, La1/a;->m:[I

    new-array v0, v0, [I

    const v4, 0x7f03002a

    aput v4, v0, v3

    sput-object v0, La1/a;->n:[I

    new-array v0, v2, [I

    fill-array-data v0, :array_8

    sput-object v0, La1/a;->o:[I

    new-array v0, v2, [I

    fill-array-data v0, :array_9

    sput-object v0, La1/a;->p:[I

    const/16 v0, 0x9

    new-array v2, v0, [I

    fill-array-data v2, :array_a

    sput-object v2, La1/a;->q:[I

    const/4 v2, 0x2

    new-array v3, v2, [I

    fill-array-data v3, :array_b

    sput-object v3, La1/a;->r:[I

    new-array v1, v1, [I

    fill-array-data v1, :array_c

    sput-object v1, La1/a;->s:[I

    const/16 v1, 0x17

    new-array v1, v1, [I

    fill-array-data v1, :array_d

    sput-object v1, La1/a;->t:[I

    new-array v0, v0, [I

    fill-array-data v0, :array_e

    sput-object v0, La1/a;->u:[I

    const/4 v0, 0x3

    new-array v1, v0, [I

    fill-array-data v1, :array_f

    sput-object v1, La1/a;->v:[I

    new-array v1, v2, [I

    fill-array-data v1, :array_10

    sput-object v1, La1/a;->w:[I

    const/16 v1, 0x1b

    new-array v1, v1, [I

    fill-array-data v1, :array_11

    sput-object v1, La1/a;->x:[I

    const/4 v1, 0x5

    new-array v2, v1, [I

    fill-array-data v2, :array_12

    sput-object v2, La1/a;->y:[I

    const/16 v2, 0x10

    new-array v2, v2, [I

    fill-array-data v2, :array_13

    sput-object v2, La1/a;->z:[I

    const/16 v2, 0x1e

    new-array v2, v2, [I

    fill-array-data v2, :array_14

    sput-object v2, La1/a;->A:[I

    new-array v1, v1, [I

    fill-array-data v1, :array_15

    sput-object v1, La1/a;->B:[I

    new-array v1, v0, [I

    fill-array-data v1, :array_16

    sput-object v1, La1/a;->C:[I

    new-array v0, v0, [I

    fill-array-data v0, :array_17

    sput-object v0, La1/a;->D:[I

    const/4 v0, 0x3

    new-array v1, v0, [I

    fill-array-data v1, :array_18

    sput-object v1, La1/a;->E:[I

    const/16 v1, 0x16

    new-array v2, v1, [I

    fill-array-data v2, :array_19

    sput-object v2, La1/a;->F:[I

    const/16 v2, 0x18

    new-array v2, v2, [I

    fill-array-data v2, :array_1a

    sput-object v2, La1/a;->G:[I

    const/16 v2, 0x2a

    new-array v2, v2, [I

    fill-array-data v2, :array_1b

    sput-object v2, La1/a;->H:[I

    const/4 v2, 0x2

    new-array v3, v2, [I

    fill-array-data v3, :array_1c

    sput-object v3, La1/a;->I:[I

    new-array v3, v0, [I

    fill-array-data v3, :array_1d

    sput-object v3, La1/a;->J:[I

    new-array v3, v2, [I

    fill-array-data v3, :array_1e

    sput-object v3, La1/a;->K:[I

    const/4 v3, 0x1

    new-array v4, v3, [I

    const v5, 0x7f03005e

    const/4 v6, 0x0

    aput v5, v4, v6

    sput-object v4, La1/a;->L:[I

    new-array v4, v0, [I

    fill-array-data v4, :array_1f

    sput-object v4, La1/a;->M:[I

    const/4 v4, 0x6

    new-array v4, v4, [I

    fill-array-data v4, :array_20

    sput-object v4, La1/a;->N:[I

    new-array v1, v1, [I

    fill-array-data v1, :array_21

    sput-object v1, La1/a;->O:[I

    const/4 v1, 0x4

    new-array v1, v1, [I

    fill-array-data v1, :array_22

    sput-object v1, La1/a;->P:[I

    const/16 v1, 0xa

    new-array v4, v1, [I

    fill-array-data v4, :array_23

    sput-object v4, La1/a;->Q:[I

    new-array v4, v1, [I

    fill-array-data v4, :array_24

    sput-object v4, La1/a;->R:[I

    const/16 v4, 0xb

    new-array v4, v4, [I

    fill-array-data v4, :array_25

    sput-object v4, La1/a;->S:[I

    new-array v4, v2, [I

    fill-array-data v4, :array_26

    sput-object v4, La1/a;->T:[I

    new-array v2, v2, [I

    fill-array-data v2, :array_27

    sput-object v2, La1/a;->U:[I

    new-array v2, v0, [I

    fill-array-data v2, :array_28

    sput-object v2, La1/a;->V:[I

    new-array v2, v0, [I

    fill-array-data v2, :array_29

    sput-object v2, La1/a;->W:[I

    const/4 v2, 0x5

    new-array v2, v2, [I

    fill-array-data v2, :array_2a

    sput-object v2, La1/a;->X:[I

    new-array v2, v3, [I

    const v4, 0x7f0302ba

    aput v4, v2, v6

    sput-object v2, La1/a;->Y:[I

    new-array v2, v3, [I

    const v4, 0x7f030065

    aput v4, v2, v6

    sput-object v2, La1/a;->Z:[I

    new-array v2, v1, [I

    fill-array-data v2, :array_2b

    sput-object v2, La1/a;->a0:[I

    const/16 v2, 0x8

    new-array v2, v2, [I

    fill-array-data v2, :array_2c

    sput-object v2, La1/a;->b0:[I

    new-array v1, v1, [I

    fill-array-data v1, :array_2d

    sput-object v1, La1/a;->c0:[I

    const/16 v1, 0x1b

    new-array v1, v1, [I

    fill-array-data v1, :array_2e

    sput-object v1, La1/a;->d0:[I

    const/16 v1, 0x10

    new-array v1, v1, [I

    fill-array-data v1, :array_2f

    sput-object v1, La1/a;->e0:[I

    new-array v1, v3, [I

    const v2, 0x7f030405

    aput v2, v1, v6

    sput-object v1, La1/a;->f0:[I

    const/16 v1, 0x48

    new-array v1, v1, [I

    fill-array-data v1, :array_30

    sput-object v1, La1/a;->g0:[I

    new-array v0, v0, [I

    fill-array-data v0, :array_31

    sput-object v0, La1/a;->h0:[I

    new-instance v0, La1/a;

    invoke-direct {v0}, La1/a;-><init>()V

    sput-object v0, La1/a;->i0:La1/a;

    const/4 v0, 0x0

    new-array v0, v0, [Ljava/lang/Object;

    sput-object v0, La1/a;->j0:[Ljava/lang/Object;

    const/4 v0, 0x0

    new-array v1, v0, [I

    sput-object v1, La1/a;->k0:[I

    new-array v0, v0, [Ljava/lang/Object;

    sput-object v0, La1/a;->l0:[Ljava/lang/Object;

    const-string v0, "decelerate"

    const-string v1, "linear"

    const-string v2, "standard"

    const-string v3, "accelerate"

    filled-new-array {v2, v3, v0, v1}, [Ljava/lang/String;

    move-result-object v0

    sput-object v0, La1/a;->m0:[Ljava/lang/String;

    const/4 v0, 0x3

    new-array v0, v0, [Z

    sput-object v0, La1/a;->n0:[Z

    const/4 v0, 0x3

    new-array v0, v0, [I

    fill-array-data v0, :array_32

    sput-object v0, La1/a;->o0:[I

    const/4 v0, 0x2

    new-array v0, v0, [I

    fill-array-data v0, :array_33

    sput-object v0, La1/a;->p0:[I

    const/16 v0, 0x6d

    new-array v0, v0, [I

    fill-array-data v0, :array_34

    sput-object v0, La1/a;->q0:[I

    const/16 v0, 0x5a

    new-array v0, v0, [I

    fill-array-data v0, :array_35

    sput-object v0, La1/a;->r0:[I

    const/16 v0, 0x6f

    new-array v0, v0, [I

    fill-array-data v0, :array_36

    sput-object v0, La1/a;->s0:[I

    const/16 v0, 0x9

    new-array v0, v0, [I

    fill-array-data v0, :array_37

    sput-object v0, La1/a;->t0:[I

    const/16 v0, 0x43

    new-array v0, v0, [I

    fill-array-data v0, :array_38

    sput-object v0, La1/a;->u0:[I

    const/4 v0, 0x6

    new-array v0, v0, [I

    fill-array-data v0, :array_39

    sput-object v0, La1/a;->v0:[I

    const/4 v0, 0x5

    new-array v1, v0, [I

    fill-array-data v1, :array_3a

    sput-object v1, La1/a;->w0:[I

    const/4 v1, 0x2

    new-array v1, v1, [I

    fill-array-data v1, :array_3b

    sput-object v1, La1/a;->x0:[I

    const/16 v1, 0xb

    new-array v1, v1, [I

    fill-array-data v1, :array_3c

    sput-object v1, La1/a;->y0:[I

    new-array v0, v0, [I

    fill-array-data v0, :array_3d

    sput-object v0, La1/a;->z0:[I

    new-instance v0, Lq0/c;

    const-string v1, "REMOVED_TASK"

    invoke-direct {v0, v1}, Lq0/c;-><init>(Ljava/lang/String;)V

    sput-object v0, La1/a;->B0:Lq0/c;

    new-instance v0, Lq0/c;

    const-string v1, "CLOSED_EMPTY"

    invoke-direct {v0, v1}, Lq0/c;-><init>(Ljava/lang/String;)V

    sput-object v0, La1/a;->C0:Lq0/c;

    const/4 v0, 0x2

    new-array v0, v0, [I

    fill-array-data v0, :array_3e

    sput-object v0, La1/a;->D0:[I

    const/4 v0, 0x7

    new-array v0, v0, [I

    fill-array-data v0, :array_3f

    sput-object v0, La1/a;->E0:[I

    const/16 v0, 0xc

    new-array v0, v0, [I

    fill-array-data v0, :array_40

    sput-object v0, La1/a;->F0:[I

    const/4 v0, 0x5

    new-array v0, v0, [I

    fill-array-data v0, :array_41

    sput-object v0, La1/a;->G0:[I

    const/4 v0, 0x7

    new-array v0, v0, [I

    fill-array-data v0, :array_42

    sput-object v0, La1/a;->H0:[I

    const/16 v0, 0xa

    new-array v0, v0, [I

    fill-array-data v0, :array_43

    sput-object v0, La1/a;->I0:[I

    const/16 v0, 0xc

    new-array v0, v0, [I

    fill-array-data v0, :array_44

    sput-object v0, La1/a;->J0:[I

    const/4 v0, 0x2

    new-array v0, v0, [I

    fill-array-data v0, :array_45

    sput-object v0, La1/a;->K0:[I

    const/4 v0, 0x3

    new-array v1, v0, [[F

    new-array v2, v0, [F

    fill-array-data v2, :array_46

    const/4 v3, 0x0

    aput-object v2, v1, v3

    new-array v2, v0, [F

    fill-array-data v2, :array_47

    const/4 v4, 0x1

    aput-object v2, v1, v4

    new-array v2, v0, [F

    fill-array-data v2, :array_48

    const/4 v5, 0x2

    aput-object v2, v1, v5

    sput-object v1, La1/a;->L0:[[F

    new-array v1, v0, [[F

    new-array v2, v0, [F

    fill-array-data v2, :array_49

    aput-object v2, v1, v3

    new-array v2, v0, [F

    fill-array-data v2, :array_4a

    aput-object v2, v1, v4

    new-array v2, v0, [F

    fill-array-data v2, :array_4b

    aput-object v2, v1, v5

    sput-object v1, La1/a;->M0:[[F

    new-array v1, v0, [F

    fill-array-data v1, :array_4c

    sput-object v1, La1/a;->N0:[F

    new-array v1, v0, [[F

    new-array v2, v0, [F

    fill-array-data v2, :array_4d

    aput-object v2, v1, v3

    new-array v2, v0, [F

    fill-array-data v2, :array_4e

    aput-object v2, v1, v4

    new-array v0, v0, [F

    fill-array-data v0, :array_4f

    aput-object v0, v1, v5

    sput-object v1, La1/a;->O0:[[F

    return-void

    :array_0
    .array-data 4
        0x7f030040
        0x7f030047
        0x7f030048
        0x7f03011b
        0x7f03011c
        0x7f03011d
        0x7f03011e
        0x7f03011f
        0x7f030120
        0x7f030147
        0x7f030159
        0x7f03015a
        0x7f030179
        0x7f0301ee
        0x7f0301f6
        0x7f0301fc
        0x7f0301fd
        0x7f030201
        0x7f03020c
        0x7f030222
        0x7f030296
        0x7f03030d
        0x7f03033c
        0x7f030343
        0x7f030344
        0x7f0303ab
        0x7f0303af
        0x7f030425
        0x7f030433
    .end array-data

    :array_1
    .array-data 4
        0x7f030040
        0x7f030047
        0x7f0300c9
        0x7f0301ee
        0x7f0303af
        0x7f030433
    .end array-data

    :array_2
    .array-data 4
        0x10100f2
        0x7f030086
        0x7f030089
        0x7f03028b
        0x7f03028c
        0x7f030309
        0x7f030378
        0x7f030380
    .end array-data

    :array_3
    .array-data 4
        0x1010119
        0x7f03038d
        0x7f030422
        0x7f030423
    .end array-data

    :array_4
    .array-data 4
        0x1010142
        0x7f03041c
        0x7f03041d
        0x7f03041e
    .end array-data

    :array_5
    .array-data 4
        0x1010034
        0x101016d
        0x101016e
        0x101016f
        0x1010170
        0x1010392
        0x1010393
    .end array-data

    :array_6
    .array-data 4
        0x1010034
        0x7f03003a
        0x7f03003b
        0x7f03003c
        0x7f03003d
        0x7f03003e
        0x7f030166
        0x7f030167
        0x7f030168
        0x7f030169
        0x7f03016b
        0x7f03016c
        0x7f03016d
        0x7f03016e
        0x7f03017d
        0x7f0301b5
        0x7f0301d9
        0x7f0301e2
        0x7f03023c
        0x7f030284
        0x7f0303d9
        0x7f03040a
    .end array-data

    :array_7
    .array-data 4
        0x1010057
        0x10100ae
        0x7f030000
        0x7f030001
        0x7f030002
        0x7f030003
        0x7f030004
        0x7f030005
        0x7f030006
        0x7f030007
        0x7f030008
        0x7f030009
        0x7f03000a
        0x7f03000b
        0x7f03000c
        0x7f03000e
        0x7f03000f
        0x7f030010
        0x7f030011
        0x7f030012
        0x7f030013
        0x7f030014
        0x7f030015
        0x7f030016
        0x7f030017
        0x7f030018
        0x7f030019
        0x7f03001a
        0x7f03001b
        0x7f03001c
        0x7f03001d
        0x7f03001e
        0x7f03001f
        0x7f030020
        0x7f030024
        0x7f030026
        0x7f030027
        0x7f030028
        0x7f030029
        0x7f030038
        0x7f03006b
        0x7f03007e
        0x7f03007f
        0x7f030080
        0x7f030081
        0x7f030082
        0x7f03008a
        0x7f03008b
        0x7f03009b
        0x7f0300a6
        0x7f0300d6
        0x7f0300d7
        0x7f0300d8
        0x7f0300da
        0x7f0300db
        0x7f0300dc
        0x7f0300dd
        0x7f0300f6
        0x7f0300f8
        0x7f03010d
        0x7f03012a
        0x7f030156
        0x7f030157
        0x7f030158
        0x7f03015c
        0x7f030161
        0x7f030172
        0x7f030173
        0x7f030176
        0x7f030177
        0x7f030178
        0x7f0301fc
        0x7f03020a
        0x7f030287
        0x7f030288
        0x7f030289
        0x7f03028a
        0x7f03028d
        0x7f03028e
        0x7f03028f
        0x7f030290
        0x7f030291
        0x7f030292
        0x7f030293
        0x7f030294
        0x7f030295
        0x7f030326
        0x7f030327
        0x7f030328
        0x7f03033b
        0x7f03033d
        0x7f030348
        0x7f03034a
        0x7f03034b
        0x7f03034c
        0x7f03035e
        0x7f03035f
        0x7f030360
        0x7f030361
        0x7f03038a
        0x7f03038b
        0x7f0303b6
        0x7f0303f0
        0x7f0303f2
        0x7f0303f3
        0x7f0303f4
        0x7f0303f6
        0x7f0303f7
        0x7f0303f8
        0x7f0303f9
        0x7f0303ff
        0x7f030400
        0x7f030436
        0x7f030437
        0x7f030439
        0x7f03043a
        0x7f03045c
        0x7f030465
        0x7f030466
        0x7f030467
        0x7f030468
        0x7f030469
        0x7f03046a
        0x7f03046b
        0x7f03046c
        0x7f03046d
        0x7f03046e
    .end array-data

    :array_8
    .array-data 4
        0x1010108
        0x7f030098
        0x7f030099
        0x7f03009a
    .end array-data

    :array_9
    .array-data 4
        0x1010107
        0x7f030083
        0x7f03008c
        0x7f03008d
    .end array-data

    :array_a
    .array-data 4
        0x10100af
        0x10100c4
        0x1010126
        0x1010127
        0x1010128
        0x7f03015a
        0x7f03015f
        0x7f0302d4
        0x7f030374
    .end array-data

    :array_b
    .array-data 4
        0x10102ac
        0x10102ad
    .end array-data

    :array_c
    .array-data 4
        0x101000e
        0x10100d0
        0x1010194
        0x10101de
        0x10101df
        0x10101e0
    .end array-data

    :array_d
    .array-data 4
        0x1010002
        0x101000e
        0x10100d0
        0x1010106
        0x1010194
        0x10101de
        0x10101df
        0x10101e1
        0x10101e2
        0x10101e3
        0x10101e4
        0x10101e5
        0x101026f
        0x7f03000d
        0x7f030021
        0x7f030023
        0x7f03002c
        0x7f03011a
        0x7f030207
        0x7f030208
        0x7f030314
        0x7f030372
        0x7f03043c
    .end array-data

    :array_e
    .array-data 4
        0x10100ae
        0x101012c
        0x101012d
        0x101012e
        0x101012f
        0x1010130
        0x1010131
        0x7f030341
        0x7f0303a5
    .end array-data

    :array_f
    .array-data 4
        0x1010176
        0x10102c9
        0x7f03031c
    .end array-data

    :array_10
    .array-data 4
        0x7f03031e
        0x7f030324
    .end array-data

    :array_11
    .array-data 4
        0x1010034
        0x10100da
        0x101011f
        0x101014f
        0x1010150
        0x1010220
        0x1010264
        0x7f03002e
        0x7f03002f
        0x7f030039
        0x7f0300c2
        0x7f030112
        0x7f030150
        0x7f0301ea
        0x7f0301ed
        0x7f0301f5
        0x7f030209
        0x7f03023e
        0x7f030345
        0x7f030346
        0x7f03035b
        0x7f03035c
        0x7f03035d
        0x7f0303aa
        0x7f0303b3
        0x7f030457
        0x7f03045e
    .end array-data

    :array_12
    .array-data 4
        0x10100b2
        0x1010176
        0x101017b
        0x1010262
        0x7f03033c
    .end array-data

    :array_13
    .array-data 4
        0x1010095
        0x1010096
        0x1010097
        0x1010098
        0x101009a
        0x101009b
        0x1010161
        0x1010162
        0x1010163
        0x1010164
        0x10103ac
        0x1010585
        0x7f0301d9
        0x7f0301e2
        0x7f0303d9
        0x7f03040a
    .end array-data

    :array_14
    .array-data 4
        0x10100af
        0x1010140
        0x7f030084
        0x7f0300ca
        0x7f0300cb
        0x7f03011b
        0x7f03011c
        0x7f03011d
        0x7f03011e
        0x7f03011f
        0x7f030120
        0x7f030296
        0x7f030298
        0x7f0302cd
        0x7f0302d5
        0x7f03030a
        0x7f03030b
        0x7f03033c
        0x7f0303ab
        0x7f0303ad
        0x7f0303ae
        0x7f030425
        0x7f030429
        0x7f03042a
        0x7f03042b
        0x7f03042c
        0x7f03042d
        0x7f03042e
        0x7f030430
        0x7f030431
    .end array-data

    :array_15
    .array-data 4
        0x1010000
        0x10100da
        0x7f030320
        0x7f030323
        0x7f03040c
    .end array-data

    :array_16
    .array-data 4
        0x10100d4
        0x7f030049
        0x7f03004a
    .end array-data

    :array_17
    .array-data 4
        0x10100d0
        0x10100f2
        0x10100f3
    .end array-data

    :array_18
    .array-data 4
        0x7f03027d
        0x7f03027e
        0x7f03027f
    .end array-data

    :array_19
    .array-data 4
        0x7f030041
        0x7f03004b
        0x7f03004c
        0x7f03004d
        0x7f03004e
        0x7f03004f
        0x7f030051
        0x7f030052
        0x7f030053
        0x7f030054
        0x7f030055
        0x7f030056
        0x7f030057
        0x7f030058
        0x7f030059
        0x7f0301fe
        0x7f0301ff
        0x7f0302ce
        0x7f030313
        0x7f030315
        0x7f03045a
        0x7f03045b
    .end array-data

    :array_1a
    .array-data 4
        0x101011f
        0x1010120
        0x1010440
        0x7f030049
        0x7f030060
        0x7f030061
        0x7f030062
        0x7f030063
        0x7f030064
        0x7f030066
        0x7f030067
        0x7f030068
        0x7f030069
        0x7f0301e9
        0x7f03029b
        0x7f03029c
        0x7f03029d
        0x7f03031f
        0x7f030321
        0x7f030322
        0x7f030325
        0x7f030364
        0x7f03036c
        0x7f030370
    .end array-data

    :array_1b
    .array-data 4
        0x1010034
        0x1010095
        0x1010098
        0x10100ab
        0x101011f
        0x101014f
        0x10101e5
        0x7f03009e
        0x7f03009f
        0x7f0300a3
        0x7f0300a4
        0x7f0300a7
        0x7f0300a8
        0x7f0300a9
        0x7f0300ab
        0x7f0300ac
        0x7f0300ad
        0x7f0300ae
        0x7f0300af
        0x7f0300b0
        0x7f0300b1
        0x7f0300b6
        0x7f0300b7
        0x7f0300b8
        0x7f0300ba
        0x7f0300c2
        0x7f0300c3
        0x7f0300c4
        0x7f0300c5
        0x7f0300c6
        0x7f0300c7
        0x7f0300c8
        0x7f030189
        0x7f0301f4
        0x7f030202
        0x7f030206
        0x7f030354
        0x7f030364
        0x7f03036c
        0x7f030375
        0x7f030401
        0x7f03040b
    .end array-data

    :array_1c
    .array-data 4
        0x7f0300be
        0x7f0300c1
    .end array-data

    :array_1d
    .array-data 4
        0x7f0300bf
        0x7f0302ba
        0x7f030363
    .end array-data

    :array_1e
    .array-data 4
        0x7f03005e
        0x7f03005f
    .end array-data

    :array_1f
    .array-data 4
        0x1010109
        0x1010200
        0x7f0301e6
    .end array-data

    :array_20
    .array-data 4
        0x1010220
        0x101048c
        0x7f03037c
        0x7f03037d
        0x7f03037e
        0x7f03037f
    .end array-data

    :array_21
    .array-data 4
        0x10100d4
        0x10101b7
        0x10101b8
        0x10101b9
        0x10101ba
        0x10101e5
        0x7f030049
        0x7f03004a
        0x7f030132
        0x7f030179
        0x7f030201
        0x7f030203
        0x7f030204
        0x7f030205
        0x7f030207
        0x7f030208
        0x7f030354
        0x7f030364
        0x7f03036c
        0x7f0303a3
        0x7f0303a4
        0x7f030434
    .end array-data

    :array_22
    .array-data 4
        0x101000e
        0x7f03009c
        0x7f030362
        0x7f030382
    .end array-data

    :array_23
    .array-data 4
        0x101020d
        0x7f03014a
        0x7f03014b
        0x7f03014c
        0x7f03014d
        0x7f030312
        0x7f030349
        0x7f03046f
        0x7f030470
        0x7f030471
    .end array-data

    :array_24
    .array-data 4
        0x10101b7
        0x10101b8
        0x10101b9
        0x10101ba
        0x7f03021a
        0x7f030226
        0x7f030227
        0x7f03022e
        0x7f03022f
        0x7f030233
    .end array-data

    :array_25
    .array-data 4
        0x1010107
        0x7f030083
        0x7f030085
        0x7f030087
        0x7f030088
        0x7f03008c
        0x7f030096
        0x7f0300a5
        0x7f03018a
        0x7f030191
        0x7f030458
    .end array-data

    :array_26
    .array-data 4
        0x7f03008c
        0x7f030458
    .end array-data

    :array_27
    .array-data 4
        0x7f030364
        0x7f03036c
    .end array-data

    :array_28
    .array-data 4
        0x10104b6
        0x101057f
        0x7f030284
    .end array-data

    :array_29
    .array-data 4
        0x1010034
        0x101057f
        0x7f030284
    .end array-data

    :array_2a
    .array-data 4
        0x7f030297
        0x7f030299
        0x7f03030c
        0x7f0303ac
        0x7f030426
    .end array-data

    :array_2b
    .array-data 4
        0x7f03012d
        0x7f03012e
        0x7f03012f
        0x7f030130
        0x7f030131
        0x7f030133
        0x7f030134
        0x7f030135
        0x7f030136
        0x7f030137
    .end array-data

    :array_2c
    .array-data 4
        0x101011f
        0x1010120
        0x1010440
        0x7f030049
        0x7f030060
        0x7f03012c
        0x7f030364
        0x7f03036c
    .end array-data

    :array_2d
    .array-data 4
        0x101011f
        0x7f030022
        0x7f030031
        0x7f030046
        0x7f030049
        0x7f03004a
        0x7f030179
        0x7f0302cc
        0x7f030364
        0x7f03036c
    .end array-data

    :array_2e
    .array-data 4
        0x7f0303b8
        0x7f0303b9
        0x7f0303ba
        0x7f0303bb
        0x7f0303bc
        0x7f0303bd
        0x7f0303be
        0x7f0303bf
        0x7f0303c0
        0x7f0303c1
        0x7f0303c2
        0x7f0303c3
        0x7f0303c4
        0x7f0303c5
        0x7f0303c6
        0x7f0303c7
        0x7f0303c8
        0x7f0303c9
        0x7f0303ca
        0x7f0303cb
        0x7f0303cc
        0x7f0303cd
        0x7f0303cf
        0x7f0303d0
        0x7f0303d2
        0x7f0303d3
        0x7f0303d4
    .end array-data

    :array_2f
    .array-data 4
        0x1010095
        0x1010096
        0x1010097
        0x1010098
        0x101009a
        0x101009b
        0x1010161
        0x1010162
        0x1010163
        0x1010164
        0x10103ac
        0x1010585
        0x7f0301d9
        0x7f0301e2
        0x7f0303d9
        0x7f03040a
    .end array-data

    :array_30
    .array-data 4
        0x101000e
        0x101009a
        0x101011f
        0x101013f
        0x1010150
        0x1010157
        0x101015a
        0x7f030072
        0x7f030073
        0x7f030074
        0x7f030075
        0x7f030076
        0x7f030077
        0x7f030078
        0x7f030079
        0x7f03007a
        0x7f03007b
        0x7f03007c
        0x7f030138
        0x7f030139
        0x7f03013a
        0x7f03013b
        0x7f03013c
        0x7f03013d
        0x7f03017f
        0x7f030180
        0x7f030181
        0x7f030182
        0x7f030183
        0x7f030184
        0x7f030185
        0x7f030186
        0x7f03018b
        0x7f03018c
        0x7f03018d
        0x7f03018e
        0x7f03018f
        0x7f030190
        0x7f030192
        0x7f030193
        0x7f030196
        0x7f0301ef
        0x7f0301f0
        0x7f0301f1
        0x7f0301f2
        0x7f0301f8
        0x7f0301f9
        0x7f0301fa
        0x7f0301fb
        0x7f030329
        0x7f03032a
        0x7f03032b
        0x7f03032c
        0x7f03032d
        0x7f030336
        0x7f030337
        0x7f030338
        0x7f03033e
        0x7f03033f
        0x7f030340
        0x7f030364
        0x7f03036c
        0x7f030390
        0x7f030391
        0x7f030392
        0x7f030393
        0x7f030394
        0x7f030395
        0x7f030396
        0x7f0303b0
        0x7f0303b1
        0x7f0303b2
    .end array-data

    :array_31
    .array-data 4
        0x1010034
        0x7f030187
        0x7f030188
    .end array-data

    :array_32
    .array-data 4
        0x1010003
        0x10100d0
        0x10100d1
    .end array-data

    :array_33
    .array-data 4
        0x1010003
        0x10100d1
    .end array-data

    :array_34
    .array-data 4
        0x10100c4
        0x10100d0
        0x10100dc
        0x10100f4
        0x10100f5
        0x10100f7
        0x10100f8
        0x10100f9
        0x10100fa
        0x101011f
        0x1010120
        0x101013f
        0x1010140
        0x101031f
        0x1010320
        0x1010321
        0x1010322
        0x1010323
        0x1010324
        0x1010325
        0x1010326
        0x1010327
        0x1010328
        0x10103b5
        0x10103b6
        0x10103fa
        0x1010440
        0x7f030030
        0x7f03005b
        0x7f03005c
        0x7f03005d
        0x7f030097
        0x7f030117
        0x7f030165
        0x7f0301c5
        0x7f0301c6
        0x7f0301c7
        0x7f0301c8
        0x7f0301c9
        0x7f0301ca
        0x7f0301cb
        0x7f0301cc
        0x7f0301cd
        0x7f0301ce
        0x7f0301cf
        0x7f0301d0
        0x7f0301d1
        0x7f0301d3
        0x7f0301d4
        0x7f0301d5
        0x7f0301d6
        0x7f0301d7
        0x7f030247
        0x7f030248
        0x7f030249
        0x7f03024a
        0x7f03024b
        0x7f03024c
        0x7f03024d
        0x7f03024e
        0x7f03024f
        0x7f030250
        0x7f030251
        0x7f030252
        0x7f030253
        0x7f030254
        0x7f030255
        0x7f030256
        0x7f030257
        0x7f030258
        0x7f030259
        0x7f03025a
        0x7f03025b
        0x7f03025c
        0x7f03025d
        0x7f03025e
        0x7f03025f
        0x7f030260
        0x7f030261
        0x7f030262
        0x7f030263
        0x7f030264
        0x7f030265
        0x7f030266
        0x7f030267
        0x7f030268
        0x7f030269
        0x7f03026a
        0x7f03026b
        0x7f03026c
        0x7f03026d
        0x7f03026e
        0x7f03026f
        0x7f030270
        0x7f030272
        0x7f030273
        0x7f030274
        0x7f030275
        0x7f030276
        0x7f030277
        0x7f030278
        0x7f030279
        0x7f030303
        0x7f030304
        0x7f03032e
        0x7f030335
        0x7f03044e
        0x7f030450
        0x7f03045d
    .end array-data

    :array_35
    .array-data 4
        0x10100c4
        0x10100d5
        0x10100d6
        0x10100d7
        0x10100d8
        0x10100d9
        0x10100dc
        0x101011f
        0x1010120
        0x101013f
        0x1010140
        0x10103b3
        0x10103b4
        0x1010440
        0x7f03005b
        0x7f03005c
        0x7f03005d
        0x7f030097
        0x7f030114
        0x7f030117
        0x7f0301c5
        0x7f0301c6
        0x7f0301c7
        0x7f0301c8
        0x7f0301c9
        0x7f0301ca
        0x7f0301cb
        0x7f0301cc
        0x7f0301cd
        0x7f0301ce
        0x7f0301cf
        0x7f0301d0
        0x7f0301d1
        0x7f0301d3
        0x7f0301d4
        0x7f0301d5
        0x7f0301d6
        0x7f0301d7
        0x7f03023f
        0x7f030247
        0x7f030248
        0x7f030249
        0x7f03024a
        0x7f03024b
        0x7f03024c
        0x7f03024d
        0x7f03024e
        0x7f03024f
        0x7f030250
        0x7f030251
        0x7f030252
        0x7f030253
        0x7f030254
        0x7f030255
        0x7f030256
        0x7f030257
        0x7f030258
        0x7f030259
        0x7f03025a
        0x7f03025b
        0x7f03025c
        0x7f03025d
        0x7f03025e
        0x7f03025f
        0x7f030260
        0x7f030261
        0x7f030262
        0x7f030263
        0x7f030264
        0x7f030265
        0x7f030266
        0x7f030267
        0x7f030268
        0x7f030269
        0x7f03026a
        0x7f03026b
        0x7f03026c
        0x7f03026d
        0x7f03026e
        0x7f03026f
        0x7f030270
        0x7f030272
        0x7f030273
        0x7f030274
        0x7f030275
        0x7f030276
        0x7f030277
        0x7f030278
        0x7f030279
        0x7f03027c
    .end array-data

    :array_36
    .array-data 4
        0x10100c4
        0x10100d0
        0x10100dc
        0x10100f4
        0x10100f5
        0x10100f7
        0x10100f8
        0x10100f9
        0x10100fa
        0x101011f
        0x1010120
        0x101013f
        0x1010140
        0x10101b5
        0x10101b6
        0x101031f
        0x1010320
        0x1010321
        0x1010322
        0x1010323
        0x1010324
        0x1010325
        0x1010326
        0x1010327
        0x1010328
        0x10103b5
        0x10103b6
        0x10103fa
        0x1010440
        0x7f030030
        0x7f03005b
        0x7f03005c
        0x7f03005d
        0x7f030097
        0x7f030117
        0x7f030155
        0x7f030165
        0x7f0301c5
        0x7f0301c6
        0x7f0301c7
        0x7f0301c8
        0x7f0301c9
        0x7f0301ca
        0x7f0301cb
        0x7f0301cc
        0x7f0301cd
        0x7f0301ce
        0x7f0301cf
        0x7f0301d0
        0x7f0301d1
        0x7f0301d3
        0x7f0301d4
        0x7f0301d5
        0x7f0301d6
        0x7f0301d7
        0x7f030247
        0x7f030248
        0x7f030249
        0x7f03024a
        0x7f03024b
        0x7f03024c
        0x7f03024d
        0x7f03024e
        0x7f03024f
        0x7f030250
        0x7f030251
        0x7f030252
        0x7f030253
        0x7f030254
        0x7f030255
        0x7f030256
        0x7f030257
        0x7f030258
        0x7f030259
        0x7f03025a
        0x7f03025b
        0x7f03025c
        0x7f03025d
        0x7f03025e
        0x7f03025f
        0x7f030260
        0x7f030261
        0x7f030262
        0x7f030263
        0x7f030264
        0x7f030265
        0x7f030266
        0x7f030267
        0x7f030268
        0x7f030269
        0x7f03026a
        0x7f03026b
        0x7f03026c
        0x7f03026d
        0x7f03026e
        0x7f03026f
        0x7f030270
        0x7f030272
        0x7f030273
        0x7f030274
        0x7f030275
        0x7f030276
        0x7f030277
        0x7f030278
        0x7f030279
        0x7f030303
        0x7f030304
        0x7f03032e
        0x7f030335
        0x7f03044e
        0x7f030450
    .end array-data

    :array_37
    .array-data 4
        0x7f030037
        0x7f030141
        0x7f030142
        0x7f030143
        0x7f030144
        0x7f030145
        0x7f030146
        0x7f030148
        0x7f030149
    .end array-data

    :array_38
    .array-data 4
        0x10100c4
        0x10100f4
        0x10100f5
        0x10100f7
        0x10100f8
        0x10100f9
        0x10100fa
        0x10103b5
        0x10103b6
        0x7f03005b
        0x7f03005c
        0x7f03005d
        0x7f030097
        0x7f030117
        0x7f030247
        0x7f030248
        0x7f030249
        0x7f03024a
        0x7f03024b
        0x7f03024c
        0x7f03024d
        0x7f03024e
        0x7f03024f
        0x7f030250
        0x7f030251
        0x7f030252
        0x7f030253
        0x7f030254
        0x7f030255
        0x7f030256
        0x7f030257
        0x7f030258
        0x7f030259
        0x7f03025a
        0x7f03025b
        0x7f03025c
        0x7f03025d
        0x7f03025e
        0x7f03025f
        0x7f030260
        0x7f030261
        0x7f030262
        0x7f030263
        0x7f030264
        0x7f030265
        0x7f030267
        0x7f030268
        0x7f030269
        0x7f03026a
        0x7f03026b
        0x7f03026c
        0x7f03026d
        0x7f03026e
        0x7f03026f
        0x7f030270
        0x7f030272
        0x7f030273
        0x7f030274
        0x7f030275
        0x7f030276
        0x7f030277
        0x7f030278
        0x7f030279
        0x7f0302cf
        0x7f0302d3
        0x7f0302d8
        0x7f0302dc
    .end array-data

    :array_39
    .array-data 4
        0x7f030030
        0x7f030165
        0x7f030302
        0x7f030304
        0x7f03032e
        0x7f03044e
    .end array-data

    :array_3a
    .array-data 4
        0x10100dc
        0x101031f
        0x7f030266
        0x7f030303
        0x7f03045d
    .end array-data

    :array_3b
    .array-data 4
        0x10100d0
        0x7f030118
    .end array-data

    :array_3c
    .array-data 4
        0x1010320
        0x1010321
        0x1010322
        0x1010323
        0x1010324
        0x1010325
        0x1010326
        0x1010327
        0x1010328
        0x10103fa
        0x1010440
    .end array-data

    :array_3d
    .array-data 4
        0x7f030118
        0x7f03034e
        0x7f03034f
        0x7f030350
        0x7f030351
    .end array-data

    :array_3e
    .array-data 4
        0x7f030237
        0x7f0303a0
    .end array-data

    :array_3f
    .array-data 4
        0x10100b3
        0x7f030242
        0x7f030243
        0x7f030244
        0x7f030271
        0x7f03027a
        0x7f03027b
    .end array-data

    :array_40
    .array-data 4
        0x10100c4
        0x10100eb
        0x10100f1
        0x7f0301b0
        0x7f0301b1
        0x7f0301b2
        0x7f0301b3
        0x7f0301b4
        0x7f030241
        0x7f030353
        0x7f030388
        0x7f03038e
    .end array-data

    :array_41
    .array-data 4
        0x10101a5
        0x101031f
        0x1010647
        0x7f03002b
        0x7f030238
    .end array-data

    :array_42
    .array-data 4
        0x7f0301da
        0x7f0301db
        0x7f0301dc
        0x7f0301dd
        0x7f0301de
        0x7f0301df
        0x7f0301e0
    .end array-data

    :array_43
    .array-data 4
        0x1010532
        0x1010533
        0x101053f
        0x101056f
        0x1010570
        0x7f0301d8
        0x7f0301e1
        0x7f0301e2
        0x7f0301e3
        0x7f030455
    .end array-data

    :array_44
    .array-data 4
        0x101019d
        0x101019e
        0x10101a1
        0x10101a2
        0x10101a3
        0x10101a4
        0x1010201
        0x101020b
        0x1010510
        0x1010511
        0x1010512
        0x1010513
    .end array-data

    :array_45
    .array-data 4
        0x10101a5
        0x1010514
    .end array-data

    :array_46
    .array-data 4
        0x3ecd759f
        0x3f2671bd
        -0x42ad373b    # -0.051461f
    .end array-data

    :array_47
    .array-data 4
        -0x417fdcdf
        0x3f9a2a3d
        0x3d3bd167
    .end array-data

    :array_48
    .array-data 4
        -0x44f7c02b    # -0.002079f
        0x3d4881e4
        0x3f740022
    .end array-data

    :array_49
    .array-data 4
        0x3fee583d
        -0x407e8f35
        0x3e18c46b
    .end array-data

    :array_4a
    .array-data 4
        0x3ec669e1
        0x3f1f172e
        -0x43ecf866
    .end array-data

    :array_4b
    .array-data 4
        -0x437e39f7
        -0x42f43b81
        0x3f86653c
    .end array-data

    :array_4c
    .array-data 4
        0x42be1810
        0x42c80000    # 100.0f
        0x42d9c419
    .end array-data

    :array_4d
    .array-data 4
        0x3ed31e17
        0x3eb71a0d
        0x3e38d7b9
    .end array-data

    :array_4e
    .array-data 4
        0x3e59b3d0    # 0.2126f
        0x3f371759    # 0.7152f
        0x3d93dd98    # 0.0722f
    .end array-data

    :array_4f
    .array-data 4
        0x3c9e47ef
        0x3df40c29
        0x3f7349cc
    .end array-data
.end method

.method public synthetic constructor <init>()V
    .locals 0

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method

.method public synthetic constructor <init>(I)V
    .locals 0

    .line 2
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method

.method public synthetic constructor <init>(Landroid/widget/TextView;)V
    .locals 0

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 3
    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    return-void
.end method

.method public static A(FII)I
    .locals 1

    invoke-static {p2}, Landroid/graphics/Color;->alpha(I)I

    move-result v0

    int-to-float v0, v0

    mul-float/2addr v0, p0

    invoke-static {v0}, Ljava/lang/Math;->round(F)I

    move-result p0

    invoke-static {p2, p0}, Lx/a;->c(II)I

    move-result p0

    invoke-static {p0, p1}, Lx/a;->b(II)I

    move-result p0

    return p0
.end method

.method public static B(I)F
    .locals 6

    int-to-float p0, p0

    const/high16 v0, 0x437f0000    # 255.0f

    div-float/2addr p0, v0

    const v0, 0x3d25aee6    # 0.04045f

    cmpg-float v0, p0, v0

    const/high16 v1, 0x42c80000    # 100.0f

    if-gtz v0, :cond_0

    const v0, 0x414eb852    # 12.92f

    div-float/2addr p0, v0

    :goto_0
    mul-float/2addr p0, v1

    return p0

    :cond_0
    const v0, 0x3d6147ae    # 0.055f

    add-float/2addr p0, v0

    const v0, 0x3f870a3d    # 1.055f

    div-float/2addr p0, v0

    float-to-double v2, p0

    const-wide v4, 0x4003333340000000L    # 2.4000000953674316

    invoke-static {v2, v3, v4, v5}, Ljava/lang/Math;->pow(DD)D

    move-result-wide v2

    double-to-float p0, v2

    goto :goto_0
.end method

.method public static final C(I)I
    .locals 1

    if-gez p0, :cond_0

    goto :goto_0

    :cond_0
    const/4 v0, 0x3

    if-ge p0, v0, :cond_1

    add-int/lit8 p0, p0, 0x1

    goto :goto_0

    :cond_1
    const/high16 v0, 0x40000000    # 2.0f

    if-ge p0, v0, :cond_2

    int-to-float p0, p0

    const/high16 v0, 0x3f400000    # 0.75f

    div-float/2addr p0, v0

    const/high16 v0, 0x3f800000    # 1.0f

    add-float/2addr p0, v0

    float-to-int p0, p0

    goto :goto_0

    :cond_2
    const p0, 0x7fffffff

    :goto_0
    return p0
.end method

.method public static D(Landroid/view/View;Landroid/view/inputmethod/EditorInfo;Landroid/view/inputmethod/InputConnection;)V
    .locals 0

    if-eqz p2, :cond_1

    iget-object p2, p1, Landroid/view/inputmethod/EditorInfo;->hintText:Ljava/lang/CharSequence;

    if-nez p2, :cond_1

    invoke-virtual {p0}, Landroid/view/View;->getParent()Landroid/view/ViewParent;

    move-result-object p0

    :goto_0
    instance-of p2, p0, Landroid/view/View;

    if-eqz p2, :cond_1

    instance-of p2, p0, Landroidx/appcompat/widget/i1;

    if-eqz p2, :cond_0

    check-cast p0, Landroidx/appcompat/widget/i1;

    invoke-interface {p0}, Landroidx/appcompat/widget/i1;->a()Ljava/lang/CharSequence;

    move-result-object p0

    iput-object p0, p1, Landroid/view/inputmethod/EditorInfo;->hintText:Ljava/lang/CharSequence;

    goto :goto_1

    :cond_0
    invoke-interface {p0}, Landroid/view/ViewParent;->getParent()Landroid/view/ViewParent;

    move-result-object p0

    goto :goto_0

    :cond_1
    :goto_1
    return-void
.end method

.method public static E(Ljava/lang/String;)Ljava/math/BigDecimal;
    .locals 5

    invoke-static {p0}, La1/a;->m(Ljava/lang/String;)V

    new-instance v0, Ljava/math/BigDecimal;

    invoke-direct {v0, p0}, Ljava/math/BigDecimal;-><init>(Ljava/lang/String;)V

    invoke-virtual {v0}, Ljava/math/BigDecimal;->scale()I

    move-result v1

    int-to-long v1, v1

    invoke-static {v1, v2}, Ljava/lang/Math;->abs(J)J

    move-result-wide v1

    const-wide/16 v3, 0x2710

    cmp-long v1, v1, v3

    if-gez v1, :cond_0

    return-object v0

    :cond_0
    new-instance v0, Ljava/lang/NumberFormatException;

    const-string v1, "Number has unsupported scale: "

    invoke-virtual {v1, p0}, Ljava/lang/String;->concat(Ljava/lang/String;)Ljava/lang/String;

    move-result-object p0

    invoke-direct {v0, p0}, Ljava/lang/NumberFormatException;-><init>(Ljava/lang/String;)V

    throw v0
.end method

.method public static F(Landroid/animation/AnimatorSet;Ljava/util/ArrayList;)V
    .locals 10

    invoke-virtual {p1}, Ljava/util/ArrayList;->size()I

    move-result v0

    const-wide/16 v1, 0x0

    const/4 v3, 0x0

    move v4, v3

    :goto_0
    if-ge v4, v0, :cond_0

    invoke-virtual {p1, v4}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v5

    check-cast v5, Landroid/animation/Animator;

    invoke-virtual {v5}, Landroid/animation/Animator;->getStartDelay()J

    move-result-wide v6

    invoke-virtual {v5}, Landroid/animation/Animator;->getDuration()J

    move-result-wide v8

    add-long/2addr v8, v6

    invoke-static {v1, v2, v8, v9}, Ljava/lang/Math;->max(JJ)J

    move-result-wide v1

    add-int/lit8 v4, v4, 0x1

    goto :goto_0

    :cond_0
    const/4 v0, 0x2

    new-array v0, v0, [I

    fill-array-data v0, :array_0

    invoke-static {v0}, Landroid/animation/ValueAnimator;->ofInt([I)Landroid/animation/ValueAnimator;

    move-result-object v0

    invoke-virtual {v0, v1, v2}, Landroid/animation/Animator;->setDuration(J)Landroid/animation/Animator;

    invoke-virtual {p1, v3, v0}, Ljava/util/ArrayList;->add(ILjava/lang/Object;)V

    invoke-virtual {p0, p1}, Landroid/animation/AnimatorSet;->playTogether(Ljava/util/Collection;)V

    return-void

    :array_0
    .array-data 4
        0x0
        0x0
    .end array-data
.end method

.method public static G(ILjava/lang/CharSequence;)I
    .locals 7

    invoke-interface {p1}, Ljava/lang/CharSequence;->length()I

    move-result v0

    const/4 v1, -0x1

    if-lt p0, v0, :cond_0

    return v1

    :cond_0
    invoke-interface {p1, p0}, Ljava/lang/CharSequence;->charAt(I)C

    move-result v0

    const/16 v2, 0x5c

    const/16 v3, 0x3c

    if-ne v0, v3, :cond_5

    :cond_1
    :goto_0
    add-int/lit8 p0, p0, 0x1

    invoke-interface {p1}, Ljava/lang/CharSequence;->length()I

    move-result v0

    if-ge p0, v0, :cond_4

    invoke-interface {p1, p0}, Ljava/lang/CharSequence;->charAt(I)C

    move-result v0

    const/16 v4, 0xa

    if-eq v0, v4, :cond_4

    if-eq v0, v3, :cond_4

    const/16 v4, 0x3e

    if-eq v0, v4, :cond_3

    if-eq v0, v2, :cond_2

    goto :goto_0

    :cond_2
    add-int/lit8 v0, p0, 0x1

    invoke-static {v0, p1}, Lw0/u;->a(ILjava/lang/CharSequence;)Z

    move-result v4

    if-eqz v4, :cond_1

    move p0, v0

    goto :goto_0

    :cond_3
    add-int/lit8 p0, p0, 0x1

    return p0

    :cond_4
    return v1

    :cond_5
    const/4 v0, 0x0

    move v3, p0

    :goto_1
    invoke-interface {p1}, Ljava/lang/CharSequence;->length()I

    move-result v4

    if-ge v3, v4, :cond_c

    invoke-interface {p1, v3}, Ljava/lang/CharSequence;->charAt(I)C

    move-result v4

    if-eqz v4, :cond_b

    const/16 v5, 0x20

    if-eq v4, v5, :cond_b

    if-eq v4, v2, :cond_9

    const/16 v6, 0x28

    if-eq v4, v6, :cond_8

    const/16 v5, 0x29

    if-eq v4, v5, :cond_6

    invoke-static {v4}, Ljava/lang/Character;->isISOControl(C)Z

    move-result v4

    if-eqz v4, :cond_a

    if-eq v3, p0, :cond_d

    :goto_2
    move v1, v3

    goto :goto_4

    :cond_6
    if-nez v0, :cond_7

    goto :goto_2

    :cond_7
    add-int/lit8 v0, v0, -0x1

    goto :goto_3

    :cond_8
    add-int/lit8 v0, v0, 0x1

    if-le v0, v5, :cond_a

    goto :goto_4

    :cond_9
    add-int/lit8 v4, v3, 0x1

    invoke-static {v4, p1}, Lw0/u;->a(ILjava/lang/CharSequence;)Z

    move-result v5

    if-eqz v5, :cond_a

    move v3, v4

    :cond_a
    :goto_3
    add-int/lit8 v3, v3, 0x1

    goto :goto_1

    :cond_b
    if-eq v3, p0, :cond_d

    goto :goto_2

    :cond_c
    invoke-interface {p1}, Ljava/lang/CharSequence;->length()I

    move-result v1

    :cond_d
    :goto_4
    return v1
.end method

.method public static H(ILjava/lang/CharSequence;)I
    .locals 2

    :goto_0
    invoke-interface {p1}, Ljava/lang/CharSequence;->length()I

    move-result v0

    if-ge p0, v0, :cond_1

    invoke-interface {p1, p0}, Ljava/lang/CharSequence;->charAt(I)C

    move-result v0

    packed-switch v0, :pswitch_data_0

    goto :goto_1

    :pswitch_0
    return p0

    :pswitch_1
    add-int/lit8 v0, p0, 0x1

    invoke-static {v0, p1}, Lw0/u;->a(ILjava/lang/CharSequence;)Z

    move-result v1

    if-eqz v1, :cond_0

    move p0, v0

    goto :goto_1

    :pswitch_2
    const/4 p0, -0x1

    return p0

    :cond_0
    :goto_1
    add-int/lit8 p0, p0, 0x1

    goto :goto_0

    :cond_1
    invoke-interface {p1}, Ljava/lang/CharSequence;->length()I

    move-result p0

    return p0

    nop

    :pswitch_data_0
    .packed-switch 0x5b
        :pswitch_2
        :pswitch_1
        :pswitch_0
    .end packed-switch
.end method

.method public static I(CILjava/lang/CharSequence;)I
    .locals 3

    :goto_0
    invoke-interface {p2}, Ljava/lang/CharSequence;->length()I

    move-result v0

    if-ge p1, v0, :cond_3

    invoke-interface {p2, p1}, Ljava/lang/CharSequence;->charAt(I)C

    move-result v0

    const/16 v1, 0x5c

    if-ne v0, v1, :cond_0

    add-int/lit8 v1, p1, 0x1

    invoke-static {v1, p2}, Lw0/u;->a(ILjava/lang/CharSequence;)Z

    move-result v2

    if-eqz v2, :cond_0

    move p1, v1

    goto :goto_1

    :cond_0
    if-ne v0, p0, :cond_1

    return p1

    :cond_1
    const/16 v1, 0x29

    if-ne p0, v1, :cond_2

    const/16 v1, 0x28

    if-ne v0, v1, :cond_2

    const/4 p0, -0x1

    return p0

    :cond_2
    :goto_1
    add-int/lit8 p1, p1, 0x1

    goto :goto_0

    :cond_3
    invoke-interface {p2}, Ljava/lang/CharSequence;->length()I

    move-result p0

    return p0
.end method

.method public static J(Landroid/view/View;)V
    .locals 2

    invoke-virtual {p0}, Landroid/view/View;->getBackground()Landroid/graphics/drawable/Drawable;

    move-result-object v0

    instance-of v1, v0, Lb2/f;

    if-eqz v1, :cond_0

    check-cast v0, Lb2/f;

    invoke-static {p0, v0}, La1/a;->K(Landroid/view/View;Lb2/f;)V

    :cond_0
    return-void
.end method

.method public static K(Landroid/view/View;Lb2/f;)V
    .locals 3

    iget-object v0, p1, Lb2/f;->b:Lb2/f$b;

    iget-object v0, v0, Lb2/f$b;->b:Lr1/a;

    if-eqz v0, :cond_0

    iget-boolean v0, v0, Lr1/a;->a:Z

    if-eqz v0, :cond_0

    const/4 v0, 0x1

    goto :goto_0

    :cond_0
    const/4 v0, 0x0

    :goto_0
    if-eqz v0, :cond_2

    invoke-virtual {p0}, Landroid/view/View;->getParent()Landroid/view/ViewParent;

    move-result-object p0

    const/4 v0, 0x0

    :goto_1
    instance-of v1, p0, Landroid/view/View;

    if-eqz v1, :cond_1

    move-object v1, p0

    check-cast v1, Landroid/view/View;

    sget-object v2, Le0/a0;->a:Ljava/util/WeakHashMap;

    invoke-static {v1}, Le0/a0$i;->i(Landroid/view/View;)F

    move-result v1

    add-float/2addr v0, v1

    invoke-interface {p0}, Landroid/view/ViewParent;->getParent()Landroid/view/ViewParent;

    move-result-object p0

    goto :goto_1

    :cond_1
    iget-object p0, p1, Lb2/f;->b:Lb2/f$b;

    iget v1, p0, Lb2/f$b;->m:F

    cmpl-float v1, v1, v0

    if-eqz v1, :cond_2

    iput v0, p0, Lb2/f$b;->m:F

    invoke-virtual {p1}, Lb2/f;->n()V

    :cond_2
    return-void
.end method

.method public static final L(Ljava/lang/String;JJJ)J
    .locals 23

    move-object/from16 v0, p0

    move-wide/from16 v1, p3

    move-wide/from16 v3, p5

    sget v5, Lt3/h;->a:I

    :try_start_0
    invoke-static/range {p0 .. p0}, Ljava/lang/System;->getProperty(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v6
    :try_end_0
    .catch Ljava/lang/SecurityException; {:try_start_0 .. :try_end_0} :catch_0

    goto :goto_0

    :catch_0
    const/4 v6, 0x0

    :goto_0
    if-nez v6, :cond_0

    move-wide/from16 v8, p1

    goto/16 :goto_a

    :cond_0
    new-instance v7, Lm3/c;

    const/4 v8, 0x2

    const/16 v9, 0x24

    invoke-direct {v7, v8, v9}, Lm3/c;-><init>(II)V

    const/4 v10, 0x0

    const/4 v11, 0x1

    iget v7, v7, Lm3/a;->c:I

    const/16 v12, 0xa

    if-gt v12, v7, :cond_1

    move v7, v11

    goto :goto_1

    :cond_1
    move v7, v10

    :goto_1
    if-eqz v7, :cond_12

    invoke-virtual {v6}, Ljava/lang/String;->length()I

    move-result v7

    if-nez v7, :cond_3

    :cond_2
    :goto_2
    move-object/from16 v19, v6

    goto/16 :goto_7

    :cond_3
    invoke-virtual {v6, v10}, Ljava/lang/String;->charAt(I)C

    move-result v8

    const/16 v9, 0x30

    if-ge v8, v9, :cond_4

    const/4 v9, -0x1

    goto :goto_3

    :cond_4
    if-ne v8, v9, :cond_5

    move v9, v10

    goto :goto_3

    :cond_5
    move v9, v11

    :goto_3
    const-wide v13, -0x7fffffffffffffffL    # -4.9E-324

    if-gez v9, :cond_8

    if-ne v7, v11, :cond_6

    goto :goto_2

    :cond_6
    const/16 v9, 0x2d

    if-ne v8, v9, :cond_7

    const-wide/high16 v13, -0x8000000000000000L

    move v8, v11

    goto :goto_4

    :cond_7
    const/16 v9, 0x2b

    if-ne v8, v9, :cond_2

    move v9, v10

    move v8, v11

    goto :goto_5

    :cond_8
    move v8, v10

    :goto_4
    move v9, v8

    :goto_5
    const-wide v15, -0x38e38e38e38e38eL    # -2.772000429909333E291

    const-wide/16 v17, 0x0

    move-wide/from16 v10, v17

    move-wide/from16 v17, v15

    :goto_6
    if-ge v8, v7, :cond_d

    invoke-virtual {v6, v8}, Ljava/lang/String;->charAt(I)C

    move-result v5

    invoke-static {v5, v12}, Ljava/lang/Character;->digit(II)I

    move-result v5

    if-gez v5, :cond_9

    goto :goto_2

    :cond_9
    cmp-long v19, v10, v17

    if-gez v19, :cond_a

    cmp-long v17, v17, v15

    if-nez v17, :cond_2

    move-object/from16 v19, v6

    move/from16 v20, v7

    int-to-long v6, v12

    div-long v17, v13, v6

    cmp-long v6, v10, v17

    if-gez v6, :cond_b

    goto :goto_7

    :cond_a
    move-object/from16 v19, v6

    move/from16 v20, v7

    :cond_b
    int-to-long v6, v12

    mul-long/2addr v10, v6

    int-to-long v5, v5

    add-long v21, v13, v5

    cmp-long v7, v10, v21

    if-gez v7, :cond_c

    :goto_7
    const/4 v5, 0x0

    goto :goto_8

    :cond_c
    sub-long/2addr v10, v5

    add-int/lit8 v8, v8, 0x1

    move-object/from16 v6, v19

    move/from16 v7, v20

    goto :goto_6

    :cond_d
    move-object/from16 v19, v6

    if-eqz v9, :cond_e

    invoke-static {v10, v11}, Ljava/lang/Long;->valueOf(J)Ljava/lang/Long;

    move-result-object v5

    goto :goto_8

    :cond_e
    neg-long v5, v10

    invoke-static {v5, v6}, Ljava/lang/Long;->valueOf(J)Ljava/lang/Long;

    move-result-object v5

    :goto_8
    const/16 v6, 0x27

    const-string v7, "System property \'"

    if-eqz v5, :cond_11

    invoke-virtual {v5}, Ljava/lang/Long;->longValue()J

    move-result-wide v8

    cmp-long v5, v1, v8

    if-gtz v5, :cond_f

    cmp-long v5, v8, v3

    if-gtz v5, :cond_f

    const/4 v10, 0x1

    goto :goto_9

    :cond_f
    const/4 v10, 0x0

    :goto_9
    if-eqz v10, :cond_10

    :goto_a
    return-wide v8

    :cond_10
    new-instance v5, Ljava/lang/IllegalStateException;

    new-instance v10, Ljava/lang/StringBuilder;

    invoke-direct {v10, v7}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-virtual {v10, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string v0, "\' should be in range "

    invoke-virtual {v10, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v10, v1, v2}, Ljava/lang/StringBuilder;->append(J)Ljava/lang/StringBuilder;

    const-string v0, ".."

    invoke-virtual {v10, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v10, v3, v4}, Ljava/lang/StringBuilder;->append(J)Ljava/lang/StringBuilder;

    const-string v0, ", but is \'"

    invoke-virtual {v10, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v10, v8, v9}, Ljava/lang/StringBuilder;->append(J)Ljava/lang/StringBuilder;

    invoke-virtual {v10, v6}, Ljava/lang/StringBuilder;->append(C)Ljava/lang/StringBuilder;

    invoke-virtual {v10}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/Object;->toString()Ljava/lang/String;

    move-result-object v0

    invoke-direct {v5, v0}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    throw v5

    :cond_11
    new-instance v1, Ljava/lang/IllegalStateException;

    new-instance v2, Ljava/lang/StringBuilder;

    invoke-direct {v2, v7}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-virtual {v2, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string v0, "\' has unrecognized value \'"

    invoke-virtual {v2, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-object/from16 v5, v19

    invoke-virtual {v2, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v2, v6}, Ljava/lang/StringBuilder;->append(C)Ljava/lang/StringBuilder;

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/Object;->toString()Ljava/lang/String;

    move-result-object v0

    invoke-direct {v1, v0}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    throw v1

    :cond_12
    new-instance v0, Ljava/lang/IllegalArgumentException;

    new-instance v1, Ljava/lang/StringBuilder;

    const-string v2, "radix 10 was not in valid range "

    invoke-direct {v1, v2}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    new-instance v2, Lm3/c;

    invoke-direct {v2, v8, v9}, Lm3/c;-><init>(II)V

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    invoke-direct {v0, v1}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    throw v0
.end method

.method public static M(Ljava/lang/String;IIII)I
    .locals 7

    and-int/lit8 v0, p4, 0x4

    if-eqz v0, :cond_0

    const/4 p2, 0x1

    :cond_0
    and-int/lit8 p4, p4, 0x8

    if-eqz p4, :cond_1

    const p3, 0x7fffffff

    :cond_1
    int-to-long v1, p1

    int-to-long v3, p2

    int-to-long v5, p3

    move-object v0, p0

    invoke-static/range {v0 .. v6}, La1/a;->L(Ljava/lang/String;JJJ)J

    move-result-wide p0

    long-to-int p0, p0

    return p0
.end method

.method public static final N(Ljava/util/Collection;)[Ljava/lang/Object;
    .locals 5

    const-string v0, "collection"

    invoke-static {v0, p0}, Lj3/c;->d(Ljava/lang/String;Ljava/lang/Object;)V

    invoke-interface {p0}, Ljava/util/Collection;->size()I

    move-result v0

    sget-object v1, La1/a;->j0:[Ljava/lang/Object;

    if-nez v0, :cond_0

    goto :goto_2

    :cond_0
    invoke-interface {p0}, Ljava/util/Collection;->iterator()Ljava/util/Iterator;

    move-result-object p0

    invoke-interface {p0}, Ljava/util/Iterator;->hasNext()Z

    move-result v2

    if-nez v2, :cond_1

    goto :goto_2

    :cond_1
    new-array v0, v0, [Ljava/lang/Object;

    const/4 v1, 0x0

    move v4, v1

    move-object v1, v0

    move v0, v4

    :goto_0
    add-int/lit8 v2, v0, 0x1

    invoke-interface {p0}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v3

    aput-object v3, v1, v0

    array-length v0, v1

    if-lt v2, v0, :cond_5

    invoke-interface {p0}, Ljava/util/Iterator;->hasNext()Z

    move-result v0

    if-nez v0, :cond_2

    goto :goto_2

    :cond_2
    mul-int/lit8 v0, v2, 0x3

    add-int/lit8 v0, v0, 0x1

    ushr-int/lit8 v0, v0, 0x1

    if-gt v0, v2, :cond_4

    const v0, 0x7ffffffd

    if-ge v2, v0, :cond_3

    goto :goto_1

    :cond_3
    new-instance p0, Ljava/lang/OutOfMemoryError;

    invoke-direct {p0}, Ljava/lang/OutOfMemoryError;-><init>()V

    throw p0

    :cond_4
    :goto_1
    invoke-static {v1, v0}, Ljava/util/Arrays;->copyOf([Ljava/lang/Object;I)[Ljava/lang/Object;

    move-result-object v1

    const-string v0, "copyOf(result, newSize)"

    invoke-static {v0, v1}, Lj3/c;->c(Ljava/lang/String;Ljava/lang/Object;)V

    goto :goto_3

    :cond_5
    invoke-interface {p0}, Ljava/util/Iterator;->hasNext()Z

    move-result v0

    if-nez v0, :cond_6

    invoke-static {v1, v2}, Ljava/util/Arrays;->copyOf([Ljava/lang/Object;I)[Ljava/lang/Object;

    move-result-object v1

    const-string p0, "copyOf(result, size)"

    invoke-static {p0, v1}, Lj3/c;->c(Ljava/lang/String;Ljava/lang/Object;)V

    :goto_2
    return-object v1

    :cond_6
    :goto_3
    move v0, v2

    goto :goto_0
.end method

.method public static final O(Ljava/util/Collection;[Ljava/lang/Object;)[Ljava/lang/Object;
    .locals 5

    const-string v0, "collection"

    invoke-static {v0, p0}, Lj3/c;->d(Ljava/lang/String;Ljava/lang/Object;)V

    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-interface {p0}, Ljava/util/Collection;->size()I

    move-result v0

    const/4 v1, 0x0

    const/4 v2, 0x0

    if-nez v0, :cond_0

    array-length p0, p1

    if-lez p0, :cond_8

    aput-object v1, p1, v2

    goto/16 :goto_2

    :cond_0
    invoke-interface {p0}, Ljava/util/Collection;->iterator()Ljava/util/Iterator;

    move-result-object p0

    invoke-interface {p0}, Ljava/util/Iterator;->hasNext()Z

    move-result v3

    if-nez v3, :cond_1

    array-length p0, p1

    if-lez p0, :cond_8

    aput-object v1, p1, v2

    goto :goto_2

    :cond_1
    array-length v3, p1

    if-gt v0, v3, :cond_2

    move-object v0, p1

    goto :goto_0

    :cond_2
    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    move-result-object v3

    invoke-virtual {v3}, Ljava/lang/Class;->getComponentType()Ljava/lang/Class;

    move-result-object v3

    invoke-static {v3, v0}, Ljava/lang/reflect/Array;->newInstance(Ljava/lang/Class;I)Ljava/lang/Object;

    move-result-object v0

    if-eqz v0, :cond_a

    check-cast v0, [Ljava/lang/Object;

    :goto_0
    add-int/lit8 v3, v2, 0x1

    invoke-interface {p0}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v4

    aput-object v4, v0, v2

    array-length v2, v0

    if-lt v3, v2, :cond_6

    invoke-interface {p0}, Ljava/util/Iterator;->hasNext()Z

    move-result v2

    if-nez v2, :cond_3

    move-object p1, v0

    goto :goto_2

    :cond_3
    mul-int/lit8 v2, v3, 0x3

    add-int/lit8 v2, v2, 0x1

    ushr-int/lit8 v2, v2, 0x1

    if-gt v2, v3, :cond_5

    const v2, 0x7ffffffd

    if-ge v3, v2, :cond_4

    goto :goto_1

    :cond_4
    new-instance p0, Ljava/lang/OutOfMemoryError;

    invoke-direct {p0}, Ljava/lang/OutOfMemoryError;-><init>()V

    throw p0

    :cond_5
    :goto_1
    invoke-static {v0, v2}, Ljava/util/Arrays;->copyOf([Ljava/lang/Object;I)[Ljava/lang/Object;

    move-result-object v0

    const-string v2, "copyOf(result, newSize)"

    invoke-static {v2, v0}, Lj3/c;->c(Ljava/lang/String;Ljava/lang/Object;)V

    goto :goto_3

    :cond_6
    invoke-interface {p0}, Ljava/util/Iterator;->hasNext()Z

    move-result v2

    if-nez v2, :cond_9

    if-ne v0, p1, :cond_7

    aput-object v1, p1, v3

    goto :goto_2

    :cond_7
    invoke-static {v0, v3}, Ljava/util/Arrays;->copyOf([Ljava/lang/Object;I)[Ljava/lang/Object;

    move-result-object p1

    const-string p0, "copyOf(result, size)"

    invoke-static {p0, p1}, Lj3/c;->c(Ljava/lang/String;Ljava/lang/Object;)V

    :cond_8
    :goto_2
    return-object p1

    :cond_9
    :goto_3
    move v2, v3

    goto :goto_0

    :cond_a
    new-instance p0, Ljava/lang/NullPointerException;

    const-string p1, "null cannot be cast to non-null type kotlin.Array<kotlin.Any?>"

    invoke-direct {p0, p1}, Ljava/lang/NullPointerException;-><init>(Ljava/lang/String;)V

    invoke-static {p0}, Lj3/c;->e(Ljava/lang/RuntimeException;)V

    throw p0
.end method

.method public static final P(Le3/d;)Ljava/lang/String;
    .locals 3

    instance-of v0, p0, Lt3/a;

    if-eqz v0, :cond_0

    invoke-virtual {p0}, Ljava/lang/Object;->toString()Ljava/lang/String;

    move-result-object p0

    goto :goto_2

    :cond_0
    const/16 v0, 0x40

    :try_start_0
    new-instance v1, Ljava/lang/StringBuilder;

    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v1, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    invoke-virtual {v1, v0}, Ljava/lang/StringBuilder;->append(C)Ljava/lang/StringBuilder;

    invoke-static {p0}, La1/a;->v(Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    goto :goto_0

    :catchall_0
    move-exception v1

    invoke-static {v1}, La1/a;->q(Ljava/lang/Throwable;)Lc3/b$a;

    move-result-object v1

    :goto_0
    invoke-static {v1}, Lc3/b;->a(Ljava/lang/Object;)Ljava/lang/Throwable;

    move-result-object v2

    if-nez v2, :cond_1

    goto :goto_1

    :cond_1
    new-instance v1, Ljava/lang/StringBuilder;

    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {p0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    move-result-object v2

    invoke-virtual {v2}, Ljava/lang/Class;->getName()Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    invoke-virtual {v1, v0}, Ljava/lang/StringBuilder;->append(C)Ljava/lang/StringBuilder;

    invoke-static {p0}, La1/a;->v(Ljava/lang/Object;)Ljava/lang/String;

    move-result-object p0

    invoke-virtual {v1, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    :goto_1
    move-object p0, v1

    check-cast p0, Ljava/lang/String;

    :goto_2
    return-object p0
.end method

.method public static final Q(Ljava/util/LinkedHashMap;)Ljava/util/Map;
    .locals 1

    invoke-virtual {p0}, Ljava/util/LinkedHashMap;->entrySet()Ljava/util/Set;

    move-result-object p0

    invoke-interface {p0}, Ljava/util/Set;->iterator()Ljava/util/Iterator;

    move-result-object p0

    invoke-interface {p0}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object p0

    check-cast p0, Ljava/util/Map$Entry;

    invoke-interface {p0}, Ljava/util/Map$Entry;->getKey()Ljava/lang/Object;

    move-result-object v0

    invoke-interface {p0}, Ljava/util/Map$Entry;->getValue()Ljava/lang/Object;

    move-result-object p0

    invoke-static {v0, p0}, Ljava/util/Collections;->singletonMap(Ljava/lang/Object;Ljava/lang/Object;)Ljava/util/Map;

    move-result-object p0

    const-string v0, "with(entries.iterator().\u2026ingletonMap(key, value) }"

    invoke-static {v0, p0}, Lj3/c;->c(Ljava/lang/String;Ljava/lang/Object;)V

    return-object p0
.end method

.method public static R()F
    .locals 4

    const/high16 v0, 0x42480000    # 50.0f

    float-to-double v0, v0

    const-wide/high16 v2, 0x4030000000000000L    # 16.0

    add-double/2addr v0, v2

    const-wide/high16 v2, 0x405d000000000000L    # 116.0

    div-double/2addr v0, v2

    const-wide/high16 v2, 0x4008000000000000L    # 3.0

    invoke-static {v0, v1, v2, v3}, Ljava/lang/Math;->pow(DD)D

    move-result-wide v0

    double-to-float v0, v0

    const/high16 v1, 0x42c80000    # 100.0f

    mul-float/2addr v0, v1

    return v0
.end method

.method public static final d(Ljava/lang/Throwable;Ljava/lang/Throwable;)V
    .locals 1

    const-string v0, "<this>"

    invoke-static {v0, p0}, Lj3/c;->d(Ljava/lang/String;Ljava/lang/Object;)V

    const-string v0, "exception"

    invoke-static {v0, p1}, Lj3/c;->d(Ljava/lang/String;Ljava/lang/Object;)V

    if-eq p0, p1, :cond_0

    sget-object v0, Lf3/b;->a:Lf3/a;

    invoke-virtual {v0, p0, p1}, Lf3/a;->a(Ljava/lang/Throwable;Ljava/lang/Throwable;)V

    :cond_0
    return-void
.end method

.method public static e(Lo/e;Ln/d;I)V
    .locals 37

    move-object/from16 v0, p0

    move-object/from16 v10, p1

    const/4 v11, 0x2

    if-nez p2, :cond_0

    iget v1, v0, Lo/e;->m0:I

    iget-object v2, v0, Lo/e;->p0:[Lo/b;

    move v13, v1

    move-object v14, v2

    const/4 v15, 0x0

    goto :goto_0

    :cond_0
    iget v1, v0, Lo/e;->n0:I

    iget-object v2, v0, Lo/e;->o0:[Lo/b;

    move v13, v1

    move-object v14, v2

    move v15, v11

    :goto_0
    const/4 v9, 0x0

    :goto_1
    if-ge v9, v13, :cond_6c

    aget-object v1, v14, v9

    iget-boolean v2, v1, Lo/b;->q:Z

    const/4 v3, 0x3

    const/16 v8, 0x8

    const/4 v5, 0x1

    iget-object v7, v1, Lo/b;->a:Lo/d;

    const/16 v16, 0x0

    if-nez v2, :cond_15

    iget v2, v1, Lo/b;->l:I

    mul-int/lit8 v6, v2, 0x2

    move-object v12, v7

    move-object/from16 v18, v12

    const/16 v17, 0x0

    :goto_2
    if-nez v17, :cond_10

    iget v4, v1, Lo/b;->i:I

    add-int/2addr v4, v5

    iput v4, v1, Lo/b;->i:I

    iget-object v4, v12, Lo/d;->d0:[Lo/d;

    aput-object v16, v4, v2

    iget-object v4, v12, Lo/d;->c0:[Lo/d;

    aput-object v16, v4, v2

    iget v4, v12, Lo/d;->X:I

    iget-object v5, v12, Lo/d;->G:[Lo/c;

    if-eq v4, v8, :cond_b

    invoke-virtual {v12, v2}, Lo/d;->i(I)I

    move-result v4

    aget-object v4, v5, v6

    invoke-virtual {v4}, Lo/c;->c()I

    add-int/lit8 v4, v6, 0x1

    aget-object v21, v5, v4

    invoke-virtual/range {v21 .. v21}, Lo/c;->c()I

    aget-object v21, v5, v6

    invoke-virtual/range {v21 .. v21}, Lo/c;->c()I

    aget-object v4, v5, v4

    invoke-virtual {v4}, Lo/c;->c()I

    iget-object v4, v1, Lo/b;->b:Lo/d;

    if-nez v4, :cond_1

    iput-object v12, v1, Lo/b;->b:Lo/d;

    :cond_1
    iput-object v12, v1, Lo/b;->d:Lo/d;

    iget-object v4, v12, Lo/d;->J:[I

    aget v4, v4, v2

    if-ne v4, v3, :cond_b

    iget-object v8, v12, Lo/d;->l:[I

    aget v8, v8, v2

    if-eqz v8, :cond_2

    if-eq v8, v3, :cond_2

    if-ne v8, v11, :cond_b

    :cond_2
    iget v11, v1, Lo/b;->j:I

    const/16 v20, 0x1

    add-int/lit8 v11, v11, 0x1

    iput v11, v1, Lo/b;->j:I

    iget-object v11, v12, Lo/d;->b0:[F

    aget v11, v11, v2

    const/16 v19, 0x0

    cmpl-float v22, v11, v19

    if-lez v22, :cond_3

    iget v3, v1, Lo/b;->k:F

    add-float/2addr v3, v11

    iput v3, v1, Lo/b;->k:F

    :cond_3
    iget v3, v12, Lo/d;->X:I

    move/from16 v23, v9

    const/16 v9, 0x8

    if-eq v3, v9, :cond_5

    const/4 v3, 0x3

    if-ne v4, v3, :cond_5

    if-eqz v8, :cond_4

    if-ne v8, v3, :cond_5

    :cond_4
    const/4 v3, 0x1

    goto :goto_3

    :cond_5
    const/4 v3, 0x0

    :goto_3
    if-eqz v3, :cond_8

    const/4 v3, 0x0

    cmpg-float v4, v11, v3

    if-gez v4, :cond_6

    const/4 v3, 0x1

    iput-boolean v3, v1, Lo/b;->n:Z

    goto :goto_4

    :cond_6
    const/4 v3, 0x1

    iput-boolean v3, v1, Lo/b;->o:Z

    :goto_4
    iget-object v3, v1, Lo/b;->h:Ljava/util/ArrayList;

    if-nez v3, :cond_7

    new-instance v3, Ljava/util/ArrayList;

    invoke-direct {v3}, Ljava/util/ArrayList;-><init>()V

    iput-object v3, v1, Lo/b;->h:Ljava/util/ArrayList;

    :cond_7
    iget-object v3, v1, Lo/b;->h:Ljava/util/ArrayList;

    invoke-virtual {v3, v12}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    :cond_8
    iget-object v3, v1, Lo/b;->f:Lo/d;

    if-nez v3, :cond_9

    iput-object v12, v1, Lo/b;->f:Lo/d;

    :cond_9
    iget-object v3, v1, Lo/b;->g:Lo/d;

    if-eqz v3, :cond_a

    iget-object v3, v3, Lo/d;->c0:[Lo/d;

    aput-object v12, v3, v2

    :cond_a
    iput-object v12, v1, Lo/b;->g:Lo/d;

    goto :goto_5

    :cond_b
    move/from16 v23, v9

    :goto_5
    move-object/from16 v3, v18

    if-eq v3, v12, :cond_c

    iget-object v3, v3, Lo/d;->d0:[Lo/d;

    aput-object v12, v3, v2

    :cond_c
    add-int/lit8 v3, v6, 0x1

    aget-object v3, v5, v3

    iget-object v3, v3, Lo/c;->d:Lo/c;

    if-eqz v3, :cond_d

    iget-object v3, v3, Lo/c;->b:Lo/d;

    iget-object v4, v3, Lo/d;->G:[Lo/c;

    aget-object v4, v4, v6

    iget-object v4, v4, Lo/c;->d:Lo/c;

    if-eqz v4, :cond_d

    iget-object v4, v4, Lo/c;->b:Lo/d;

    if-eq v4, v12, :cond_e

    :cond_d
    move-object/from16 v3, v16

    :cond_e
    if-eqz v3, :cond_f

    goto :goto_6

    :cond_f
    move-object v3, v12

    const/16 v17, 0x1

    :goto_6
    move-object/from16 v18, v12

    move/from16 v9, v23

    const/4 v5, 0x1

    const/16 v8, 0x8

    const/4 v11, 0x2

    move-object v12, v3

    const/4 v3, 0x3

    goto/16 :goto_2

    :cond_10
    move/from16 v23, v9

    iget-object v3, v1, Lo/b;->b:Lo/d;

    if-eqz v3, :cond_11

    iget-object v3, v3, Lo/d;->G:[Lo/c;

    aget-object v3, v3, v6

    invoke-virtual {v3}, Lo/c;->c()I

    :cond_11
    iget-object v3, v1, Lo/b;->d:Lo/d;

    if-eqz v3, :cond_12

    add-int/lit8 v6, v6, 0x1

    iget-object v3, v3, Lo/d;->G:[Lo/c;

    aget-object v3, v3, v6

    invoke-virtual {v3}, Lo/c;->c()I

    :cond_12
    iput-object v12, v1, Lo/b;->c:Lo/d;

    if-nez v2, :cond_13

    iget-boolean v2, v1, Lo/b;->m:Z

    if-eqz v2, :cond_13

    iput-object v12, v1, Lo/b;->e:Lo/d;

    goto :goto_7

    :cond_13
    iput-object v7, v1, Lo/b;->e:Lo/d;

    :goto_7
    iget-boolean v2, v1, Lo/b;->o:Z

    if-eqz v2, :cond_14

    iget-boolean v2, v1, Lo/b;->n:Z

    if-eqz v2, :cond_14

    const/4 v2, 0x1

    goto :goto_8

    :cond_14
    const/4 v2, 0x0

    :goto_8
    iput-boolean v2, v1, Lo/b;->p:Z

    const/4 v2, 0x1

    goto :goto_9

    :cond_15
    move/from16 v23, v9

    move v2, v5

    :goto_9
    iput-boolean v2, v1, Lo/b;->q:Z

    iget-object v11, v1, Lo/b;->c:Lo/d;

    iget-object v12, v1, Lo/b;->b:Lo/d;

    iget-object v9, v1, Lo/b;->d:Lo/d;

    iget-object v2, v1, Lo/b;->e:Lo/d;

    iget v3, v1, Lo/b;->k:F

    iget-object v4, v0, Lo/d;->J:[I

    aget v4, v4, p2

    const/4 v8, 0x2

    if-ne v4, v8, :cond_16

    const/4 v4, 0x1

    goto :goto_a

    :cond_16
    const/4 v4, 0x0

    :goto_a
    if-nez p2, :cond_1a

    iget v5, v2, Lo/d;->Z:I

    const/4 v6, 0x1

    if-nez v5, :cond_17

    const/16 v20, 0x1

    goto :goto_b

    :cond_17
    const/16 v20, 0x0

    :goto_b
    if-ne v5, v6, :cond_18

    move/from16 v17, v6

    goto :goto_c

    :cond_18
    const/16 v17, 0x0

    :goto_c
    if-ne v5, v8, :cond_19

    move/from16 v5, v20

    goto :goto_f

    :cond_19
    move/from16 v5, v20

    goto :goto_10

    :cond_1a
    const/4 v6, 0x1

    iget v5, v2, Lo/d;->a0:I

    if-nez v5, :cond_1b

    move/from16 v17, v6

    goto :goto_d

    :cond_1b
    const/16 v17, 0x0

    :goto_d
    if-ne v5, v6, :cond_1c

    const/4 v6, 0x1

    goto :goto_e

    :cond_1c
    const/4 v6, 0x0

    :goto_e
    if-ne v5, v8, :cond_1d

    move/from16 v5, v17

    move/from16 v17, v6

    :goto_f
    move/from16 v18, v17

    move/from16 v17, v5

    const/4 v5, 0x1

    goto :goto_11

    :cond_1d
    move/from16 v5, v17

    move/from16 v17, v6

    :goto_10
    move/from16 v18, v17

    move/from16 v17, v5

    const/4 v5, 0x0

    :goto_11
    move/from16 v24, v3

    move-object v8, v7

    const/4 v6, 0x0

    :goto_12
    iget-object v3, v0, Lo/d;->G:[Lo/c;

    if-nez v6, :cond_2a

    move/from16 v27, v6

    iget-object v6, v8, Lo/d;->G:[Lo/c;

    aget-object v6, v6, v15

    if-eqz v5, :cond_1e

    const/16 v26, 0x1

    goto :goto_13

    :cond_1e
    const/16 v26, 0x4

    :goto_13
    invoke-virtual {v6}, Lo/c;->c()I

    move-result v28

    move/from16 v29, v13

    iget-object v13, v8, Lo/d;->J:[I

    move-object/from16 v30, v14

    aget v14, v13, p2

    move-object/from16 v31, v2

    const/4 v2, 0x3

    if-ne v14, v2, :cond_1f

    iget-object v2, v8, Lo/d;->l:[I

    aget v2, v2, p2

    if-nez v2, :cond_1f

    const/4 v2, 0x1

    goto :goto_14

    :cond_1f
    const/4 v2, 0x0

    :goto_14
    iget-object v14, v6, Lo/c;->d:Lo/c;

    if-eqz v14, :cond_20

    if-eq v8, v7, :cond_20

    invoke-virtual {v14}, Lo/c;->c()I

    move-result v14

    add-int v28, v14, v28

    :cond_20
    move/from16 v14, v28

    if-eqz v5, :cond_21

    if-eq v8, v7, :cond_21

    if-eq v8, v12, :cond_21

    move-object/from16 v28, v7

    const/16 v26, 0x5

    goto :goto_15

    :cond_21
    move-object/from16 v28, v7

    :goto_15
    iget-object v7, v6, Lo/c;->d:Lo/c;

    if-eqz v7, :cond_24

    if-ne v8, v12, :cond_22

    move-object/from16 v32, v12

    iget-object v12, v6, Lo/c;->g:Ln/h;

    iget-object v7, v7, Lo/c;->g:Ln/h;

    move-object/from16 v33, v1

    const/4 v1, 0x6

    invoke-virtual {v10, v12, v7, v14, v1}, Ln/d;->f(Ln/h;Ln/h;II)V

    goto :goto_16

    :cond_22
    move-object/from16 v33, v1

    move-object/from16 v32, v12

    iget-object v1, v6, Lo/c;->g:Ln/h;

    iget-object v7, v7, Lo/c;->g:Ln/h;

    const/16 v12, 0x8

    invoke-virtual {v10, v1, v7, v14, v12}, Ln/d;->f(Ln/h;Ln/h;II)V

    :goto_16
    if-eqz v2, :cond_23

    if-nez v5, :cond_23

    const/4 v1, 0x5

    goto :goto_17

    :cond_23
    move/from16 v1, v26

    :goto_17
    iget-object v2, v6, Lo/c;->g:Ln/h;

    iget-object v6, v6, Lo/c;->d:Lo/c;

    iget-object v6, v6, Lo/c;->g:Ln/h;

    invoke-virtual {v10, v2, v6, v14, v1}, Ln/d;->e(Ln/h;Ln/h;II)V

    goto :goto_18

    :cond_24
    move-object/from16 v33, v1

    move-object/from16 v32, v12

    :goto_18
    iget-object v1, v8, Lo/d;->G:[Lo/c;

    if-eqz v4, :cond_26

    iget v2, v8, Lo/d;->X:I

    const/16 v6, 0x8

    if-eq v2, v6, :cond_25

    aget v2, v13, p2

    const/4 v6, 0x3

    if-ne v2, v6, :cond_25

    add-int/lit8 v2, v15, 0x1

    aget-object v2, v1, v2

    iget-object v2, v2, Lo/c;->g:Ln/h;

    aget-object v6, v1, v15

    iget-object v6, v6, Lo/c;->g:Ln/h;

    const/4 v7, 0x5

    const/4 v12, 0x0

    invoke-virtual {v10, v2, v6, v12, v7}, Ln/d;->f(Ln/h;Ln/h;II)V

    goto :goto_19

    :cond_25
    const/4 v12, 0x0

    :goto_19
    aget-object v2, v1, v15

    iget-object v2, v2, Lo/c;->g:Ln/h;

    aget-object v3, v3, v15

    iget-object v3, v3, Lo/c;->g:Ln/h;

    const/16 v6, 0x8

    invoke-virtual {v10, v2, v3, v12, v6}, Ln/d;->f(Ln/h;Ln/h;II)V

    :cond_26
    add-int/lit8 v2, v15, 0x1

    aget-object v1, v1, v2

    iget-object v1, v1, Lo/c;->d:Lo/c;

    if-eqz v1, :cond_27

    iget-object v1, v1, Lo/c;->b:Lo/d;

    iget-object v2, v1, Lo/d;->G:[Lo/c;

    aget-object v2, v2, v15

    iget-object v2, v2, Lo/c;->d:Lo/c;

    if-eqz v2, :cond_27

    iget-object v2, v2, Lo/c;->b:Lo/d;

    if-eq v2, v8, :cond_28

    :cond_27
    move-object/from16 v1, v16

    :cond_28
    if-eqz v1, :cond_29

    move-object v8, v1

    move/from16 v6, v27

    goto :goto_1a

    :cond_29
    const/4 v6, 0x1

    :goto_1a
    move-object/from16 v7, v28

    move/from16 v13, v29

    move-object/from16 v14, v30

    move-object/from16 v2, v31

    move-object/from16 v12, v32

    move-object/from16 v1, v33

    goto/16 :goto_12

    :cond_2a
    move-object/from16 v33, v1

    move-object/from16 v31, v2

    move-object/from16 v28, v7

    move-object/from16 v32, v12

    move/from16 v29, v13

    move-object/from16 v30, v14

    const/4 v7, 0x5

    if-eqz v9, :cond_2e

    iget-object v1, v11, Lo/d;->G:[Lo/c;

    add-int/lit8 v2, v15, 0x1

    aget-object v1, v1, v2

    iget-object v1, v1, Lo/c;->d:Lo/c;

    if-eqz v1, :cond_2e

    iget-object v1, v9, Lo/d;->G:[Lo/c;

    aget-object v1, v1, v2

    iget-object v6, v9, Lo/d;->J:[I

    aget v6, v6, p2

    const/4 v8, 0x3

    if-ne v6, v8, :cond_2b

    iget-object v6, v9, Lo/d;->l:[I

    aget v6, v6, p2

    if-nez v6, :cond_2b

    const/4 v6, 0x1

    goto :goto_1b

    :cond_2b
    const/4 v6, 0x0

    :goto_1b
    if-eqz v6, :cond_2c

    if-nez v5, :cond_2c

    iget-object v6, v1, Lo/c;->d:Lo/c;

    iget-object v8, v6, Lo/c;->b:Lo/d;

    if-ne v8, v0, :cond_2c

    iget-object v8, v1, Lo/c;->g:Ln/h;

    iget-object v6, v6, Lo/c;->g:Ln/h;

    invoke-virtual {v1}, Lo/c;->c()I

    move-result v12

    neg-int v12, v12

    move v13, v7

    goto :goto_1c

    :cond_2c
    if-eqz v5, :cond_2d

    iget-object v6, v1, Lo/c;->d:Lo/c;

    iget-object v8, v6, Lo/c;->b:Lo/d;

    if-ne v8, v0, :cond_2d

    iget-object v8, v1, Lo/c;->g:Ln/h;

    iget-object v6, v6, Lo/c;->g:Ln/h;

    invoke-virtual {v1}, Lo/c;->c()I

    move-result v12

    neg-int v12, v12

    const/4 v13, 0x4

    :goto_1c
    invoke-virtual {v10, v8, v6, v12, v13}, Ln/d;->e(Ln/h;Ln/h;II)V

    :cond_2d
    iget-object v6, v1, Lo/c;->g:Ln/h;

    iget-object v8, v11, Lo/d;->G:[Lo/c;

    aget-object v2, v8, v2

    iget-object v2, v2, Lo/c;->d:Lo/c;

    iget-object v2, v2, Lo/c;->g:Ln/h;

    invoke-virtual {v1}, Lo/c;->c()I

    move-result v1

    neg-int v1, v1

    const/4 v8, 0x6

    invoke-virtual {v10, v6, v2, v1, v8}, Ln/d;->g(Ln/h;Ln/h;II)V

    :cond_2e
    if-eqz v4, :cond_2f

    add-int/lit8 v1, v15, 0x1

    aget-object v2, v3, v1

    iget-object v2, v2, Lo/c;->g:Ln/h;

    iget-object v3, v11, Lo/d;->G:[Lo/c;

    aget-object v1, v3, v1

    iget-object v3, v1, Lo/c;->g:Ln/h;

    invoke-virtual {v1}, Lo/c;->c()I

    move-result v1

    const/16 v4, 0x8

    invoke-virtual {v10, v2, v3, v1, v4}, Ln/d;->f(Ln/h;Ln/h;II)V

    :cond_2f
    move-object/from16 v1, v33

    iget-object v2, v1, Lo/b;->h:Ljava/util/ArrayList;

    if-eqz v2, :cond_39

    invoke-virtual {v2}, Ljava/util/ArrayList;->size()I

    move-result v3

    const/4 v4, 0x1

    if-le v3, v4, :cond_39

    iget-boolean v6, v1, Lo/b;->n:Z

    if-eqz v6, :cond_30

    iget-boolean v6, v1, Lo/b;->p:Z

    if-nez v6, :cond_30

    iget v6, v1, Lo/b;->j:I

    int-to-float v6, v6

    goto :goto_1d

    :cond_30
    move/from16 v6, v24

    :goto_1d
    move-object/from16 v13, v16

    const/4 v8, 0x0

    const/4 v12, 0x0

    :goto_1e
    if-ge v12, v3, :cond_39

    invoke-virtual {v2, v12}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v14

    check-cast v14, Lo/d;

    iget-object v4, v14, Lo/d;->b0:[F

    aget v4, v4, p2

    const/16 v19, 0x0

    cmpg-float v22, v4, v19

    iget-object v7, v14, Lo/d;->G:[Lo/c;

    if-gez v22, :cond_32

    iget-boolean v4, v1, Lo/b;->p:Z

    if-eqz v4, :cond_31

    add-int/lit8 v4, v15, 0x1

    aget-object v4, v7, v4

    iget-object v4, v4, Lo/c;->g:Ln/h;

    aget-object v7, v7, v15

    iget-object v7, v7, Lo/c;->g:Ln/h;

    const/4 v0, 0x0

    const/4 v14, 0x4

    :goto_1f
    invoke-virtual {v10, v4, v7, v0, v14}, Ln/d;->e(Ln/h;Ln/h;II)V

    goto :goto_21

    :cond_31
    const/4 v0, 0x4

    const/high16 v4, 0x3f800000    # 1.0f

    goto :goto_20

    :cond_32
    const/4 v0, 0x4

    :goto_20
    const/16 v19, 0x0

    cmpl-float v22, v4, v19

    if-nez v22, :cond_33

    add-int/lit8 v4, v15, 0x1

    aget-object v4, v7, v4

    iget-object v4, v4, Lo/c;->g:Ln/h;

    aget-object v7, v7, v15

    iget-object v7, v7, Lo/c;->g:Ln/h;

    const/4 v0, 0x0

    const/16 v14, 0x8

    goto :goto_1f

    :goto_21
    move-object/from16 v27, v2

    move/from16 v25, v3

    const/16 v19, 0x0

    goto/16 :goto_27

    :cond_33
    const/4 v0, 0x0

    if-eqz v13, :cond_38

    iget-object v13, v13, Lo/d;->G:[Lo/c;

    aget-object v0, v13, v15

    iget-object v0, v0, Lo/c;->g:Ln/h;

    add-int/lit8 v25, v15, 0x1

    aget-object v13, v13, v25

    iget-object v13, v13, Lo/c;->g:Ln/h;

    move-object/from16 v27, v2

    aget-object v2, v7, v15

    iget-object v2, v2, Lo/c;->g:Ln/h;

    aget-object v7, v7, v25

    iget-object v7, v7, Lo/c;->g:Ln/h;

    move/from16 v25, v3

    invoke-virtual/range {p1 .. p1}, Ln/d;->l()Ln/b;

    move-result-object v3

    move-object/from16 v33, v14

    const/4 v14, 0x0

    iput v14, v3, Ln/b;->b:F

    cmpl-float v19, v6, v14

    const/high16 v14, -0x40800000    # -1.0f

    if-eqz v19, :cond_37

    cmpl-float v19, v8, v4

    if-nez v19, :cond_34

    goto :goto_23

    :cond_34
    const/16 v19, 0x0

    cmpl-float v34, v8, v19

    if-nez v34, :cond_35

    iget-object v2, v3, Ln/b;->d:Ln/b$a;

    const/high16 v7, 0x3f800000    # 1.0f

    invoke-interface {v2, v0, v7}, Ln/b$a;->d(Ln/h;F)V

    iget-object v0, v3, Ln/b;->d:Ln/b$a;

    invoke-interface {v0, v13, v14}, Ln/b$a;->d(Ln/h;F)V

    goto :goto_22

    :cond_35
    const/high16 v14, 0x3f800000    # 1.0f

    if-nez v22, :cond_36

    iget-object v0, v3, Ln/b;->d:Ln/b$a;

    invoke-interface {v0, v2, v14}, Ln/b$a;->d(Ln/h;F)V

    iget-object v0, v3, Ln/b;->d:Ln/b$a;

    const/high16 v2, -0x40800000    # -1.0f

    invoke-interface {v0, v7, v2}, Ln/b$a;->d(Ln/h;F)V

    :goto_22
    move/from16 v22, v4

    goto :goto_25

    :cond_36
    div-float/2addr v8, v6

    div-float v22, v4, v6

    div-float v8, v8, v22

    move/from16 v22, v4

    iget-object v4, v3, Ln/b;->d:Ln/b$a;

    invoke-interface {v4, v0, v14}, Ln/b$a;->d(Ln/h;F)V

    iget-object v0, v3, Ln/b;->d:Ln/b$a;

    const/high16 v4, -0x40800000    # -1.0f

    invoke-interface {v0, v13, v4}, Ln/b$a;->d(Ln/h;F)V

    iget-object v0, v3, Ln/b;->d:Ln/b$a;

    invoke-interface {v0, v7, v8}, Ln/b$a;->d(Ln/h;F)V

    iget-object v0, v3, Ln/b;->d:Ln/b$a;

    neg-float v14, v8

    goto :goto_24

    :cond_37
    :goto_23
    move/from16 v22, v4

    move v4, v14

    const/high16 v14, 0x3f800000    # 1.0f

    const/16 v19, 0x0

    iget-object v8, v3, Ln/b;->d:Ln/b$a;

    invoke-interface {v8, v0, v14}, Ln/b$a;->d(Ln/h;F)V

    iget-object v0, v3, Ln/b;->d:Ln/b$a;

    invoke-interface {v0, v13, v4}, Ln/b$a;->d(Ln/h;F)V

    iget-object v0, v3, Ln/b;->d:Ln/b$a;

    invoke-interface {v0, v7, v14}, Ln/b$a;->d(Ln/h;F)V

    iget-object v0, v3, Ln/b;->d:Ln/b$a;

    move v14, v4

    :goto_24
    invoke-interface {v0, v2, v14}, Ln/b$a;->d(Ln/h;F)V

    :goto_25
    invoke-virtual {v10, v3}, Ln/d;->c(Ln/b;)V

    goto :goto_26

    :cond_38
    move-object/from16 v27, v2

    move/from16 v25, v3

    move/from16 v22, v4

    move-object/from16 v33, v14

    const/16 v19, 0x0

    :goto_26
    move/from16 v8, v22

    move-object/from16 v13, v33

    :goto_27
    add-int/lit8 v12, v12, 0x1

    move/from16 v3, v25

    move-object/from16 v2, v27

    const/4 v4, 0x1

    const/4 v7, 0x5

    move-object/from16 v0, p0

    goto/16 :goto_1e

    :cond_39
    if-eqz v32, :cond_41

    move-object/from16 v0, v32

    if-eq v0, v9, :cond_3b

    if-eqz v5, :cond_3a

    goto :goto_28

    :cond_3a
    move-object v12, v9

    move/from16 v14, v23

    move-object/from16 v7, v28

    goto/16 :goto_2d

    :cond_3b
    :goto_28
    move-object/from16 v7, v28

    iget-object v1, v7, Lo/d;->G:[Lo/c;

    aget-object v1, v1, v15

    iget-object v2, v11, Lo/d;->G:[Lo/c;

    add-int/lit8 v3, v15, 0x1

    aget-object v2, v2, v3

    iget-object v1, v1, Lo/c;->d:Lo/c;

    if-eqz v1, :cond_3c

    iget-object v1, v1, Lo/c;->g:Ln/h;

    move-object v4, v1

    goto :goto_29

    :cond_3c
    move-object/from16 v4, v16

    :goto_29
    iget-object v1, v2, Lo/c;->d:Lo/c;

    if-eqz v1, :cond_3d

    iget-object v1, v1, Lo/c;->g:Ln/h;

    move-object v6, v1

    goto :goto_2a

    :cond_3d
    move-object/from16 v6, v16

    :goto_2a
    iget-object v1, v0, Lo/d;->G:[Lo/c;

    aget-object v1, v1, v15

    iget-object v2, v9, Lo/d;->G:[Lo/c;

    aget-object v2, v2, v3

    if-eqz v4, :cond_3f

    if-eqz v6, :cond_3f

    move-object/from16 v3, v31

    if-nez p2, :cond_3e

    iget v3, v3, Lo/d;->U:F

    goto :goto_2b

    :cond_3e
    iget v3, v3, Lo/d;->V:F

    :goto_2b
    move v5, v3

    invoke-virtual {v1}, Lo/c;->c()I

    move-result v7

    invoke-virtual {v2}, Lo/c;->c()I

    move-result v8

    iget-object v3, v1, Lo/c;->g:Ln/h;

    iget-object v12, v2, Lo/c;->g:Ln/h;

    const/4 v13, 0x7

    move-object/from16 v1, p1

    move-object v2, v3

    move-object v3, v4

    move v4, v7

    move-object v7, v12

    const/4 v12, 0x2

    move-object v12, v9

    move/from16 v14, v23

    move v9, v13

    invoke-virtual/range {v1 .. v9}, Ln/d;->b(Ln/h;Ln/h;IFLn/h;Ln/h;II)V

    goto :goto_2c

    :cond_3f
    move-object v12, v9

    move/from16 v14, v23

    :cond_40
    :goto_2c
    move-object/from16 v19, v11

    move/from16 v21, v14

    goto/16 :goto_47

    :cond_41
    move-object v12, v9

    move/from16 v14, v23

    move-object/from16 v7, v28

    move-object/from16 v0, v32

    :goto_2d
    if-eqz v17, :cond_54

    if-eqz v0, :cond_54

    iget v2, v1, Lo/b;->j:I

    if-lez v2, :cond_42

    iget v1, v1, Lo/b;->i:I

    if-ne v1, v2, :cond_42

    const/16 v20, 0x1

    goto :goto_2e

    :cond_42
    const/16 v20, 0x0

    :goto_2e
    move-object v9, v0

    move-object v13, v9

    :goto_2f
    if-eqz v13, :cond_40

    iget-object v1, v13, Lo/d;->d0:[Lo/d;

    aget-object v1, v1, p2

    move-object v8, v1

    :goto_30
    if-eqz v8, :cond_43

    iget v1, v8, Lo/d;->X:I

    const/16 v6, 0x8

    if-ne v1, v6, :cond_44

    iget-object v1, v8, Lo/d;->d0:[Lo/d;

    aget-object v8, v1, p2

    goto :goto_30

    :cond_43
    const/16 v6, 0x8

    :cond_44
    if-nez v8, :cond_46

    if-ne v13, v12, :cond_45

    goto :goto_31

    :cond_45
    move-object/from16 v35, v7

    move-object/from16 v21, v8

    move-object/from16 v19, v9

    goto/16 :goto_38

    :cond_46
    :goto_31
    iget-object v1, v13, Lo/d;->G:[Lo/c;

    aget-object v2, v1, v15

    iget-object v3, v2, Lo/c;->g:Ln/h;

    iget-object v4, v2, Lo/c;->d:Lo/c;

    if-eqz v4, :cond_47

    iget-object v4, v4, Lo/c;->g:Ln/h;

    goto :goto_32

    :cond_47
    move-object/from16 v4, v16

    :goto_32
    if-eq v9, v13, :cond_48

    iget-object v4, v9, Lo/d;->G:[Lo/c;

    add-int/lit8 v5, v15, 0x1

    aget-object v4, v4, v5

    goto :goto_33

    :cond_48
    if-ne v13, v0, :cond_4a

    if-ne v9, v13, :cond_4a

    iget-object v4, v7, Lo/d;->G:[Lo/c;

    aget-object v4, v4, v15

    iget-object v4, v4, Lo/c;->d:Lo/c;

    if-eqz v4, :cond_49

    :goto_33
    iget-object v4, v4, Lo/c;->g:Ln/h;

    goto :goto_34

    :cond_49
    move-object/from16 v4, v16

    :cond_4a
    :goto_34
    invoke-virtual {v2}, Lo/c;->c()I

    move-result v2

    add-int/lit8 v5, v15, 0x1

    aget-object v19, v1, v5

    invoke-virtual/range {v19 .. v19}, Lo/c;->c()I

    move-result v19

    if-eqz v8, :cond_4b

    iget-object v6, v8, Lo/d;->G:[Lo/c;

    aget-object v6, v6, v15

    move-object/from16 v28, v7

    iget-object v7, v6, Lo/c;->g:Ln/h;

    aget-object v1, v1, v5

    goto :goto_36

    :cond_4b
    move-object/from16 v28, v7

    iget-object v6, v11, Lo/d;->G:[Lo/c;

    aget-object v6, v6, v5

    iget-object v6, v6, Lo/c;->d:Lo/c;

    if-eqz v6, :cond_4c

    iget-object v7, v6, Lo/c;->g:Ln/h;

    goto :goto_35

    :cond_4c
    move-object/from16 v7, v16

    :goto_35
    aget-object v1, v1, v5

    :goto_36
    iget-object v1, v1, Lo/c;->g:Ln/h;

    if-eqz v6, :cond_4d

    invoke-virtual {v6}, Lo/c;->c()I

    move-result v6

    add-int v19, v6, v19

    :cond_4d
    if-eqz v9, :cond_4e

    iget-object v6, v9, Lo/d;->G:[Lo/c;

    aget-object v6, v6, v5

    invoke-virtual {v6}, Lo/c;->c()I

    move-result v6

    add-int/2addr v2, v6

    :cond_4e
    if-eqz v3, :cond_52

    if-eqz v4, :cond_52

    if-eqz v7, :cond_52

    if-eqz v1, :cond_52

    if-ne v13, v0, :cond_4f

    iget-object v2, v0, Lo/d;->G:[Lo/c;

    aget-object v2, v2, v15

    invoke-virtual {v2}, Lo/c;->c()I

    move-result v2

    :cond_4f
    move v6, v2

    if-ne v13, v12, :cond_50

    iget-object v2, v12, Lo/d;->G:[Lo/c;

    aget-object v2, v2, v5

    invoke-virtual {v2}, Lo/c;->c()I

    move-result v2

    move/from16 v19, v2

    :cond_50
    if-eqz v20, :cond_51

    const/16 v22, 0x8

    goto :goto_37

    :cond_51
    const/16 v22, 0x5

    :goto_37
    const/high16 v5, 0x3f000000    # 0.5f

    move-object/from16 v23, v1

    move-object/from16 v1, p1

    move-object v2, v3

    move-object v3, v4

    move v4, v6

    const/16 v21, 0x8

    move-object v6, v7

    move-object/from16 v35, v28

    move-object/from16 v7, v23

    move-object/from16 v21, v8

    move/from16 v8, v19

    move-object/from16 v19, v9

    move/from16 v9, v22

    invoke-virtual/range {v1 .. v9}, Ln/d;->b(Ln/h;Ln/h;IFLn/h;Ln/h;II)V

    goto :goto_38

    :cond_52
    move-object/from16 v21, v8

    move-object/from16 v19, v9

    move-object/from16 v35, v28

    :goto_38
    iget v1, v13, Lo/d;->X:I

    const/16 v9, 0x8

    if-eq v1, v9, :cond_53

    goto :goto_39

    :cond_53
    move-object/from16 v13, v19

    :goto_39
    move-object v9, v13

    move-object/from16 v13, v21

    move-object/from16 v7, v35

    goto/16 :goto_2f

    :cond_54
    move-object/from16 v35, v7

    const/16 v9, 0x8

    if-eqz v18, :cond_40

    if-eqz v0, :cond_40

    iget v2, v1, Lo/b;->j:I

    if-lez v2, :cond_55

    iget v1, v1, Lo/b;->i:I

    if-ne v1, v2, :cond_55

    const/16 v20, 0x1

    goto :goto_3a

    :cond_55
    const/16 v20, 0x0

    :goto_3a
    move-object v8, v0

    move-object v13, v8

    :goto_3b
    if-eqz v13, :cond_60

    iget-object v1, v13, Lo/d;->d0:[Lo/d;

    aget-object v1, v1, p2

    :goto_3c
    if-eqz v1, :cond_56

    iget v2, v1, Lo/d;->X:I

    if-ne v2, v9, :cond_56

    iget-object v1, v1, Lo/d;->d0:[Lo/d;

    aget-object v1, v1, p2

    goto :goto_3c

    :cond_56
    if-eq v13, v0, :cond_5e

    if-eq v13, v12, :cond_5e

    if-eqz v1, :cond_5e

    if-ne v1, v12, :cond_57

    move-object/from16 v7, v16

    goto :goto_3d

    :cond_57
    move-object v7, v1

    :goto_3d
    iget-object v1, v13, Lo/d;->G:[Lo/c;

    aget-object v2, v1, v15

    iget-object v3, v2, Lo/c;->g:Ln/h;

    iget-object v4, v8, Lo/d;->G:[Lo/c;

    add-int/lit8 v5, v15, 0x1

    aget-object v4, v4, v5

    iget-object v4, v4, Lo/c;->g:Ln/h;

    invoke-virtual {v2}, Lo/c;->c()I

    move-result v2

    aget-object v6, v1, v5

    invoke-virtual {v6}, Lo/c;->c()I

    move-result v6

    if-eqz v7, :cond_59

    iget-object v1, v7, Lo/d;->G:[Lo/c;

    aget-object v1, v1, v15

    iget-object v9, v1, Lo/c;->g:Ln/h;

    move-object/from16 v19, v7

    iget-object v7, v1, Lo/c;->d:Lo/c;

    if-eqz v7, :cond_58

    iget-object v7, v7, Lo/c;->g:Ln/h;

    goto :goto_3f

    :cond_58
    move-object/from16 v7, v16

    goto :goto_3f

    :cond_59
    move-object/from16 v19, v7

    iget-object v7, v12, Lo/d;->G:[Lo/c;

    aget-object v7, v7, v15

    if-eqz v7, :cond_5a

    iget-object v9, v7, Lo/c;->g:Ln/h;

    goto :goto_3e

    :cond_5a
    move-object/from16 v9, v16

    :goto_3e
    aget-object v1, v1, v5

    iget-object v1, v1, Lo/c;->g:Ln/h;

    move-object/from16 v36, v7

    move-object v7, v1

    move-object/from16 v1, v36

    :goto_3f
    if-eqz v1, :cond_5b

    invoke-virtual {v1}, Lo/c;->c()I

    move-result v1

    add-int/2addr v1, v6

    move/from16 v21, v1

    goto :goto_40

    :cond_5b
    move/from16 v21, v6

    :goto_40
    iget-object v1, v8, Lo/d;->G:[Lo/c;

    aget-object v1, v1, v5

    invoke-virtual {v1}, Lo/c;->c()I

    move-result v1

    add-int v5, v1, v2

    if-eqz v20, :cond_5c

    const/16 v22, 0x8

    goto :goto_41

    :cond_5c
    const/16 v22, 0x4

    :goto_41
    if-eqz v3, :cond_5d

    if-eqz v4, :cond_5d

    if-eqz v9, :cond_5d

    if-eqz v7, :cond_5d

    const/high16 v6, 0x3f000000    # 0.5f

    move-object/from16 v1, p1

    move-object v2, v3

    const/16 v23, 0x4

    move-object v3, v4

    move v4, v5

    move v5, v6

    move-object v6, v9

    move-object/from16 v24, v8

    move/from16 v8, v21

    move/from16 v21, v14

    const/16 v14, 0x8

    move/from16 v9, v22

    invoke-virtual/range {v1 .. v9}, Ln/d;->b(Ln/h;Ln/h;IFLn/h;Ln/h;II)V

    goto :goto_42

    :cond_5d
    move-object/from16 v24, v8

    move/from16 v21, v14

    const/16 v14, 0x8

    const/16 v23, 0x4

    :goto_42
    move-object/from16 v1, v19

    goto :goto_43

    :cond_5e
    move-object/from16 v24, v8

    move/from16 v21, v14

    const/16 v23, 0x4

    move v14, v9

    :goto_43
    iget v2, v13, Lo/d;->X:I

    if-eq v2, v14, :cond_5f

    move-object v8, v13

    goto :goto_44

    :cond_5f
    move-object/from16 v8, v24

    :goto_44
    move-object v13, v1

    move v9, v14

    move/from16 v14, v21

    goto/16 :goto_3b

    :cond_60
    move/from16 v21, v14

    iget-object v1, v0, Lo/d;->G:[Lo/c;

    aget-object v1, v1, v15

    move-object/from16 v2, v35

    iget-object v2, v2, Lo/d;->G:[Lo/c;

    aget-object v2, v2, v15

    iget-object v2, v2, Lo/c;->d:Lo/c;

    iget-object v3, v12, Lo/d;->G:[Lo/c;

    add-int/lit8 v4, v15, 0x1

    aget-object v13, v3, v4

    iget-object v3, v11, Lo/d;->G:[Lo/c;

    aget-object v3, v3, v4

    iget-object v14, v3, Lo/c;->d:Lo/c;

    if-eqz v2, :cond_63

    if-eq v0, v12, :cond_61

    iget-object v3, v1, Lo/c;->g:Ln/h;

    iget-object v2, v2, Lo/c;->g:Ln/h;

    invoke-virtual {v1}, Lo/c;->c()I

    move-result v1

    const/4 v9, 0x5

    invoke-virtual {v10, v3, v2, v1, v9}, Ln/d;->e(Ln/h;Ln/h;II)V

    goto :goto_45

    :cond_61
    const/4 v9, 0x5

    if-eqz v14, :cond_62

    iget-object v3, v1, Lo/c;->g:Ln/h;

    iget-object v4, v2, Lo/c;->g:Ln/h;

    invoke-virtual {v1}, Lo/c;->c()I

    move-result v5

    const/high16 v6, 0x3f000000    # 0.5f

    iget-object v7, v13, Lo/c;->g:Ln/h;

    iget-object v8, v14, Lo/c;->g:Ln/h;

    invoke-virtual {v13}, Lo/c;->c()I

    move-result v19

    const/16 v20, 0x5

    move-object/from16 v1, p1

    move-object v2, v3

    move-object v3, v4

    move v4, v5

    move v5, v6

    move-object v6, v7

    move-object v7, v8

    move/from16 v8, v19

    move-object/from16 v19, v11

    move v11, v9

    move/from16 v9, v20

    invoke-virtual/range {v1 .. v9}, Ln/d;->b(Ln/h;Ln/h;IFLn/h;Ln/h;II)V

    goto :goto_46

    :cond_62
    :goto_45
    move-object/from16 v19, v11

    move v11, v9

    goto :goto_46

    :cond_63
    move-object/from16 v19, v11

    const/4 v11, 0x5

    :goto_46
    if-eqz v14, :cond_64

    if-eq v0, v12, :cond_64

    iget-object v1, v13, Lo/c;->g:Ln/h;

    iget-object v2, v14, Lo/c;->g:Ln/h;

    invoke-virtual {v13}, Lo/c;->c()I

    move-result v3

    neg-int v3, v3

    invoke-virtual {v10, v1, v2, v3, v11}, Ln/d;->e(Ln/h;Ln/h;II)V

    :cond_64
    :goto_47
    if-nez v17, :cond_65

    if-eqz v18, :cond_6b

    :cond_65
    if-eqz v0, :cond_6b

    if-eq v0, v12, :cond_6b

    iget-object v1, v0, Lo/d;->G:[Lo/c;

    aget-object v2, v1, v15

    iget-object v3, v12, Lo/d;->G:[Lo/c;

    add-int/lit8 v4, v15, 0x1

    aget-object v3, v3, v4

    iget-object v5, v2, Lo/c;->d:Lo/c;

    if-eqz v5, :cond_66

    iget-object v5, v5, Lo/c;->g:Ln/h;

    goto :goto_48

    :cond_66
    move-object/from16 v5, v16

    :goto_48
    iget-object v6, v3, Lo/c;->d:Lo/c;

    if-eqz v6, :cond_67

    iget-object v6, v6, Lo/c;->g:Ln/h;

    goto :goto_49

    :cond_67
    move-object/from16 v6, v16

    :goto_49
    move-object/from16 v7, v19

    if-eq v7, v12, :cond_69

    iget-object v6, v7, Lo/d;->G:[Lo/c;

    aget-object v6, v6, v4

    iget-object v6, v6, Lo/c;->d:Lo/c;

    if-eqz v6, :cond_68

    iget-object v6, v6, Lo/c;->g:Ln/h;

    move-object/from16 v16, v6

    :cond_68
    move-object/from16 v6, v16

    :cond_69
    if-ne v0, v12, :cond_6a

    aget-object v3, v1, v4

    :cond_6a
    if-eqz v5, :cond_6b

    if-eqz v6, :cond_6b

    const/high16 v0, 0x3f000000    # 0.5f

    invoke-virtual {v2}, Lo/c;->c()I

    move-result v7

    iget-object v1, v12, Lo/d;->G:[Lo/c;

    aget-object v1, v1, v4

    invoke-virtual {v1}, Lo/c;->c()I

    move-result v8

    iget-object v2, v2, Lo/c;->g:Ln/h;

    iget-object v9, v3, Lo/c;->g:Ln/h;

    const/4 v11, 0x5

    move-object/from16 v1, p1

    move-object v3, v5

    move v4, v7

    move v5, v0

    move-object v7, v9

    move v9, v11

    invoke-virtual/range {v1 .. v9}, Ln/d;->b(Ln/h;Ln/h;IFLn/h;Ln/h;II)V

    :cond_6b
    add-int/lit8 v9, v21, 0x1

    const/4 v11, 0x2

    move-object/from16 v0, p0

    move/from16 v13, v29

    move-object/from16 v14, v30

    goto/16 :goto_1

    :cond_6c
    return-void
.end method

.method public static f(II[I)I
    .locals 3

    add-int/lit8 p0, p0, -0x1

    const/4 v0, 0x0

    :goto_0
    if-gt v0, p0, :cond_2

    add-int v1, v0, p0

    ushr-int/lit8 v1, v1, 0x1

    aget v2, p2, v1

    if-ge v2, p1, :cond_0

    add-int/lit8 v1, v1, 0x1

    move v0, v1

    goto :goto_0

    :cond_0
    if-le v2, p1, :cond_1

    add-int/lit8 v1, v1, -0x1

    move p0, v1

    goto :goto_0

    :cond_1
    return v1

    :cond_2
    not-int p0, v0

    return p0
.end method

.method public static g([JIJ)I
    .locals 4

    add-int/lit8 p1, p1, -0x1

    const/4 v0, 0x0

    :goto_0
    if-gt v0, p1, :cond_2

    add-int v1, v0, p1

    ushr-int/lit8 v1, v1, 0x1

    aget-wide v2, p0, v1

    cmp-long v2, v2, p2

    if-gez v2, :cond_0

    add-int/lit8 v1, v1, 0x1

    move v0, v1

    goto :goto_0

    :cond_0
    if-lez v2, :cond_1

    add-int/lit8 v1, v1, -0x1

    move p1, v1

    goto :goto_0

    :cond_1
    return v1

    :cond_2
    not-int p0, v0

    return p0
.end method

.method public static h(Landroidx/lifecycle/k;Ljava/lang/StringBuilder;)V
    .locals 2

    if-nez p0, :cond_0

    const-string p0, "null"

    goto :goto_0

    :cond_0
    invoke-virtual {p0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/Class;->getSimpleName()Ljava/lang/String;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/String;->length()I

    move-result v1

    if-gtz v1, :cond_1

    invoke-virtual {p0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/Class;->getName()Ljava/lang/String;

    move-result-object v0

    const/16 v1, 0x2e

    invoke-virtual {v0, v1}, Ljava/lang/String;->lastIndexOf(I)I

    move-result v1

    if-lez v1, :cond_1

    add-int/lit8 v1, v1, 0x1

    invoke-virtual {v0, v1}, Ljava/lang/String;->substring(I)Ljava/lang/String;

    move-result-object v0

    :cond_1
    invoke-virtual {p1, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/16 v0, 0x7b

    invoke-virtual {p1, v0}, Ljava/lang/StringBuilder;->append(C)Ljava/lang/StringBuilder;

    invoke-static {p0}, Ljava/lang/System;->identityHashCode(Ljava/lang/Object;)I

    move-result p0

    invoke-static {p0}, Ljava/lang/Integer;->toHexString(I)Ljava/lang/String;

    move-result-object p0

    :goto_0
    invoke-virtual {p1, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    return-void
.end method

.method public static i(Ljava/lang/String;Z)V
    .locals 0

    if-eqz p1, :cond_0

    return-void

    :cond_0
    new-instance p1, Ljava/lang/IllegalArgumentException;

    invoke-direct {p1, p0}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    throw p1
.end method

.method public static j(Z)V
    .locals 0

    if-eqz p0, :cond_0

    return-void

    :cond_0
    new-instance p0, Ljava/lang/IllegalArgumentException;

    invoke-direct {p0}, Ljava/lang/IllegalArgumentException;-><init>()V

    throw p0
.end method

.method public static k(I)V
    .locals 0

    if-ltz p0, :cond_0

    return-void

    :cond_0
    new-instance p0, Ljava/lang/IllegalArgumentException;

    invoke-direct {p0}, Ljava/lang/IllegalArgumentException;-><init>()V

    throw p0
.end method

.method public static l(Ljava/lang/Object;Ljava/lang/String;)V
    .locals 0

    if-eqz p0, :cond_0

    return-void

    :cond_0
    new-instance p0, Ljava/lang/NullPointerException;

    invoke-direct {p0, p1}, Ljava/lang/NullPointerException;-><init>(Ljava/lang/String;)V

    throw p0
.end method

.method public static m(Ljava/lang/String;)V
    .locals 4

    invoke-virtual {p0}, Ljava/lang/String;->length()I

    move-result v0

    const/16 v1, 0x2710

    if-gt v0, v1, :cond_0

    return-void

    :cond_0
    new-instance v0, Ljava/lang/NumberFormatException;

    new-instance v1, Ljava/lang/StringBuilder;

    const-string v2, "Number string too large: "

    invoke-direct {v1, v2}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    const/4 v2, 0x0

    const/16 v3, 0x1e

    invoke-virtual {p0, v2, v3}, Ljava/lang/String;->substring(II)Ljava/lang/String;

    move-result-object p0

    invoke-virtual {v1, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string p0, "..."

    invoke-virtual {v1, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p0

    invoke-direct {v0, p0}, Ljava/lang/NumberFormatException;-><init>(Ljava/lang/String;)V

    throw v0
.end method

.method public static n(Landroid/content/Context;Ljava/lang/String;)I
    .locals 5

    invoke-static {}, Landroid/os/Process;->myPid()I

    move-result v0

    invoke-static {}, Landroid/os/Process;->myUid()I

    move-result v1

    invoke-virtual {p0}, Landroid/content/Context;->getPackageName()Ljava/lang/String;

    move-result-object v2

    invoke-virtual {p0, p1, v0, v1}, Landroid/content/Context;->checkPermission(Ljava/lang/String;II)I

    move-result v0

    const/4 v3, -0x1

    if-ne v0, v3, :cond_0

    goto :goto_3

    :cond_0
    invoke-static {p1}, Lu/b;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object p1

    const/4 v0, 0x0

    if-nez p1, :cond_1

    goto :goto_2

    :cond_1
    if-nez v2, :cond_3

    invoke-virtual {p0}, Landroid/content/Context;->getPackageManager()Landroid/content/pm/PackageManager;

    move-result-object v2

    invoke-virtual {v2, v1}, Landroid/content/pm/PackageManager;->getPackagesForUid(I)[Ljava/lang/String;

    move-result-object v2

    if-eqz v2, :cond_8

    array-length v4, v2

    if-gtz v4, :cond_2

    goto :goto_3

    :cond_2
    aget-object v2, v2, v0

    :cond_3
    invoke-static {}, Landroid/os/Process;->myUid()I

    move-result v3

    invoke-virtual {p0}, Landroid/content/Context;->getPackageName()Ljava/lang/String;

    move-result-object v4

    if-ne v3, v1, :cond_4

    invoke-static {v4, v2}, Ld0/b;->a(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v3

    if-eqz v3, :cond_4

    const/4 v3, 0x1

    goto :goto_0

    :cond_4
    move v3, v0

    :goto_0
    if-eqz v3, :cond_6

    invoke-static {p0}, Lu/c;->c(Landroid/content/Context;)Landroid/app/AppOpsManager;

    move-result-object v3

    invoke-static {}, Landroid/os/Binder;->getCallingUid()I

    move-result v4

    invoke-static {v3, p1, v4, v2}, Lu/c;->a(Landroid/app/AppOpsManager;Ljava/lang/String;ILjava/lang/String;)I

    move-result v2

    if-eqz v2, :cond_5

    goto :goto_1

    :cond_5
    invoke-static {p0}, Lu/c;->b(Landroid/content/Context;)Ljava/lang/String;

    move-result-object p0

    invoke-static {v3, p1, v1, p0}, Lu/c;->a(Landroid/app/AppOpsManager;Ljava/lang/String;ILjava/lang/String;)I

    move-result v2

    goto :goto_1

    :cond_6
    const-class v1, Landroid/app/AppOpsManager;

    invoke-static {p0, v1}, Lu/b;->a(Landroid/content/Context;Ljava/lang/Class;)Ljava/lang/Object;

    move-result-object p0

    check-cast p0, Landroid/app/AppOpsManager;

    invoke-static {p0, p1, v2}, Lu/b;->c(Landroid/app/AppOpsManager;Ljava/lang/String;Ljava/lang/String;)I

    move-result v2

    :goto_1
    if-nez v2, :cond_7

    :goto_2
    move v3, v0

    goto :goto_3

    :cond_7
    const/4 v3, -0x2

    :cond_8
    :goto_3
    return v3
.end method

.method public static o(III)I
    .locals 0

    if-ge p0, p1, :cond_0

    return p1

    :cond_0
    if-le p0, p2, :cond_1

    return p2

    :cond_1
    return p0
.end method

.method public static p(I)La1/a;
    .locals 1

    if-eqz p0, :cond_1

    const/4 v0, 0x1

    if-eq p0, v0, :cond_0

    new-instance p0, Lb2/i;

    invoke-direct {p0}, Lb2/i;-><init>()V

    return-object p0

    :cond_0
    new-instance p0, Lb2/d;

    invoke-direct {p0}, Lb2/d;-><init>()V

    return-object p0

    :cond_1
    new-instance p0, Lb2/i;

    invoke-direct {p0}, Lb2/i;-><init>()V

    return-object p0
.end method

.method public static final q(Ljava/lang/Throwable;)Lc3/b$a;
    .locals 1

    const-string v0, "exception"

    invoke-static {v0, p0}, Lj3/c;->d(Ljava/lang/String;Ljava/lang/Object;)V

    new-instance v0, Lc3/b$a;

    invoke-direct {v0, p0}, Lc3/b$a;-><init>(Ljava/lang/Throwable;)V

    return-object v0
.end method

.method public static r(Ljava/lang/String;)Ljava/lang/String;
    .locals 1

    const-string v0, "https://github.com/google/gson/blob/main/Troubleshooting.md#"

    invoke-virtual {v0, p0}, Ljava/lang/String;->concat(Ljava/lang/String;)Ljava/lang/String;

    move-result-object p0

    return-object p0
.end method

.method public static s(Landroid/content/Context;II)I
    .locals 0

    invoke-static {p0, p1}, Lx1/b;->a(Landroid/content/Context;I)Landroid/util/TypedValue;

    move-result-object p1

    if-eqz p1, :cond_1

    iget p2, p1, Landroid/util/TypedValue;->resourceId:I

    if-eqz p2, :cond_0

    sget-object p1, Lv/a;->a:Ljava/lang/Object;

    invoke-static {p0, p2}, Lv/a$d;->a(Landroid/content/Context;I)I

    move-result p0

    goto :goto_0

    :cond_0
    iget p0, p1, Landroid/util/TypedValue;->data:I

    :goto_0
    return p0

    :cond_1
    return p2
.end method

.method public static t(Landroid/view/View;I)I
    .locals 2

    invoke-virtual {p0}, Landroid/view/View;->getContext()Landroid/content/Context;

    move-result-object v0

    invoke-virtual {p0}, Landroid/view/View;->getContext()Landroid/content/Context;

    move-result-object v1

    invoke-virtual {p0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    move-result-object p0

    invoke-virtual {p0}, Ljava/lang/Class;->getCanonicalName()Ljava/lang/String;

    move-result-object p0

    invoke-static {p1, v1, p0}, Lx1/b;->c(ILandroid/content/Context;Ljava/lang/String;)Landroid/util/TypedValue;

    move-result-object p0

    iget p1, p0, Landroid/util/TypedValue;->resourceId:I

    if-eqz p1, :cond_0

    sget-object p0, Lv/a;->a:Ljava/lang/Object;

    invoke-static {v0, p1}, Lv/a$d;->a(Landroid/content/Context;I)I

    move-result p0

    goto :goto_0

    :cond_0
    iget p0, p0, Landroid/util/TypedValue;->data:I

    :goto_0
    return p0
.end method

.method public static final v(Ljava/lang/Object;)Ljava/lang/String;
    .locals 0

    invoke-static {p0}, Ljava/lang/System;->identityHashCode(Ljava/lang/Object;)I

    move-result p0

    invoke-static {p0}, Ljava/lang/Integer;->toHexString(I)Ljava/lang/String;

    move-result-object p0

    return-object p0
.end method

.method public static final w(Ln3/a;)Ljava/lang/Class;
    .locals 2

    const-string v0, "<this>"

    invoke-static {v0, p0}, Lj3/c;->d(Ljava/lang/String;Ljava/lang/Object;)V

    check-cast p0, Lj3/a;

    invoke-interface {p0}, Lj3/a;->a()Ljava/lang/Class;

    move-result-object p0

    invoke-virtual {p0}, Ljava/lang/Class;->isPrimitive()Z

    move-result v0

    if-nez v0, :cond_0

    return-object p0

    :cond_0
    invoke-virtual {p0}, Ljava/lang/Class;->getName()Ljava/lang/String;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/String;->hashCode()I

    move-result v1

    sparse-switch v1, :sswitch_data_0

    goto/16 :goto_0

    :sswitch_0
    const-string v1, "short"

    invoke-virtual {v0, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-nez v0, :cond_1

    goto/16 :goto_0

    :cond_1
    const-class p0, Ljava/lang/Short;

    goto/16 :goto_0

    :sswitch_1
    const-string v1, "float"

    invoke-virtual {v0, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-nez v0, :cond_2

    goto :goto_0

    :cond_2
    const-class p0, Ljava/lang/Float;

    goto :goto_0

    :sswitch_2
    const-string v1, "boolean"

    invoke-virtual {v0, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-nez v0, :cond_3

    goto :goto_0

    :cond_3
    const-class p0, Ljava/lang/Boolean;

    goto :goto_0

    :sswitch_3
    const-string v1, "void"

    invoke-virtual {v0, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-nez v0, :cond_4

    goto :goto_0

    :cond_4
    const-class p0, Ljava/lang/Void;

    goto :goto_0

    :sswitch_4
    const-string v1, "long"

    invoke-virtual {v0, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-nez v0, :cond_5

    goto :goto_0

    :cond_5
    const-class p0, Ljava/lang/Long;

    goto :goto_0

    :sswitch_5
    const-string v1, "char"

    invoke-virtual {v0, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-nez v0, :cond_6

    goto :goto_0

    :cond_6
    const-class p0, Ljava/lang/Character;

    goto :goto_0

    :sswitch_6
    const-string v1, "byte"

    invoke-virtual {v0, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-nez v0, :cond_7

    goto :goto_0

    :cond_7
    const-class p0, Ljava/lang/Byte;

    goto :goto_0

    :sswitch_7
    const-string v1, "int"

    invoke-virtual {v0, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-nez v0, :cond_8

    goto :goto_0

    :cond_8
    const-class p0, Ljava/lang/Integer;

    goto :goto_0

    :sswitch_8
    const-string v1, "double"

    invoke-virtual {v0, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-nez v0, :cond_9

    goto :goto_0

    :cond_9
    const-class p0, Ljava/lang/Double;

    :goto_0
    return-object p0

    nop

    :sswitch_data_0
    .sparse-switch
        -0x4f08842f -> :sswitch_8
        0x197ef -> :sswitch_7
        0x2e6108 -> :sswitch_6
        0x2e9356 -> :sswitch_5
        0x32c67c -> :sswitch_4
        0x375194 -> :sswitch_3
        0x3db6c28 -> :sswitch_2
        0x5d0225c -> :sswitch_1
        0x685847c -> :sswitch_0
    .end sparse-switch
.end method

.method public static final x(Le3/f;Ljava/lang/Throwable;)V
    .locals 3

    :try_start_0
    sget-object v0, Lq3/b$a;->a:Lq3/b$a;

    invoke-interface {p0, v0}, Le3/f;->get(Le3/f$b;)Le3/f$a;

    move-result-object v0

    check-cast v0, Lq3/b;
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    if-nez v0, :cond_0

    invoke-static {p0, p1}, Lq3/c;->a(Le3/f;Ljava/lang/Throwable;)V

    return-void

    :cond_0
    :try_start_1
    invoke-interface {v0, p0, p1}, Lq3/b;->handleException(Le3/f;Ljava/lang/Throwable;)V
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    return-void

    :catchall_0
    move-exception v0

    if-ne p1, v0, :cond_1

    goto :goto_0

    :cond_1
    new-instance v1, Ljava/lang/RuntimeException;

    const-string v2, "Exception while trying to handle coroutine exception"

    invoke-direct {v1, v2, v0}, Ljava/lang/RuntimeException;-><init>(Ljava/lang/String;Ljava/lang/Throwable;)V

    invoke-static {v1, p1}, La1/a;->d(Ljava/lang/Throwable;Ljava/lang/Throwable;)V

    move-object p1, v1

    :goto_0
    invoke-static {p0, p1}, Lq3/c;->a(Le3/f;Ljava/lang/Throwable;)V

    return-void
.end method

.method public static y(I)Z
    .locals 20

    if-eqz p0, :cond_5

    sget-object v1, Lx/a;->a:Ljava/lang/ThreadLocal;

    invoke-virtual {v1}, Ljava/lang/ThreadLocal;->get()Ljava/lang/Object;

    move-result-object v2

    check-cast v2, [D

    const/4 v3, 0x3

    if-nez v2, :cond_0

    new-array v2, v3, [D

    invoke-virtual {v1, v2}, Ljava/lang/ThreadLocal;->set(Ljava/lang/Object;)V

    :cond_0
    invoke-static/range {p0 .. p0}, Landroid/graphics/Color;->red(I)I

    move-result v1

    invoke-static/range {p0 .. p0}, Landroid/graphics/Color;->green(I)I

    move-result v4

    invoke-static/range {p0 .. p0}, Landroid/graphics/Color;->blue(I)I

    move-result v5

    array-length v6, v2

    if-ne v6, v3, :cond_4

    int-to-double v6, v1

    const-wide v8, 0x406fe00000000000L    # 255.0

    div-double/2addr v6, v8

    const-wide v10, 0x3fa4b5dcc63f1412L    # 0.04045

    cmpg-double v1, v6, v10

    const-wide v12, 0x4003333333333333L    # 2.4

    const-wide v14, 0x3ff0e147ae147ae1L    # 1.055

    const-wide v16, 0x4029d70a3d70a3d7L    # 12.92

    const-wide v18, 0x3fac28f5c28f5c29L    # 0.055

    if-gez v1, :cond_1

    div-double v6, v6, v16

    goto :goto_0

    :cond_1
    add-double v6, v6, v18

    div-double/2addr v6, v14

    invoke-static {v6, v7, v12, v13}, Ljava/lang/Math;->pow(DD)D

    move-result-wide v6

    :goto_0
    int-to-double v3, v4

    div-double/2addr v3, v8

    cmpg-double v1, v3, v10

    if-gez v1, :cond_2

    div-double v3, v3, v16

    goto :goto_1

    :cond_2
    add-double v3, v3, v18

    div-double/2addr v3, v14

    invoke-static {v3, v4, v12, v13}, Ljava/lang/Math;->pow(DD)D

    move-result-wide v3

    :goto_1
    int-to-double v0, v5

    div-double/2addr v0, v8

    cmpg-double v5, v0, v10

    if-gez v5, :cond_3

    div-double v0, v0, v16

    goto :goto_2

    :cond_3
    add-double v0, v0, v18

    div-double/2addr v0, v14

    invoke-static {v0, v1, v12, v13}, Ljava/lang/Math;->pow(DD)D

    move-result-wide v0

    :goto_2
    const-wide v8, 0x3fda64c2f837b4a2L    # 0.4124

    mul-double/2addr v8, v6

    const-wide v10, 0x3fd6e2eb1c432ca5L    # 0.3576

    mul-double/2addr v10, v3

    add-double/2addr v10, v8

    const-wide v8, 0x3fc71a9fbe76c8b4L    # 0.1805

    mul-double/2addr v8, v0

    add-double/2addr v8, v10

    const-wide/high16 v10, 0x4059000000000000L    # 100.0

    mul-double/2addr v8, v10

    const/4 v5, 0x0

    aput-wide v8, v2, v5

    const-wide v8, 0x3fcb367a0f9096bcL    # 0.2126

    mul-double/2addr v8, v6

    const-wide v12, 0x3fe6e2eb1c432ca5L    # 0.7152

    mul-double/2addr v12, v3

    add-double/2addr v12, v8

    const-wide v8, 0x3fb27bb2fec56d5dL    # 0.0722

    mul-double/2addr v8, v0

    add-double/2addr v8, v12

    mul-double/2addr v8, v10

    const/4 v12, 0x1

    aput-wide v8, v2, v12

    const-wide v13, 0x3f93c36113404ea5L    # 0.0193

    mul-double/2addr v6, v13

    const-wide v13, 0x3fbe83e425aee632L    # 0.1192

    mul-double/2addr v3, v13

    add-double/2addr v3, v6

    const-wide v6, 0x3fee6a7ef9db22d1L    # 0.9505

    mul-double/2addr v0, v6

    add-double/2addr v0, v3

    mul-double/2addr v0, v10

    const/4 v3, 0x2

    aput-wide v0, v2, v3

    div-double/2addr v8, v10

    const-wide/high16 v0, 0x3fe0000000000000L    # 0.5

    cmpl-double v0, v8, v0

    if-lez v0, :cond_6

    move v0, v12

    goto :goto_3

    :cond_4
    new-instance v0, Ljava/lang/IllegalArgumentException;

    const-string v1, "outXyz must have a length of 3."

    invoke-direct {v0, v1}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    throw v0

    :cond_5
    const/4 v5, 0x0

    :cond_6
    move v0, v5

    :goto_3
    return v0
.end method

.method public static z(Landroid/view/MotionEvent;I)Z
    .locals 0

    invoke-virtual {p0}, Landroid/view/MotionEvent;->getSource()I

    move-result p0

    and-int/2addr p0, p1

    if-ne p0, p1, :cond_0

    const/4 p0, 0x1

    goto :goto_0

    :cond_0
    const/4 p0, 0x0

    :goto_0
    return p0
.end method


# virtual methods
.method public b(Landroid/view/View;)V
    .locals 0

    return-void
.end method

.method public c()V
    .locals 0

    return-void
.end method

.method public u(FFLb2/m;)V
    .locals 0

    const/4 p0, 0x0

    throw p0
.end method
