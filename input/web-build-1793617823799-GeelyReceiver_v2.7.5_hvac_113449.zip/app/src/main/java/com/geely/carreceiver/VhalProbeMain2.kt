package com.geely.carreceiver

import android.content.Context
import android.os.Looper

/**
 * Second-generation standalone probe, launched the exact same way as [VhalProbeMain]
 * (`su 1000 app_process -Djava.class.path=<apk> / com.geely.carreceiver.VhalProbeMain2`).
 *
 * [VhalProbeMain] proved that uid=1000 + a bootstrapped system Context lets this code run, but its
 * attempt to reach CarPropertyManager via the normal `android.car.Car.createCar(context)` path failed
 * with a *different* problem than the one we set out to test: ActivityManagerService rejected the
 * underlying `bindService()` call with "Unable to find app for caller" - a process started directly by
 * `app_process` has no ProcessRecord in AMS, so this bind never gets anywhere near the
 * android.car.permission.* check we actually want to test. That failure says nothing about whether
 * uid=1000 can write the blocked properties - the real question is still open.
 *
 * This probe instead goes through [VhalDirectAccess], which fetches the car_service connection
 * straight from ServiceManager (no AMS involved at all), then tries to build a genuine
 * android.car.Car object from it by reflection-probing android.car.Car's real constructors/factory
 * methods on THIS ROM. If that succeeds, it reuses [VhalAccess]'s already-proven describeValue/setBool
 * code unchanged to run the exact same DOME_LIGHT / MIRROR_FOLD read-write-read-restore probe
 * [VhalProbeMain] was meant to run. If it does not succeed, it prints every constructor/method it
 * tried and why, so the next attempt can be built from real data instead of another guess.
 */
object VhalProbeMain2 {

    @JvmStatic
    fun main(args: Array<String>) {
        val watchdog = Thread {
            try {
                Thread.sleep(15_000)
            } catch (ignored: InterruptedException) {
                return@Thread
            }
            System.out.println("WATCHDOG: forcing exit after 15s (nothing should normally take this long)")
            System.out.flush()
            Runtime.getRuntime().halt(1)
        }
        watchdog.isDaemon = true
        watchdog.start()

        println("== VhalProbeMain2 (direct ServiceManager path) ==")
        try {
            println("uid=" + android.os.Process.myUid() + " pid=" + android.os.Process.myPid())

            if (Looper.myLooper() == null) Looper.prepareMainLooper()

            val activityThreadClass = Class.forName("android.app.ActivityThread")
            val systemMain = activityThreadClass.getMethod("systemMain")
            val thread = systemMain.invoke(null)
            val getSystemContext = activityThreadClass.getMethod("getSystemContext")
            val context = getSystemContext.invoke(thread) as Context
            println("context ok: package=" + context.packageName)

            val mgr = VhalDirectAccess.manager(context)
            println("--- VhalDirectAccess log ---")
            println(VhalDirectAccess.lastLog)
            println("-----------------------------")
            if (mgr == null) {
                println("VHAL manager (direct path) FAILED: " + (VhalDirectAccess.lastError ?: "unknown reason"))
                println("== done (no properties tested) ==")
                return
            }
            println("VHAL manager (direct path) OK: " + mgr.javaClass.name)

            // Sanity check: a standard AOSP property every car implements and that is continuously
            // pushed by the real VHAL (current vehicle speed, type FLOAT) - if THIS also comes back as
            // a fixed placeholder (status/timestamp never changing across repeated reads a moment
            // apart), that proves the problem is this connection itself returning stub/default data,
            // not something specific to DOME_LIGHT/MIRROR_FOLD or their area id.
            println("--- sanity check: PERF_VEHICLE_SPEED (standard, should be LIVE) ---")
            println("config:  " + VhalAccess.describeProperty(mgr, 0x11600207))
            println("read 1:  " + VhalAccess.describeFull(mgr, 0x11600207, 0x0, java.lang.Float::class.java))
            try { Thread.sleep(500) } catch (ignored: InterruptedException) {}
            println("read 2:  " + VhalAccess.describeFull(mgr, 0x11600207, 0x0, java.lang.Float::class.java))

            // FUEL_CAP_PROP (0x11200308, real name FUEL_DOOR_OPEN) is - unlike DOME_LIGHT/MIRROR_FOLD -
            // a SYSTEM-group property (bits 0xf0000000 = 0x10000000), exactly like PERF_VEHICLE_SPEED
            // above, and BOOLEAN-typed (bits 0x00ff0000 = 0x00200000). If the earlier VENDOR-group
            // properties are being gated by something car_service applies only to VENDOR properties,
            // this one should behave like the speed sanity check (real status/timestamp, value actually
            // flips) rather than like DOME_LIGHT/MIRROR_FOLD (areas=[], status=3, timestamp=0, frozen).
            probeBool("FUEL_CAP (fuel door)", mgr, 0x11200308, 0x0)

            probe("DOME_LIGHT (interior light)", mgr, 0x21402069, 0x0)
            probe("MIRROR_FOLD", mgr, 0x21402023, 0x0)

            // 2026-11-02: fresh dumpsys car_service shows EVERY single HVAC/climate property on this car
            // is access=0x3 (READ_WRITE) - not one is access=0x1 (read-only) like PERF_VEHICLE_SPEED. If
            // "access includes WRITE -> car_service returns a stub/filtered value no matter the caller" is
            // really the rule (as FUEL_CAP/DOME_LIGHT/MIRROR_FOLD all suggest, regardless of VENDOR vs
            // SYSTEM group), climate should fail the exact same way. These two are the most central climate
            // controls (real ids from this car's own catalogue, not guessed): HVAC_AC_ON (SYSTEM group per
            // its id bits, like FUEL_CAP) and HVAC_POWER_ON (VENDOR group, like MIRROR_FOLD/DOME_LIGHT;
            // area=75 is this car's own dumped areaId for it, not a guess - not a clean single-bit seat
            // mask, so it is used exactly as dumped rather than reinterpreted).
            probe("HVAC_AC_ON (climate: AC compressor)", mgr, 0x21401023, 0x0)
            probe("HVAC_POWER_ON (climate: master power)", mgr, 0x2140102e, 75)

            println("== done ==")
        } catch (e: Throwable) {
            println("FATAL: " + e.javaClass.name + ": " + e.message)
        } finally {
            System.out.flush()
            Runtime.getRuntime().halt(0)
        }
    }

    private fun probe(label: String, mgr: Any, propId: Int, area: Int) {
        println("--- $label (prop=0x${propId.toString(16)} area=0x${area.toString(16)}) ---")
        // The property id's own type bits (bits 0x00ff0000) say this is INT32, not BOOLEAN - the
        // earlier run of this probe used setBooleanProperty/getBooleanProperty on an INT32 property,
        // a type mismatch that CarPropertyManager accepted without throwing (ok=true) but which never
        // actually reached the VHAL as a real value change. describeProperty() below prints this car's
        // own declared type/access/areas for the property, straight from its real CarPropertyConfig,
        // so we are no longer going on the id's bit pattern alone.
        println("config:      " + VhalAccess.describeProperty(mgr, propId))
        println("before:      " + VhalAccess.describeValue(mgr, propId, area))
        // status/timestamp alongside the raw value - a set() that reports ok=true but never changes
        // the readback can mean the VHAL itself reports this property UNAVAILABLE or ERROR, which the
        // plain int/bool getters never reveal on their own.
        println("before full: " + VhalAccess.describeFull(mgr, propId, area))
        val on = VhalAccess.setInt(mgr, propId, area, 1)
        println("set int 1 -> ok=${on.ok}  ${on.message}")
        try { Thread.sleep(600) } catch (ignored: InterruptedException) {}
        println("after 1:     " + VhalAccess.describeValue(mgr, propId, area))
        println("after 1 full:" + VhalAccess.describeFull(mgr, propId, area))
        val off = VhalAccess.setInt(mgr, propId, area, 0)
        println("set int 0 -> ok=${off.ok}  ${off.message}")
        try { Thread.sleep(600) } catch (ignored: InterruptedException) {}
        println("after 0:     " + VhalAccess.describeValue(mgr, propId, area))
        println("after 0 full:" + VhalAccess.describeFull(mgr, propId, area))
    }

    /** Same shape as [probe] but for a genuinely BOOLEAN-typed property (confirmed via this car's own
     *  CarPropertyConfig, not guessed from the id's bits), using setBool/describeFull(Boolean) instead
     *  of the int path - FUEL_CAP_PROP is a real on/off door, so this also restores it to CLOSED
     *  (false) at the end regardless of what the probe found, to avoid leaving the fuel door open. */
    private fun probeBool(label: String, mgr: Any, propId: Int, area: Int) {
        println("--- $label (prop=0x${propId.toString(16)} area=0x${area.toString(16)}) ---")
        println("config:      " + VhalAccess.describeProperty(mgr, propId))
        println("before:      " + VhalAccess.describeValue(mgr, propId, area))
        println("before full: " + VhalAccess.describeFull(mgr, propId, area, java.lang.Boolean::class.java))
        val on = VhalAccess.setBool(mgr, propId, area, true)
        println("set true (OPEN) -> ok=${on.ok}  ${on.message}")
        try { Thread.sleep(800) } catch (ignored: InterruptedException) {}
        println("after open:     " + VhalAccess.describeValue(mgr, propId, area))
        println("after open full:" + VhalAccess.describeFull(mgr, propId, area, java.lang.Boolean::class.java))
        val off = VhalAccess.setBool(mgr, propId, area, false)
        println("set false (CLOSE, restore) -> ok=${off.ok}  ${off.message}")
        try { Thread.sleep(800) } catch (ignored: InterruptedException) {}
        println("after close:     " + VhalAccess.describeValue(mgr, propId, area))
        println("after close full:" + VhalAccess.describeFull(mgr, propId, area, java.lang.Boolean::class.java))
    }
}
