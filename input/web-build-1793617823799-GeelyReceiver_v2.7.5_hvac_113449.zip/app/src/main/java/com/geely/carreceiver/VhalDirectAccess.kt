package com.geely.carreceiver

import android.content.Context
import java.lang.reflect.InvocationTargetException

/**
 * A second way to reach android.car's CarPropertyManager, for use ONLY from a process that
 * ActivityManagerService has no record of (such as one launched directly via `app_process` from a
 * root shell, outside the normal Zygote fork -> attachApplication() handshake every real app goes
 * through).
 *
 * [VhalAccess.manager] goes through `android.car.Car.createCar(context)`, which on this ROM resolves
 * to a `Context.bindService()` call against the `android.car.ICar` / `com.android.car` service. That
 * call is mediated by ActivityManagerService, which must already have a ProcessRecord for the calling
 * pid to process it. A process started by `app_process` directly (as this probe is) has no such
 * ProcessRecord, so the bind fails immediately with:
 *   SecurityException: Unable to find app for caller ... when binding service Intent { act=android.car.ICar ... }
 * This happens before any android.car.permission.* check is even reached - it is unrelated to this
 * app's uid or signature, and would happen the same way even running as uid=0.
 *
 * This class instead fetches the car_service Binder straight from the system's ServiceManager
 * registry - a flat name -> IBinder lookup (the same mechanism `dumpsys` itself uses) that has no
 * concept of "which app is calling" at all, so it works regardless of whether AMS recognizes this
 * process. From that raw ICar Binder, it tries to build a real, fully-functional android.car.Car
 * object (so the rest of the codebase - [VhalAccess.describeValue], [VhalAccess.setBool], etc. - can
 * be reused completely unchanged once this succeeds).
 *
 * Every step logs exactly what it tried and what it found, because the exact constructor/factory
 * shape android.car.Car exposes for "wrap an existing ICar connection" is undocumented and can differ
 * by AOSP version - this is written to discover the real shape on THIS ROM from real reflection data,
 * not to assume one in advance.
 */
object VhalDirectAccess {

    @Volatile private var cachedCar: Any? = null
    @Volatile var lastError: String? = null
        private set
    @Volatile var lastLog: String = ""
        private set
    private val lock = Any()

    private fun describe(t: Throwable): String {
        val name = t.javaClass.simpleName
        val msg = t.message
        return if (msg.isNullOrBlank()) name else "$name: $msg"
    }

    /** Step 1: the raw car_service Binder, straight from ServiceManager - no AMS involved. */
    private fun getCarServiceBinder(): android.os.IBinder? {
        val smClass = Class.forName("android.os.ServiceManager")
        val getService = smClass.getMethod("getService", String::class.java)
        return getService.invoke(null, "car_service") as? android.os.IBinder
    }

    /** Step 2: wrap it as the ICar AIDL interface (android.car.ICar\$Stub.asInterface). */
    private fun asICar(binder: android.os.IBinder): Any {
        val stubClass = Class.forName("android.car.ICar\$Stub")
        val asInterface = stubClass.getMethod("asInterface", android.os.IBinder::class.java)
        return asInterface.invoke(null, binder)
            ?: throw IllegalStateException("ICar.Stub.asInterface(binder) returned null")
    }

    /**
     * Step 3: turn a live ICar interface into a real android.car.Car object, by finding whichever
     * constructor or factory method on android.car.Car accepts something ICar-shaped. Tries every
     * declared constructor and every static method, in order, logging each attempt.
     */
    private fun buildCarFrom(context: Context, iCar: Any, log: StringBuilder): Any? {
        val carClass = Class.forName("android.car.Car")
        val iCarClass = Class.forName("android.car.ICar")

        // --- Try constructors: look for one whose parameter types include Context and something
        //     ICar-assignable (iCarClass.isAssignableFrom(paramType)). ---
        for (ctor in carClass.declaredConstructors) {
            val params = ctor.parameterTypes
            log.append("ctor candidate: Car(").append(params.joinToString(", ") { it.name }).append(")\n")
            val hasContext = params.any { it.isAssignableFrom(context.javaClass) || it == Context::class.java }
            val iCarIdx = params.indexOfFirst { it.isAssignableFrom(iCar.javaClass) || it == iCarClass }
            if (!hasContext || iCarIdx < 0) continue
            try {
                ctor.isAccessible = true
                val args = arrayOfNulls<Any?>(params.size)
                for (i in params.indices) {
                    args[i] = when {
                        i == iCarIdx -> iCar
                        params[i] == Context::class.java -> context
                        params[i] == android.os.Handler::class.java -> null
                        else -> null
                    }
                }
                val car = ctor.newInstance(*args)
                log.append("  -> SUCCESS via this constructor\n")
                return car
            } catch (e: Throwable) {
                log.append("  -> failed: ").append(describe((e as? InvocationTargetException)?.targetException ?: e)).append("\n")
            }
        }

        // --- Try static factory methods on Car that accept an ICar-shaped or IBinder-shaped arg. ---
        for (m in carClass.declaredMethods) {
            if (!java.lang.reflect.Modifier.isStatic(m.modifiers)) continue
            if (!carClass.isAssignableFrom(m.returnType) && m.returnType != carClass) continue
            val params = m.parameterTypes
            val iCarIdx = params.indexOfFirst { it.isAssignableFrom(iCar.javaClass) || it == iCarClass }
            if (iCarIdx < 0) continue
            log.append("static candidate: ${m.name}(").append(params.joinToString(", ") { it.name }).append(")\n")
            try {
                m.isAccessible = true
                val args = arrayOfNulls<Any?>(params.size)
                for (i in params.indices) {
                    args[i] = when {
                        i == iCarIdx -> iCar
                        params[i] == Context::class.java -> context
                        params[i] == android.os.Handler::class.java -> null
                        else -> null
                    }
                }
                val car = m.invoke(null, *args)
                if (car != null) {
                    log.append("  -> SUCCESS via this static method\n")
                    return car
                }
                log.append("  -> returned null\n")
            } catch (e: Throwable) {
                log.append("  -> failed: ").append(describe((e as? InvocationTargetException)?.targetException ?: e)).append("\n")
            }
        }
        return null
    }

    /**
     * Full chain: ServiceManager -> ICar -> (constructor/factory discovery) -> Car object
     * -> getCarManager("property"). Returns the same kind of CarPropertyManager-ish object
     * [VhalAccess.manager] returns, so [VhalAccess.describeValue]/[setBool]/[setInt] work unchanged
     * on it, or null with [lastError] / [lastLog] set to exactly what was tried.
     */
    fun manager(context: Context): Any? = synchronized(lock) {
        cachedCar?.let { car ->
            return try {
                val getCarManager = car.javaClass.getMethod("getCarManager", String::class.java)
                getCarManager.invoke(car, "property")
            } catch (e: Exception) {
                lastError = describe(e); null
            }
        }
        val log = StringBuilder()
        try {
            log.append("Fetching car_service binder from ServiceManager...\n")
            val binder = getCarServiceBinder()
                ?: throw IllegalStateException("ServiceManager.getService(\"car_service\") returned null")
            log.append("  -> got binder, interfaceDescriptor=").append(binder.interfaceDescriptor).append("\n")

            log.append("Wrapping as ICar...\n")
            val iCar = asICar(binder)
            log.append("  -> ICar instance: ").append(iCar.javaClass.name).append("\n")

            log.append("Building android.car.Car from this ICar (trying all constructors/factories)...\n")
            val car = buildCarFrom(context, iCar, log)
            if (car == null) {
                lastLog = log.toString()
                throw IllegalStateException("No constructor or static method on android.car.Car accepted this ICar instance - see lastLog")
            }
            cachedCar = car
            log.append("Calling car.getCarManager(\"property\")...\n")
            val getCarManager = car.javaClass.getMethod("getCarManager", String::class.java)
            val mgr = getCarManager.invoke(car, "property")
            log.append(if (mgr != null) "  -> SUCCESS, got a property manager\n" else "  -> returned null\n")
            lastLog = log.toString()
            mgr
        } catch (e: InvocationTargetException) {
            lastLog = log.toString()
            lastError = describe(e.targetException ?: e)
            null
        } catch (e: Exception) {
            lastLog = log.toString()
            lastError = describe(e)
            null
        }
    }
}
