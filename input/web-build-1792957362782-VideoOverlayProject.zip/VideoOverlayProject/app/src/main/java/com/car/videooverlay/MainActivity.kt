package com.car.videooverlay

import android.content.Intent
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.widget.Button
import android.widget.CheckBox
import android.widget.SeekBar
import android.widget.TextView
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import android.preference.PreferenceManager

class MainActivity : AppCompatActivity() {

    private var selectedVideoUri: Uri? = null
    private lateinit var statusText: TextView
    private lateinit var opacitySeekBar: SeekBar
    private lateinit var muteCheckBox: CheckBox
    private lateinit var autoStartCheckBox: CheckBox

    private val prefs by lazy { PreferenceManager.getDefaultSharedPreferences(this) }

    private val pickVideo = registerForActivityResult(
        ActivityResultContracts.OpenDocument()
    ) { uri ->
        if (uri != null) {
            try {
                contentResolver.takePersistableUriPermission(
                    uri,
                    Intent.FLAG_GRANT_READ_URI_PERMISSION
                )
            } catch (_: SecurityException) {
                // Some document providers do not support persistable grants.
            } catch (_: IllegalArgumentException) {
                // Provider returned a URI that cannot be persisted.
            }

            selectedVideoUri = uri
            prefs.edit().putString("last_video_uri", uri.toString()).apply()
            statusText.text = "تم اختيار الفيديو"
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        statusText = findViewById(R.id.statusText)
        opacitySeekBar = findViewById(R.id.opacitySeekBar)
        muteCheckBox = findViewById(R.id.muteCheckBox)
        autoStartCheckBox = findViewById(R.id.autoStartCheckBox)

        findViewById<Button>(R.id.btnSelectVideo).setOnClickListener {
            pickVideo.launch(arrayOf("video/*"))
        }

        findViewById<Button>(R.id.btnStart).setOnClickListener {
            val uri = selectedVideoUri
            if (uri == null) {
                Toast.makeText(this, "اختر فيديو أولاً", Toast.LENGTH_SHORT).show()
            } else {
                checkPermissionAndStart(uri)
            }
        }

        findViewById<Button>(R.id.btnStop).setOnClickListener {
            stopService(Intent(this, VideoOverlayService::class.java))
            statusText.text = "تم الإيقاف"
        }

        opacitySeekBar.max = 100
        opacitySeekBar.progress = (prefs.getFloat("opacity", 1f) * 100f)
            .toInt().coerceIn(0, 100)
        muteCheckBox.isChecked = prefs.getBoolean("muted", true)
        autoStartCheckBox.isChecked = prefs.getBoolean("auto_start", false)

        val lastUri = prefs.getString("last_video_uri", null)
        if (!lastUri.isNullOrBlank()) {
            selectedVideoUri = Uri.parse(lastUri)
            statusText.text = "آخر فيديو محفوظ"
        }

        opacitySeekBar.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(seekBar: SeekBar?, progress: Int, fromUser: Boolean) = Unit
            override fun onStartTrackingTouch(seekBar: SeekBar?) = Unit
            override fun onStopTrackingTouch(seekBar: SeekBar?) {
                prefs.edit().putFloat("opacity", opacitySeekBar.progress / 100f).apply()
            }
        })

        muteCheckBox.setOnCheckedChangeListener { _, checked ->
            prefs.edit().putBoolean("muted", checked).apply()
        }

        autoStartCheckBox.setOnCheckedChangeListener { _, checked ->
            prefs.edit().putBoolean("auto_start", checked).apply()
        }
    }

    private fun checkPermissionAndStart(uri: Uri) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M &&
            !Settings.canDrawOverlays(this)
        ) {
            val permissionIntent = Intent(
                Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                Uri.parse("package:$packageName")
            )
            overlayPermissionLauncher.launch(permissionIntent)
            Toast.makeText(
                this,
                "امنح صلاحية الظهور فوق التطبيقات ثم اضغط تشغيل مرة أخرى",
                Toast.LENGTH_LONG
            ).show()
            return
        }
        startOverlay(uri)
    }

    private val overlayPermissionLauncher = registerForActivityResult(
        ActivityResultContracts.StartActivityForResult()
    ) {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.M || Settings.canDrawOverlays(this)) {
            statusText.text = "تم منح صلاحية العرض؛ اضغط تشغيل"
        } else {
            statusText.text = "صلاحية العرض العائم غير مفعّلة"
        }
    }

    private fun startOverlay(uri: Uri) {
        val serviceIntent = Intent(this, VideoOverlayService::class.java).apply {
            putExtra("video_uri", uri.toString())
            putExtra("opacity", opacitySeekBar.progress / 100f)
            putExtra("muted", muteCheckBox.isChecked)
        }

        try {
            ContextCompat.startForegroundService(this, serviceIntent)
            statusText.text = "جارٍ تشغيل الفيديو العائم..."
        } catch (e: Exception) {
            statusText.text = "تعذّر تشغيل الخدمة: ${e.javaClass.simpleName}"
        }
    }
}
