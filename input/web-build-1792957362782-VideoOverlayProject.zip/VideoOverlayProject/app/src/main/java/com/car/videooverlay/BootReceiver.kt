package com.car.videooverlay

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.os.Build
import android.provider.Settings
import android.preference.PreferenceManager
import android.util.Log
import androidx.core.content.ContextCompat

class BootReceiver : BroadcastReceiver() {

    override fun onReceive(context: Context, intent: Intent?) {
        if (intent?.action != Intent.ACTION_BOOT_COMPLETED) return

        val prefs = PreferenceManager.getDefaultSharedPreferences(context)
        if (!prefs.getBoolean("auto_start", false)) return

        val lastUri = prefs.getString("last_video_uri", null)
        if (lastUri.isNullOrBlank()) return

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M &&
            !Settings.canDrawOverlays(context)
        ) {
            Log.w(TAG, "Overlay permission missing; open app and grant it manually")
            return
        }

        val serviceIntent = Intent(context, VideoOverlayService::class.java).apply {
            putExtra("video_uri", lastUri)
            putExtra("opacity", prefs.getFloat("opacity", 1f))
            putExtra("muted", prefs.getBoolean("muted", true))
        }

        try {
            ContextCompat.startForegroundService(context, serviceIntent)
        } catch (e: Exception) {
            Log.e(TAG, "Could not start overlay after boot", e)
        }
    }

    companion object {
        private const val TAG = "VideoOverlayBoot"
    }
}
