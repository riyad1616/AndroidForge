plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}
android {
    namespace = "com.coolray.navwidget"
    compileSdk = 34
    defaultConfig {
        applicationId = "com.coolray.navwidget"
        minSdk = 26
        targetSdk = 28
        versionCode = 4
        versionName = "1.4"
    }
}
