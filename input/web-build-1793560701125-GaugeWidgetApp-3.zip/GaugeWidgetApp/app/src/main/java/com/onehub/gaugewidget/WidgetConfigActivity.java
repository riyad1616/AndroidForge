package com.onehub.gaugewidget;

import android.app.Activity;
import android.appwidget.AppWidgetManager;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.Button;
import android.widget.GridView;
import android.widget.ImageView;

public class WidgetConfigActivity extends Activity {

    private int appWidgetId = AppWidgetManager.INVALID_APPWIDGET_ID;
    private String selectedStyle = "a";
    private GridView styleGrid;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_widget_config);
        setResult(RESULT_CANCELED);

        Intent intent = getIntent();
        Bundle extras = intent.getExtras();
        if (extras != null) {
            appWidgetId = extras.getInt(AppWidgetManager.EXTRA_APPWIDGET_ID, AppWidgetManager.INVALID_APPWIDGET_ID);
        }

        if (appWidgetId == AppWidgetManager.INVALID_APPWIDGET_ID) {
            finish();
            return;
        }

        styleGrid = findViewById(R.id.style_grid);
        styleGrid.setAdapter(new StyleAdapter());
        styleGrid.setOnItemClickListener((parent, view, position, id) -> {
            selectedStyle = GaugeWidgetProvider.STYLES[position];
            ((StyleAdapter) styleGrid.getAdapter()).setSelected(position);
        });

        Button applyBtn = findViewById(R.id.btn_apply);
        applyBtn.setOnClickListener(v -> {
            SharedPreferences.Editor prefs = getSharedPreferences(GaugeWidgetProvider.PREFS_NAME, MODE_PRIVATE).edit();
            prefs.putString(GaugeWidgetProvider.PREF_STYLE_PREFIX + appWidgetId, selectedStyle);
            prefs.apply();

            AppWidgetManager appWidgetManager = AppWidgetManager.getInstance(this);
            GaugeWidgetProvider.updateAppWidget(this, appWidgetManager, appWidgetId);

            Intent result = new Intent();
            result.putExtra(AppWidgetManager.EXTRA_APPWIDGET_ID, appWidgetId);
            setResult(RESULT_OK, result);
            finish();
        });
    }

    private class StyleAdapter extends BaseAdapter {
        private int selectedPos = 0;

        public void setSelected(int pos) {
            selectedPos = pos;
            notifyDataSetChanged();
        }

        @Override
        public int getCount() {
            return GaugeWidgetProvider.STYLES.length;
        }

        @Override
        public Object getItem(int position) {
            return GaugeWidgetProvider.STYLES[position];
        }

        @Override
        public long getItemId(int position) {
            return position;
        }

        @Override
        public View getView(int position, View convertView, ViewGroup parent) {
            ImageView imageView;
            if (convertView == null) {
                imageView = new ImageView(WidgetConfigActivity.this);
                imageView.setLayoutParams(new GridView.LayoutParams(
                        ViewGroup.LayoutParams.MATCH_PARENT, 280));
                imageView.setScaleType(ImageView.ScaleType.FIT_CENTER);
                imageView.setPadding(8, 8, 8, 8);
            } else {
                imageView = (ImageView) convertView;
            }

            String style = GaugeWidgetProvider.STYLES[position];
            int resId;
            if ("bmw".equals(style)) {
                resId = getResources().getIdentifier("gauge_bmw_bg", "drawable", getPackageName());
            } else {
                resId = getResources().getIdentifier("gauge_" + style + "1", "drawable", getPackageName());
            }
            imageView.setImageResource(resId);

            if (position == selectedPos) {
                imageView.setBackgroundColor(0xFF1A73E8);
            } else {
                imageView.setBackgroundColor(0x00000000);
            }

            return imageView;
        }
    }
}
