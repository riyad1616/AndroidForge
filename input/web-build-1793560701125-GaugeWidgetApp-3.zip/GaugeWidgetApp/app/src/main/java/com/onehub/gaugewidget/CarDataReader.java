package com.onehub.gaugewidget;

import android.content.Context;
import android.os.Handler;
import android.os.Looper;
import android.util.Log;

import java.lang.reflect.Method;
import java.util.concurrent.Executors;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.atomic.AtomicBoolean;

/**
 * Reads vehicle data the same way Coolray Dash does:
 * via reflection on android.car.Car → CarPropertyManager.
 *
 * Property IDs extracted from Coolray Dash v1.50/v1.54.
 */
public class CarDataReader {

    private static final String TAG = "CarDataReader";

    // From Coolray VehicleSamples / NativeDashboard
    public static final int PROP_SPEED       = 0x11600207; // km/h float
    public static final int PROP_FUEL_PCT    = 0x2140a569; // 0-100 int
    public static final int PROP_ENG_TEMP    = 0x2740a665; // area 1 often temp-related
    public static final int PROP_TRIP_INFO   = 0x2740a67a; // trip duration etc
    public static final int PROP_RANGE_LIKE  = 0x2140a564;
    public static final int PROP_VOLTAGE_CAND = 0x21408017;

    // Common Android Automotive odometer-related (may or may not exist on Coolray)
    public static final int PROP_PERF_ODOMETER = 0x11600205; // PERF_ODOMETER if available

    public static class Snapshot {
        public float speedKmh = Float.NaN;
        public int fuelPercent = -1;       // 0-100 or -1
        public float odometerKm = Float.NaN;
        public int oilDaysRemaining = -1;  // days or -1
        public float engineTempC = Float.NaN;
        public float voltage = Float.NaN;
        public boolean fromCar = false;    // true if real data, false if demo
        public long timestamp = 0;
    }

    public interface Listener {
        void onData(Snapshot snap);
    }

    private final Context appContext;
    private final Listener listener;
    private final Handler mainHandler = new Handler(Looper.getMainLooper());
    private ScheduledExecutorService executor;
    private final AtomicBoolean running = new AtomicBoolean(false);

    private Object car;
    private Object propertyManager;
    private Method getFloatProperty;
    private Method getIntProperty;
    private boolean carAvailable = false;

    // Demo state
    private float demoSpeed = 0f;
    private boolean demoUp = true;

    public CarDataReader(Context context, Listener listener) {
        this.appContext = context.getApplicationContext();
        this.listener = listener;
        initCarReflection();
    }

    private void initCarReflection() {
        try {
            Class<?> carClass = Class.forName("android.car.Car");
            Method createMethod = carClass.getMethod("createCar", Context.class);
            car = createMethod.invoke(null, appContext);
            if (car == null) {
                Log.w(TAG, "Car.createCar returned null");
                return;
            }

            Method getPm = carClass.getMethod("getCarManager", String.class);
            // "property" is Car.PROPERTY_SERVICE
            propertyManager = getPm.invoke(car, "property");
            if (propertyManager == null) {
                Log.w(TAG, "CarPropertyManager is null");
                return;
            }

            Class<?> pmClass = propertyManager.getClass();
            getFloatProperty = pmClass.getMethod("getFloatProperty", int.class, int.class);
            getIntProperty = pmClass.getMethod("getIntProperty", int.class, int.class);
            carAvailable = true;
            Log.i(TAG, "CarPropertyManager ready");
        } catch (Throwable t) {
            Log.w(TAG, "Car API not available: " + t.getMessage());
            carAvailable = false;
        }
    }

    public boolean isCarAvailable() {
        return carAvailable;
    }

    public void start() {
        if (running.getAndSet(true)) return;
        executor = Executors.newSingleThreadScheduledExecutor();
        executor.scheduleAtFixedRate(this::poll, 0, 200, TimeUnit.MILLISECONDS);
    }

    public void stop() {
        running.set(false);
        if (executor != null) {
            executor.shutdownNow();
            executor = null;
        }
        disconnectCar();
    }

    private void disconnectCar() {
        try {
            if (car != null) {
                Method disconnect = car.getClass().getMethod("disconnect");
                disconnect.invoke(car);
            }
        } catch (Throwable ignored) {}
        car = null;
        propertyManager = null;
        carAvailable = false;
    }

    private void poll() {
        if (!running.get()) return;
        Snapshot snap = new Snapshot();
        snap.timestamp = System.currentTimeMillis();

        if (carAvailable && propertyManager != null) {
            try {
                snap.speedKmh = readFloat(PROP_SPEED, 0, Float.NaN);
                int fuel = readInt(PROP_FUEL_PCT, 0, Integer.MIN_VALUE);
                if (fuel >= 0 && fuel <= 100) snap.fuelPercent = fuel;

                // Try odometer candidates
                float odo = readFloat(PROP_PERF_ODOMETER, 0, Float.NaN);
                if (Float.isNaN(odo)) {
                    // Some platforms put total distance under trip property areas
                    odo = readFloat(PROP_TRIP_INFO, 0, Float.NaN);
                }
                if (!Float.isNaN(odo) && odo > 0) snap.odometerKm = odo;

                // Engine temp candidate
                float temp = readFloat(PROP_ENG_TEMP, 1, Float.NaN);
                if (!Float.isNaN(temp)) snap.engineTempC = temp;

                // Oil / service remaining days – try int properties that look like counters
                int serviceVal = readInt(PROP_TRIP_INFO, 2, Integer.MIN_VALUE);
                if (serviceVal >= 0 && serviceVal < 1000) {
                    snap.oilDaysRemaining = serviceVal;
                }

                snap.fromCar = !Float.isNaN(snap.speedKmh) || snap.fuelPercent >= 0;
            } catch (Throwable t) {
                Log.w(TAG, "Read error: " + t.getMessage());
                carAvailable = false;
            }
        }

        // Demo fallback when no car data
        if (!snap.fromCar) {
            if (demoUp) {
                demoSpeed += 1.8f;
                if (demoSpeed >= 140f) demoUp = false;
            } else {
                demoSpeed -= 1.5f;
                if (demoSpeed <= 0f) {
                    demoSpeed = 0f;
                    demoUp = true;
                }
            }
            snap.speedKmh = demoSpeed;
            snap.fuelPercent = 67;
            snap.odometerKm = 45280f;
            snap.oilDaysRemaining = 42;
            snap.engineTempC = 91f;
            snap.voltage = 13.9f;
            snap.fromCar = false;
        }

        final Snapshot out = snap;
        mainHandler.post(() -> {
            if (listener != null) listener.onData(out);
        });
    }

    private float readFloat(int propId, int areaId, float def) {
        try {
            Object r = getFloatProperty.invoke(propertyManager, propId, areaId);
            if (r instanceof Float) return (Float) r;
        } catch (Throwable ignored) {}
        return def;
    }

    private int readInt(int propId, int areaId, int def) {
        try {
            Object r = getIntProperty.invoke(propertyManager, propId, areaId);
            if (r instanceof Integer) return (Integer) r;
        } catch (Throwable ignored) {}
        return def;
    }
}
