package com.onehub.gaugewidget;

import android.appwidget.AppWidgetManager;
import android.appwidget.AppWidgetProvider;
import android.content.Context;
import android.content.SharedPreferences;
import android.widget.RemoteViews;

public class GaugeWidgetProvider extends AppWidgetProvider {

    public static final String PREFS_NAME = "GaugeWidgetPrefs";
    public static final String PREF_STYLE_PREFIX = "style_";

    // Available gauge styles
    public static final String[] STYLES = {
            "a", "b", "c", "d", "e", "f", "g", "h", "i", "j", "k", "l", "m", "bmw"
    };

    @Override
    public void onUpdate(Context context, AppWidgetManager appWidgetManager, int[] appWidgetIds) {
        for (int appWidgetId : appWidgetIds) {
            updateAppWidget(context, appWidgetManager, appWidgetId);
        }
    }

    public static void updateAppWidget(Context context, AppWidgetManager appWidgetManager, int appWidgetId) {
        SharedPreferences prefs = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE);
        String style = prefs.getString(PREF_STYLE_PREFIX + appWidgetId, "a");

        RemoteViews views = new RemoteViews(context.getPackageName(), R.layout.gauge_widget);

        int bgRes, needleRes;
        if ("bmw".equals(style)) {
            bgRes = getDrawableId(context, "gauge_bmw_bg");
            needleRes = getDrawableId(context, "gauge_bmw_needle");
        } else {
            bgRes = getDrawableId(context, "gauge_" + style + "1");
            needleRes = getDrawableId(context, "gauge_" + style + "2");
        }

        if (bgRes != 0) {
            views.setImageViewResource(R.id.gauge_background, bgRes);
        }
        if (needleRes != 0) {
            views.setImageViewResource(R.id.gauge_needle, needleRes);
        }

        appWidgetManager.updateAppWidget(appWidgetId, views);
    }

    private static int getDrawableId(Context context, String name) {
        return context.getResources().getIdentifier(name, "drawable", context.getPackageName());
    }

    @Override
    public void onDeleted(Context context, int[] appWidgetIds) {
        SharedPreferences.Editor editor = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE).edit();
        for (int id : appWidgetIds) {
            editor.remove(PREF_STYLE_PREFIX + id);
        }
        editor.apply();
    }
}
