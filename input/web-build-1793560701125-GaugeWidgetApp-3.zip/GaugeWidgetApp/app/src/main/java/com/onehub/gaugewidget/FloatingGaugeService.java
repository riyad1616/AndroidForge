package com.onehub.gaugewidget;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.PixelFormat;
import android.os.Build;
import android.os.IBinder;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.MotionEvent;
import android.view.View;
import android.view.WindowManager;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.core.app.NotificationCompat;

public class FloatingGaugeService extends Service implements CarDataReader.Listener {

    public static final String ACTION_START = "com.onehub.gaugewidget.START_FLOATING";
    public static final String ACTION_STOP = "com.onehub.gaugewidget.STOP_FLOATING";
    public static final String ACTION_UPDATE_STYLE = "com.onehub.gaugewidget.UPDATE_STYLE";
    public static final String EXTRA_STYLE = "style";

    private static final String CHANNEL_ID = "floating_gauge_channel";
    private static final int NOTIFICATION_ID = 1001;

    // Gauge needle: assume 0 km/h at -120°, 240 km/h at +120° (typical semicircle)
    private static final float NEEDLE_MIN_DEG = -120f;
    private static final float NEEDLE_MAX_DEG = 120f;
    private static final float SPEED_MAX = 240f;

    private WindowManager windowManager;
    private View floatingView;
    private WindowManager.LayoutParams params;
    private String currentStyle = "a";

    private ImageView gaugeBg, gaugeNeedle;
    private TextView txtSpeed, txtOdometer, txtOil, txtFuel;

    private CarDataReader dataReader;

    private int initialX, initialY;
    private float initialTouchX, initialTouchY;

    @Override
    public IBinder onBind(Intent intent) {
        return null;
    }

    @Override
    public void onCreate() {
        super.onCreate();
        windowManager = (WindowManager) getSystemService(WINDOW_SERVICE);
        createNotificationChannel();
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        SharedPreferences prefs = getSharedPreferences(GaugeWidgetProvider.PREFS_NAME, MODE_PRIVATE);

        if (intent == null) {
            if (prefs.getBoolean("floating_enabled", false)) {
                if (floatingView == null) {
                    currentStyle = prefs.getString("floating_style", "a");
                    showFloatingWindow();
                    startDataReader();
                }
                startForeground(NOTIFICATION_ID, buildNotification());
                return START_STICKY;
            }
            stopSelf();
            return START_NOT_STICKY;
        }

        String action = intent.getAction();

        if (ACTION_STOP.equals(action)) {
            stopFloating();
            return START_NOT_STICKY;
        }

        if (ACTION_UPDATE_STYLE.equals(action)) {
            String style = intent.getStringExtra(EXTRA_STYLE);
            if (style != null) {
                currentStyle = style;
                prefs.edit().putString("floating_style", style).apply();
                applyStyle();
            }
            return START_STICKY;
        }

        // START
        if (floatingView == null) {
            currentStyle = prefs.getString("floating_style", "a");
            showFloatingWindow();
            startDataReader();
        }

        startForeground(NOTIFICATION_ID, buildNotification());
        return START_STICKY;
    }

    private void startDataReader() {
        if (dataReader != null) {
            dataReader.stop();
        }
        dataReader = new CarDataReader(this, this);
        dataReader.start();
    }

    @Override
    public void onData(CarDataReader.Snapshot snap) {
        if (floatingView == null) return;

        // Speed text + needle
        float speed = Float.isNaN(snap.speedKmh) ? 0f : Math.max(0f, snap.speedKmh);
        txtSpeed.setText(String.valueOf(Math.round(speed)));

        float ratio = Math.min(1f, speed / SPEED_MAX);
        float angle = NEEDLE_MIN_DEG + ratio * (NEEDLE_MAX_DEG - NEEDLE_MIN_DEG);
        gaugeNeedle.setRotation(angle);

        // Odometer (سير العداد)
        if (!Float.isNaN(snap.odometerKm) && snap.odometerKm >= 0) {
            txtOdometer.setText(String.format("%.0f km", snap.odometerKm));
        } else {
            txtOdometer.setText("-- km");
        }

        // Oil remaining days (أيام الزيت)
        if (snap.oilDaysRemaining >= 0) {
            txtOil.setText(snap.oilDaysRemaining + " يوم");
            if (snap.oilDaysRemaining <= 7) {
                txtOil.setTextColor(0xFFFF5252);
            } else if (snap.oilDaysRemaining <= 30) {
                txtOil.setTextColor(0xFFFFAB40);
            } else {
                txtOil.setTextColor(0xFFFFFFFF);
            }
        } else {
            txtOil.setText("-- يوم");
            txtOil.setTextColor(0xFFFFFFFF);
        }

        // Fuel
        if (snap.fuelPercent >= 0) {
            txtFuel.setText(snap.fuelPercent + " %");
            if (snap.fuelPercent <= 15) {
                txtFuel.setTextColor(0xFFFF5252);
            } else {
                txtFuel.setTextColor(0xFFFFFFFF);
            }
        } else {
            txtFuel.setText("-- %");
            txtFuel.setTextColor(0xFFFFFFFF);
        }
    }

    private void showFloatingWindow() {
        LayoutInflater inflater = LayoutInflater.from(this);
        floatingView = inflater.inflate(R.layout.floating_gauge, null);

        gaugeBg = floatingView.findViewById(R.id.gauge_bg);
        gaugeNeedle = floatingView.findViewById(R.id.gauge_needle);
        txtSpeed = floatingView.findViewById(R.id.txt_speed);
        txtOdometer = floatingView.findViewById(R.id.txt_odometer);
        txtOil = floatingView.findViewById(R.id.txt_oil);
        txtFuel = floatingView.findViewById(R.id.txt_fuel);

        int layoutType = (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O)
                ? WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
                : WindowManager.LayoutParams.TYPE_PHONE;

        params = new WindowManager.LayoutParams(
                dpToPx(240),
                dpToPx(280),
                layoutType,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE
                        | WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
                PixelFormat.TRANSLUCENT
        );

        params.gravity = Gravity.TOP | Gravity.START;
        params.x = 60;
        params.y = 120;

        applyStyle();

        floatingView.setOnTouchListener((v, event) -> {
            switch (event.getAction()) {
                case MotionEvent.ACTION_DOWN:
                    initialX = params.x;
                    initialY = params.y;
                    initialTouchX = event.getRawX();
                    initialTouchY = event.getRawY();
                    return true;
                case MotionEvent.ACTION_MOVE:
                    params.x = initialX + (int) (event.getRawX() - initialTouchX);
                    params.y = initialY + (int) (event.getRawY() - initialTouchY);
                    try {
                        windowManager.updateViewLayout(floatingView, params);
                    } catch (Exception ignored) {}
                    return true;
            }
            return false;
        });

        ImageButton btnClose = floatingView.findViewById(R.id.btn_close);
        btnClose.setOnClickListener(v -> {
            getSharedPreferences(GaugeWidgetProvider.PREFS_NAME, MODE_PRIVATE)
                    .edit().putBoolean("floating_enabled", false).apply();
            stopFloating();
        });

        ImageButton btnStyle = floatingView.findViewById(R.id.btn_style);
        btnStyle.setOnClickListener(v -> {
            Intent styleIntent = new Intent(this, StyleSelectActivity.class);
            styleIntent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            startActivity(styleIntent);
        });

        try {
            windowManager.addView(floatingView, params);
        } catch (Exception e) {
            Toast.makeText(this, "خطأ: امنح إذن الظهور فوق التطبيقات", Toast.LENGTH_LONG).show();
            stopSelf();
        }
    }

    private void applyStyle() {
        if (floatingView == null) return;
        int bgRes, needleRes;
        if ("bmw".equals(currentStyle)) {
            bgRes = getResources().getIdentifier("gauge_bmw_bg", "drawable", getPackageName());
            needleRes = getResources().getIdentifier("gauge_bmw_needle", "drawable", getPackageName());
        } else {
            bgRes = getResources().getIdentifier("gauge_" + currentStyle + "1", "drawable", getPackageName());
            needleRes = getResources().getIdentifier("gauge_" + currentStyle + "2", "drawable", getPackageName());
        }
        if (bgRes != 0) gaugeBg.setImageResource(bgRes);
        if (needleRes != 0) gaugeNeedle.setImageResource(needleRes);
    }

    private void stopFloating() {
        if (dataReader != null) {
            dataReader.stop();
            dataReader = null;
        }
        if (floatingView != null) {
            try {
                windowManager.removeView(floatingView);
            } catch (Exception ignored) {}
            floatingView = null;
        }
        stopForeground(true);
        stopSelf();
    }

    private Notification buildNotification() {
        Intent stopIntent = new Intent(this, FloatingGaugeService.class);
        stopIntent.setAction(ACTION_STOP);
        PendingIntent stopPending = PendingIntent.getService(this, 0, stopIntent,
                PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);

        Intent openIntent = new Intent(this, MainActivity.class);
        PendingIntent openPending = PendingIntent.getActivity(this, 0, openIntent,
                PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);

        String mode = (dataReader != null && dataReader.isCarAvailable())
                ? "بيانات السيارة الحقيقية"
                : "وضع تجريبي";

        return new NotificationCompat.Builder(this, CHANNEL_ID)
                .setContentTitle("العداد العائم يعمل")
                .setContentText(mode)
                .setSmallIcon(android.R.drawable.ic_menu_compass)
                .setContentIntent(openPending)
                .addAction(android.R.drawable.ic_menu_close_clear_cancel, "إيقاف", stopPending)
                .setOngoing(true)
                .setPriority(NotificationCompat.PRIORITY_LOW)
                .build();
    }

    private void createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            NotificationChannel channel = new NotificationChannel(
                    CHANNEL_ID, "العداد العائم", NotificationManager.IMPORTANCE_LOW);
            channel.setDescription("خدمة العداد العائم");
            NotificationManager manager = getSystemService(NotificationManager.class);
            if (manager != null) manager.createNotificationChannel(channel);
        }
    }

    private int dpToPx(int dp) {
        return Math.round(dp * getResources().getDisplayMetrics().density);
    }

    @Override
    public void onDestroy() {
        if (dataReader != null) {
            dataReader.stop();
            dataReader = null;
        }
        if (floatingView != null) {
            try { windowManager.removeView(floatingView); } catch (Exception ignored) {}
            floatingView = null;
        }
        super.onDestroy();
    }
}
