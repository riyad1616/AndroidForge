package com.onehub.gaugewidget;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.Button;
import android.widget.GridView;
import android.widget.ImageView;
import android.widget.Toast;

public class StyleSelectActivity extends Activity {

    private String selectedStyle = "a";
    private GridView styleGrid;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_widget_config); // reuse the same layout

        // Change the apply button text if needed, but keep it simple
        Button applyBtn = findViewById(R.id.btn_apply);
        applyBtn.setText("تطبيق على العداد العائم");

        styleGrid = findViewById(R.id.style_grid);
        styleGrid.setAdapter(new StyleAdapter());
        styleGrid.setOnItemClickListener((parent, view, position, id) -> {
            selectedStyle = GaugeWidgetProvider.STYLES[position];
            ((StyleAdapter) styleGrid.getAdapter()).setSelected(position);
        });

        applyBtn.setOnClickListener(v -> {
            // Send style to the floating service
            Intent intent = new Intent(this, FloatingGaugeService.class);
            intent.setAction(FloatingGaugeService.ACTION_UPDATE_STYLE);
            intent.putExtra(FloatingGaugeService.EXTRA_STYLE, selectedStyle);
            startService(intent);

            Toast.makeText(this, "تم تغيير التصميم", Toast.LENGTH_SHORT).show();
            finish();
        });
    }

    private class StyleAdapter extends BaseAdapter {
        private int selectedPos = 0;

        public void setSelected(int pos) {
            selectedPos = pos;
            notifyDataSetChanged();
        }

        @Override
        public int getCount() {
            return GaugeWidgetProvider.STYLES.length;
        }

        @Override
        public Object getItem(int position) {
            return GaugeWidgetProvider.STYLES[position];
        }

        @Override
        public long getItemId(int position) {
            return position;
        }

        @Override
        public View getView(int position, View convertView, ViewGroup parent) {
            ImageView imageView;
            if (convertView == null) {
                imageView = new ImageView(StyleSelectActivity.this);
                imageView.setLayoutParams(new GridView.LayoutParams(
                        ViewGroup.LayoutParams.MATCH_PARENT, 280));
                imageView.setScaleType(ImageView.ScaleType.FIT_CENTER);
                imageView.setPadding(8, 8, 8, 8);
            } else {
                imageView = (ImageView) convertView;
            }

            String style = GaugeWidgetProvider.STYLES[position];
            int resId;
            if ("bmw".equals(style)) {
                resId = getResources().getIdentifier("gauge_bmw_bg", "drawable", getPackageName());
            } else {
                resId = getResources().getIdentifier("gauge_" + style + "1", "drawable", getPackageName());
            }
            imageView.setImageResource(resId);

            if (position == selectedPos) {
                imageView.setBackgroundColor(0xFF1A73E8);
            } else {
                imageView.setBackgroundColor(0x00000000);
            }

            return imageView;
        }
    }
}
