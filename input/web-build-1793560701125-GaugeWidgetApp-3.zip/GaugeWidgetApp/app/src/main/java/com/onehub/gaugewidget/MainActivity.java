package com.onehub.gaugewidget;

import android.content.Intent;
import android.content.SharedPreferences;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.provider.Settings;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.Switch;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {

    private static final String PREF_FLOATING_ENABLED = "floating_enabled";

    private Switch switchFloating;
    private TextView statusText;
    private TextView dataSourceText;
    private SharedPreferences prefs;
    private boolean waitingForPermission = false;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        prefs = getSharedPreferences(GaugeWidgetProvider.PREFS_NAME, MODE_PRIVATE);

        switchFloating = findViewById(R.id.switch_floating);
        statusText = findViewById(R.id.status_text);
        dataSourceText = findViewById(R.id.data_source_text);
        Button btnStyle = findViewById(R.id.btn_choose_style);

        boolean wasEnabled = prefs.getBoolean(PREF_FLOATING_ENABLED, false);
        switchFloating.setChecked(wasEnabled);
        updateStatusText(wasEnabled);

        if (wasEnabled && canDrawOverlays()) {
            startFloatingService();
        }

        switchFloating.setOnCheckedChangeListener((buttonView, isChecked) -> {
            if (isChecked) enableFloating();
            else disableFloating();
        });

        btnStyle.setOnClickListener(v ->
                startActivity(new Intent(this, StyleSelectActivity.class)));

        updatePreview();
        dataSourceText.setText("مصدر البيانات: يُحدَّد تلقائياً عند التشغيل\n(CarProperty على Coolray أو وضع تجريبي)");
    }

    @Override
    protected void onResume() {
        super.onResume();
        updatePreview();

        if (waitingForPermission) {
            waitingForPermission = false;
            if (canDrawOverlays()) {
                switchFloating.setChecked(true);
                prefs.edit().putBoolean(PREF_FLOATING_ENABLED, true).apply();
                startFloatingService();
                updateStatusText(true);
                Toast.makeText(this, "تم تفعيل العداد العائم", Toast.LENGTH_SHORT).show();
            } else {
                switchFloating.setChecked(false);
                prefs.edit().putBoolean(PREF_FLOATING_ENABLED, false).apply();
                updateStatusText(false);
                Toast.makeText(this, "لم يتم منح الإذن", Toast.LENGTH_SHORT).show();
            }
        }
    }

    private void enableFloating() {
        if (!canDrawOverlays()) {
            switchFloating.setOnCheckedChangeListener(null);
            switchFloating.setChecked(false);
            switchFloating.setOnCheckedChangeListener((buttonView, isChecked) -> {
                if (isChecked) enableFloating();
                else disableFloating();
            });
            waitingForPermission = true;
            Toast.makeText(this, "يجب منح إذن الظهور فوق التطبيقات", Toast.LENGTH_LONG).show();
            startActivity(new Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                    Uri.parse("package:" + getPackageName())));
            return;
        }
        prefs.edit().putBoolean(PREF_FLOATING_ENABLED, true).apply();
        startFloatingService();
        updateStatusText(true);
        Toast.makeText(this, "تم إظهار العداد", Toast.LENGTH_SHORT).show();
    }

    private void disableFloating() {
        prefs.edit().putBoolean(PREF_FLOATING_ENABLED, false).apply();
        stopFloatingService();
        updateStatusText(false);
        Toast.makeText(this, "تم إخفاء العداد", Toast.LENGTH_SHORT).show();
    }

    private void startFloatingService() {
        Intent intent = new Intent(this, FloatingGaugeService.class);
        intent.setAction(FloatingGaugeService.ACTION_START);
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            startForegroundService(intent);
        } else {
            startService(intent);
        }
    }

    private void stopFloatingService() {
        Intent intent = new Intent(this, FloatingGaugeService.class);
        intent.setAction(FloatingGaugeService.ACTION_STOP);
        startService(intent);
    }

    private boolean canDrawOverlays() {
        return Build.VERSION.SDK_INT < Build.VERSION_CODES.M || Settings.canDrawOverlays(this);
    }

    private void updateStatusText(boolean enabled) {
        if (enabled) {
            statusText.setText("العداد ظاهر على الشاشة");
            statusText.setTextColor(0xFF4CAF50);
        } else {
            statusText.setText("العداد متوقف");
            statusText.setTextColor(0xFF888888);
        }
    }

    private void updatePreview() {
        String style = prefs.getString("floating_style", "a");
        ImageView preview = findViewById(R.id.preview_image);
        int resId = "bmw".equals(style)
                ? getResources().getIdentifier("gauge_bmw_bg", "drawable", getPackageName())
                : getResources().getIdentifier("gauge_" + style + "1", "drawable", getPackageName());
        if (resId != 0) preview.setImageResource(resId);
    }
}
