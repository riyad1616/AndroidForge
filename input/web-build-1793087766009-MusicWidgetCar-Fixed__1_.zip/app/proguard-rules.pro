# Keep media session classes
-keep class android.media.session.** { *; }
