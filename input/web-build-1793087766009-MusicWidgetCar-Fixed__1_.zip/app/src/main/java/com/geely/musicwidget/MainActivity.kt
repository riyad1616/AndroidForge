package com.geely.musicwidget

import android.content.Intent
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.widget.Button
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.NotificationManagerCompat

class MainActivity : AppCompatActivity() {

    private lateinit var tvStatus: TextView
    private lateinit var btnOverlay: Button
    private lateinit var btnNotificationAccess: Button
    private lateinit var btnStart: Button
    private lateinit var btnStop: Button

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        tvStatus = findViewById(R.id.tvStatus)
        btnOverlay = findViewById(R.id.btnOverlayPermission)
        btnNotificationAccess = findViewById(R.id.btnNotificationAccess)
        btnStart = findViewById(R.id.btnStart)
        btnStop = findViewById(R.id.btnStop)

        btnOverlay.setOnClickListener { requestOverlayPermission() }
        btnNotificationAccess.setOnClickListener { requestNotificationListenerPermission() }
        btnStart.setOnClickListener { startWidget() }
        btnStop.setOnClickListener { stopWidget() }

        updateStatus()
    }

    override fun onResume() {
        super.onResume()
        updateStatus()
    }

    private fun hasOverlayPermission(): Boolean {
        return if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            Settings.canDrawOverlays(this)
        } else {
            true
        }
    }

    private fun hasNotificationAccess(): Boolean {
        val packages = NotificationManagerCompat.getEnabledListenerPackages(this)
        return packages.contains(packageName)
    }

    private fun requestOverlayPermission() {
        if (hasOverlayPermission()) {
            Toast.makeText(this, "إذن العرض فوق التطبيقات ممنوح", Toast.LENGTH_SHORT).show()
            return
        }
        val intent = Intent(
            Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
            Uri.parse("package:$packageName")
        )
        startActivity(intent)
    }

    private fun requestNotificationListenerPermission() {
        if (hasNotificationAccess()) {
            Toast.makeText(this, "إذن الوصول للموسيقى ممنوح مسبقاً", Toast.LENGTH_SHORT).show()
            return
        }
        val intent = Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS)
        startActivity(intent)
    }

    private fun startWidget() {
        if (!hasOverlayPermission()) {
            Toast.makeText(this, "يرجى منح إذن العرض فوق التطبيقات أولاً", Toast.LENGTH_LONG).show()
            requestOverlayPermission()
            return
        }
        if (!hasNotificationAccess()) {
            Toast.makeText(this, "مهم: امنح التطبيق إذن الوصول للإشعارات لكي يقرأ الموسيقى!", Toast.LENGTH_LONG).show()
            requestNotificationListenerPermission()
            return
        }

        val intent = Intent(this, FloatingMusicService::class.java)
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            startForegroundService(intent)
        } else {
            startService(intent)
        }
        Toast.makeText(this, "تم تشغيل الويدجت بنجاح", Toast.LENGTH_SHORT).show()
        updateStatus()
    }

    private fun stopWidget() {
        stopService(Intent(this, FloatingMusicService::class.java))
        Toast.makeText(this, "تم إيقاف الويدجت", Toast.LENGTH_SHORT).show()
        updateStatus()
    }

    private fun updateStatus() {
        val running = FloatingMusicService.isRunning
        tvStatus.text = if (running) "حالة الويدجت: يعمل ومرتبط بالموسيقى" else "حالة الويدجت: متوقف"
        btnOverlay.text = if (hasOverlayPermission()) "✓ إذن العرض فوق الشاشة (ممنوح)" else "1) السماح بالعرض فوق التطبيقات"
        btnNotificationAccess.text = if (hasNotificationAccess()) "✓ إذن التحكم بالموسيقى (ممنوح)" else "2) السماح بالوصول للموسيقى والإشعارات"
    }
}
