package com.geely.musicwidget

import android.content.ComponentName
import android.service.notification.NotificationListenerService
import android.service.notification.StatusBarNotification

/**
 * خدمة ضرورية في نظام أندرويد وشاشات سيارات Geely:
 * بدون هذه الخدمة يرفض النظام إعطاء getActiveSessions وتحدث SecurityException!
 */
class MediaNotificationListener : NotificationListenerService() {

    companion object {
        fun getComponentName(context: android.content.Context): ComponentName {
            return ComponentName(context, MediaNotificationListener::class.java)
        }
    }

    override fun onNotificationPosted(sbn: StatusBarNotification?) {
        super.onNotificationPosted(sbn)
    }

    override fun onNotificationRemoved(sbn: StatusBarNotification?) {
        super.onNotificationRemoved(sbn)
    }
}
