package com.onehub.floatgauge;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.Typeface;
import android.util.AttributeSet;
import android.view.View;

/** Hosts OneHub SpeedoEngine + Coolray mode / D-step overlay. */
public class SpeedoView extends View {

    public static final int STYLE_COUNT = 10;
    public static final int THEME_COUNT = SpeedoEngine.f1039s.size();

    private final SpeedoEngine engine = new SpeedoEngine();
    private final SpeedoData data = new SpeedoData();
    private final Paint overlayPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private int styleIndex = 0;
    private int themeIndex = 0;

    public SpeedoView(Context c) { super(c); init(); }
    public SpeedoView(Context c, AttributeSet a) { super(c, a); init(); }

    private void init() {
        overlayPaint.setTypeface(Typeface.create("sans-serif-medium", Typeface.BOLD));
        overlayPaint.setTextAlign(Paint.Align.CENTER);
    }

    public void setStyle(int s) {
        styleIndex = ((s % STYLE_COUNT) + STYLE_COUNT) % STYLE_COUNT;
        requestLayout();
        invalidate();
    }
    public int getStyle() { return styleIndex; }
    public void nextStyle() { setStyle(styleIndex + 1); }

    public void setThemeIndex(int t) {
        themeIndex = ((t % THEME_COUNT) + THEME_COUNT) % THEME_COUNT;
        invalidate();
    }
    public int getThemeIndex() { return themeIndex; }
    public void nextTheme() { setThemeIndex(themeIndex + 1); }

    public void setData(float speed, int gearIdx, int gearStep, String gearLetter,
                        String driveMode, int batt, int fuel, int powerKw,
                        int tempOut, int tempBatt) {
        data.set(speed, gearIdx, gearStep, gearLetter, driveMode, batt, fuel, powerKw, tempOut, tempBatt);
        invalidate();
    }

    public float aspect() {
        float[] q = SpeedoEngine.f1037q;
        if (styleIndex < 0 || styleIndex >= q.length) return 1f;
        return q[styleIndex];
    }

    @Override
    protected void onDraw(Canvas canvas) {
        super.onDraw(canvas);
        float w = getWidth();
        float h = getHeight();
        if (w < 4 || h < 4) return;
        try {
            engine.j(canvas, w, h, styleIndex, themeIndex, data);
        } catch (Throwable ignored) {}

        // Coolray overlays: mode (left) + D-step (right)
        float textSize = Math.max(18f, Math.min(w, h) * 0.055f);
        overlayPaint.setTextSize(textSize);
        overlayPaint.setColor(0xFFE0F7FA);
        float y = h * 0.12f;

        if (data.driveMode != null && !data.driveMode.equals("—") && data.driveMode.length() > 0) {
            overlayPaint.setTextAlign(Paint.Align.LEFT);
            canvas.drawText(data.driveMode, w * 0.06f, y, overlayPaint);
        }
        if (data.gearStep > 0) {
            overlayPaint.setTextAlign(Paint.Align.RIGHT);
            canvas.drawText("D" + data.gearStep, w * 0.94f, y, overlayPaint);
        } else if (data.gearLetter != null && data.gearLetter.length() > 0) {
            // optional: already in PRND of engine
        }
    }
}
