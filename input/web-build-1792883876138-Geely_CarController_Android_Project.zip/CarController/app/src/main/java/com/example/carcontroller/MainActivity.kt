package com.example.carcontroller

import android.Manifest
import android.content.Context
import android.content.Intent
import android.content.SharedPreferences
import android.content.pm.PackageManager
import android.os.Bundle
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.widget.Button
import android.widget.EditText
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import java.io.PrintWriter
import java.net.Socket
import java.util.Locale
import kotlin.concurrent.thread

class MainActivity : AppCompatActivity() {

    private lateinit var etCarIp: EditText
    private lateinit var btnConnect: Button
    private lateinit var btnVoiceCommand: Button
    private lateinit var sharedPreferences: SharedPreferences
    private lateinit var speechRecognizer: SpeechRecognizer
    private val PORT = 8888

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        sharedPreferences = getSharedPreferences("CarConfig", Context.MODE_PRIVATE)

        etCarIp = findViewById(R.id.etCarIp)
        btnConnect = findViewById(R.id.btnConnect)
        btnVoiceCommand = findViewById(R.id.btnVoiceCommand)

        val savedIp = sharedPreferences.getString("CAR_IP", "")
        if (!savedIp.isNullOrEmpty()) {
            etCarIp.setText(savedIp)
        }

        if (ContextCompat.checkSelfPermission(this, Manifest.permission.RECORD_AUDIO)
            != PackageManager.PERMISSION_GRANTED
        ) {
            ActivityCompat.requestPermissions(
                this,
                arrayOf(Manifest.permission.RECORD_AUDIO),
                1
            )
        }

        setupSpeechRecognizer()

        btnConnect.setOnClickListener {
            val ip = etCarIp.text.toString().trim()
            if (ip.isNotEmpty()) {
                sharedPreferences.edit().putString("CAR_IP", ip).apply()
                testSocketConnection(ip)
            } else {
                Toast.makeText(this, "يرجى إدخال عنوان IP الشاشة", Toast.LENGTH_SHORT).show()
            }
        }

        btnVoiceCommand.setOnClickListener {
            val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
                putExtra(
                    RecognizerIntent.EXTRA_LANGUAGE_MODEL,
                    RecognizerIntent.LANGUAGE_MODEL_FREE_FORM
                )
                putExtra(RecognizerIntent.EXTRA_LANGUAGE, "ar-SA")
            }
            speechRecognizer.startListening(intent)
        }

        findViewById<Button>(R.id.btnOpenWindows).setOnClickListener {
            sendSocketCommand("CMD_WINDOW_OPEN")
        }
        findViewById<Button>(R.id.btnCloseWindows).setOnClickListener {
            sendSocketCommand("CMD_WINDOW_CLOSE")
        }
        findViewById<Button>(R.id.btnOpenSunroof).setOnClickListener {
            sendSocketCommand("CMD_SUNROOF_OPEN")
        }
        findViewById<Button>(R.id.btnCloseSunroof).setOnClickListener {
            sendSocketCommand("CMD_SUNROOF_CLOSE")
        }
        findViewById<Button>(R.id.btnAcOn).setOnClickListener {
            sendSocketCommand("CMD_AC_ON")
        }
        findViewById<Button>(R.id.btnAcOff).setOnClickListener {
            sendSocketCommand("CMD_AC_OFF")
        }
        findViewById<Button>(R.id.btnMirrorsOpen).setOnClickListener {
            sendSocketCommand("CMD_MIRROR_UNFOLD")
        }
        findViewById<Button>(R.id.btnMirrorsFold).setOnClickListener {
            sendSocketCommand("CMD_MIRROR_FOLD")
        }

        // الإضاءة
        findViewById<Button>(R.id.btnHeadlightsOn).setOnClickListener {
            sendSocketCommand("CMD_HEADLIGHTS_ON")
        }
        findViewById<Button>(R.id.btnHeadlightsOff).setOnClickListener {
            sendSocketCommand("CMD_HEADLIGHTS_OFF")
        }
        findViewById<Button>(R.id.btnHighBeamOn).setOnClickListener {
            sendSocketCommand("CMD_HIGHBEAM_ON")
        }
        findViewById<Button>(R.id.btnHighBeamOff).setOnClickListener {
            sendSocketCommand("CMD_HIGHBEAM_OFF")
        }
        findViewById<Button>(R.id.btnInteriorOn).setOnClickListener {
            sendSocketCommand("CMD_INTERIOR_ON")
        }
        findViewById<Button>(R.id.btnInteriorOff).setOnClickListener {
            sendSocketCommand("CMD_INTERIOR_OFF")
        }
        findViewById<Button>(R.id.btnFogOn).setOnClickListener {
            sendSocketCommand("CMD_FOG_ON")
        }
        findViewById<Button>(R.id.btnFogOff).setOnClickListener {
            sendSocketCommand("CMD_FOG_OFF")
        }

        // الأبواب والصندوق
        findViewById<Button>(R.id.btnDoorUnlock).setOnClickListener {
            sendSocketCommand("CMD_DOOR_UNLOCK")
        }
        findViewById<Button>(R.id.btnDoorLock).setOnClickListener {
            sendSocketCommand("CMD_DOOR_LOCK")
        }
        findViewById<Button>(R.id.btnTrunkOpen).setOnClickListener {
            sendSocketCommand("CMD_TRUNK_OPEN")
        }
        findViewById<Button>(R.id.btnTrunkClose).setOnClickListener {
            sendSocketCommand("CMD_TRUNK_CLOSE")
        }

        // المنبه والراديو
        findViewById<Button>(R.id.btnHorn).setOnClickListener {
            sendSocketCommand("CMD_HORN")
        }
        findViewById<Button>(R.id.btnRadioOn).setOnClickListener {
            sendSocketCommand("CMD_RADIO_ON")
        }
        findViewById<Button>(R.id.btnRadioOff).setOnClickListener {
            sendSocketCommand("CMD_RADIO_OFF")
        }

        // المقاعد والHazard
        findViewById<Button>(R.id.btnSeatHeatOn).setOnClickListener {
            sendSocketCommand("CMD_SEAT_HEAT_ON")
        }
        findViewById<Button>(R.id.btnSeatHeatOff).setOnClickListener {
            sendSocketCommand("CMD_SEAT_HEAT_OFF")
        }
        findViewById<Button>(R.id.btnHazardOn).setOnClickListener {
            sendSocketCommand("CMD_HAZARD_ON")
        }
        findViewById<Button>(R.id.btnHazardOff).setOnClickListener {
            sendSocketCommand("CMD_HAZARD_OFF")
        }

        findViewById<Button>(R.id.btnReboot).setOnClickListener {
            sendSocketCommand("CMD_REBOOT")
        }
    }

    private fun setupSpeechRecognizer() {
        speechRecognizer = SpeechRecognizer.createSpeechRecognizer(this)
        speechRecognizer.setRecognitionListener(object : RecognitionListener {
            override fun onReadyForSpeech(params: Bundle?) {}
            override fun onBeginningOfSpeech() {
                Toast.makeText(this@MainActivity, "جاري الاستماع للأمر...", Toast.LENGTH_SHORT)
                    .show()
            }

            override fun onRmsChanged(rmsdB: Float) {}
            override fun onBufferReceived(buffer: ByteArray?) {}
            override fun onEndOfSpeech() {}
            override fun onError(error: Int) {
                Toast.makeText(
                    this@MainActivity,
                    "لم يتم فهم الأمر بشكل صحيح",
                    Toast.LENGTH_SHORT
                ).show()
            }

            override fun onResults(results: Bundle) {
                val matches = results.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)
                if (!matches.isNullOrEmpty()) {
                    processVoiceCommand(matches[0].lowercase(Locale.ROOT))
                }
            }

            override fun onPartialResults(partialResults: Bundle?) {}
            override fun onEvent(eventType: Int, params: Bundle?) {}
        })
    }

    private fun processVoiceCommand(command: String) {
        Toast.makeText(this, "الأمر الصوتي: $command", Toast.LENGTH_SHORT).show()
        when {
            command.contains("فتح النوافذ") -> sendSocketCommand("CMD_WINDOW_OPEN")
            command.contains("غلق النوافذ") || command.contains("اغلاق النوافذ") ->
                sendSocketCommand("CMD_WINDOW_CLOSE")

            command.contains("فتح السقف") -> sendSocketCommand("CMD_SUNROOF_OPEN")
            command.contains("غلق السقف") || command.contains("اغلاق السقف") ->
                sendSocketCommand("CMD_SUNROOF_CLOSE")

            command.contains("تشغيل المكيف") || command.contains("المبرد") ->
                sendSocketCommand("CMD_AC_ON")

            command.contains("اطفاء المكيف") || command.contains("ايقاف المكيف") ->
                sendSocketCommand("CMD_AC_OFF")

            command.contains("فتح المرايا") -> sendSocketCommand("CMD_MIRROR_UNFOLD")
            command.contains("طي المرايا") || command.contains("غلق المرايا") ->
                sendSocketCommand("CMD_MIRROR_FOLD")

            // الإضاءة
            command.contains("تشغيل الانوار") || command.contains("تشغيل الأضواء") ||
                    command.contains("تشغيل المصابيح") || command.contains("انوار امامية") ||
                    command.contains("أضواء أمامية") ->
                sendSocketCommand("CMD_HEADLIGHTS_ON")

            command.contains("اطفاء الانوار") || command.contains("ايقاف الانوار") ||
                    command.contains("اطفاء الأضواء") || command.contains("ايقاف الأضواء") ||
                    command.contains("اطفاء المصابيح") ->
                sendSocketCommand("CMD_HEADLIGHTS_OFF")

            command.contains("الضوء العالي") || command.contains("الانوار العالية") ||
                    command.contains("الأضواء العالية") ->
                sendSocketCommand("CMD_HIGHBEAM_ON")

            command.contains("اطفاء الضوء العالي") || command.contains("ايقاف الضوء العالي") ||
                    command.contains("الضوء المنخفض") ->
                sendSocketCommand("CMD_HIGHBEAM_OFF")

            command.contains("انوار داخلية") || command.contains("أضواء داخلية") ||
                    command.contains("تشغيل الإضاءة الداخلية") || command.contains("اضاءة داخلية") ->
                sendSocketCommand("CMD_INTERIOR_ON")

            command.contains("اطفاء الانوار الداخلية") || command.contains("ايقاف الانوار الداخلية") ||
                    command.contains("اطفاء الإضاءة الداخلية") ->
                sendSocketCommand("CMD_INTERIOR_OFF")

            command.contains("انوار الضباب") || command.contains("أضواء الضباب") ||
                    command.contains("تشغيل الضباب") ->
                sendSocketCommand("CMD_FOG_ON")

            command.contains("اطفاء انوار الضباب") || command.contains("ايقاف انوار الضباب") ||
                    command.contains("اطفاء الضباب") ->
                sendSocketCommand("CMD_FOG_OFF")

            // الأبواب والصندوق
            command.contains("فتح الباب") || command.contains("فتح الابواب") ||
                    command.contains("فتح الأبواب") || command.contains("فتح السيارة") ->
                sendSocketCommand("CMD_DOOR_UNLOCK")

            command.contains("قفل الباب") || command.contains("قفل الابواب") ||
                    command.contains("قفل الأبواب") || command.contains("اقفل السيارة") ||
                    command.contains("غلق الباب") || command.contains("اغلاق الباب") ->
                sendSocketCommand("CMD_DOOR_LOCK")

            command.contains("فتح الصندوق") || command.contains("فتح الشنطة") ||
                    command.contains("فتح الخلف") ->
                sendSocketCommand("CMD_TRUNK_OPEN")

            command.contains("غلق الصندوق") || command.contains("اغلاق الصندوق") ||
                    command.contains("غلق الشنطة") || command.contains("اغلاق الشنطة") ->
                sendSocketCommand("CMD_TRUNK_CLOSE")

            // المنبه والراديو
            command.contains("المنبه") || command.contains("صوت المنبه") ||
                    command.contains("بوق") || command.contains("النفير") ->
                sendSocketCommand("CMD_HORN")

            command.contains("تشغيل الراديو") || command.contains("تشغيل المذياع") ||
                    command.contains("شغل الراديو") ->
                sendSocketCommand("CMD_RADIO_ON")

            command.contains("اطفاء الراديو") || command.contains("ايقاف الراديو") ||
                    command.contains("اطفاء المذياع") || command.contains("ايقاف المذياع") ->
                sendSocketCommand("CMD_RADIO_OFF")

            // المقاعد والتسخين
            command.contains("تسخين المقاعد") || command.contains("تشغيل تدفئة المقاعد") ||
                    command.contains("المقاعد المدفأة") || command.contains("تدفئة المقعد") ->
                sendSocketCommand("CMD_SEAT_HEAT_ON")

            command.contains("اطفاء تسخين المقاعد") || command.contains("ايقاف تدفئة المقاعد") ||
                    command.contains("اطفاء تدفئة المقاعد") ->
                sendSocketCommand("CMD_SEAT_HEAT_OFF")

            // أضواء الطوارئ
            command.contains("أضواء الطوارئ") || command.contains("انوار الطوارئ") ||
                    command.contains("فلاشر") || command.contains("تشغيل الطوارئ") ->
                sendSocketCommand("CMD_HAZARD_ON")

            command.contains("اطفاء أضواء الطوارئ") || command.contains("اطفاء انوار الطوارئ") ||
                    command.contains("اطفاء الفلاشر") || command.contains("ايقاف الطوارئ") ->
                sendSocketCommand("CMD_HAZARD_OFF")

            else -> Toast.makeText(this, "أمر غير معروف", Toast.LENGTH_SHORT).show()
        }
    }

    private fun testSocketConnection(ip: String) {
        thread {
            try {
                val socket = Socket(ip, PORT)
                socket.close()
                runOnUiThread {
                    Toast.makeText(this, "تم الاتصال بالسيارة بنجاح!", Toast.LENGTH_SHORT)
                        .show()
                }
            } catch (e: Exception) {
                runOnUiThread {
                    Toast.makeText(this, "فشل الاتصال بـ IP السيارة", Toast.LENGTH_LONG).show()
                }
            }
        }
    }

    private fun sendSocketCommand(cmd: String) {
        val ip = etCarIp.text.toString().trim()
        if (ip.isEmpty()) {
            Toast.makeText(this, "يرجى تحديد IP السيارة أولاً", Toast.LENGTH_SHORT).show()
            return
        }

        thread {
            try {
                val socket = Socket(ip, PORT)
                val out = PrintWriter(socket.getOutputStream(), true)
                out.println(cmd)
                socket.close()
                runOnUiThread {
                    Toast.makeText(this, "تم إرسال الأمر: $cmd", Toast.LENGTH_SHORT).show()
                }
            } catch (e: Exception) {
                runOnUiThread {
                    Toast.makeText(this, "خطأ في الإرسال: ${e.message}", Toast.LENGTH_SHORT)
                        .show()
                }
            }
        }
    }

    override fun onDestroy() {
        super.onDestroy()
        if (::speechRecognizer.isInitialized) {
            speechRecognizer.destroy()
        }
    }
}
