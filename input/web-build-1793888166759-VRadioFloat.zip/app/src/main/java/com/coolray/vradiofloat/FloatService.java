package com.coolray.vradiofloat;

import android.app.AppOpsManager;
import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.app.usage.UsageStats;
import android.app.usage.UsageStatsManager;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Bitmap;
import android.graphics.PixelFormat;
import android.media.browse.MediaBrowser;
import android.os.Build;
import android.os.Handler;
import android.os.IBinder;
import android.os.Looper;
import android.os.Process;
import android.view.Gravity;
import android.view.WindowManager;
import android.widget.Toast;

import androidx.core.app.NotificationCompat;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import java.util.SortedMap;
import java.util.TreeMap;

public class FloatService extends Service implements RadioBarView.Listener {
    public static final String ACTION_STOP = "STOP";
    private static final String PREFS = "vradio_float";
    private static final String CH = "vradio_float_ch";
    private static final int NID = 42;

    private WindowManager wm;
    private WindowManager.LayoutParams params;
    private RadioBarView bar;
    private RadioClient client;
    private RadioClient statusClient;
    private final Handler handler = new Handler(Looper.getMainLooper());
    private final List<MediaBrowser.MediaItem> stations = new ArrayList<>();
    private boolean hiddenForApp;
    private final Runnable pollFg = this::checkForeground;
    private final Runnable refreshFav = this::loadStations;

    @Override
    public void onCreate() {
        super.onCreate();
        wm = (WindowManager) getSystemService(WINDOW_SERVICE);
        createChannel();
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        if (intent != null && ACTION_STOP.equals(intent.getAction())) {
            stopAll();
            return START_NOT_STICKY;
        }
        SharedPreferences p = getSharedPreferences(PREFS, MODE_PRIVATE);
        if (!p.getBoolean("on", false)) {
            stopSelf();
            return START_NOT_STICKY;
        }
        startForeground(NID, notif());
        if (bar == null) show();
        return START_STICKY;
    }

    private void show() {
        bar = new RadioBarView(this);
        bar.setListener(this);
        SharedPreferences p = getSharedPreferences(PREFS, MODE_PRIVATE);
        bar.setThemeIndex(p.getInt("theme", 0));

        int type = Build.VERSION.SDK_INT >= 26
                ? WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
                : WindowManager.LayoutParams.TYPE_PHONE;

        float density = getResources().getDisplayMetrics().density;
        int screenW = getResources().getDisplayMetrics().widthPixels;
        // Larger bar similar to original widget strip
        int w = Math.min(screenW - (int) (8 * density), (int) (920 * density));
        int h = (int) (72 * density);

        params = new WindowManager.LayoutParams(w, h, type,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE
                        | WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
                PixelFormat.TRANSLUCENT);
        params.gravity = Gravity.BOTTOM | Gravity.CENTER_HORIZONTAL;
        params.y = (int) (88 * density); // above system dock
        // restore position
        params.x = p.getInt("pos_x", 0);
        params.y = p.getInt("pos_y", params.y);
        applyAlpha();
        try {
            wm.addView(bar, params);
        } catch (Exception e) {
            Toast.makeText(this, R.string.need_overlay, Toast.LENGTH_LONG).show();
            stopSelf();
            return;
        }
        loadStations();
        listenStatus();
        handler.post(pollFg);
        // Refresh favorites every 8s so newly added stations appear
        handler.postDelayed(refreshFav, 8000);
    }

    private void loadStations() {
        if (client != null) client.disconnect();
        client = new RadioClient();
        client.load(this, new RadioClient.Callback() {
            @Override public void favorites(List<MediaBrowser.MediaItem> list) {
                stations.clear();
                if (list != null) stations.addAll(list);
                Bitmap[] logos = new Bitmap[RadioBarView.MAX];
                String[] names = new String[RadioBarView.MAX];
                for (int i = 0; i < stations.size() && i < RadioBarView.MAX; i++) {
                    MediaBrowser.MediaItem item = stations.get(i);
                    if (item.getDescription() != null) {
                        CharSequence t = item.getDescription().getTitle();
                        if (t != null) names[i] = t.toString();
                        logos[i] = LogoLoader.load(FloatService.this, item.getDescription());
                    }
                }
                if (bar != null) bar.setStations(stations, logos, names);
            }
            @Override public void error(String msg) {
                if (bar != null) bar.setStatus(msg != null ? msg : "ARRET", false);
            }
        });
        // schedule next refresh
        handler.removeCallbacks(refreshFav);
        handler.postDelayed(refreshFav, 10000);
    }

    // dummy to keep lambda simple

    private void listenStatus() {
        if (statusClient != null) statusClient.disconnect();
        statusClient = new RadioClient();
        statusClient.listenStatus(this, (text, playing) -> {
            if (bar != null) {
                bar.setStatus(text, playing);
                if (playing) bar.postInvalidateOnAnimation();
            }
        });
    }

    @Override public void onStation(int index) {
        if (index < 0 || index >= stations.size()) {
            // try reload then play
            loadStations();
            return;
        }
        if (client == null) client = new RadioClient();
        client.play(this, stations.get(index));
    }

    @Override public void onStop() {
        if (client == null) client = new RadioClient();
        client.stop(this);
        if (bar != null) bar.setStatus("ARRET", false);
    }

    @Override public void onThemeCycle() {
        if (bar == null) return;
        bar.nextTheme();
        getSharedPreferences(PREFS, MODE_PRIVATE).edit()
                .putInt("theme", bar.getThemeIndex()).apply();
    }

    @Override public void onDrag(float dx, float dy) {
        if (params == null || bar == null) return;
        params.x += (int) dx;
        params.y -= (int) dy; // gravity BOTTOM: increasing y moves up visually? 
        // With BOTTOM gravity, y is offset from bottom. Finger up → dy negative in rawY? 
        // rawY decreases when moving up → dy negative → y increases → moves up from bottom. Good.
        // Actually: with Gravity.BOTTOM, params.y is distance from bottom edge.
        // Moving finger up: rawY decreases, dy = new-last is negative, y -= (negative) = y increases = higher from bottom. OK.
        // Horizontal: with CENTER_HORIZONTAL, x is offset from center.
        try { wm.updateViewLayout(bar, params); } catch (Exception ignored) {}
    }

    @Override public void onDragEnd() {
        if (params == null) return;
        getSharedPreferences(PREFS, MODE_PRIVATE).edit()
                .putInt("pos_x", params.x)
                .putInt("pos_y", params.y)
                .apply();
    }

    private void applyAlpha() {
        if (bar == null) return;
        float a = getSharedPreferences(PREFS, MODE_PRIVATE).getFloat("alpha", 1f);
        if (a < 0.2f) a = 0.2f;
        if (a > 1f) a = 1f;
        bar.setAlpha(a);
    }

    private void checkForeground() {
        try {
            SharedPreferences prefs = getSharedPreferences(PREFS, MODE_PRIVATE);
            boolean homeOnly = prefs.getBoolean("home_only", true);
            applyAlpha();
            if (!homeOnly) {
                applyHide(false);
            } else {
                String[] pa = foregroundPkgAndActivity();
                String fg = pa != null ? pa[0] : null;
                String act = pa != null ? pa[1] : "";
                applyHide(!isHomeScreen(fg, act));
            }
        } catch (Throwable ignored) {}
        handler.postDelayed(pollFg, 280);
    }

    private void applyHide(boolean hide) {
        if (hide == hiddenForApp) return;
        hiddenForApp = hide;
        if (bar != null) bar.setVisibility(hide ? android.view.View.GONE : android.view.View.VISIBLE);
    }

    private String[] foregroundPkgAndActivity() {
        try {
            android.app.ActivityManager am =
                    (android.app.ActivityManager) getSystemService(ACTIVITY_SERVICE);
            if (am != null) {
                List<android.app.ActivityManager.RunningTaskInfo> tasks = am.getRunningTasks(1);
                if (tasks != null && !tasks.isEmpty() && tasks.get(0).topActivity != null) {
                    android.content.ComponentName cn = tasks.get(0).topActivity;
                    return new String[]{cn.getPackageName(),
                            cn.getClassName() != null ? cn.getClassName() : ""};
                }
            }
        } catch (Throwable ignored) {}
        if (!hasUsageAccess()) return null;
        try {
            UsageStatsManager usm = (UsageStatsManager) getSystemService(USAGE_STATS_SERVICE);
            long now = System.currentTimeMillis();
            List<UsageStats> stats = usm.queryUsageStats(UsageStatsManager.INTERVAL_DAILY, now - 8000, now);
            if (stats == null || stats.isEmpty()) return null;
            SortedMap<Long, UsageStats> sorted = new TreeMap<>();
            for (UsageStats u : stats) if (u.getLastTimeUsed() > 0) sorted.put(u.getLastTimeUsed(), u);
            if (sorted.isEmpty()) return null;
            return new String[]{sorted.get(sorted.lastKey()).getPackageName(), ""};
        } catch (Throwable t) {
            return null;
        }
    }

    private boolean hasUsageAccess() {
        try {
            AppOpsManager ops = (AppOpsManager) getSystemService(APP_OPS_SERVICE);
            int mode = ops.checkOpNoThrow(AppOpsManager.OPSTR_GET_USAGE_STATS,
                    Process.myUid(), getPackageName());
            return mode == AppOpsManager.MODE_ALLOWED;
        } catch (Throwable t) {
            return false;
        }
    }

    private boolean isHomeScreen(String fg, String activity) {
        if (fg == null || fg.isEmpty()) return false;
        if (fg.equals(getPackageName())) return false;
        String act = activity != null ? activity.toLowerCase() : "";
        if (act.contains("allapp") || act.contains("appdrawer") || act.contains("drawer")
                || act.contains("applist") || act.contains("app_list") || act.contains("grid")
                || act.contains("settings") || act.contains("application")) {
            return false;
        }
        if (launcherPackages().contains(fg)) return true;
        String low = fg.toLowerCase();
        return low.contains("launcher") || low.contains("trebuchet")
                || low.contains("carlauncher") || low.endsWith(".home")
                || low.contains("android.car.home");
    }

    private Set<String> launcherPackages() {
        Set<String> set = new HashSet<>();
        try {
            android.content.pm.PackageManager pm = getPackageManager();
            Intent home = new Intent(Intent.ACTION_MAIN);
            home.addCategory(Intent.CATEGORY_HOME);
            List<android.content.pm.ResolveInfo> list = pm.queryIntentActivities(home, 0);
            if (list != null) {
                for (android.content.pm.ResolveInfo ri : list) {
                    if (ri.activityInfo != null) set.add(ri.activityInfo.packageName);
                }
            }
        } catch (Throwable ignored) {}
        set.add("com.android.launcher3");
        set.add("com.android.car.carlauncher");
        set.add("com.flyme.auto.launcher");
        return set;
    }

    private void stopAll() {
        handler.removeCallbacksAndMessages(null);
        if (client != null) { client.disconnect(); client = null; }
        if (statusClient != null) { statusClient.disconnect(); statusClient = null; }
        if (bar != null) {
            try { wm.removeView(bar); } catch (Exception ignored) {}
            bar = null;
        }
        stopForeground(true);
        stopSelf();
    }

    private void createChannel() {
        if (Build.VERSION.SDK_INT >= 26) {
            NotificationChannel ch = new NotificationChannel(CH, getString(R.string.channel_name),
                    NotificationManager.IMPORTANCE_LOW);
            NotificationManager nm = getSystemService(NotificationManager.class);
            if (nm != null) nm.createNotificationChannel(ch);
        }
    }

    private Notification notif() {
        Intent stop = new Intent(this, FloatService.class).setAction(ACTION_STOP);
        PendingIntent pi = PendingIntent.getService(this, 1, stop,
                PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
        Intent open = new Intent(this, MainActivity.class);
        PendingIntent oi = PendingIntent.getActivity(this, 2, open,
                PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
        return new NotificationCompat.Builder(this, CH)
                .setContentTitle(getString(R.string.app_name))
                .setContentText(getString(R.string.status_on))
                .setSmallIcon(android.R.drawable.ic_media_play)
                .setContentIntent(oi)
                .addAction(0, "Stop", pi)
                .setOngoing(true)
                .build();
    }

    @Override public IBinder onBind(Intent intent) { return null; }

    @Override public void onDestroy() {
        handler.removeCallbacksAndMessages(null);
        if (client != null) client.disconnect();
        if (statusClient != null) statusClient.disconnect();
        if (bar != null) {
            try { wm.removeView(bar); } catch (Exception ignored) {}
            bar = null;
        }
        super.onDestroy();
    }
}
