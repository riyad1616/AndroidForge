package com.coolray.vradiofloat;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.media.MediaDescription;
import android.net.Uri;

import java.io.InputStream;

public final class LogoLoader {
    private LogoLoader() {}

    public static Bitmap load(Context context, MediaDescription desc) {
        if (desc == null) return null;
        Bitmap bmp = desc.getIconBitmap();
        if (bmp == null) {
            Uri uri = desc.getIconUri();
            if (uri != null) {
                InputStream in = null;
                try {
                    in = context.getContentResolver().openInputStream(uri);
                    if (in != null) bmp = BitmapFactory.decodeStream(in);
                } catch (Exception ignored) {
                } finally {
                    if (in != null) try { in.close(); } catch (Exception ignored) {}
                }
            }
        }
        if (bmp == null || bmp.getWidth() <= 0 || bmp.getHeight() <= 0) return null;
        try {
            return Bitmap.createScaledBitmap(bmp, 120, 120, true);
        } catch (Exception e) {
            return bmp;
        }
    }
}
