package com.geely.carreceiver

import android.content.Context
import java.io.File
import java.io.IOException

/**
 * Turns a command name received from the phone into a shell command.
 *
 * The table lives in an editable text file (see [defaultText]) so it can be changed on the car screen
 * ("أوامر السيارة" button) without rebuilding the app. As shipped, every command still writes a token to
 * /dev/car_control, exactly like the original project; that device does not exist on a real head unit,
 * so the lines must be replaced with commands that really work on the car (see the "فحص النظام" report).
 */
class CommandBackend(
    private val context: Context,
    private val suPaths: List<String> = SU_PATHS
) {

    data class ExecResult(val ok: Boolean, val message: String)

    /** Can this app really become root through su? [message] is "ok" or the reason su refused. */
    class SuStatus(val path: String?, val works: Boolean, val message: String)

    private class Config(val options: Map<String, String>, val commands: Map<String, String>)

    private val file: File get() = File(context.filesDir, FILE_NAME)
    private val execLock = Any()
    private val suLock = Any()
    private var suCache: SuStatus? = null
    private var suCacheAt = 0L

    fun isKnown(cmd: String) = cmd in KNOWN

    fun ensureConfig() {
        if (!file.exists()) {
            try {
                writeText(defaultText())
            } catch (e: IOException) {
                // execute() falls back to the built-in defaults when the file cannot be read
            }
        }
    }

    fun readText(): String = try {
        if (file.exists()) file.readText(Charsets.UTF_8) else defaultText()
    } catch (e: IOException) {
        defaultText()
    }

    @Throws(IOException::class)
    fun writeText(text: String) {
        file.writeText(text, Charsets.UTF_8)
    }

    @Throws(IOException::class)
    fun resetToDefault() = writeText(defaultText())

    /** True while the table still points at the placeholder device and that device is missing. */
    fun usesPlaceholder(): Boolean =
        parse(readText()).commands.values.any { it.contains(PLACEHOLDER_DEVICE) } && !File(PLACEHOLDER_DEVICE).exists()

    fun execute(cmd: String): ExecResult = synchronized(execLock) {
        val config = parse(readText())
        val line = config.commands[cmd] ?: return ExecResult(false, "no shell command configured for $cmd")
        if (line.isBlank()) return ExecResult(false, "empty shell command for $cmd")

        val timeoutMs = (config.options["timeout_ms"]?.toLongOrNull() ?: 4000L).coerceIn(500L, 20000L)
        val mode = (config.options["run_as_root"] ?: "auto").lowercase()
        val su = suStatus()
        val useRoot = when (mode) {
            "true" -> true
            "false" -> false
            else -> su.works // auto: only when su really gives root to this app
        }
        val suPath = su.path
        if (useRoot && suPath == null) return ExecResult(false, "run_as_root=true but no su binary was found")

        // The command runs exactly once: no silent retry without su (it hid the real reason and could repeat side effects).
        val out = if (useRoot && suPath != null) {
            Shell.run(arrayOf(suPath, "-c", line), timeoutMs)
        } else {
            Shell.run(arrayOf("sh", "-c", line), timeoutMs)
        }
        if (out.ok) return ExecResult(true, out.text)

        var detail = out.failure ?: ("exit=" + out.exit + (if (out.text.isNotEmpty()) ": " + out.text else ""))
        if (!useRoot && mode != "false" && suPath != null) detail += "  [su unusable: " + su.message + "]"
        ExecResult(false, detail)
    }

    /** Result of a real `su -c id` test, cached for a minute (running su before every command would be slow). */
    fun suStatus(): SuStatus = synchronized(suLock) {
        val now = System.currentTimeMillis()
        val cached = suCache
        if (cached != null && now - suCacheAt < SU_CACHE_MS) return cached
        val fresh = probeSu()
        suCache = fresh
        suCacheAt = now
        fresh
    }

    private fun probeSu(): SuStatus {
        val path = findSu() ?: return SuStatus(null, false, "no su binary found")
        val out = Shell.run(arrayOf(path, "-c", "id"), SU_PROBE_TIMEOUT_MS)
        val works = out.ok && out.text.contains("uid=0")
        val failure = out.failure
        val message = when {
            works -> "ok"
            failure != null -> failure
            out.text.isNotEmpty() -> out.text.replace(Regex("\\s+"), " ").take(120)
            else -> "exit=" + out.exit
        }
        return SuStatus(path, works, message)
    }

    private fun findSu(): String? =
        suPaths.firstOrNull { File(it).exists() }

    private fun parse(text: String): Config {
        val options = HashMap<String, String>()
        val commands = HashMap<String, String>()
        for (raw in text.lineSequence()) {
            val line = raw.trim()
            if (line.isEmpty() || line.startsWith("#")) continue
            val eq = line.indexOf('=')
            if (eq <= 0) continue
            val key = line.substring(0, eq).trim()
            val value = line.substring(eq + 1).trim()
            if (key in KNOWN) commands[key] = value else options[key.lowercase()] = value
        }
        return Config(options, commands)
    }

    companion object {
        const val FILE_NAME = "car_commands.txt"
        const val PLACEHOLDER_DEVICE = "/dev/car_control"
        private const val SU_CACHE_MS = 60_000L
        private const val SU_PROBE_TIMEOUT_MS = 5000L

        val SU_PATHS: List<String> = listOf(
            "/system/bin/su", "/system/xbin/su", "/sbin/su", "/su/bin/su", "/vendor/bin/su", "/system/sbin/su"
        )

        /** command name -> token written to the placeholder device (same table as the original project). */
        private val DEFAULTS: LinkedHashMap<String, String> = linkedMapOf(
            "CMD_WINDOW_OPEN" to "OPEN_WINDOWS",
            "CMD_WINDOW_CLOSE" to "CLOSE_WINDOWS",
            "CMD_SUNROOF_OPEN" to "OPEN_SUNROOF",
            "CMD_SUNROOF_CLOSE" to "CLOSE_SUNROOF",
            "CMD_AC_ON" to "AC_ON",
            "CMD_AC_OFF" to "AC_OFF",
            "CMD_MIRROR_UNFOLD" to "UNFOLD_MIRRORS",
            "CMD_MIRROR_FOLD" to "FOLD_MIRRORS",
            "CMD_HEADLIGHTS_ON" to "HEADLIGHTS_ON",
            "CMD_HEADLIGHTS_OFF" to "HEADLIGHTS_OFF",
            "CMD_HIGHBEAM_ON" to "HIGHBEAM_ON",
            "CMD_HIGHBEAM_OFF" to "HIGHBEAM_OFF",
            "CMD_INTERIOR_ON" to "INTERIOR_ON",
            "CMD_INTERIOR_OFF" to "INTERIOR_OFF",
            "CMD_FOG_ON" to "FOG_ON",
            "CMD_FOG_OFF" to "FOG_OFF",
            "CMD_DOOR_UNLOCK" to "DOOR_UNLOCK",
            "CMD_DOOR_LOCK" to "DOOR_LOCK",
            "CMD_TRUNK_OPEN" to "TRUNK_OPEN",
            "CMD_TRUNK_CLOSE" to "TRUNK_CLOSE",
            "CMD_HORN" to "HORN",
            "CMD_RADIO_ON" to "RADIO_ON",
            "CMD_RADIO_OFF" to "RADIO_OFF",
            "CMD_SEAT_HEAT_ON" to "SEAT_HEAT_ON",
            "CMD_SEAT_HEAT_OFF" to "SEAT_HEAT_OFF",
            "CMD_HAZARD_ON" to "HAZARD_ON",
            "CMD_HAZARD_OFF" to "HAZARD_OFF"
        )

        /** Every command the phone may send (the table above plus the reboot command). */
        val KNOWN: Set<String> = DEFAULTS.keys + "CMD_REBOOT"

        fun defaultText(): String {
            val sb = StringBuilder()
            sb.append("# Geely Receiver - command table\n")
            sb.append("# One command per line:  COMMAND_NAME=shell command   (run with: sh -c ...)\n")
            sb.append("# The /dev/car_control lines below are placeholders from the original project.\n")
            sb.append("# Replace them with commands that really work on this head unit.\n")
            sb.append("# Avoid backslashes. Lines starting with # are ignored.\n")
            sb.append("#\n")
            sb.append("# run_as_root: auto = use su when it exists | true | false\n")
            sb.append("run_as_root=auto\n")
            sb.append("timeout_ms=4000\n\n")
            for ((name, token) in DEFAULTS) {
                sb.append(name).append("=echo '").append(token).append("' > ").append(PLACEHOLDER_DEVICE).append('\n')
            }
            sb.append("CMD_REBOOT=reboot\n")
            return sb.toString()
        }
    }
}
