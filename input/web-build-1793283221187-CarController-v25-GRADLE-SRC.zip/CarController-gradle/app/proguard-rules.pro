# قواعد ProGuard (متعطلة افتراضيًا: minifyEnabled false)
-keep class com.example.carcontroller.** { *; }
-keep class com.journeyapps.barcodescanner.** { *; }
-keep class com.google.zxing.** { *; }
-dontwarn kotlin.**
