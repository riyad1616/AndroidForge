package com.example.carcontroller;

import androidx.constraintlayout.widget.ConstraintLayout;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Iterator;
import java.util.List;
import kotlin.collections.CollectionsKt;
import kotlin.jvm.internal.Intrinsics;
import kotlin.text.MatchResult;
import kotlin.text.Regex;
import kotlin.text.StringsKt;
import kotlin.text.Typography;

/* compiled from: PairingLink.kt */
/* loaded from: classes3.dex */
public final class PairingLink {
    public static final PairingLink INSTANCE = new PairingLink();
    private static final Regex IPV4 = new Regex("^(\\d{1,3})\\.(\\d{1,3})\\.(\\d{1,3})\\.(\\d{1,3})$");
    private static final Regex PIN = new Regex("^\\d{4,8}$");
    private static final String PREFIX = "geelycar://pair?";
    public static final String SCHEME = "geelycar";

    /* compiled from: PairingLink.kt */
        public static final /* data */ class Data {
        private final List<String> ips;
        private final String pin;

        public Data(List<String> ips, String pin) {
            Intrinsics.checkNotNullParameter(ips, "ips");
            Intrinsics.checkNotNullParameter(pin, "pin");
            this.ips = ips;
            this.pin = pin;
        }

        /* JADX WARN: Multi-variable type inference failed */
        public static /* synthetic */ Data copy$default(Data data, List list, String str, int i, Object obj) {
            if ((i & 1) != 0) {
                list = data.ips;
            }
            if ((i & 2) != 0) {
                str = data.pin;
            }
            return data.copy(list, str);
        }

        public final List<String> component1() {
            return this.ips;
        }

        /* renamed from: component2, reason: from getter */
        public final String getPin() {
            return this.pin;
        }

        public final Data copy(List<String> ips, String pin) {
            Intrinsics.checkNotNullParameter(ips, "ips");
            Intrinsics.checkNotNullParameter(pin, "pin");
            return new Data(ips, pin);
        }

        public boolean equals(Object other) {
            if (this == other) {
                return true;
            }
            if (!(other instanceof Data)) {
                return false;
            }
            Data data = (Data) other;
            return Intrinsics.areEqual(this.ips, data.ips) && Intrinsics.areEqual(this.pin, data.pin);
        }

        public final List<String> getIps() {
            return this.ips;
        }

        public int hashCode() {
            return (this.ips.hashCode() * 31) + this.pin.hashCode();
        }

        public String toString() {
            return "Data(ips=" + this.ips + ", pin=" + this.pin + ')';
        }
    }

    private PairingLink() {
    }

    public final String build(List<String> ips, String pin) {
        Intrinsics.checkNotNullParameter(ips, "ips");
        Intrinsics.checkNotNullParameter(pin, "pin");
        ArrayList arrayList = new ArrayList();
        for (Object obj : ips) {
            if (INSTANCE.isValidIp((String) obj)) {
                arrayList.add(obj);
            }
        }
        ArrayList arrayList2 = arrayList;
        if (!(!arrayList2.isEmpty())) {
            throw new IllegalArgumentException("no valid IPv4 address".toString());
        }
        if (isValidPin(pin)) {
            return "geelycar://pair?ip=" + CollectionsKt.joinToString(arrayList2, ", ", "", "", -1, "…", null) + "&pin=" + pin;
        }
        throw new IllegalArgumentException("invalid PIN".toString());
    }

    public final boolean isValidIp(String ip) throws NumberFormatException {
        Intrinsics.checkNotNullParameter(ip, "ip");
        MatchResult matchResultMatchEntire = IPV4.matchEntire(ip);
        if (matchResultMatchEntire == null) {
            return false;
        }
        List listDrop = CollectionsKt.drop(matchResultMatchEntire.getGroupValues(), 1);
        if ((listDrop instanceof Collection) && listDrop.isEmpty()) {
            return true;
        }
        Iterator it = listDrop.iterator();
        while (it.hasNext()) {
            int i = Integer.parseInt((String) it.next());
            if (!(i >= 0 && i < 256)) {
                return false;
            }
        }
        return true;
    }

    public final boolean isValidPin(String pin) {
        Intrinsics.checkNotNullParameter(pin, "pin");
        return PIN.matches(pin);
    }

    public final Data parse(String text) {
        boolean z;
        Intrinsics.checkNotNullParameter(text, "text");
        String string = StringsKt.trim((CharSequence) text).toString();
        int i = 1;
        if (!StringsKt.startsWith(string, PREFIX, true)) {
            return null;
        }
        String strSubstring = string.substring(16);
        Intrinsics.checkNotNullExpressionValue(strSubstring, "substring(...)");
        List listEmptyList = CollectionsKt.emptyList();
        String string2 = "";
        int i2 = 0;
        for (String str : StringsKt.split(strSubstring, new char[]{'&'}, false, 0)) {
            int iIndexOf$default = StringsKt.indexOf(str, '=', 0, false);
            if (iIndexOf$default > 0) {
                String strSubstring2 = str.substring(i2, iIndexOf$default);
                Intrinsics.checkNotNullExpressionValue(strSubstring2, "substring(...)");
                String strSubstring3 = str.substring(iIndexOf$default + 1);
                Intrinsics.checkNotNullExpressionValue(strSubstring3, "substring(...)");
                if (Intrinsics.areEqual(strSubstring2, "ip")) {
                    char[] cArr = new char[]{','};
                    List listSplit$default = StringsKt.split(strSubstring3, cArr, false, 0);
                    ArrayList arrayList = new ArrayList(CollectionsKt.collectionSizeOrDefault(listSplit$default, 10));
                    Iterator it = listSplit$default.iterator();
                    while (it.hasNext()) {
                        arrayList.add(StringsKt.trim((CharSequence) it.next()).toString());
                    }
                    ArrayList arrayList2 = new ArrayList();
                    for (Object obj : arrayList) {
                        if (((String) obj).length() > 0) {
                            arrayList2.add(obj);
                        }
                    }
                    listEmptyList = arrayList2;
                    i = 1;
                    i2 = 0;
                } else if (Intrinsics.areEqual(strSubstring2, "pin")) {
                    string2 = StringsKt.trim((CharSequence) strSubstring3).toString();
                    i = 1;
                    i2 = 0;
                }
            }
            i = 1;
            i2 = 0;
        }
        if (!listEmptyList.isEmpty()) {
            List list = listEmptyList;
            if (!(list instanceof Collection) || !list.isEmpty()) {
                Iterator it2 = list.iterator();
                while (true) {
                    if (!it2.hasNext()) {
                        z = true;
                        break;
                    }
                    if (!INSTANCE.isValidIp((String) it2.next())) {
                        z = false;
                        break;
                    }
                }
            } else {
                z = true;
            }
            if (z) {
                if (isValidPin(string2)) {
                    return new Data(CollectionsKt.distinct(listEmptyList), string2);
                }
                return null;
            }
        }
        return null;
    }
}
