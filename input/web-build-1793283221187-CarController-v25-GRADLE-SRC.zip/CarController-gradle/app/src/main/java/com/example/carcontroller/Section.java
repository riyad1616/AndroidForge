package com.example.carcontroller;

import androidx.constraintlayout.widget.ConstraintLayout;
import java.util.List;
import kotlin.jvm.internal.Intrinsics;

/* compiled from: Controls.kt */
/* loaded from: classes3.dex */
public final /* data */ class Section {
    private final int icon;
    private final List<Control> items;
    private final int title;

    public Section(int i, int i2, List<Control> items) {
        Intrinsics.checkNotNullParameter(items, "items");
        this.icon = i;
        this.title = i2;
        this.items = items;
    }

    /* JADX WARN: Multi-variable type inference failed */
    public static /* synthetic */ Section copy$default(Section section, int i, int i2, List list, int i3, Object obj) {
        if ((i3 & 1) != 0) {
            i = section.icon;
        }
        if ((i3 & 2) != 0) {
            i2 = section.title;
        }
        if ((i3 & 4) != 0) {
            list = section.items;
        }
        return section.copy(i, i2, list);
    }

    /* renamed from: component1, reason: from getter */
    public final int getIcon() {
        return this.icon;
    }

    /* renamed from: component2, reason: from getter */
    public final int getTitle() {
        return this.title;
    }

    public final List<Control> component3() {
        return this.items;
    }

    public final Section copy(int icon, int title, List<Control> items) {
        Intrinsics.checkNotNullParameter(items, "items");
        return new Section(icon, title, items);
    }

    public boolean equals(Object other) {
        if (this == other) {
            return true;
        }
        if (!(other instanceof Section)) {
            return false;
        }
        Section section = (Section) other;
        return this.icon == section.icon && this.title == section.title && Intrinsics.areEqual(this.items, section.items);
    }

    public final List<Control> getItems() {
        return this.items;
    }

    public int hashCode() {
        return (((Integer.hashCode(this.icon) * 31) + Integer.hashCode(this.title)) * 31) + this.items.hashCode();
    }

    public String toString() {
        return "Section(icon=" + this.icon + ", title=" + this.title + ", items=" + this.items + ')';
    }
}
