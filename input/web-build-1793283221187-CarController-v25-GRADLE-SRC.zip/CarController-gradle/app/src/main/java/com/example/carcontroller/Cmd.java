package com.example.carcontroller;

import androidx.constraintlayout.widget.ConstraintLayout;

/* compiled from: Cmd.kt */
/* loaded from: classes3.dex */
public final class Cmd {
    public static final String AC_OFF = "CMD_AC_OFF";
    public static final String AC_ON = "CMD_AC_ON";
    public static final String DOOR_LOCK = "CMD_DOOR_LOCK";
    public static final String DOOR_UNLOCK = "CMD_DOOR_UNLOCK";
    public static final String FOG_OFF = "CMD_FOG_OFF";
    public static final String FOG_ON = "CMD_FOG_ON";
    public static final String HAZARD_OFF = "CMD_HAZARD_OFF";
    public static final String HAZARD_ON = "CMD_HAZARD_ON";
    public static final String HEADLIGHTS_OFF = "CMD_HEADLIGHTS_OFF";
    public static final String HEADLIGHTS_ON = "CMD_HEADLIGHTS_ON";
    public static final String HIGHBEAM_OFF = "CMD_HIGHBEAM_OFF";
    public static final String HIGHBEAM_ON = "CMD_HIGHBEAM_ON";
    public static final String HORN = "CMD_HORN";
    public static final Cmd INSTANCE = new Cmd();
    public static final String INTERIOR_OFF = "CMD_INTERIOR_OFF";
    public static final String INTERIOR_ON = "CMD_INTERIOR_ON";
    public static final String MIRROR_FOLD = "CMD_MIRROR_FOLD";
    public static final String MIRROR_UNFOLD = "CMD_MIRROR_UNFOLD";
    public static final String PING = "PING";
    public static final String RADIO_OFF = "CMD_RADIO_OFF";
    public static final String RADIO_ON = "CMD_RADIO_ON";
    public static final String REBOOT = "CMD_REBOOT";
    public static final String SEAT_HEAT_OFF = "CMD_SEAT_HEAT_OFF";
    public static final String SEAT_HEAT_ON = "CMD_SEAT_HEAT_ON";
    public static final String SUNROOF_CLOSE = "CMD_SUNROOF_CLOSE";
    public static final String SUNROOF_OPEN = "CMD_SUNROOF_OPEN";
    public static final String TRUNK_CLOSE = "CMD_TRUNK_CLOSE";
    public static final String TRUNK_OPEN = "CMD_TRUNK_OPEN";
    public static final String WINDOW_CLOSE = "CMD_WINDOW_CLOSE";
    public static final String WINDOW_OPEN = "CMD_WINDOW_OPEN";

    private Cmd() {
    }
}
