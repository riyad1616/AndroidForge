package com.example.carcontroller;

import androidx.constraintlayout.widget.ConstraintLayout;
import com.google.zxing.client.android.Intents;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.net.ConnectException;
import java.net.InetSocketAddress;
import java.net.NoRouteToHostException;
import java.net.Socket;
import java.net.SocketTimeoutException;
import java.net.UnknownHostException;
import kotlin.jvm.internal.DefaultConstructorMarker;
import kotlin.jvm.internal.Intrinsics;
import kotlin.text.CharsKt;
import kotlin.text.Charsets;
import kotlin.text.StringsKt;

/* compiled from: CarClient.kt */
/* loaded from: classes3.dex */
public final class CarClient {
    public static final int CONNECT_TIMEOUT_MS = 3000;

    /* renamed from: Companion, reason: from kotlin metadata */
    public static final Companion INSTANCE = new Companion(null);
    public static final int DEFAULT_PORT = 8888;
    public static final int READ_TIMEOUT_MS = 8000;
    private final String host;
    private final String pin;
    private final int port;

    /* JADX WARN: Failed to restore enum class, 'enum' modifier and super class removed */
    /* JADX WARN: Unknown enum class pattern. Please report as an issue! */
    /* compiled from: CarClient.kt */
        public enum Code {
OK, AUTH, LOCKED, UNKNOWN, EXEC, FORMAT, UNREACHABLE, TIMEOUT, BAD_IP, NO_REPLY, IO
        }
    /* compiled from: CarClient.kt */
        public static final class Companion {
        private Companion() {
        }

        public /* synthetic */ Companion(DefaultConstructorMarker defaultConstructorMarker) {
            this();
        }

        /* JADX WARN: Multi-variable type inference failed */
        public final Result parseReply(String line) {
            Intrinsics.checkNotNullParameter(line, "line");
            int i = 2;
            return Intrinsics.areEqual(line, "OK") ? new Result(Code.OK, null, i, null) : Intrinsics.areEqual(line, "ERR_AUTH") ? new Result(Code.AUTH, null, i, null) : Intrinsics.areEqual(line, "ERR_LOCKED") ? new Result(Code.LOCKED, null, i, null) : Intrinsics.areEqual(line, "ERR_UNKNOWN") ? new Result(Code.UNKNOWN, null, i, null) : Intrinsics.areEqual(line, "ERR_FORMAT") ? new Result(Code.FORMAT, null, i, null) : StringsKt.startsWith(line, "ERR_EXEC", false) ? new Result(Code.EXEC, StringsKt.trim((CharSequence) StringsKt.removePrefix(line, (CharSequence) "ERR_EXEC")).toString()) : new Result(Code.NO_REPLY, line);
        }
    }

    /* compiled from: CarClient.kt */
        public static final /* data */ class Result {
        private final Code code;
        private final String detail;

        public Result(Code code, String detail) {
            Intrinsics.checkNotNullParameter(code, "code");
            Intrinsics.checkNotNullParameter(detail, "detail");
            this.code = code;
            this.detail = detail;
        }

        public /* synthetic */ Result(Code code, String str, int i, DefaultConstructorMarker defaultConstructorMarker) {
            this(code, (i & 2) != 0 ? "" : str);
        }

        public static /* synthetic */ Result copy$default(Result result, Code code, String str, int i, Object obj) {
            if ((i & 1) != 0) {
                code = result.code;
            }
            if ((i & 2) != 0) {
                str = result.detail;
            }
            return result.copy(code, str);
        }

        /* renamed from: component1, reason: from getter */
        public final Code getCode() {
            return this.code;
        }

        /* renamed from: component2, reason: from getter */
        public final String getDetail() {
            return this.detail;
        }

        public final Result copy(Code code, String detail) {
            Intrinsics.checkNotNullParameter(code, "code");
            Intrinsics.checkNotNullParameter(detail, "detail");
            return new Result(code, detail);
        }

        public boolean equals(Object other) {
            if (this == other) {
                return true;
            }
            if (!(other instanceof Result)) {
                return false;
            }
            Result result = (Result) other;
            return this.code == result.code && Intrinsics.areEqual(this.detail, result.detail);
        }

        public final boolean getOk() {
            return this.code == Code.OK;
        }

        public int hashCode() {
            return (this.code.hashCode() * 31) + this.detail.hashCode();
        }

        public String toString() {
            return "Result(code=" + this.code + ", detail=" + this.detail + ')';
        }
    }

    public CarClient(String host, String pin, int i) {
        Intrinsics.checkNotNullParameter(host, "host");
        Intrinsics.checkNotNullParameter(pin, "pin");
        this.host = host;
        this.pin = pin;
        this.port = i;
    }

    public /* synthetic */ CarClient(String str, String str2, int i, int i2, DefaultConstructorMarker defaultConstructorMarker) {
        this(str, str2, (i2 & 4) != 0 ? DEFAULT_PORT : i);
    }

    public final Result ping() {
        return send(Cmd.PING);
    }

    /* JADX WARN: Multi-variable type inference failed */
    public final Result send(String cmd) {
        Intrinsics.checkNotNullParameter(cmd, "cmd");
        Socket socket = new Socket();
        try {
            InetSocketAddress inetSocketAddress = new InetSocketAddress(this.host, this.port);
            if (inetSocketAddress.isUnresolved()) {
                Result badIp = new Result(Code.BAD_IP, "");
                try {
                    socket.close();
                } catch (IOException e) {
                }
                return badIp;
            }
            socket.connect(inetSocketAddress, 3000);
            socket.setSoTimeout(READ_TIMEOUT_MS);
            String str3 = this.pin;
            StringBuilder sb = new StringBuilder();
            int length = str3.length();
            for (int i2 = 0; i2 < length; i2++) {
                char cCharAt = str3.charAt(i2);
                if (!CharsKt.isWhitespace(cCharAt)) {
                    sb.append(cCharAt);
                }
            }
            String string2 = sb.toString();
            Intrinsics.checkNotNullExpressionValue(string2, "toString(...)");
            OutputStreamWriter outputStreamWriter = new OutputStreamWriter(socket.getOutputStream(), Charsets.UTF_8);
            outputStreamWriter.write("AUTH " + string2 + ' ' + cmd + '\n');
            outputStreamWriter.flush();
            String line = new BufferedReader(new InputStreamReader(socket.getInputStream(), Charsets.UTF_8)).readLine();
            if (line != null) {
                String string = StringsKt.trim((CharSequence) line).toString();
                Result reply = INSTANCE.parseReply(string);
                try {
                    socket.close();
                    return reply;
                } catch (IOException e2) {
                    return reply;
                }
            }
            Result noReply = new Result(Code.NO_REPLY, "");
            try {
                socket.close();
            } catch (IOException e3) {
            }
            return noReply;
        } catch (SocketTimeoutException e8) {
            Result timeout = new Result(Code.TIMEOUT, "");
            try {
                socket.close();
                return timeout;
            } catch (IOException e9) {
                return timeout;
            }
        } catch (NoRouteToHostException e6) {
            String message2 = e6.getMessage();
            Result unreachable1 = new Result(Code.UNREACHABLE, message2 != null ? message2 : "");
            try {
                socket.close();
            } catch (IOException e7) {
            }
            return unreachable1;
        } catch (ConnectException e10) {
            String message3 = e10.getMessage();
            Result unreachable2 = new Result(Code.UNREACHABLE, message3 != null ? message3 : "");
            try {
                socket.close();
            } catch (IOException e11) {
            }
            return unreachable2;
        } catch (UnknownHostException e12) {
            Result badIp2 = new Result(Code.BAD_IP, "");
            try {
                socket.close();
                return badIp2;
            } catch (IOException e13) {
                return badIp2;
            }
        } catch (IOException e4) {
            String message = e4.getMessage();
            Result io = new Result(Code.IO, message != null ? message : "");
            try {
                socket.close();
            } catch (IOException e5) {
            }
            return io;
        }
    }

}
