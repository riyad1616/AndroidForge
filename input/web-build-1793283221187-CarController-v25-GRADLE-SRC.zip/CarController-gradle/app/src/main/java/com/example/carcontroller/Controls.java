package com.example.carcontroller;

import androidx.constraintlayout.widget.ConstraintLayout;
import java.util.List;
import kotlin.collections.CollectionsKt;

/* compiled from: Controls.kt */
/* loaded from: classes3.dex */
public final class Controls {
    public static final Controls INSTANCE = new Controls();
    private static final List<Section> sections;

    static {
        Section[] sectionArr = new Section[6];
        sectionArr[0] = new Section(R.drawable.ic_car, R.string.sec_body, CollectionsKt.<Control>listOf(new Control[]{new Control(R.drawable.ic_window, R.string.lbl_windows, R.string.act_open, Cmd.WINDOW_OPEN, Integer.valueOf(R.string.act_close), Cmd.WINDOW_CLOSE), new Control(R.drawable.ic_sunroof, R.string.lbl_sunroof, R.string.act_open, Cmd.SUNROOF_OPEN, Integer.valueOf(R.string.act_close), Cmd.SUNROOF_CLOSE), new Control(R.drawable.ic_mirror, R.string.lbl_mirrors, R.string.act_open, Cmd.MIRROR_UNFOLD, Integer.valueOf(R.string.act_fold), Cmd.MIRROR_FOLD)}));
        sectionArr[1] = new Section(R.drawable.ic_ac, R.string.sec_climate, CollectionsKt.<Control>listOf(new Control[]{new Control(R.drawable.ic_ac, R.string.lbl_ac, R.string.act_on, Cmd.AC_ON, Integer.valueOf(R.string.act_off), Cmd.AC_OFF), new Control(R.drawable.ic_seat_heat, R.string.lbl_seat_heat, R.string.act_on, Cmd.SEAT_HEAT_ON, Integer.valueOf(R.string.act_off), Cmd.SEAT_HEAT_OFF)}));
        int i = R.drawable.ic_headlight;
        int i2 = R.string.sec_lights;
        Control[] controlArr = new Control[6];
        controlArr[0] = new Control(R.drawable.ic_headlight, R.string.lbl_headlights, R.string.act_on, Cmd.HEADLIGHTS_ON, Integer.valueOf(R.string.act_lights_off), Cmd.HEADLIGHTS_OFF);
        controlArr[1] = new Control(R.drawable.ic_highbeam, R.string.lbl_highbeam, R.string.act_on, Cmd.HIGHBEAM_ON, Integer.valueOf(R.string.act_lights_off), Cmd.HIGHBEAM_OFF);
        controlArr[2] = new Control(R.drawable.ic_interior, R.string.lbl_interior, R.string.act_on, Cmd.INTERIOR_ON, Integer.valueOf(R.string.act_lights_off), Cmd.INTERIOR_OFF);
        controlArr[3] = new Control(R.drawable.ic_fog, R.string.lbl_fog, R.string.act_on, Cmd.FOG_ON, Integer.valueOf(R.string.act_lights_off), Cmd.FOG_OFF);
        controlArr[4] = new Control(R.drawable.ic_hazard, R.string.lbl_hazard, R.string.act_on, Cmd.HAZARD_ON, Integer.valueOf(R.string.act_off), Cmd.HAZARD_OFF);
        sectionArr[2] = new Section(i, i2, CollectionsKt.<Control>listOf(controlArr));
        sectionArr[3] = new Section(R.drawable.ic_lock, R.string.sec_security, CollectionsKt.<Control>listOf(new Control[]{new Control(R.drawable.ic_lock, R.string.lbl_doors, R.string.act_open, Cmd.DOOR_UNLOCK, Integer.valueOf(R.string.act_lock), Cmd.DOOR_LOCK), new Control(R.drawable.ic_car, R.string.lbl_trunk, R.string.act_open, Cmd.TRUNK_OPEN, Integer.valueOf(R.string.act_close), Cmd.TRUNK_CLOSE)}));
        new Section(R.drawable.ic_horn, R.string.sec_sound, CollectionsKt.<Control>listOf(new Control[]{new Control(R.drawable.ic_horn, R.string.lbl_horn, R.string.act_horn, Cmd.HORN, null, null, 48, null), new Control(R.drawable.ic_radio, R.string.lbl_radio, R.string.act_on, Cmd.RADIO_ON, Integer.valueOf(R.string.act_off), Cmd.RADIO_OFF)}));
        sectionArr[5] = new Section(R.drawable.ic_mirror, R.string.sec_vhal, CollectionsKt.<Control>listOf(new Control[]{new Control(R.drawable.ic_mirror, R.string.lbl_mirror_l, R.string.act_fold, "CMD_MIRROR_FOLD_L", Integer.valueOf(R.string.act_unfold), "CMD_MIRROR_UNFOLD_L"), new Control(R.drawable.ic_mirror, R.string.lbl_mirror_r, R.string.act_fold, "CMD_MIRROR_FOLD_R", Integer.valueOf(R.string.act_unfold), "CMD_MIRROR_UNFOLD_R"), new Control(R.drawable.ic_lock, R.string.lbl_childlock_l, R.string.act_on, "CMD_CHILDLOCK_L_ON", Integer.valueOf(R.string.act_off), "CMD_CHILDLOCK_L_OFF"), new Control(R.drawable.ic_lock, R.string.lbl_childlock_r, R.string.act_on, "CMD_CHILDLOCK_R_ON", Integer.valueOf(R.string.act_off), "CMD_CHILDLOCK_R_OFF"), new Control(R.drawable.ic_car, R.string.lbl_frunk, R.string.act_open, "CMD_FRONTTRUNK_OPEN", Integer.valueOf(R.string.act_close), "CMD_FRONTTRUNK_CLOSE"), new Control(R.drawable.ic_key, R.string.lbl_glovebox, R.string.act_open, "CMD_GLOVEBOX_OPEN", Integer.valueOf(R.string.act_close), "CMD_GLOVEBOX_CLOSE"), new Control(R.drawable.ic_car, R.string.lbl_fuelcap, R.string.act_open, "CMD_FUELCAP_OPEN", Integer.valueOf(R.string.act_close), "CMD_FUELCAP_CLOSE"), new Control(R.drawable.ic_interior, R.string.lbl_ambient, R.string.act_on, "CMD_AMBIENT_ON", Integer.valueOf(R.string.act_off), "CMD_AMBIENT_OFF"), new Control(R.drawable.ic_car, R.string.lbl_display, R.string.act_off, "CMD_DISPLAY_OFF", Integer.valueOf(R.string.act_on), "CMD_DISPLAY_ON"), new Control(R.drawable.ic_seat_heat, R.string.lbl_seat_vent, R.string.act_on, "CMD_SEAT_VENT_ON", Integer.valueOf(R.string.act_off), "CMD_SEAT_VENT_OFF"), new Control(R.drawable.ic_car, R.string.lbl_vhal, R.string.act_list, "CMD_VHAL_LIST", Integer.valueOf(R.string.act_read), "CMD_VHAL_PING")}));
        sections = CollectionsKt.<Section>listOf(sectionArr);
    }

    private Controls() {
    }

    public final List<Section> getSections() {
        return sections;
    }
}
