package com.example.carcontroller;

import androidx.constraintlayout.widget.ConstraintLayout;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Iterator;
import java.util.List;
import java.util.Locale;
import java.util.Set;
import kotlin.collections.CollectionsKt;
import kotlin.jvm.internal.DefaultConstructorMarker;
import kotlin.jvm.internal.Intrinsics;
import kotlin.text.Regex;
import kotlin.text.StringsKt;
import kotlinx.coroutines.DebugKt;

/* compiled from: VoiceCommandParser.kt */
/* loaded from: classes3.dex */
public final class VoiceCommandParser {
    public static final VoiceCommandParser INSTANCE = new VoiceCommandParser();
    private static final List<String> LIGHT_WORDS;
    private static final Set<String> OFF_VERBS;
    private static final Set<String> ON_VERBS;
    private static final List<Rule> RULES;

    /* compiled from: VoiceCommandParser.kt */
        private static final class Rule {
        private final boolean defaultOn;
        private final List<String> fo;
        private final List<String> forceOff;
        private final List<List<String>> g;
        private final List<List<String>> groups;
        private final String off;
        private final String on;
        private final String single;

        /* JADX WARN: Multi-variable type inference failed */
        public Rule(List<List<String>> groups, String str, String str2, boolean z, List<String> forceOff, String str3) {
            Intrinsics.checkNotNullParameter(groups, "groups");
            Intrinsics.checkNotNullParameter(forceOff, "forceOff");
            this.groups = groups;
            this.on = str;
            this.off = str2;
            this.defaultOn = z;
            this.forceOff = forceOff;
            this.single = str3;
            List<List<String>> list = groups;
            ArrayList arrayList = new ArrayList(CollectionsKt.collectionSizeOrDefault(list, 10));
            Iterator it = list.iterator();
            while (it.hasNext()) {
                List list2 = (List) it.next();
                ArrayList arrayList2 = new ArrayList(CollectionsKt.collectionSizeOrDefault(list2, 10));
                List list3 = list2;
                boolean z2 = false;
                Iterator it2 = list3.iterator();
                while (it2.hasNext()) {
                    List list4 = list3;
                    arrayList2.add(VoiceCommandParser.INSTANCE.normalize((String) it2.next()));
                    list3 = list4;
                    z2 = z2;
                }
                arrayList.add(arrayList2);
            }
            this.g = arrayList;
            List<String> list5 = this.forceOff;
            ArrayList arrayList3 = new ArrayList(CollectionsKt.collectionSizeOrDefault(list5, 10));
            Iterator<String> it3 = list5.iterator();
            while (it3.hasNext()) {
                arrayList3.add(VoiceCommandParser.INSTANCE.normalize((String) it3.next()));
            }
            this.fo = arrayList3;
        }

        public /* synthetic */ Rule(List list, String str, String str2, boolean z, List list2, String str3, int i, DefaultConstructorMarker defaultConstructorMarker) {
            this(list, str, str2, (i & 8) != 0 ? false : z, (i & 16) != 0 ? CollectionsKt.emptyList() : list2, (i & 32) != 0 ? null : str3);
        }

        public final boolean forcesOff(String text) {
            Intrinsics.checkNotNullParameter(text, "text");
            List<String> list = this.fo;
            if ((list instanceof Collection) && list.isEmpty()) {
                return false;
            }
            Iterator<String> it = list.iterator();
            while (it.hasNext()) {
                if (StringsKt.contains(text, (CharSequence) it.next(), false)) {
                    return true;
                }
            }
            return false;
        }

        public final boolean getDefaultOn() {
            return this.defaultOn;
        }

        public final List<String> getForceOff() {
            return this.forceOff;
        }

        public final List<List<String>> getGroups() {
            return this.groups;
        }

        public final String getOff() {
            return this.off;
        }

        public final String getOn() {
            return this.on;
        }

        public final String getSingle() {
            return this.single;
        }

        public final boolean matches(String text, String padded) {
            List<List<String>> list;
            boolean z;
            boolean zContains$default;
            String padded2 = padded;
            Intrinsics.checkNotNullParameter(text, "text");
            Intrinsics.checkNotNullParameter(padded2, "padded");
            List<List<String>> list2 = this.g;
            if ((list2 instanceof Collection) && list2.isEmpty()) {
                return true;
            }
            Iterator<List<String>> it = list2.iterator();
            while (it.hasNext()) {
                List list3 = (List) it.next();
                boolean z2 = false;
                if (!(list3 instanceof Collection) || !list3.isEmpty()) {
                    Iterator it2 = list3.iterator();
                    while (true) {
                        if (!it2.hasNext()) {
                            list = list2;
                            z = z2;
                            break;
                        }
                        String str = (String) it2.next();
                        list = list2;
                        if (StringsKt.startsWith(str, "=", false)) {
                            StringBuilder sbAppend = new StringBuilder().append(' ');
                            String strSubstring = str.substring(1);
                            Intrinsics.checkNotNullExpressionValue(strSubstring, "substring(...)");
                            z = false;
                            zContains$default = StringsKt.contains(padded2, sbAppend.append(strSubstring).append(' ').toString(), false);
                        } else {
                            z = z2;
                            zContains$default = StringsKt.contains(text, str, false);
                        }
                        if (zContains$default) {
                            z2 = true;
                            break;
                        }
                        z2 = z;
                        list2 = list;
                        padded2 = padded;
                    }
                } else {
                    list = list2;
                    z = false;
                }
                if (!z2) {
                    return z;
                }
                padded2 = padded;
                list2 = list;
            }
            return true;
        }
    }

    /* JADX WARN: Multi-variable type inference failed */
    static {
        List listListOf = CollectionsKt.<String>listOf(new String[]{"تشغيل", "شغل", "شغلي", "فتح", "افتح", "افتحي", "تفعيل", "فعل", "فعلي", "اوقد", "ايقاد", "فرد", "افرد"});
        ArrayList arrayList = new ArrayList(CollectionsKt.collectionSizeOrDefault(listListOf, 10));
        Iterator it = listListOf.iterator();
        while (it.hasNext()) {
            arrayList.add(INSTANCE.n((String) it.next()));
        }
        ON_VERBS = CollectionsKt.toSet(arrayList);
        List listListOf2 = CollectionsKt.<String>listOf(new String[]{"اطفاء", "اطفا", "اطفي", "ايقاف", "اوقف", "وقف", "قفل", "اقفل", "اقفال", "غلق", "اغلق", "اغلاق", "اغلقي", "اقفلي", "طي", "اطوي", "اطو", "الغاء", "الغي"});
        ArrayList arrayList2 = new ArrayList(CollectionsKt.collectionSizeOrDefault(listListOf2, 10));
        Iterator it2 = listListOf2.iterator();
        while (it2.hasNext()) {
            arrayList2.add(INSTANCE.n((String) it2.next()));
        }
        OFF_VERBS = CollectionsKt.toSet(arrayList2);
        List listListOf3 = CollectionsKt.<String>listOf(new String[]{"ضوء", "اضواء", "نور", "انوار", "مصابيح", "مصباح", "كشاف", "كشافات", "اضاءه", "لمبه", "لمبات", "فوانيس", "فانوس"});
        ArrayList arrayList3 = new ArrayList(CollectionsKt.collectionSizeOrDefault(listListOf3, 10));
        Iterator it3 = listListOf3.iterator();
        while (it3.hasNext()) {
            arrayList3.add(INSTANCE.n((String) it3.next()));
        }
        ArrayList arrayList4 = arrayList3;
        LIGHT_WORDS = arrayList4;
        boolean z = true;
        List list = null;
        String str = null;
        int i = 48;
        boolean z2 = true;
        String str2 = null;
        int i2 = 48;
        DefaultConstructorMarker defaultConstructorMarker = null;
        boolean z3 = false;
        List list2 = null;
        int i3 = 56;
        DefaultConstructorMarker defaultConstructorMarker2 = null;
        RULES = CollectionsKt.<Rule>listOf(new Rule[]{new Rule(CollectionsKt.listOf(CollectionsKt.<String>listOf(new String[]{"نوافذ", "نافذه", "شبابيك", "شباك", "زجاج"})), "WINDOW_OPEN", "WINDOW_CLOSE", false, null, null, 56, null), new Rule(CollectionsKt.listOf(CollectionsKt.<String>listOf(new String[]{"سقف", "سنروف", "بانوراما"})), "SUNROOF_OPEN", "SUNROOF_CLOSE", false, null, null, 56, null), new Rule(CollectionsKt.listOf(CollectionsKt.<String>listOf(new String[]{"مكيف", "تكييف", "تكيف", "مبرد", "تبريد"})), "AC_ON", "AC_OFF", true, null, null, 48, null), new Rule(CollectionsKt.listOf(CollectionsKt.<String>listOf(new String[]{"مرايا", "مراه", "مراي"})), "MIRROR_UNFOLD", "MIRROR_FOLD", false, null, null, 56, null), new Rule(CollectionsKt.<List>listOf(new List[]{CollectionsKt.<String>listOf(new String[]{"مقاعد", "مقعد", "كراسي", "كرسي"}), CollectionsKt.<String>listOf(new String[]{"تسخين", "سخن", "تدفي", "دفا", "دفي", "حراره"})}), "SEAT_HEAT_ON", "SEAT_HEAT_OFF", z, list, str, i, null), new Rule(CollectionsKt.<List>listOf(new List[]{CollectionsKt.listOf("داخل"), arrayList4}), "INTERIOR_ON", "INTERIOR_OFF", z, list, str, i, null), new Rule(CollectionsKt.<List>listOf(new List[]{CollectionsKt.<String>listOf(new String[]{"عالي", "منخفض", "واطي"}), arrayList4}), "HIGHBEAM_ON", "HIGHBEAM_OFF", z, CollectionsKt.<String>listOf(new String[]{"منخفض", "واطي"}), str, 32, null), new Rule(CollectionsKt.listOf(CollectionsKt.<String>listOf(new String[]{"ضباب", "شبوره"})), "FOG_ON", "FOG_OFF", z2, null, str2, i2, defaultConstructorMarker), new Rule(CollectionsKt.listOf(CollectionsKt.<String>listOf(new String[]{"طواري", "فلاشر", "فلاشرات", "هازرد", "تحذير"})), "HAZARD_ON", "HAZARD_OFF", z2, null, str2, i2, defaultConstructorMarker), new Rule(CollectionsKt.listOf(arrayList4), "HEADLIGHTS_ON", "HEADLIGHTS_OFF", z2, null, str2, i2, defaultConstructorMarker), new Rule(CollectionsKt.listOf(CollectionsKt.<String>listOf(new String[]{"صندوق", "شنطه", "حقيبه", "=الخلف"})), "TRUNK_OPEN", "TRUNK_CLOSE", false, null, null, 56, null), new Rule(CollectionsKt.listOf(CollectionsKt.<String>listOf(new String[]{"منبه", "بوق", "نفير", "كلاكس", "هورن"})), null, null, false, null, "HORN", 24, null), new Rule(CollectionsKt.listOf(CollectionsKt.<String>listOf(new String[]{"راديو", "مذياع", "اذاعه"})), "RADIO_ON", "RADIO_OFF", z3, list2, null, i3, defaultConstructorMarker2), new Rule(CollectionsKt.listOf(CollectionsKt.<String>listOf(new String[]{"باب", "ابواب", "سياره", "عربيه"})), "DOOR_UNLOCK", "DOOR_LOCK", z3, list2, null, i3, defaultConstructorMarker2)});
    }

    private VoiceCommandParser() {
    }

    private final boolean isVerb(String token, Set<String> verbs) {
        if (verbs.contains(token)) {
            return true;
        }
        if (token.length() > 1 && StringsKt.contains("بلو", token.charAt(0), false)) {
            String strSubstring = token.substring(1);
            Intrinsics.checkNotNullExpressionValue(strSubstring, "substring(...)");
            if (verbs.contains(strSubstring)) {
                return true;
            }
        }
        return false;
    }

    private final String n(String s) {
        return normalize(s);
    }

    public final String normalize(String input) {
        Intrinsics.checkNotNullParameter(input, "input");
        StringBuilder sb = new StringBuilder(input.length());
        String lowerCase = input.toLowerCase(Locale.ROOT);
        Intrinsics.checkNotNullExpressionValue(lowerCase, "toLowerCase(...)");
        int length = lowerCase.length();
        for (int i = 0; i < length; i++) {
            char cCharAt = lowerCase.charAt(i);
            if (!(1611 <= cCharAt && cCharAt < 1632) && cCharAt != 1648 && cCharAt != 1600) {
                if (cCharAt == 1571 || cCharAt == 1573 || cCharAt == 1570 || cCharAt == 1649) {
                    sb.append((char) 1575);
                } else if (cCharAt == 1609 || cCharAt == 1574) {
                    sb.append((char) 1610);
                } else if (cCharAt == 1577) {
                    sb.append((char) 1607);
                } else if (cCharAt == 1572) {
                    sb.append((char) 1608);
                } else if (Character.isLetterOrDigit(cCharAt) || cCharAt == 1569) {
                    sb.append(cCharAt);
                } else {
                    sb.append(' ');
                }
            }
        }
        String string = sb.toString();
        Intrinsics.checkNotNullExpressionValue(string, "toString(...)");
        return new Regex("\\s+").replace(StringsKt.trim((CharSequence) string).toString(), " ");
    }

    public final String parse(String text) {
        boolean z;
        boolean z2;
        Intrinsics.checkNotNullParameter(text, "text");
        String strNormalize = normalize(text);
        boolean z3 = true;
        if (strNormalize.length() == 0) {
            return null;
        }
        List listSplit$default = StringsKt.split(strNormalize, new char[]{' '}, false, 0);
        String str = ' ' + strNormalize + ' ';
        List list = listSplit$default;
        if (!(list instanceof Collection) || !list.isEmpty()) {
            Iterator it = list.iterator();
            while (true) {
                if (!it.hasNext()) {
                    z = false;
                    break;
                }
                if (INSTANCE.isVerb((String) it.next(), OFF_VERBS)) {
                    z = true;
                    break;
                }
            }
        } else {
            z = false;
        }
        List list2 = listSplit$default;
        if (!(list2 instanceof Collection) || !list2.isEmpty()) {
            Iterator it2 = list2.iterator();
            while (true) {
                if (!it2.hasNext()) {
                    z2 = false;
                    break;
                }
                if (INSTANCE.isVerb((String) it2.next(), ON_VERBS)) {
                    z2 = true;
                    break;
                }
            }
        } else {
            z2 = false;
        }
        for (Rule rule : RULES) {
            if (rule.matches(strNormalize, str)) {
                if (!z && !rule.forcesOff(strNormalize)) {
                    z3 = false;
                }
                if (rule.getSingle() != null) {
                    if (z3) {
                        return null;
                    }
                    return rule.getSingle();
                }
                if (z3) {
                    return rule.getOff();
                }
                if (z2 || rule.getDefaultOn()) {
                    return rule.getOn();
                }
                return null;
            }
        }
        return null;
    }
}
