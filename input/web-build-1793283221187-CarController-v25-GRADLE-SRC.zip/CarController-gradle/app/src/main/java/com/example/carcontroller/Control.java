package com.example.carcontroller;

import androidx.constraintlayout.widget.ConstraintLayout;
import kotlin.jvm.internal.DefaultConstructorMarker;
import kotlin.jvm.internal.Intrinsics;

/* compiled from: Controls.kt */
/* loaded from: classes3.dex */
public final /* data */ class Control {
    private final String aCmd;
    private final int aLabel;
    private final String bCmd;
    private final Integer bLabel;
    private final int icon;
    private final int label;

    public Control(int i, int i2, int i3, String aCmd, Integer num, String str) {
        Intrinsics.checkNotNullParameter(aCmd, "aCmd");
        this.icon = i;
        this.label = i2;
        this.aLabel = i3;
        this.aCmd = aCmd;
        this.bLabel = num;
        this.bCmd = str;
    }

    public /* synthetic */ Control(int i, int i2, int i3, String str, Integer num, String str2, int i4, DefaultConstructorMarker defaultConstructorMarker) {
        this(i, i2, i3, str, (i4 & 16) != 0 ? null : num, (i4 & 32) != 0 ? null : str2);
    }

    public static /* synthetic */ Control copy$default(Control control, int i, int i2, int i3, String str, Integer num, String str2, int i4, Object obj) {
        if ((i4 & 1) != 0) {
            i = control.icon;
        }
        if ((i4 & 2) != 0) {
            i2 = control.label;
        }
        int i5 = i2;
        if ((i4 & 4) != 0) {
            i3 = control.aLabel;
        }
        int i6 = i3;
        if ((i4 & 8) != 0) {
            str = control.aCmd;
        }
        String str3 = str;
        if ((i4 & 16) != 0) {
            num = control.bLabel;
        }
        Integer num2 = num;
        if ((i4 & 32) != 0) {
            str2 = control.bCmd;
        }
        return control.copy(i, i5, i6, str3, num2, str2);
    }

    /* renamed from: component1, reason: from getter */
    public final int getIcon() {
        return this.icon;
    }

    /* renamed from: component2, reason: from getter */
    public final int getLabel() {
        return this.label;
    }

    /* renamed from: component3, reason: from getter */
    public final int getALabel() {
        return this.aLabel;
    }

    /* renamed from: component4, reason: from getter */
    public final String getACmd() {
        return this.aCmd;
    }

    /* renamed from: component5, reason: from getter */
    public final Integer getBLabel() {
        return this.bLabel;
    }

    /* renamed from: component6, reason: from getter */
    public final String getBCmd() {
        return this.bCmd;
    }

    public final Control copy(int icon, int label, int aLabel, String aCmd, Integer bLabel, String bCmd) {
        Intrinsics.checkNotNullParameter(aCmd, "aCmd");
        return new Control(icon, label, aLabel, aCmd, bLabel, bCmd);
    }

    public boolean equals(Object other) {
        if (this == other) {
            return true;
        }
        if (!(other instanceof Control)) {
            return false;
        }
        Control control = (Control) other;
        return this.icon == control.icon && this.label == control.label && this.aLabel == control.aLabel && Intrinsics.areEqual(this.aCmd, control.aCmd) && Intrinsics.areEqual(this.bLabel, control.bLabel) && Intrinsics.areEqual(this.bCmd, control.bCmd);
    }

    public int hashCode() {
        int iHashCode = ((((((Integer.hashCode(this.icon) * 31) + Integer.hashCode(this.label)) * 31) + Integer.hashCode(this.aLabel)) * 31) + this.aCmd.hashCode()) * 31;
        Integer num = this.bLabel;
        int iHashCode2 = (iHashCode + (num == null ? 0 : num.hashCode())) * 31;
        String str = this.bCmd;
        return iHashCode2 + (str != null ? str.hashCode() : 0);
    }

    public String toString() {
        return "Control(icon=" + this.icon + ", label=" + this.label + ", aLabel=" + this.aLabel + ", aCmd=" + this.aCmd + ", bLabel=" + this.bLabel + ", bCmd=" + this.bCmd + ')';
    }
}
