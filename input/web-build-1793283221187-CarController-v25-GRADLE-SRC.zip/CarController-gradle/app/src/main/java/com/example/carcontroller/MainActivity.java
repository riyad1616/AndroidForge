package com.example.carcontroller;

import android.content.ActivityNotFoundException;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.res.ColorStateList;
import android.net.Uri;
import android.os.Bundle;
import android.speech.RecognitionListener;
import android.speech.SpeechRecognizer;
import android.text.Editable;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;
import androidx.activity.result.ActivityResult;
import androidx.activity.result.ActivityResultCallback;
import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.appcompat.app.AppCompatActivity;
import androidx.constraintlayout.widget.ConstraintLayout;
import androidx.core.content.ContextCompat;
import androidx.core.graphics.Insets;
import androidx.core.view.OnApplyWindowInsetsListener;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowCompat;
import androidx.core.view.WindowInsetsCompat;
import com.example.carcontroller.CarClient;
import com.example.carcontroller.MainActivity;
import com.example.carcontroller.PairingLink;
import com.google.android.material.button.MaterialButton;
import com.google.android.material.dialog.MaterialAlertDialogBuilder;
import com.google.android.material.textfield.TextInputEditText;
import com.journeyapps.barcodescanner.ScanContract;
import com.journeyapps.barcodescanner.ScanIntentResult;
import com.journeyapps.barcodescanner.ScanOptions;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import kotlin.NoWhenBranchMatchedException;
import kotlin.Unit;
import kotlin.collections.CollectionsKt;
import kotlin.concurrent.ThreadsKt;
import kotlin.jvm.functions.Function0;
import kotlin.jvm.internal.Intrinsics;
import kotlin.jvm.internal.Lambda;
import kotlin.jvm.internal.Ref;
import kotlin.ranges.RangesKt;
import kotlin.text.StringsKt;
import kotlinx.coroutines.DebugKt;

/* compiled from: MainActivity.kt */
/* loaded from: classes3.dex */
public final class MainActivity extends AppCompatActivity {
    private static final String KEY_IP = "CAR_IP";
    private static final String KEY_PIN = "CAR_PIN";
    private static final String PREFS = "CarConfig";
    private MaterialButton btnVoice;
    private View dotStatus;
    private TextInputEditText etIp;
    private TextInputEditText etPin;
    private final RecognitionListener listener;
    private final ActivityResultLauncher<String> micPermission;
    private SharedPreferences prefs;
    private final ActivityResultLauncher<ScanOptions> qrScanner;
    private SpeechRecognizer recognizer;
    private final ActivityResultLauncher<Intent> systemVoice;
    private TextView tvStatus;

    /* JADX WARN: Failed to restore enum class, 'enum' modifier and super class removed */
    /* JADX WARN: Unknown enum class pattern. Please report as an issue! */
    /* compiled from: MainActivity.kt */
        private enum State {
IDLE, BUSY, OK, ERROR
        }
    /* compiled from: MainActivity.kt */
        public /* synthetic */ class WhenMappings {
        public static final /* synthetic */ int[] $EnumSwitchMapping$0;
        public static final /* synthetic */ int[] $EnumSwitchMapping$1;

        static {
            int[] iArr = new int[State.values().length];
            try {
                iArr[State.IDLE.ordinal()] = 1;
            } catch (NoSuchFieldError e) {
            }
            try {
                iArr[State.BUSY.ordinal()] = 2;
            } catch (NoSuchFieldError e2) {
            }
            try {
                iArr[State.OK.ordinal()] = 3;
            } catch (NoSuchFieldError e3) {
            }
            try {
                iArr[State.ERROR.ordinal()] = 4;
            } catch (NoSuchFieldError e4) {
            }
            $EnumSwitchMapping$0 = iArr;
            int[] iArr2 = new int[CarClient.Code.values().length];
            try {
                iArr2[CarClient.Code.OK.ordinal()] = 1;
            } catch (NoSuchFieldError e5) {
            }
            try {
                iArr2[CarClient.Code.AUTH.ordinal()] = 2;
            } catch (NoSuchFieldError e6) {
            }
            try {
                iArr2[CarClient.Code.LOCKED.ordinal()] = 3;
            } catch (NoSuchFieldError e7) {
            }
            try {
                iArr2[CarClient.Code.UNKNOWN.ordinal()] = 4;
            } catch (NoSuchFieldError e8) {
            }
            try {
                iArr2[CarClient.Code.EXEC.ordinal()] = 5;
            } catch (NoSuchFieldError e9) {
            }
            try {
                iArr2[CarClient.Code.FORMAT.ordinal()] = 6;
            } catch (NoSuchFieldError e10) {
            }
            try {
                iArr2[CarClient.Code.UNREACHABLE.ordinal()] = 7;
            } catch (NoSuchFieldError e11) {
            }
            try {
                iArr2[CarClient.Code.TIMEOUT.ordinal()] = 8;
            } catch (NoSuchFieldError e12) {
            }
            try {
                iArr2[CarClient.Code.BAD_IP.ordinal()] = 9;
            } catch (NoSuchFieldError e13) {
            }
            try {
                iArr2[CarClient.Code.NO_REPLY.ordinal()] = 10;
            } catch (NoSuchFieldError e14) {
            }
            try {
                iArr2[CarClient.Code.IO.ordinal()] = 11;
            } catch (NoSuchFieldError e15) {
            }
            $EnumSwitchMapping$1 = iArr2;
        }
    }

    /* compiled from: MainActivity.kt */
        /* renamed from: com.example.carcontroller.MainActivity$applyPairing$1, reason: invalid class name */
    static final class AnonymousClass1 implements Function0<Unit> {
        final /* synthetic */ PairingLink.Data $p;
        final /* synthetic */ MainActivity this$0;

        /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
        AnonymousClass1(PairingLink.Data data, MainActivity mainActivity) {
            this.$p = data;
            this.this$0 = mainActivity;
        }

        /* JADX INFO: Access modifiers changed from: private */
        public static final void invoke$lambda$0(MainActivity this$0, String chosen, PairingLink.Data p, Ref.ObjectRef reachable) {
            Intrinsics.checkNotNullParameter(this$0, "this$0");
            Intrinsics.checkNotNullParameter(chosen, "$chosen");
            Intrinsics.checkNotNullParameter(p, "$p");
            Intrinsics.checkNotNullParameter(reachable, "$reachable");
            if (this$0.isFinishing() || this$0.isDestroyed()) {
                return;
            }
            TextInputEditText textInputEditText = this$0.etIp;
            if (textInputEditText == null) {
                Intrinsics.throwUninitializedPropertyAccessException("etIp");
                textInputEditText = null;
            }
            textInputEditText.setText(chosen);
            TextInputEditText textInputEditText2 = this$0.etPin;
            if (textInputEditText2 == null) {
                Intrinsics.throwUninitializedPropertyAccessException("etPin");
                textInputEditText2 = null;
            }
            textInputEditText2.setText(p.getPin());
            this$0.save(chosen, p.getPin());
            if (reachable.element != null) {
                State state = State.OK;
                String string = this$0.getString(R.string.status_connected);
                Intrinsics.checkNotNullExpressionValue(string, "getString(...)");
                this$0.setStatus(state, string);
                String string2 = this$0.getString(R.string.qr_paired, new Object[]{chosen});
                Intrinsics.checkNotNullExpressionValue(string2, "getString(...)");
                MainActivity.toast$default(this$0, string2, false, 2, null);
                return;
            }
            State state2 = State.ERROR;
            String string3 = this$0.getString(R.string.res_unreachable);
            Intrinsics.checkNotNullExpressionValue(string3, "getString(...)");
            this$0.setStatus(state2, string3);
            String string4 = this$0.getString(R.string.qr_paired_unverified);
            Intrinsics.checkNotNullExpressionValue(string4, "getString(...)");
            this$0.toast(string4, true);
        }

        @Override // kotlin.jvm.functions.Function0
        public /* bridge */ /* synthetic */ Unit invoke() {
            invoke2();
            return Unit.INSTANCE;
        }

        /* JADX WARN: Multi-variable type inference failed */
        /* JADX WARN: Type inference failed for: r2v3, types: [T, java.lang.String] */
        /* renamed from: invoke, reason: avoid collision after fix types in other method */
        public final void invoke2() {
            final Ref.ObjectRef objectRef = new Ref.ObjectRef();
            Iterator<String> it = this.$p.getIps().iterator();
            while (true) {
                if (!it.hasNext()) {
                    break;
                }
                String next = it.next();
                if (new CarClient(next, this.$p.getPin(), 0, 4, null).ping().getOk()) {
                    objectRef.element = next;
                    break;
                }
            }
            String strTmp = (String) objectRef.element;
            if (strTmp == null) {
                strTmp = (String) CollectionsKt.first((List) this.$p.getIps());
            }
            final String str = strTmp;
            final MainActivity mainActivity = this.this$0;
            final PairingLink.Data data = this.$p;
            mainActivity.runOnUiThread(new Runnable() { // from class: com.example.carcontroller.MainActivity$applyPairing$1$$ExternalSyntheticLambda0
                @Override // java.lang.Runnable
                public final void run() {
                    MainActivity.AnonymousClass1.invoke$lambda$0(mainActivity, str, data, objectRef);
                }
            });
        }
    }

    /* compiled from: MainActivity.kt */
        /* renamed from: com.example.carcontroller.MainActivity$autoPing$1, reason: invalid class name and case insensitive filesystem */
    static final class C00261 implements Function0<Unit> {
        final /* synthetic */ String $ip;
        final /* synthetic */ String $pin;
        final /* synthetic */ MainActivity this$0;

        /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
        C00261(String str, String str2, MainActivity mainActivity) {
            this.$ip = str;
            this.$pin = str2;
            this.this$0 = mainActivity;
        }

        /* JADX INFO: Access modifiers changed from: private */
        public static final void invoke$lambda$0(boolean z, MainActivity this$0) {
            Intrinsics.checkNotNullParameter(this$0, "this$0");
            if (!z || this$0.isFinishing() || this$0.isDestroyed()) {
                return;
            }
            State state = State.OK;
            String string = this$0.getString(R.string.status_connected);
            Intrinsics.checkNotNullExpressionValue(string, "getString(...)");
            this$0.setStatus(state, string);
        }

        @Override // kotlin.jvm.functions.Function0
        public /* bridge */ /* synthetic */ Unit invoke() {
            invoke2();
            return Unit.INSTANCE;
        }

        /* renamed from: invoke, reason: avoid collision after fix types in other method */
        public final void invoke2() {
            final boolean ok = new CarClient(this.$ip, this.$pin, 0, 4, null).ping().getOk();
            final MainActivity mainActivity = this.this$0;
            mainActivity.runOnUiThread(new Runnable() { // from class: com.example.carcontroller.MainActivity$autoPing$1$$ExternalSyntheticLambda0
                @Override // java.lang.Runnable
                public final void run() {
                    MainActivity.C00261.invoke$lambda$0(ok, mainActivity);
                }
            });
        }
    }

    /* compiled from: MainActivity.kt */
        /* renamed from: com.example.carcontroller.MainActivity$connectAndTest$1, reason: invalid class name and case insensitive filesystem */
    static final class C00271 implements Function0<Unit> {
        final /* synthetic */ String $ip;
        final /* synthetic */ String $pin;
        final /* synthetic */ MainActivity this$0;

        /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
        C00271(String str, String str2, MainActivity mainActivity) {
            this.$ip = str;
            this.$pin = str2;
            this.this$0 = mainActivity;
        }

        /* JADX INFO: Access modifiers changed from: private */
        public static final void invoke$lambda$0(MainActivity this$0, CarClient.Result result) {
            Intrinsics.checkNotNullParameter(this$0, "this$0");
            Intrinsics.checkNotNullParameter(result, "$result");
            if (this$0.isFinishing() || this$0.isDestroyed()) {
                return;
            }
            if (!result.getOk()) {
                this$0.showResult(result, "");
                return;
            }
            State state = State.OK;
            String string = this$0.getString(R.string.status_connected);
            Intrinsics.checkNotNullExpressionValue(string, "getString(...)");
            this$0.setStatus(state, string);
            String string2 = this$0.getString(R.string.res_connected);
            Intrinsics.checkNotNullExpressionValue(string2, "getString(...)");
            MainActivity.toast$default(this$0, string2, false, 2, null);
        }

        @Override // kotlin.jvm.functions.Function0
        public /* bridge */ /* synthetic */ Unit invoke() {
            invoke2();
            return Unit.INSTANCE;
        }

        /* renamed from: invoke, reason: avoid collision after fix types in other method */
        public final void invoke2() {
            final CarClient.Result resultPing = new CarClient(this.$ip, this.$pin, 0, 4, null).ping();
            final MainActivity mainActivity = this.this$0;
            mainActivity.runOnUiThread(new Runnable() { // from class: com.example.carcontroller.MainActivity$connectAndTest$1$$ExternalSyntheticLambda0
                @Override // java.lang.Runnable
                public final void run() {
                    MainActivity.C00271.invoke$lambda$0(mainActivity, resultPing);
                }
            });
        }
    }

    /* compiled from: MainActivity.kt */
        /* renamed from: com.example.carcontroller.MainActivity$send$1, reason: invalid class name and case insensitive filesystem */
    static final class C00281 implements Function0<Unit> {
        final /* synthetic */ String $cmd;
        final /* synthetic */ String $ip;
        final /* synthetic */ String $label;
        final /* synthetic */ String $pin;
        final /* synthetic */ MainActivity this$0;

        /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
        C00281(String str, String str2, String str3, MainActivity mainActivity, String str4) {
            this.$ip = str;
            this.$pin = str2;
            this.$cmd = str3;
            this.this$0 = mainActivity;
            this.$label = str4;
        }

        /* JADX INFO: Access modifiers changed from: private */
        public static final void invoke$lambda$0(MainActivity this$0, CarClient.Result result, String label) {
            Intrinsics.checkNotNullParameter(this$0, "this$0");
            Intrinsics.checkNotNullParameter(result, "$result");
            Intrinsics.checkNotNullParameter(label, "$label");
            if (this$0.isFinishing() || this$0.isDestroyed()) {
                return;
            }
            this$0.showResult(result, label);
        }

        @Override // kotlin.jvm.functions.Function0
        public Unit invoke() {
            try {
                invoke2();
            } catch (IOException e) {
                throw new RuntimeException(e);
            }
            return Unit.INSTANCE;
        }

        /* renamed from: invoke, reason: avoid collision after fix types in other method */
        public final void invoke2() throws IOException {
            final CarClient.Result resultSend = new CarClient(this.$ip, this.$pin, 0, 4, null).send(this.$cmd);
            final MainActivity mainActivity = this.this$0;
            final String str = this.$label;
            mainActivity.runOnUiThread(new Runnable() { // from class: com.example.carcontroller.MainActivity$send$1$$ExternalSyntheticLambda0
                @Override // java.lang.Runnable
                public final void run() {
                    MainActivity.C00281.invoke$lambda$0(mainActivity, resultSend, str);
                }
            });
        }
    }

    /* JADX WARN: Type inference failed for: r0v9, types: [com.example.carcontroller.MainActivity$listener$1] */
    public MainActivity() {
        ActivityResultLauncher<String> activityResultLauncherRegisterForActivityResult = registerForActivityResult(new ActivityResultContracts.RequestPermission(), new ActivityResultCallback() { // from class: com.example.carcontroller.MainActivity$$ExternalSyntheticLambda11
            @Override // androidx.activity.result.ActivityResultCallback
            public final void onActivityResult(Object obj) {
                MainActivity.micPermission$lambda$0(MainActivity.this, (Boolean) obj);
            }
        });
        Intrinsics.checkNotNullExpressionValue(activityResultLauncherRegisterForActivityResult, "registerForActivityResult(...)");
        this.micPermission = activityResultLauncherRegisterForActivityResult;
        ActivityResultLauncher<Intent> activityResultLauncherRegisterForActivityResult2 = registerForActivityResult(new ActivityResultContracts.StartActivityForResult(), new ActivityResultCallback() { // from class: com.example.carcontroller.MainActivity$$ExternalSyntheticLambda1
            @Override // androidx.activity.result.ActivityResultCallback
            public final void onActivityResult(Object obj) {
                MainActivity.systemVoice$lambda$1(MainActivity.this, (ActivityResult) obj);
            }
        });
        Intrinsics.checkNotNullExpressionValue(activityResultLauncherRegisterForActivityResult2, "registerForActivityResult(...)");
        this.systemVoice = activityResultLauncherRegisterForActivityResult2;
        ActivityResultLauncher<ScanOptions> activityResultLauncherRegisterForActivityResult3 = registerForActivityResult(new ScanContract(), new ActivityResultCallback() { // from class: com.example.carcontroller.MainActivity$$ExternalSyntheticLambda2
            @Override // androidx.activity.result.ActivityResultCallback
            public final void onActivityResult(Object obj) {
                MainActivity.qrScanner$lambda$2(MainActivity.this, (ScanIntentResult) obj);
            }
        });
        Intrinsics.checkNotNullExpressionValue(activityResultLauncherRegisterForActivityResult3, "registerForActivityResult(...)");
        this.qrScanner = activityResultLauncherRegisterForActivityResult3;
        this.listener = new RecognitionListener() { // from class: com.example.carcontroller.MainActivity$listener$1
            @Override // android.speech.RecognitionListener
            public void onBeginningOfSpeech() {
            }

            @Override // android.speech.RecognitionListener
            public void onBufferReceived(byte[] buffer) {
            }

            @Override // android.speech.RecognitionListener
            public void onEndOfSpeech() {
                MainActivity.this.setListening(false);
            }

            @Override // android.speech.RecognitionListener
            public void onError(int error) {
                MainActivity.this.setListening(false);
                switch (error) {
                    case 6:
                    case 7:
                        MainActivity mainActivity = MainActivity.this;
                        String string = mainActivity.getString(R.string.voice_no_match);
                        Intrinsics.checkNotNullExpressionValue(string, "getString(...)");
                        MainActivity.toast$default(mainActivity, string, false, 2, null);
                        break;
                    case 8:
                    default:
                        MainActivity mainActivity2 = MainActivity.this;
                        String string2 = mainActivity2.getString(R.string.voice_error, new Object[]{Integer.valueOf(error)});
                        Intrinsics.checkNotNullExpressionValue(string2, "getString(...)");
                        mainActivity2.toast(string2, true);
                        break;
                    case 9:
                        MainActivity mainActivity3 = MainActivity.this;
                        String string3 = mainActivity3.getString(R.string.mic_denied);
                        Intrinsics.checkNotNullExpressionValue(string3, "getString(...)");
                        mainActivity3.toast(string3, true);
                        break;
                }
            }

            @Override // android.speech.RecognitionListener
            public void onEvent(int eventType, Bundle params) {
            }

            @Override // android.speech.RecognitionListener
            public void onPartialResults(Bundle partialResults) {
            }

            @Override // android.speech.RecognitionListener
            public void onReadyForSpeech(Bundle params) {
                MainActivity.this.setListening(true);
            }

            @Override // android.speech.RecognitionListener
            public void onResults(Bundle results) {
                Intrinsics.checkNotNullParameter(results, "results");
                MainActivity.this.setListening(false);
                MainActivity mainActivity = MainActivity.this;
                ArrayList<String> stringArrayList = results.getStringArrayList("results_recognition");
                if (stringArrayList == null) {
                    stringArrayList = new ArrayList<>();
                }
                mainActivity.handleVoice(stringArrayList);
            }

            @Override // android.speech.RecognitionListener
            public void onRmsChanged(float rmsdB) {
            }
        };
    }

    private final void applyInsets() {
        final View viewFindViewById = findViewById(R.id.topBar);
        final View viewFindViewById2 = findViewById(R.id.scroll);
        final int paddingTop = viewFindViewById.getPaddingTop();
        final int paddingBottom = viewFindViewById2.getPaddingBottom();
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.root), new OnApplyWindowInsetsListener() { // from class: com.example.carcontroller.MainActivity$$ExternalSyntheticLambda0
            @Override // androidx.core.view.OnApplyWindowInsetsListener
            public final WindowInsetsCompat onApplyWindowInsets(View view, WindowInsetsCompat windowInsetsCompat) {
                return MainActivity.applyInsets$lambda$7(viewFindViewById, paddingTop, viewFindViewById2, paddingBottom, view, windowInsetsCompat);
            }
        });
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final WindowInsetsCompat applyInsets$lambda$7(View view, int i, View view2, int i2, View view3, WindowInsetsCompat insets) {
        Intrinsics.checkNotNullParameter(view3, "<anonymous parameter 0>");
        Intrinsics.checkNotNullParameter(insets, "insets");
        Insets insets2 = insets.getInsets(WindowInsetsCompat.Type.systemBars());
        Intrinsics.checkNotNullExpressionValue(insets2, "getInsets(...)");
        view.setPadding(view.getPaddingLeft(), insets2.top + i, view.getPaddingRight(), view.getPaddingBottom());
        view2.setPadding(view2.getPaddingLeft(), view2.getPaddingTop(), view2.getPaddingRight(), insets2.bottom + i2);
        return insets;
    }

    private final void applyPairing(PairingLink.Data p) {
        State state = State.BUSY;
        String string = getString(R.string.status_sending);
        Intrinsics.checkNotNullExpressionValue(string, "getString(...)");
        setStatus(state, string);
        ThreadsKt.thread((21 & 1) != 0, (21 & 2) != 0 ? false : false, (21 & 4) != 0 ? null : null, (21 & 8) != 0 ? null : null, (21 & 16) != 0 ? -1 : 0, new AnonymousClass1(p, this));
    }

    private final void autoPing() {
        String strCurrentIp = currentIp();
        String strCurrentPin = currentPin();
        if (strCurrentIp.length() == 0) {
            return;
        }
        if (strCurrentPin.length() == 0) {
            return;
        }
        ThreadsKt.thread((21 & 1) != 0, (21 & 2) != 0 ? false : false, (21 & 4) != 0 ? null : null, (21 & 8) != 0 ? null : null, (21 & 16) != 0 ? -1 : 0, new C00261(strCurrentIp, strCurrentPin, this));
    }

    private final View buildRow(LayoutInflater inflater, ViewGroup parent, final Control c) {
        View viewInflate = inflater.inflate(R.layout.item_control_row, parent, false);
        ((ImageView) viewInflate.findViewById(R.id.ivIcon)).setImageResource(c.getIcon());
        ((TextView) viewInflate.findViewById(R.id.tvLabel)).setText(c.getLabel());
        MaterialButton materialButton = (MaterialButton) viewInflate.findViewById(R.id.btnA);
        materialButton.setText(c.getALabel());
        materialButton.setOnClickListener(new View.OnClickListener() { // from class: com.example.carcontroller.MainActivity$$ExternalSyntheticLambda8
            @Override // android.view.View.OnClickListener
            public final void onClick(View view) {
                MainActivity.buildRow$lambda$8(MainActivity.this, c, view);
            }
        });
        MaterialButton materialButton2 = (MaterialButton) viewInflate.findViewById(R.id.btnB);
        final Integer bLabel = c.getBLabel();
        final String bCmd = c.getBCmd();
        if (bLabel == null || bCmd == null) {
            materialButton2.setVisibility(8);
        } else {
            materialButton2.setText(bLabel.intValue());
            materialButton2.setOnClickListener(new View.OnClickListener() { // from class: com.example.carcontroller.MainActivity$$ExternalSyntheticLambda9
                @Override // android.view.View.OnClickListener
                public final void onClick(View view) {
                    MainActivity.buildRow$lambda$9(MainActivity.this, bCmd, c, bLabel, view);
                }
            });
        }
        Intrinsics.checkNotNull(viewInflate);
        return viewInflate;
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final void buildRow$lambda$8(MainActivity this$0, Control c, View view) {
        Intrinsics.checkNotNullParameter(this$0, "this$0");
        Intrinsics.checkNotNullParameter(c, "$c");
        view.performHapticFeedback(1);
        this$0.send(c.getACmd(), this$0.getString(c.getLabel()) + " · " + this$0.getString(c.getALabel()));
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final void buildRow$lambda$9(MainActivity this$0, String str, Control c, Integer num, View view) {
        Intrinsics.checkNotNullParameter(this$0, "this$0");
        Intrinsics.checkNotNullParameter(c, "$c");
        view.performHapticFeedback(1);
        this$0.send(str, this$0.getString(c.getLabel()) + " · " + this$0.getString(num.intValue()));
    }

    private final void buildSections() {
        LinearLayout linearLayout = (LinearLayout) findViewById(R.id.sectionsContainer);
        LayoutInflater layoutInflaterFrom = LayoutInflater.from(this);
        for (Section section : Controls.INSTANCE.getSections()) {
            View viewInflate = layoutInflaterFrom.inflate(R.layout.item_section, (ViewGroup) linearLayout, false);
            ((ImageView) viewInflate.findViewById(R.id.ivSectionIcon)).setImageResource(section.getIcon());
            ((TextView) viewInflate.findViewById(R.id.tvSectionTitle)).setText(section.getTitle());
            LinearLayout linearLayout2 = (LinearLayout) viewInflate.findViewById(R.id.rowsContainer);
            for (Control control : section.getItems()) {
                Intrinsics.checkNotNull(layoutInflaterFrom);
                Intrinsics.checkNotNull(linearLayout2);
                linearLayout2.addView(buildRow(layoutInflaterFrom, linearLayout2, control));
            }
            linearLayout.addView(viewInflate);
        }
    }

    private final void confirmReboot() {
        new MaterialAlertDialogBuilder(this).setTitle(R.string.reboot_title).setMessage(R.string.reboot_msg).setPositiveButton(R.string.reboot_yes, new DialogInterface.OnClickListener() { // from class: com.example.carcontroller.MainActivity$$ExternalSyntheticLambda7
            @Override // android.content.DialogInterface.OnClickListener
            public final void onClick(DialogInterface dialogInterface, int i) {
                MainActivity.confirmReboot$lambda$10(MainActivity.this, dialogInterface, i);
            }
        }).setNegativeButton(R.string.cancel, (DialogInterface.OnClickListener) null).show();
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final void confirmReboot$lambda$10(MainActivity this$0, DialogInterface dialogInterface, int i) {
        Intrinsics.checkNotNullParameter(this$0, "this$0");
        String string = this$0.getString(R.string.btn_reboot);
        Intrinsics.checkNotNullExpressionValue(string, "getString(...)");
        this$0.send(Cmd.REBOOT, string);
    }

    private final void connectAndTest() {
        if (requireConnection()) {
            String strCurrentIp = currentIp();
            String strCurrentPin = currentPin();
            save(strCurrentIp, strCurrentPin);
            State state = State.BUSY;
            String string = getString(R.string.status_sending);
            Intrinsics.checkNotNullExpressionValue(string, "getString(...)");
            setStatus(state, string);
            ThreadsKt.thread((21 & 1) != 0, (21 & 2) != 0 ? false : false, (21 & 4) != 0 ? null : null, (21 & 8) != 0 ? null : null, (21 & 16) != 0 ? -1 : 0, new C00271(strCurrentIp, strCurrentPin, this));
        }
    }

    private final String currentIp() {
        String string;
        TextInputEditText textInputEditText = this.etIp;
        String string2 = null;
        if (textInputEditText == null) {
            Intrinsics.throwUninitializedPropertyAccessException("etIp");
            textInputEditText = null;
        }
        Editable text = textInputEditText.getText();
        if (text != null && (string = text.toString()) != null) {
            string2 = StringsKt.trim((CharSequence) string).toString();
        }
        return string2 == null ? "" : string2;
    }

    private final String currentPin() {
        String string;
        TextInputEditText textInputEditText = this.etPin;
        String string2 = null;
        if (textInputEditText == null) {
            Intrinsics.throwUninitializedPropertyAccessException("etPin");
            textInputEditText = null;
        }
        Editable text = textInputEditText.getText();
        if (text != null && (string = text.toString()) != null) {
            string2 = StringsKt.trim((CharSequence) string).toString();
        }
        return string2 == null ? "" : string2;
    }

    private final String describe(CarClient.Result r) {
        int i;
        switch (WhenMappings.$EnumSwitchMapping$1[r.getCode().ordinal()]) {
            case 1:
                i = R.string.res_connected;
                break;
            case 2:
                i = R.string.res_auth;
                break;
            case 3:
                i = R.string.res_locked;
                break;
            case 4:
                i = R.string.res_unknown;
                break;
            case 5:
                i = R.string.res_exec;
                break;
            case 6:
                i = R.string.res_format;
                break;
            case 7:
                i = R.string.res_unreachable;
                break;
            case 8:
                i = R.string.res_timeout;
                break;
            case 9:
                i = R.string.res_bad_ip;
                break;
            case 10:
                i = R.string.res_no_reply;
                break;
            case 11:
                i = R.string.res_io;
                break;
            default:
                throw new NoWhenBranchMatchedException();
        }
        String string = getString(i);
        Intrinsics.checkNotNullExpressionValue(string, "getString(...)");
        return string;
    }

    private final boolean handlePairingIntent(Intent i) {
        Uri data;
        if (i == null || !Intrinsics.areEqual(i.getAction(), "android.intent.action.VIEW") || (data = i.getData()) == null || !StringsKt.equals(PairingLink.SCHEME, data.getScheme(), true)) {
            return false;
        }
        PairingLink pairingLink = PairingLink.INSTANCE;
        String string = data.toString();
        Intrinsics.checkNotNullExpressionValue(string, "toString(...)");
        final PairingLink.Data data2 = pairingLink.parse(string);
        if (data2 != null) {
            new MaterialAlertDialogBuilder(this).setTitle(R.string.pair_dialog_title).setMessage((CharSequence) getString(R.string.pair_dialog_msg, new Object[]{CollectionsKt.first((List) data2.getIps())})).setPositiveButton(R.string.pair_yes, new DialogInterface.OnClickListener() { // from class: com.example.carcontroller.MainActivity$$ExternalSyntheticLambda10
                @Override // android.content.DialogInterface.OnClickListener
                public final void onClick(DialogInterface dialogInterface, int i2) {
                    MainActivity.handlePairingIntent$lambda$11(MainActivity.this, data2, dialogInterface, i2);
                }
            }).setNegativeButton(R.string.cancel, (DialogInterface.OnClickListener) null).show();
            return true;
        }
        String string2 = getString(R.string.qr_invalid);
        Intrinsics.checkNotNullExpressionValue(string2, "getString(...)");
        toast(string2, true);
        return true;
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final void handlePairingIntent$lambda$11(MainActivity this$0, PairingLink.Data data, DialogInterface dialogInterface, int i) {
        Intrinsics.checkNotNullParameter(this$0, "this$0");
        this$0.applyPairing(data);
    }

    /* JADX INFO: Access modifiers changed from: private */
    public final void handleVoice(List<String> texts) {
        for (String str : texts) {
            String str2 = VoiceCommandParser.INSTANCE.parse(str);
            if (str2 != null) {
                String string = getString(R.string.voice_heard, new Object[]{str});
                Intrinsics.checkNotNullExpressionValue(string, "getString(...)");
                toast$default(this, string, false, 2, null);
                send(str2, str);
                return;
            }
        }
        String string2 = texts.isEmpty() ? getString(R.string.voice_no_match) : getString(R.string.voice_unknown, new Object[]{CollectionsKt.first((List) texts)});
        Intrinsics.checkNotNull(string2);
        toast(string2, true);
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final void micPermission$lambda$0(MainActivity this$0, Boolean bool) {
        Intrinsics.checkNotNullParameter(this$0, "this$0");
        Intrinsics.checkNotNull(bool);
        if (bool.booleanValue()) {
            this$0.startVoice();
            return;
        }
        String string = this$0.getString(R.string.mic_denied);
        Intrinsics.checkNotNullExpressionValue(string, "getString(...)");
        this$0.toast(string, true);
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final void onCreate$lambda$3(MainActivity this$0, View view) {
        Intrinsics.checkNotNullParameter(this$0, "this$0");
        this$0.connectAndTest();
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final void onCreate$lambda$4(MainActivity this$0, View view) {
        Intrinsics.checkNotNullParameter(this$0, "this$0");
        this$0.scanQr();
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final void onCreate$lambda$5(MainActivity this$0, View view) {
        Intrinsics.checkNotNullParameter(this$0, "this$0");
        this$0.onVoiceClicked();
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final void onCreate$lambda$6(MainActivity this$0, View view) {
        Intrinsics.checkNotNullParameter(this$0, "this$0");
        this$0.confirmReboot();
    }

    private final void onVoiceClicked() {
        if (ContextCompat.checkSelfPermission(this, "android.permission.RECORD_AUDIO") != 0) {
            this.micPermission.launch("android.permission.RECORD_AUDIO");
        } else {
            startVoice();
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final void qrScanner$lambda$2(MainActivity this$0, ScanIntentResult scanIntentResult) {
        Intrinsics.checkNotNullParameter(this$0, "this$0");
        String contents = scanIntentResult.getContents();
        if (contents == null) {
            return;
        }
        PairingLink.Data data = PairingLink.INSTANCE.parse(contents);
        if (data != null) {
            this$0.applyPairing(data);
            return;
        }
        String string = this$0.getString(R.string.qr_invalid);
        Intrinsics.checkNotNullExpressionValue(string, "getString(...)");
        this$0.toast(string, true);
    }

    private final Intent recognizerIntent() {
        Intent intent = new Intent("android.speech.action.RECOGNIZE_SPEECH");
        intent.putExtra("android.speech.extra.LANGUAGE_MODEL", "free_form");
        intent.putExtra("android.speech.extra.LANGUAGE", "ar-SA");
        intent.putExtra("android.speech.extra.MAX_RESULTS", 5);
        return intent;
    }

    private final boolean requireConnection() {
        if (currentIp().length() == 0) {
            String string = getString(R.string.msg_need_ip);
            Intrinsics.checkNotNullExpressionValue(string, "getString(...)");
            toast(string, true);
            return false;
        }
        if (!(currentPin().length() == 0)) {
            return true;
        }
        String string2 = getString(R.string.msg_need_pin);
        Intrinsics.checkNotNullExpressionValue(string2, "getString(...)");
        toast(string2, true);
        return false;
    }

    /* JADX INFO: Access modifiers changed from: private */
    public final void save(String ip, String pin) {
        SharedPreferences sharedPreferences = this.prefs;
        if (sharedPreferences == null) {
            Intrinsics.throwUninitializedPropertyAccessException("prefs");
            sharedPreferences = null;
        }
        sharedPreferences.edit().putString(KEY_IP, ip).putString(KEY_PIN, pin).apply();
    }

    private final void scanQr() {
        try {
            this.qrScanner.launch(new ScanOptions().setDesiredBarcodeFormats("QR_CODE").setPrompt(getString(R.string.qr_prompt)).setBeepEnabled(false).setOrientationLocked(false));
        } catch (ActivityNotFoundException e) {
            String string = getString(R.string.qr_scan_failed);
            Intrinsics.checkNotNullExpressionValue(string, "getString(...)");
            toast(string, true);
        }
    }

    private final void send(String cmd, String label) {
        if (requireConnection()) {
            String strCurrentIp = currentIp();
            String strCurrentPin = currentPin();
            save(strCurrentIp, strCurrentPin);
            State state = State.BUSY;
            String string = getString(R.string.status_sending);
            Intrinsics.checkNotNullExpressionValue(string, "getString(...)");
            setStatus(state, string);
            ThreadsKt.thread((21 & 1) != 0, (21 & 2) != 0 ? false : false, (21 & 4) != 0 ? null : null, (21 & 8) != 0 ? null : null, (21 & 16) != 0 ? -1 : 0, new C00281(strCurrentIp, strCurrentPin, cmd, this, label));
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    public final void setListening(boolean on) {
        MaterialButton materialButton = this.btnVoice;
        if (materialButton == null) {
            Intrinsics.throwUninitializedPropertyAccessException("btnVoice");
            materialButton = null;
        }
        materialButton.setText(on ? R.string.voice_listening : R.string.btn_voice);
    }

    /* JADX INFO: Access modifiers changed from: private */
    public final void setStatus(State state, String text) {
        int i;
        TextView textView = this.tvStatus;
        View view = null;
        if (textView == null) {
            Intrinsics.throwUninitializedPropertyAccessException("tvStatus");
            textView = null;
        }
        textView.setText(text);
        switch (WhenMappings.$EnumSwitchMapping$0[state.ordinal()]) {
            case 1:
                i = R.color.idle;
                break;
            case 2:
                i = R.color.warning;
                break;
            case 3:
                i = R.color.success;
                break;
            case 4:
                i = R.color.danger;
                break;
            default:
                throw new NoWhenBranchMatchedException();
        }
        View view2 = this.dotStatus;
        if (view2 == null) {
            Intrinsics.throwUninitializedPropertyAccessException("dotStatus");
        } else {
            view = view2;
        }
        view.setBackgroundTintList(ColorStateList.valueOf(ContextCompat.getColor(this, i)));
    }

    /* JADX INFO: Access modifiers changed from: private */
    /* JADX WARN: Removed duplicated region for block: B:14:0x005a  */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct add '--show-bad-code' argument
    */
    private final void showResult(CarClient.Result r, String label) {
        Intrinsics.checkNotNullParameter(r, "r");
        Intrinsics.checkNotNullParameter(label, "label");
        if (r.getOk()) {
            setStatus(State.OK, getString(R.string.res_ok, new Object[]{label}));
            return;
        }
        String message = describe(r);
        setStatus(State.ERROR, message);
        String full;
        if (r.getCode() == CarClient.Code.EXEC && r.getDetail().length() > 0) {
            full = message + '\n' + r.getDetail();
        } else {
            full = message;
        }
        toast(full, true);
    }


    private final void sizeHero() {
        android.util.DisplayMetrics r0 = getResources().getDisplayMetrics();
        int iCoerceAtLeast = RangesKt.coerceAtLeast((int) Math.min(0.74f * ((r0.widthPixels * 3.0f) / 4.0f), r0.heightPixels * 0.3f), (int) (16 * r0.density));
        View viewFindViewById = findViewById(R.id.heroSpace);
        ViewGroup.LayoutParams layoutParams = viewFindViewById.getLayoutParams();
        layoutParams.height = iCoerceAtLeast;
        viewFindViewById.setLayoutParams(layoutParams);
    }

    private final void startVoice() {
        if (!SpeechRecognizer.isRecognitionAvailable(this)) {
            try {
                this.systemVoice.launch(recognizerIntent());
                return;
            } catch (ActivityNotFoundException e) {
                String string = getString(R.string.voice_unavailable);
                Intrinsics.checkNotNullExpressionValue(string, "getString(...)");
                toast(string, true);
                return;
            }
        }
        SpeechRecognizer speechRecognizerCreateSpeechRecognizer = this.recognizer;
        if (speechRecognizerCreateSpeechRecognizer == null) {
            speechRecognizerCreateSpeechRecognizer = SpeechRecognizer.createSpeechRecognizer(this);
            speechRecognizerCreateSpeechRecognizer.setRecognitionListener(this.listener);
            this.recognizer = speechRecognizerCreateSpeechRecognizer;
        }
        speechRecognizerCreateSpeechRecognizer.startListening(recognizerIntent());
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final void systemVoice$lambda$1(MainActivity this$0, ActivityResult activityResult) {
        Intrinsics.checkNotNullParameter(this$0, "this$0");
        if (activityResult.getResultCode() == -1) {
            Intent data = activityResult.getData();
            ArrayList<String> stringArrayListExtra = data != null ? data.getStringArrayListExtra("android.speech.extra.RESULTS") : null;
            if (stringArrayListExtra == null) {
                stringArrayListExtra = new ArrayList<>();
            }
            this$0.handleVoice(stringArrayListExtra);
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    public final void toast(String message, boolean z) {
        Toast.makeText(this, message, z ? 1 : 0).show();
    }

    static /* synthetic */ void toast$default(MainActivity mainActivity, String str, boolean z, int i, Object obj) {
        if ((i & 2) != 0) {
            z = false;
        }
        mainActivity.toast(str, z);
    }

    @Override // androidx.fragment.app.FragmentActivity, androidx.activity.ComponentActivity, androidx.core.app.ComponentActivity, android.app.Activity
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        WindowCompat.setDecorFitsSystemWindows(getWindow(), false);
        setContentView(R.layout.activity_main);
        SharedPreferences sharedPreferences = getSharedPreferences(PREFS, 0);
        Intrinsics.checkNotNullExpressionValue(sharedPreferences, "getSharedPreferences(...)");
        this.prefs = sharedPreferences;
        View viewFindViewById = findViewById(R.id.etCarIp);
        Intrinsics.checkNotNullExpressionValue(viewFindViewById, "findViewById(...)");
        this.etIp = (TextInputEditText) viewFindViewById;
        View viewFindViewById2 = findViewById(R.id.etPin);
        Intrinsics.checkNotNullExpressionValue(viewFindViewById2, "findViewById(...)");
        this.etPin = (TextInputEditText) viewFindViewById2;
        View viewFindViewById3 = findViewById(R.id.tvStatus);
        Intrinsics.checkNotNullExpressionValue(viewFindViewById3, "findViewById(...)");
        this.tvStatus = (TextView) viewFindViewById3;
        View viewFindViewById4 = findViewById(R.id.dotStatus);
        Intrinsics.checkNotNullExpressionValue(viewFindViewById4, "findViewById(...)");
        this.dotStatus = viewFindViewById4;
        View viewFindViewById5 = findViewById(R.id.btnVoiceCommand);
        Intrinsics.checkNotNullExpressionValue(viewFindViewById5, "findViewById(...)");
        this.btnVoice = (MaterialButton) viewFindViewById5;
        applyInsets();
        sizeHero();
        buildSections();
        TextInputEditText textInputEditText = this.etIp;
        MaterialButton materialButton = null;
        if (textInputEditText == null) {
            Intrinsics.throwUninitializedPropertyAccessException("etIp");
            textInputEditText = null;
        }
        SharedPreferences sharedPreferences2 = this.prefs;
        if (sharedPreferences2 == null) {
            Intrinsics.throwUninitializedPropertyAccessException("prefs");
            sharedPreferences2 = null;
        }
        String string = sharedPreferences2.getString(KEY_IP, "");
        if (string == null) {
            string = "";
        }
        textInputEditText.setText(string);
        TextInputEditText textInputEditText2 = this.etPin;
        if (textInputEditText2 == null) {
            Intrinsics.throwUninitializedPropertyAccessException("etPin");
            textInputEditText2 = null;
        }
        SharedPreferences sharedPreferences3 = this.prefs;
        if (sharedPreferences3 == null) {
            Intrinsics.throwUninitializedPropertyAccessException("prefs");
            sharedPreferences3 = null;
        }
        String string2 = sharedPreferences3.getString(KEY_PIN, "");
        textInputEditText2.setText(string2 != null ? string2 : "");
        State state = State.IDLE;
        String string3 = getString(R.string.status_disconnected);
        Intrinsics.checkNotNullExpressionValue(string3, "getString(...)");
        setStatus(state, string3);
        ((MaterialButton) findViewById(R.id.btnConnect)).setOnClickListener(new View.OnClickListener() { // from class: com.example.carcontroller.MainActivity$$ExternalSyntheticLambda3
            @Override // android.view.View.OnClickListener
            public final void onClick(View view) {
                MainActivity.onCreate$lambda$3(MainActivity.this, view);
            }
        });
        ((MaterialButton) findViewById(R.id.btnScan)).setOnClickListener(new View.OnClickListener() { // from class: com.example.carcontroller.MainActivity$$ExternalSyntheticLambda4
            @Override // android.view.View.OnClickListener
            public final void onClick(View view) {
                MainActivity.onCreate$lambda$4(MainActivity.this, view);
            }
        });
        MaterialButton materialButton2 = this.btnVoice;
        if (materialButton2 == null) {
            Intrinsics.throwUninitializedPropertyAccessException("btnVoice");
        } else {
            materialButton = materialButton2;
        }
        materialButton.setOnClickListener(new View.OnClickListener() { // from class: com.example.carcontroller.MainActivity$$ExternalSyntheticLambda5
            @Override // android.view.View.OnClickListener
            public final void onClick(View view) {
                MainActivity.onCreate$lambda$5(MainActivity.this, view);
            }
        });
        ((MaterialButton) findViewById(R.id.btnReboot)).setOnClickListener(new View.OnClickListener() { // from class: com.example.carcontroller.MainActivity$$ExternalSyntheticLambda6
            @Override // android.view.View.OnClickListener
            public final void onClick(View view) {
                MainActivity.onCreate$lambda$6(MainActivity.this, view);
            }
        });
        if (savedInstanceState != null || handlePairingIntent(getIntent())) {
            return;
        }
        autoPing();
    }

    @Override // androidx.appcompat.app.AppCompatActivity, androidx.fragment.app.FragmentActivity, android.app.Activity
    protected void onDestroy() {
        super.onDestroy();
        SpeechRecognizer speechRecognizer = this.recognizer;
        if (speechRecognizer != null) {
            speechRecognizer.destroy();
        }
        this.recognizer = null;
    }

    @Override // androidx.fragment.app.FragmentActivity, androidx.activity.ComponentActivity, android.app.Activity
    protected void onNewIntent(Intent intent) {
        Intrinsics.checkNotNullParameter(intent, "intent");
        super.onNewIntent(intent);
        setIntent(intent);
        handlePairingIntent(intent);
    }
}
