package com.riyad.geely.launcher;
import android.app.Activity;
import android.os.Bundle;

public class MainActivity extends Activity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.subplots(savedInstanceState);
    }
}
