package com.onehub.gaugewidget;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.PixelFormat;
import android.os.Build;
import android.os.IBinder;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.MotionEvent;
import android.view.View;
import android.view.WindowManager;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.Toast;

import androidx.core.app.NotificationCompat;

public class FloatingGaugeService extends Service {

    public static final String ACTION_START = "com.onehub.gaugewidget.START_FLOATING";
    public static final String ACTION_STOP = "com.onehub.gaugewidget.STOP_FLOATING";
    public static final String ACTION_UPDATE_STYLE = "com.onehub.gaugewidget.UPDATE_STYLE";
    public static final String EXTRA_STYLE = "style";

    private static final String CHANNEL_ID = "floating_gauge_channel";
    private static final int NOTIFICATION_ID = 1001;

    private WindowManager windowManager;
    private View floatingView;
    private WindowManager.LayoutParams params;
    private String currentStyle = "a";

    private int initialX, initialY;
    private float initialTouchX, initialTouchY;

    @Override
    public IBinder onBind(Intent intent) {
        return null;
    }

    @Override
    public void onCreate() {
        super.onCreate();
        windowManager = (WindowManager) getSystemService(WINDOW_SERVICE);
        createNotificationChannel();
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        if (intent == null) {
            // Service restarted by system — restore if preference is on
            SharedPreferences prefs = getSharedPreferences(GaugeWidgetProvider.PREFS_NAME, MODE_PRIVATE);
            if (prefs.getBoolean("floating_enabled", false)) {
                if (floatingView == null) {
                    currentStyle = prefs.getString("floating_style", "a");
                    showFloatingWindow();
                }
                startForeground(NOTIFICATION_ID, buildNotification());
                return START_STICKY;
            }
            stopSelf();
            return START_NOT_STICKY;
        }

        String action = intent.getAction();

        if (ACTION_STOP.equals(action)) {
            stopFloating();
            return START_NOT_STICKY;
        }

        if (ACTION_UPDATE_STYLE.equals(action)) {
            String style = intent.getStringExtra(EXTRA_STYLE);
            if (style != null) {
                currentStyle = style;
                saveStyle(style);
                applyStyle();
            }
            return START_STICKY;
        }

        // ACTION_START or default → show immediately with last style
        if (floatingView == null) {
            SharedPreferences prefs = getSharedPreferences(GaugeWidgetProvider.PREFS_NAME, MODE_PRIVATE);
            currentStyle = prefs.getString("floating_style", "a");
            showFloatingWindow();
        }

        startForeground(NOTIFICATION_ID, buildNotification());
        return START_STICKY;
    }

    private void showFloatingWindow() {
        LayoutInflater inflater = LayoutInflater.from(this);
        floatingView = inflater.inflate(R.layout.floating_gauge, null);

        int layoutType = (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O)
                ? WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
                : WindowManager.LayoutParams.TYPE_PHONE;

        params = new WindowManager.LayoutParams(
                dpToPx(220),
                dpToPx(220),
                layoutType,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE
                        | WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
                PixelFormat.TRANSLUCENT
        );

        params.gravity = Gravity.TOP | Gravity.START;
        params.x = 80;
        params.y = 180;

        applyStyle();

        // Drag the whole gauge
        floatingView.setOnTouchListener((v, event) -> {
            switch (event.getAction()) {
                case MotionEvent.ACTION_DOWN:
                    initialX = params.x;
                    initialY = params.y;
                    initialTouchX = event.getRawX();
                    initialTouchY = event.getRawY();
                    return true;
                case MotionEvent.ACTION_MOVE:
                    params.x = initialX + (int) (event.getRawX() - initialTouchX);
                    params.y = initialY + (int) (event.getRawY() - initialTouchY);
                    if (windowManager != null && floatingView != null) {
                        try {
                            windowManager.updateViewLayout(floatingView, params);
                        } catch (Exception ignored) {}
                    }
                    return true;
            }
            return false;
        });

        ImageButton btnClose = floatingView.findViewById(R.id.btn_close);
        btnClose.setOnClickListener(v -> {
            // Also turn off the preference so MainActivity switch stays in sync
            getSharedPreferences(GaugeWidgetProvider.PREFS_NAME, MODE_PRIVATE)
                    .edit()
                    .putBoolean("floating_enabled", false)
                    .apply();
            stopFloating();
        });

        ImageButton btnStyle = floatingView.findViewById(R.id.btn_style);
        btnStyle.setOnClickListener(v -> {
            Intent styleIntent = new Intent(this, StyleSelectActivity.class);
            styleIntent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            startActivity(styleIntent);
        });

        try {
            windowManager.addView(floatingView, params);
        } catch (Exception e) {
            Toast.makeText(this, "خطأ: تأكد من منح إذن الظهور فوق التطبيقات", Toast.LENGTH_LONG).show();
            stopSelf();
        }
    }

    private void applyStyle() {
        if (floatingView == null) return;

        ImageView bg = floatingView.findViewById(R.id.gauge_bg);
        ImageView needle = floatingView.findViewById(R.id.gauge_needle);

        int bgRes, needleRes;
        if ("bmw".equals(currentStyle)) {
            bgRes = getResources().getIdentifier("gauge_bmw_bg", "drawable", getPackageName());
            needleRes = getResources().getIdentifier("gauge_bmw_needle", "drawable", getPackageName());
        } else {
            bgRes = getResources().getIdentifier("gauge_" + currentStyle + "1", "drawable", getPackageName());
            needleRes = getResources().getIdentifier("gauge_" + currentStyle + "2", "drawable", getPackageName());
        }

        if (bgRes != 0) bg.setImageResource(bgRes);
        if (needleRes != 0) needle.setImageResource(needleRes);
    }

    private void saveStyle(String style) {
        getSharedPreferences(GaugeWidgetProvider.PREFS_NAME, MODE_PRIVATE)
                .edit()
                .putString("floating_style", style)
                .apply();
    }

    private void stopFloating() {
        if (floatingView != null) {
            try {
                windowManager.removeView(floatingView);
            } catch (Exception ignored) {}
            floatingView = null;
        }
        stopForeground(true);
        stopSelf();
    }

    private Notification buildNotification() {
        Intent stopIntent = new Intent(this, FloatingGaugeService.class);
        stopIntent.setAction(ACTION_STOP);
        PendingIntent stopPending = PendingIntent.getService(this, 0, stopIntent,
                PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);

        Intent openIntent = new Intent(this, MainActivity.class);
        PendingIntent openPending = PendingIntent.getActivity(this, 0, openIntent,
                PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);

        return new NotificationCompat.Builder(this, CHANNEL_ID)
                .setContentTitle("العداد العائم يعمل")
                .setContentText("اضغط للإيقاف أو فتح الإعدادات")
                .setSmallIcon(android.R.drawable.ic_menu_compass)
                .setContentIntent(openPending)
                .addAction(android.R.drawable.ic_menu_close_clear_cancel, "إيقاف", stopPending)
                .setOngoing(true)
                .setPriority(NotificationCompat.PRIORITY_LOW)
                .build();
    }

    private void createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            NotificationChannel channel = new NotificationChannel(
                    CHANNEL_ID,
                    "العداد العائم",
                    NotificationManager.IMPORTANCE_LOW
            );
            channel.setDescription("إشعار خدمة العداد العائم");
            NotificationManager manager = getSystemService(NotificationManager.class);
            if (manager != null) {
                manager.createNotificationChannel(channel);
            }
        }
    }

    private int dpToPx(int dp) {
        return Math.round(dp * getResources().getDisplayMetrics().density);
    }

    @Override
    public void onDestroy() {
        if (floatingView != null) {
            try {
                windowManager.removeView(floatingView);
            } catch (Exception ignored) {}
            floatingView = null;
        }
        super.onDestroy();
    }
}
