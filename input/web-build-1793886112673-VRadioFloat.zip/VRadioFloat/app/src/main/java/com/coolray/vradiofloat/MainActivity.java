package com.coolray.vradiofloat;

import android.Manifest;
import android.app.AppOpsManager;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Process;
import android.provider.Settings;
import android.widget.Button;
import android.widget.SeekBar;
import android.widget.Switch;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

public class MainActivity extends AppCompatActivity {
    private static final String PREFS = "vradio_float";
    private Switch sw, swHome;
    private TextView status;
    private boolean waitPerm;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        SharedPreferences sp0 = getSharedPreferences(PREFS, MODE_PRIVATE);
        if (!sp0.contains("home_only")) sp0.edit().putBoolean("home_only", true).apply();
        if (!sp0.contains("on")) sp0.edit().putBoolean("on", false).apply();

        sw = findViewById(R.id.switch_float);
        swHome = findViewById(R.id.switch_home_only);
        status = findViewById(R.id.status);

        SharedPreferences p = getSharedPreferences(PREFS, MODE_PRIVATE);
        boolean on = p.getBoolean("on", false);
        sw.setChecked(on);
        setStatus(on);
        if (swHome != null) {
            swHome.setChecked(p.getBoolean("home_only", true));
            swHome.setOnCheckedChangeListener((b, checked) -> {
                getSharedPreferences(PREFS, MODE_PRIVATE).edit()
                        .putBoolean("home_only", checked).apply();
            });
        }

        final SeekBar seek = findViewById(R.id.seek_alpha);
        final TextView alphaValue = findViewById(R.id.alpha_value);
        int alphaPct = Math.round(p.getFloat("alpha", 1f) * 100f);
        if (alphaPct < 20) alphaPct = 20;
        if (seek != null) {
            seek.setProgress(alphaPct);
            if (alphaValue != null) alphaValue.setText(alphaPct + "%");
            seek.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
                @Override public void onProgressChanged(SeekBar s, int progress, boolean fromUser) {
                    int v = Math.max(20, progress);
                    if (v != progress) s.setProgress(v);
                    if (alphaValue != null) alphaValue.setText(v + "%");
                    getSharedPreferences(PREFS, MODE_PRIVATE).edit()
                            .putFloat("alpha", v / 100f).apply();
                }
                @Override public void onStartTrackingTouch(SeekBar s) {}
                @Override public void onStopTrackingTouch(SeekBar s) {}
            });
        }
        Button down = findViewById(R.id.btn_alpha_down);
        Button up = findViewById(R.id.btn_alpha_up);
        if (down != null) down.setOnClickListener(v -> {
            if (seek != null) seek.setProgress(Math.max(20, seek.getProgress() - 5));
        });
        if (up != null) up.setOnClickListener(v -> {
            if (seek != null) seek.setProgress(Math.min(100, seek.getProgress() + 5));
        });

        if (on && canOverlay()) startSvc();

        sw.setOnCheckedChangeListener((b, checked) -> {
            if (checked) enable();
            else disable();
        });

        Button btnUsage = findViewById(R.id.btn_usage);
        if (btnUsage != null) {
            btnUsage.setOnClickListener(v -> {
                try {
                    startActivity(new Intent(Settings.ACTION_USAGE_ACCESS_SETTINGS));
                } catch (Exception e) {
                    Toast.makeText(this, R.string.need_usage, Toast.LENGTH_LONG).show();
                }
            });
        }

        // Audio permission for visualizer (optional)
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.RECORD_AUDIO)
                != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(this,
                    new String[]{Manifest.permission.RECORD_AUDIO}, 41);
        }
    }

    private void enable() {
        if (!canOverlay()) {
            waitPerm = true;
            sw.setChecked(false);
            try {
                Intent i = new Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                        Uri.parse("package:" + getPackageName()));
                startActivity(i);
            } catch (Exception e) {
                Toast.makeText(this, R.string.need_overlay, Toast.LENGTH_LONG).show();
            }
            return;
        }
        getSharedPreferences(PREFS, MODE_PRIVATE).edit().putBoolean("on", true).apply();
        startSvc();
        setStatus(true);
    }

    private void disable() {
        getSharedPreferences(PREFS, MODE_PRIVATE).edit().putBoolean("on", false).apply();
        stopService(new Intent(this, FloatService.class));
        setStatus(false);
    }

    private void startSvc() {
        Intent i = new Intent(this, FloatService.class);
        if (Build.VERSION.SDK_INT >= 26) startForegroundService(i);
        else startService(i);
    }

    private boolean canOverlay() {
        return Build.VERSION.SDK_INT < 23 || Settings.canDrawOverlays(this);
    }

    private void setStatus(boolean on) {
        if (status != null) status.setText(on ? R.string.status_on : R.string.status_off);
    }

    @Override
    protected void onResume() {
        super.onResume();
        if (waitPerm) {
            waitPerm = false;
            if (canOverlay()) {
                sw.setChecked(true);
                getSharedPreferences(PREFS, MODE_PRIVATE).edit().putBoolean("on", true).apply();
                startSvc();
                setStatus(true);
            }
        }
    }
}
