package com.coolray.vradiofloat;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.RectF;
import android.media.browse.MediaBrowser;
import android.util.AttributeSet;
import android.view.MotionEvent;
import android.view.View;

import java.util.ArrayList;
import java.util.List;

/** Floating radio favorites bar — 10 slots + stop + status. Tap status = cycle theme. */
public class RadioBarView extends View {
    public static final int MAX = 10;

    public interface Listener {
        void onStation(int index);
        void onStop();
        void onThemeCycle();
    }

    private final Paint paint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final RectF tmp = new RectF();
    private final List<MediaBrowser.MediaItem> stations = new ArrayList<>();
    private final Bitmap[] logos = new Bitmap[MAX];
    private String status = "ARRET";
    private boolean playing;
    private int themeIndex;
    private Listener listener;

    public RadioBarView(Context c) { super(c); }
    public RadioBarView(Context c, AttributeSet a) { super(c, a); }

    public void setListener(Listener l) { listener = l; }

    public void setThemeIndex(int i) {
        themeIndex = ((i % ThemeColors.ALL.length) + ThemeColors.ALL.length) % ThemeColors.ALL.length;
        invalidate();
    }
    public int getThemeIndex() { return themeIndex; }
    public void nextTheme() { setThemeIndex(themeIndex + 1); }

    public void setStations(List<MediaBrowser.MediaItem> list, Bitmap[] logosIn) {
        stations.clear();
        if (list != null) stations.addAll(list);
        for (int i = 0; i < MAX; i++) {
            logos[i] = (logosIn != null && i < logosIn.length) ? logosIn[i] : null;
        }
        invalidate();
    }

    public void setStatus(String s, boolean play) {
        status = s != null ? s : "ARRET";
        playing = play;
        invalidate();
    }

    @Override
    protected void onDraw(Canvas canvas) {
        super.onDraw(canvas);
        float w = getWidth();
        float h = getHeight();
        if (w < 4 || h < 4) return;
        ThemeColors th = ThemeColors.ALL[themeIndex];

        // Background
        paint.setStyle(Paint.Style.FILL);
        paint.setColor(th.bg);
        tmp.set(0, 0, w, h);
        canvas.drawRoundRect(tmp, h * 0.28f, h * 0.28f, paint);

        // Border accent
        paint.setStyle(Paint.Style.STROKE);
        paint.setStrokeWidth(Math.max(2f, h * 0.03f));
        paint.setColor(th.accent);
        canvas.drawRoundRect(tmp, h * 0.28f, h * 0.28f, paint);

        float pad = h * 0.12f;
        float tile = h - pad * 2;
        float x = pad;

        // 10 station tiles
        int n = Math.max(stations.size(), MAX);
        for (int i = 0; i < MAX; i++) {
            float left = x + i * (tile + pad * 0.55f);
            drawTile(canvas, th, left, pad, tile, i);
        }

        float afterTiles = x + MAX * (tile + pad * 0.55f) + pad * 0.4f;

        // Stop button
        float stopSize = tile * 0.85f;
        float stopX = afterTiles;
        float stopY = (h - stopSize) / 2f;
        paint.setStyle(Paint.Style.FILL);
        paint.setColor(th.tile);
        tmp.set(stopX, stopY, stopX + stopSize, stopY + stopSize);
        canvas.drawRoundRect(tmp, stopSize * 0.22f, stopSize * 0.22f, paint);
        paint.setColor(th.accent);
        float sq = stopSize * 0.32f;
        float cx = stopX + stopSize / 2f;
        float cy = h / 2f;
        canvas.drawRect(cx - sq / 2f, cy - sq / 2f, cx + sq / 2f, cy + sq / 2f, paint);

        // Status / visualizer area (tap = theme)
        float statusLeft = stopX + stopSize + pad;
        float statusRight = w - pad;
        if (statusRight > statusLeft + 20) {
            paint.setStyle(Paint.Style.FILL);
            paint.setColor(th.tile);
            tmp.set(statusLeft, pad, statusRight, h - pad);
            canvas.drawRoundRect(tmp, h * 0.18f, h * 0.18f, paint);

            // Wave decoration
            if (playing) {
                paint.setStyle(Paint.Style.STROKE);
                paint.setStrokeWidth(2f);
                paint.setColor(th.accent2);
                Path path = new Path();
                float mid = h / 2f;
                boolean first = true;
                for (int i = 0; i < 40; i++) {
                    float px = statusLeft + 8 + i * ((statusRight - statusLeft - 16) / 39f);
                    float py = mid + (float) (Math.sin(i * 0.55 + System.currentTimeMillis() / 180.0) * (h * 0.18));
                    if (first) { path.moveTo(px, py); first = false; }
                    else path.lineTo(px, py);
                }
                canvas.drawPath(path, paint);
            }

            paint.setStyle(Paint.Style.FILL);
            paint.setColor(th.text);
            float ts = Math.max(11f, h * 0.28f);
            paint.setTextSize(ts);
            paint.setTextAlign(Paint.Align.LEFT);
            paint.setFakeBoldText(true);
            String text = fit(status, paint, statusRight - statusLeft - 16);
            canvas.drawText(text, statusLeft + 10, h / 2f + ts * 0.35f, paint);
            paint.setFakeBoldText(false);
        }
    }

    private void drawTile(Canvas c, ThemeColors th, float left, float top, float size, int i) {
        paint.setStyle(Paint.Style.FILL);
        paint.setColor(th.tile);
        tmp.set(left, top, left + size, top + size);
        c.drawRoundRect(tmp, size * 0.22f, size * 0.22f, paint);

        Bitmap logo = logos[i];
        if (logo != null && !logo.isRecycled()) {
            float max = Math.max(size * 0.85f / logo.getWidth(), size * 0.85f / logo.getHeight());
            float bw = logo.getWidth() * max;
            float bh = logo.getHeight() * max;
            float bx = left + (size - bw) / 2f;
            float by = top + (size - bh) / 2f;
            c.drawBitmap(logo, null, new RectF(bx, by, bx + bw, by + bh), paint);
        } else {
            paint.setColor(th.accent);
            paint.setTextSize(size * 0.42f);
            paint.setTextAlign(Paint.Align.CENTER);
            paint.setFakeBoldText(true);
            c.drawText(String.valueOf(i + 1), left + size / 2f, top + size * 0.62f, paint);
            paint.setFakeBoldText(false);
        }
    }

    private static String fit(String s, Paint p, float maxW) {
        if (s == null) return "ARRET";
        if (p.measureText(s) <= maxW) return s;
        String e = "...";
        int n = p.breakText(s, true, Math.max(0, maxW - p.measureText(e)), null);
        return s.substring(0, Math.max(0, n)).trim() + e;
    }

    @Override
    public boolean onTouchEvent(MotionEvent e) {
        if (e.getAction() != MotionEvent.ACTION_UP || listener == null) {
            return true;
        }
        float w = getWidth();
        float h = getHeight();
        float pad = h * 0.12f;
        float tile = h - pad * 2;
        float x = e.getX();

        // stations
        for (int i = 0; i < MAX; i++) {
            float left = pad + i * (tile + pad * 0.55f);
            if (x >= left && x <= left + tile) {
                listener.onStation(i);
                return true;
            }
        }
        float afterTiles = pad + MAX * (tile + pad * 0.55f) + pad * 0.4f;
        float stopSize = tile * 0.85f;
        if (x >= afterTiles && x <= afterTiles + stopSize) {
            listener.onStop();
            return true;
        }
        // status area → theme
        if (x > afterTiles + stopSize) {
            listener.onThemeCycle();
            return true;
        }
        return true;
    }
}
