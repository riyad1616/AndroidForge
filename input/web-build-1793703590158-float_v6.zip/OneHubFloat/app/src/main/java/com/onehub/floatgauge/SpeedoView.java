package com.onehub.floatgauge;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.RectF;
import android.graphics.Typeface;
import android.util.AttributeSet;
import android.view.View;

/** OneHub engine + Coolray mode colors + clear D1..D7 strip (battery removed). */
public class SpeedoView extends View {

    public static final int STYLE_COUNT = 10;
    public static final int THEME_COUNT = SpeedoEngine.f1039s.size();

    private final SpeedoEngine engine = new SpeedoEngine();
    private final SpeedoData data = new SpeedoData();
    private final Paint paint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final RectF tmp = new RectF();
    private int styleIndex = 0;
    private int themeIndex = 0;

    public SpeedoView(Context c) { super(c); init(); }
    public SpeedoView(Context c, AttributeSet a) { super(c, a); init(); }

    private void init() {
        paint.setTypeface(Typeface.create("sans-serif-medium", Typeface.BOLD));
    }

    public void setStyle(int s) {
        styleIndex = ((s % STYLE_COUNT) + STYLE_COUNT) % STYLE_COUNT;
        requestLayout();
        invalidate();
    }
    public int getStyle() { return styleIndex; }
    public void nextStyle() { setStyle(styleIndex + 1); }

    public void setThemeIndex(int t) {
        themeIndex = ((t % THEME_COUNT) + THEME_COUNT) % THEME_COUNT;
        invalidate();
    }
    public int getThemeIndex() { return themeIndex; }
    public void nextTheme() { setThemeIndex(themeIndex + 1); }

    public void setData(float speed, int gearIdx, int gearStep, String gearLetter,
                        String driveMode, int batt, int fuel, int powerKw,
                        int tempOut, int tempBatt) {
        // Force battery slot empty (engine also ignores index 0)
        data.set(speed, gearIdx, gearStep, gearLetter, driveMode,
                Integer.MIN_VALUE, fuel, powerKw, tempOut, tempBatt);
        invalidate();
    }

    public float aspect() {
        float[] q = SpeedoEngine.f1037q;
        if (styleIndex < 0 || styleIndex >= q.length) return 1f;
        return q[styleIndex];
    }

    private static int modeColor(String mode) {
        if (mode == null) return 0xFF80CBC4;
        switch (mode) {
            case "ADAPTATIF":    return 0xFF00E5FF;
            case "SPORT":        return 0xFFFF1744;
            case "ÉCO":
            case "ECO":          return 0xFF00E676;
            case "CONFORT":      return 0xFF448AFF;
            case "NEIGE":        return 0xFFE0F7FA;
            case "NORMAL":       return 0xFFB0BEC5;
            case "PERSO":        return 0xFFD500F9;
            case "TOUT-TERRAIN": return 0xFFFF9100;
            default:             return 0xFF80CBC4;
        }
    }

    @Override
    protected void onDraw(Canvas canvas) {
        super.onDraw(canvas);
        float w = getWidth();
        float h = getHeight();
        if (w < 4 || h < 4) return;
        try {
            engine.j(canvas, w, h, styleIndex, themeIndex, data);
        } catch (Throwable ignored) {}

        drawModeBadge(canvas, w, h);
        drawGearStrip(canvas, w, h);
    }

    private void drawModeBadge(Canvas canvas, float w, float h) {
        String mode = data.driveMode;
        if (mode == null || mode.isEmpty() || "—".equals(mode)) return;

        float textSize = Math.max(15f, Math.min(w, h) * 0.05f);
        paint.setTextSize(textSize);
        paint.setTypeface(Typeface.create("sans-serif-medium", Typeface.BOLD));
        paint.setTextAlign(Paint.Align.LEFT);
        float pad = textSize * 0.4f;
        float tw = paint.measureText(mode);
        float x = w * 0.04f;
        float y = h * 0.055f + textSize;

        int col = modeColor(mode);
        paint.setColor((col & 0x00FFFFFF) | 0x44000000);
        tmp.set(x - pad * 0.25f, y - textSize * 0.95f, x + tw + pad, y + textSize * 0.3f);
        canvas.drawRoundRect(tmp, textSize * 0.3f, textSize * 0.3f, paint);

        paint.setColor(col);
        canvas.drawText(mode, x, y, paint);
    }

    /** Clear D1..D7 gear strip (replaces battery zone). */
    private void drawGearStrip(Canvas canvas, float w, float h) {
        float textSize = Math.max(13f, Math.min(w, h) * 0.05f);
        paint.setTextSize(textSize);
        paint.setTypeface(Typeface.create("sans-serif", Typeface.BOLD));
        paint.setTextAlign(Paint.Align.CENTER);

        // Bottom-left band — fully covers old battery area
        float bandH = textSize * 2.2f;
        float bandTop = h * 0.82f - bandH * 0.55f;
        float bandLeft = w * 0.03f;
        float bandRight = w * 0.52f;

        // Opaque dark cover (hides residual battery/% glyphs)
        paint.setColor(0xF0101218);
        tmp.set(bandLeft, bandTop, bandRight, bandTop + bandH);
        canvas.drawRoundRect(tmp, textSize * 0.35f, textSize * 0.35f, paint);

        // Subtle border
        paint.setStyle(Paint.Style.STROKE);
        paint.setStrokeWidth(Math.max(1.5f, textSize * 0.06f));
        paint.setColor(0x44FFFFFF);
        canvas.drawRoundRect(tmp, textSize * 0.35f, textSize * 0.35f, paint);
        paint.setStyle(Paint.Style.FILL);

        float startX = bandLeft + textSize * 0.7f;
        float endX = bandRight - textSize * 0.7f;
        float step = (endX - startX) / 6f;
        float baseY = bandTop + bandH * 0.68f;

        int active = data.gearStep;
        boolean inDrive = "D".equals(data.gearLetter) || active > 0;

        for (int i = 1; i <= 7; i++) {
            float x = startX + (i - 1) * step;
            String label = "D" + i;
            boolean on = inDrive && active == i;

            if (on) {
                // Active pill
                float pw = textSize * 1.35f;
                float ph = textSize * 1.45f;
                paint.setColor(0xFF00BCD4);
                tmp.set(x - pw / 2f, baseY - ph * 0.72f, x + pw / 2f, baseY + ph * 0.28f);
                canvas.drawRoundRect(tmp, textSize * 0.25f, textSize * 0.25f, paint);
                paint.setColor(0xFF000000);
            } else {
                paint.setColor(inDrive ? 0x99B0BEC5 : 0x66FFFFFF);
            }
            canvas.drawText(label, x, baseY, paint);
        }

        // P/R/N badge when not in D
        if (!inDrive && data.gearLetter != null && data.gearLetter.length() == 1) {
            paint.setTextSize(textSize * 1.25f);
            paint.setColor(0xFFFFEA00);
            paint.setTextAlign(Paint.Align.LEFT);
            canvas.drawText(data.gearLetter, bandLeft + textSize * 0.15f,
                    bandTop - textSize * 0.25f, paint);
        }
    }
}
