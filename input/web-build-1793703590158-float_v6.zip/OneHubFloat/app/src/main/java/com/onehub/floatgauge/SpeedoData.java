package com.onehub.floatgauge;

/** Port of OneHub C0018b2 + Coolray gear/mode fields */
public final class SpeedoData {
    public float f1011a;
    public boolean b = true;
    public int f1012c = -1;
    public final int[] f1013d;
    public int f1014e;

    /** Coolray extras for overlay */
    public String driveMode = "—";
    public String gearLetter = "P";
    public int gearStep; // 1..7 for D1..D7

    public SpeedoData() {
        f1013d = new int[7];
        for (int i = 0; i < 7; i++) f1013d[i] = Integer.MIN_VALUE;
    }

    public void set(float speed, int gearIdx, int gearStep, String gearLetter,
                    String driveMode, int batt, int fuel, int powerKw,
                    int tempOut, int tempBatt) {
        this.f1011a = Math.max(0f, speed);
        this.f1012c = gearIdx;
        this.b = true;
        this.gearStep = gearStep;
        this.gearLetter = gearLetter != null ? gearLetter : "P";
        this.driveMode = driveMode != null ? driveMode : "—";
        f1013d[0] = batt;
        f1013d[1] = fuel;
        // Show D-step in power (kW) numeric slot when available
        f1013d[4] = (gearStep > 0) ? gearStep : powerKw;
        f1013d[5] = tempOut;
        f1013d[6] = tempBatt;
    }
}
