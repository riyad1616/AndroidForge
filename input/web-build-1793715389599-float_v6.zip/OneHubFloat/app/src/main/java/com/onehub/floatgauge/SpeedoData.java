package com.onehub.floatgauge;

/** Port of OneHub C0018b2 + Coolray gear/mode fields */
public final class SpeedoData {
    public float f1011a;          // speed km/h ONLY
    public boolean b = true;
    public int f1012c = -1;       // 1P 2R 3N 4D
    public final int[] f1013d;
    public int f1014e;

    public String driveMode = "-";
    public String gearLetter = "P";
    public int gearStep; // 1..7

    public SpeedoData() {
        f1013d = new int[7];
        for (int i = 0; i < 7; i++) f1013d[i] = Integer.MIN_VALUE;
    }

    public void set(float speed, int gearIdx, int gearStep, String gearLetter,
                    String driveMode, int battOrGear, int fuel, int powerKw,
                    int tempOut, int tempBatt) {
        this.f1011a = Math.max(0f, speed); // never gear
        this.f1012c = gearIdx;
        this.b = true;
        this.gearStep = gearStep;
        this.gearLetter = gearLetter != null ? gearLetter : "P";
        this.driveMode = driveMode != null ? driveMode : "-";
        // Slot 0 = gear step (1..7) in place of battery value
        f1013d[0] = (gearStep > 0) ? gearStep : Integer.MIN_VALUE;
        f1013d[1] = fuel;
        // slots 2/3 = driving range (km) shown on some styles as "-- km"
        int range = (powerKw > 0) ? powerKw : Integer.MIN_VALUE;
        f1013d[2] = range;
        f1013d[3] = range;
        f1013d[4] = powerKw; // reused as autonomie km (label now "km")
        f1013d[5] = tempOut;
        f1013d[6] = tempBatt;
    }
}
