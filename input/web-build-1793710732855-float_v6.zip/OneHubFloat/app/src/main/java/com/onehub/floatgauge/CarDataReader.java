package com.onehub.floatgauge;

import android.Manifest;
import android.content.Context;
import android.content.pm.PackageManager;
import android.location.Location;
import android.location.LocationListener;
import android.location.LocationManager;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.util.Log;

import java.lang.reflect.Method;
import java.util.concurrent.Executors;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.atomic.AtomicBoolean;

/**
 * Vehicle data from Coolray Dash property map + GPS fallback.
 *
 * Gear 0x11400401: 1=N 2=R 4=P 8=D, 16/32/64/... = D1..D8
 * Mode 0x214020d5: ADAPTATIF, SPORT, ÉCO, ...
 * Speed 0x11600207: km/h (as Coolray uses float-to-int)
 * Fuel 0x2140a569: 0..100 %
 */
public class CarDataReader {
    private static final String TAG = "CarDataReader";

    public static final int PROP_SPEED = 0x11600207;
    public static final int PROP_GEAR = 0x11400401;
    public static final int PROP_FUEL = 0x2140a569;
    public static final int PROP_DRIVE_MODE = 0x214020d5;
    public static final int PROP_TEMP_A = 0x21408017;
    public static final int PROP_TEMP_B = 0x21408006;
    public static final int PROP_EXTRA_F = 0x11400308;
    public static final int PROP_EXTRA_F2 = 0x11400204;

    public interface Listener {
        void onData(float speedKmh, int gearIdx, int gearStep, String gearLetter,
                    String driveMode, int batt, int fuel, int powerKw,
                    int tempOut, int tempBatt, boolean fromCar, String source);
    }

    private final Context ctx;
    private final Listener listener;
    private final Handler main = new Handler(Looper.getMainLooper());
    private ScheduledExecutorService exec;
    private final AtomicBoolean running = new AtomicBoolean(false);

    private Object car, pm;
    private Method getFloat, getInt;
    private boolean carOk;

    private LocationManager locationManager;
    private volatile float gpsSpeedKmh = -1f;
    private volatile long gpsAt;

    private final LocationListener locListener = new LocationListener() {
        @Override public void onLocationChanged(Location loc) {
            if (loc != null && loc.hasSpeed()) {
                gpsSpeedKmh = Math.max(0f, loc.getSpeed() * 3.6f);
                gpsAt = System.currentTimeMillis();
            }
        }
        @Override public void onStatusChanged(String p, int s, Bundle e) {}
        @Override public void onProviderEnabled(String p) {}
        @Override public void onProviderDisabled(String p) {}
    };

    public CarDataReader(Context c, Listener l) {
        ctx = c.getApplicationContext();
        listener = l;
        initCar();
        initGps();
    }

    private void initCar() {
        try {
            Class<?> carCl = Class.forName("android.car.Car");
            car = carCl.getMethod("createCar", Context.class).invoke(null, ctx);
            if (car == null) return;
            pm = carCl.getMethod("getCarManager", String.class).invoke(car, "property");
            if (pm == null) return;
            getFloat = pm.getClass().getMethod("getFloatProperty", int.class, int.class);
            getInt = pm.getClass().getMethod("getIntProperty", int.class, int.class);
            carOk = true;
            Log.i(TAG, "CarPropertyManager OK");
        } catch (Throwable t) {
            Log.w(TAG, "Car API: " + t.getMessage());
            carOk = false;
        }
    }

    private void initGps() {
        try {
            locationManager = (LocationManager) ctx.getSystemService(Context.LOCATION_SERVICE);
            if (locationManager == null) return;
            boolean ok = ctx.checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION)
                    == PackageManager.PERMISSION_GRANTED
                    || ctx.checkSelfPermission(Manifest.permission.ACCESS_COARSE_LOCATION)
                    == PackageManager.PERMISSION_GRANTED;
            if (!ok) return;
            if (locationManager.isProviderEnabled(LocationManager.GPS_PROVIDER)) {
                locationManager.requestLocationUpdates(LocationManager.GPS_PROVIDER,
                        200L, 0f, locListener, Looper.getMainLooper());
            }
            if (locationManager.isProviderEnabled(LocationManager.NETWORK_PROVIDER)) {
                locationManager.requestLocationUpdates(LocationManager.NETWORK_PROVIDER,
                        500L, 0f, locListener, Looper.getMainLooper());
            }
        } catch (Throwable t) {
            Log.w(TAG, "GPS: " + t.getMessage());
        }
    }

    public boolean isCarOk() { return carOk; }

    public void start() {
        if (running.getAndSet(true)) return;
        exec = Executors.newSingleThreadScheduledExecutor();
        exec.scheduleAtFixedRate(this::poll, 0, 150, TimeUnit.MILLISECONDS);
    }

    public void stop() {
        running.set(false);
        if (exec != null) { exec.shutdownNow(); exec = null; }
        if (locationManager != null) {
            try { locationManager.removeUpdates(locListener); } catch (Throwable ignored) {}
        }
    }

    private Float carFloat(int prop) {
        if (!carOk || getFloat == null) return null;
        try {
            Object v = getFloat.invoke(pm, prop, 0);
            if (v instanceof Float) {
                float f = (Float) v;
                if (!Float.isNaN(f)) return f;
            }
        } catch (Throwable ignored) {}
        return null;
    }

    private Integer carInt(int prop) {
        if (!carOk || getInt == null) return null;
        try {
            Object v = getInt.invoke(pm, prop, 0);
            if (v instanceof Integer) {
                int i = (Integer) v;
                if (i != Integer.MIN_VALUE) return i;
            }
        } catch (Throwable ignored) {}
        return null;
    }

    /** Coolray gearName() mapping */
    public static final class GearInfo {
        public final String letter; // P R N D or ""
        public final int step;      // 1..8 for D1..D8, else 0
        public final int oneHubIdx; // 1P 2R 3N 4D for SpeedoEngine
        public GearInfo(String letter, int step, int oneHubIdx) {
            this.letter = letter;
            this.step = step;
            this.oneHubIdx = oneHubIdx;
        }
    }

    public static GearInfo decodeGear(int raw) {
        if (raw == 4) return new GearInfo("P", 0, 1);
        if (raw == 2) return new GearInfo("R", 0, 2);
        if (raw == 1) return new GearInfo("N", 0, 3);
        if (raw == 8) return new GearInfo("D", 0, 4);
        // D1..D8: 16,32,64,128,256,512,1024,2048
        int bit = 0x10;
        for (int step = 1; step <= 8; step++) {
            if (raw == bit) return new GearInfo("D", step, 4);
            bit <<= 1;
        }
        if (raw >= 16) return new GearInfo("D", 0, 4);
        return new GearInfo("P", 0, 1);
    }

    /** Coolray driveMode() mapping */
    public static String decodeMode(int raw) {
        switch (raw) {
            case 0x22010141: return "ADAPTATIF";
            case 0x22010140: return "PERSO";
            case 0x22010113: return "TOUT-TERRAIN";
            case 0x22010111: return "NORMAL";
            case 0x22010109: return "NEIGE";
            case 0x22010103: return "SPORT";
            case 0x22010102: return "CONFORT";
            case 0x22010101: return "ÉCO";
            case 0xFF: return "—";
            default:
                if (raw == Integer.MIN_VALUE) return "—";
                return null; // unknown
        }
    }

    private void poll() {
        if (!running.get()) return;

        float speed = -1f;
        int fuel = Integer.MIN_VALUE;
        int batt = Integer.MIN_VALUE;
        int power = Integer.MIN_VALUE;
        int temp = Integer.MIN_VALUE;
        int tbatt = Integer.MIN_VALUE;
        int gearRaw = -1;
        int modeRaw = Integer.MIN_VALUE;
        boolean fromCar = false;
        String source = "none";

        Float cs = carFloat(PROP_SPEED);
        if (cs != null && cs >= 0f) {
            // Coolray: float-to-int as km/h
            speed = Math.max(0f, Math.min(cs, 320f));
            fromCar = true;
            source = "car";
        }

        Integer fuelI = carInt(PROP_FUEL);
        if (fuelI != null && fuelI >= 0 && fuelI <= 100) {
            fuel = fuelI;
            fromCar = true;
        }

        Integer gearI = carInt(PROP_GEAR);
        if (gearI != null) {
            gearRaw = gearI;
            fromCar = true;
        }

        Integer modeI = carInt(PROP_DRIVE_MODE);
        if (modeI != null) {
            modeRaw = modeI;
            fromCar = true;
        }

        Integer tA = carInt(PROP_TEMP_A);
        if (tA != null) {
            // Coolray: val * 0.75 - 48
            temp = Math.round(tA * 0.75f - 48f);
            fromCar = true;
        }
        Integer tB = carInt(PROP_TEMP_B);
        if (tB != null && tB > 0) {
            tbatt = Math.round(tB / 10f);
            fromCar = true;
        }

        boolean gpsFresh = gpsSpeedKmh >= 0f && (System.currentTimeMillis() - gpsAt) < 3000;
        if (speed < 0f && gpsFresh) {
            speed = gpsSpeedKmh;
            source = "gps";
        } else if (speed >= 0f && speed < 0.5f && gpsFresh && gpsSpeedKmh > 2f) {
            speed = gpsSpeedKmh;
            source = "gps";
        }
        if (speed < 0f) speed = 0f;

        GearInfo gi;
        if (gearRaw >= 0) {
            gi = decodeGear(gearRaw);
        } else {
            gi = speed > 1.5f ? new GearInfo("D", 0, 4) : new GearInfo("P", 0, 1);
        }

        String mode = decodeMode(modeRaw);
        if (mode == null) mode = "—";

        power = Integer.MIN_VALUE;

        final float s = speed;
        final int gIdx = gi.oneHubIdx;
        final int gStep = gi.step;
        final String gLet = gi.letter;
        final String dm = mode;
        final int ba = batt, fu = fuel, pw = power, te = temp, tb = tbatt;
        final boolean fc = fromCar || "gps".equals(source);
        final String src = source.isEmpty() ? (fc ? "car" : "none") : source;

        main.post(() -> {
            if (listener != null) {
                listener.onData(s, gIdx, gStep, gLet, dm, ba, fu, pw, te, tb, fc, src);
            }
        });
    }
}
