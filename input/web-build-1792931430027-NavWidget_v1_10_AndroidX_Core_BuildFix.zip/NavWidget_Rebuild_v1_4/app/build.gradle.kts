plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}
android {
    namespace = "com.coolray.navwidget"
    compileSdk = 34
    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions {
        jvmTarget = "17"
    }
    defaultConfig {
        applicationId = "com.coolray.navwidget"
        minSdk = 26
        targetSdk = 28
        versionCode = 10
        versionName = "1.10-osm-alpha70-buildfix"
    }
}


dependencies {
    // Explicit AndroidX Core dependency for projects/builders that use ContextCompat.
    implementation("androidx.core:core-ktx:1.13.1")
}
