package com.coolray.navwidget

import android.app.Service
import android.app.usage.UsageStatsManager
import android.app.usage.UsageEvents
import android.os.Handler
import android.os.Looper
import android.content.*
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.IBinder
import android.provider.Settings
import android.view.*
import android.widget.*
import android.animation.ValueAnimator
import android.view.animation.LinearInterpolator

class FloatingWidgetService : Service() {
    companion object { const val ACTION_REFRESH="com.coolray.navwidget.REFRESH" }
    private var wm:WindowManager?=null
    private var card:LinearLayout?=null
    private var distance:TextView?=null
    private var directionArrow:TextView?=null
    private var instruction:TextView?=null
    private var summary:TextView?=null
    private var osmInfo:TextView?=null
    private var lastOsmLookup=0L
    private var lastOsmText="OSM: waiting for GPS permission"
    private var progressTrack:FrameLayout?=null
    private var progressIndicator:View?=null
    private var progressAnimator:ValueAnimator?=null
    private var params:WindowManager.LayoutParams?=null
    private var preview=false
    private var attached=false
    private val handler=Handler(Looper.getMainLooper())
    private val foregroundCheck=object:Runnable {
        override fun run() {
            if (!preview && prefs.getBoolean("hide_maps", false) && usageAccessGranted()) {
                val mapsForeground = isMapsForeground()
                card?.visibility = if (mapsForeground) View.GONE else View.VISIBLE
            } else {
                card?.visibility = View.VISIBLE
            }
            handler.postDelayed(this, 1200L)
        }
    }
    private val prefs by lazy { getSharedPreferences("nav_widget",Context.MODE_PRIVATE) }
    private val receiver=object:BroadcastReceiver(){
        override fun onReceive(context:Context?,intent:Intent?){ refreshContent() }
    }
    // Keep online road data fresh even when Google Maps sends no new notification.
    private val osmRefreshLoop = object : Runnable {
        override fun run() {
            if (!preview && card != null) {
                updateOsmIfNeeded()
                osmInfo?.text = lastOsmText
            }
            handler.postDelayed(this, 30000L)
        }
    }
    override fun onCreate(){
        super.onCreate()
        val filter = IntentFilter(ACTION_REFRESH)
        if (android.os.Build.VERSION.SDK_INT >= 33) {
            registerReceiver(receiver, filter, Context.RECEIVER_NOT_EXPORTED)
        } else {
            @Suppress("DEPRECATION")
            registerReceiver(receiver, filter)
        }
    }

    override fun onStartCommand(intent:Intent?,flags:Int,startId:Int):Int {
        preview=intent?.getBooleanExtra("preview",false)?:false
        if(!Settings.canDrawOverlays(this)){stopSelf();return START_NOT_STICKY}
        if(card==null) createCard() else { updateSize(); refreshContent() }
        handler.removeCallbacks(foregroundCheck)
        handler.post(foregroundCheck)
        handler.removeCallbacks(osmRefreshLoop)
        handler.post(osmRefreshLoop)
        return START_STICKY
    }

    private fun createCard(){
        wm=getSystemService(WINDOW_SERVICE) as WindowManager
        card=LinearLayout(this).apply {
            orientation=LinearLayout.VERTICAL; setPadding(18,14,18,13)
            background=GradientDrawable().apply { setColor(Color.argb(77,13,21,39));cornerRadius=25f;setStroke(1,Color.argb(190,90,150,205)) }
        }
        val line=LinearLayout(this).apply { orientation=LinearLayout.HORIZONTAL;gravity=Gravity.CENTER_VERTICAL }
        directionArrow=TextView(this).apply { text="↑";textSize=31f;typeface=Typeface.DEFAULT_BOLD;setTextColor(Color.WHITE);setPadding(0,0,15,0) }
        line.addView(directionArrow)
        distance=TextView(this).apply { textSize=25f;typeface=Typeface.DEFAULT_BOLD;setTextColor(Color.WHITE) }
        line.addView(distance);card!!.addView(line)
        instruction=TextView(this).apply { textSize=14f;setTextColor(Color.LTGRAY);setPadding(48,0,0,10) }
        card!!.addView(instruction)
        summary=TextView(this).apply { textSize=17f;typeface=Typeface.DEFAULT_BOLD;setTextColor(Color.WHITE);setPadding(0,8,0,8) }
        card!!.addView(summary)
        osmInfo=TextView(this).apply { textSize=13f; setTextColor(Color.rgb(115,220,190)); setPadding(0,4,0,8); text="OSM: waiting for GPS" }
        card!!.addView(osmInfo)
        val back=FrameLayout(this).apply {
            background=GradientDrawable().apply { setColor(Color.argb(77,37,49,70));cornerRadius=6f }
            layoutParams=LinearLayout.LayoutParams(-1,6)
        }
        progressTrack = back
        progressIndicator = View(this).apply {
            background=GradientDrawable().apply { setColor(Color.rgb(44,160,255));cornerRadius=6f }
            layoutParams=FrameLayout.LayoutParams(dp(76),-1,Gravity.START)
        }
        back.addView(progressIndicator)
        back.addOnLayoutChangeListener { _, left, _, right, _, oldLeft, _, oldRight, _ ->
            if (right-left != oldRight-oldLeft) startProgressAnimation()
        }
        card!!.addView(back)
        startProgressAnimation()
        params=WindowManager.LayoutParams(widthForSize(),WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
            PixelFormat.TRANSLUCENT).apply {
            gravity=Gravity.TOP or Gravity.START;x=prefs.getInt("x",30);y=prefs.getInt("y",180)
        }
        card!!.setOnTouchListener(object:View.OnTouchListener{
            var sx=0;var sy=0;var tx=0f;var ty=0f
            override fun onTouch(v:View,e:MotionEvent):Boolean{
                when(e.action){
                    MotionEvent.ACTION_DOWN->{sx=params!!.x;sy=params!!.y;tx=e.rawX;ty=e.rawY;return true}
                    MotionEvent.ACTION_MOVE->{params!!.x=sx+(e.rawX-tx).toInt();params!!.y=sy+(e.rawY-ty).toInt();try{wm?.updateViewLayout(card,params)}catch(_:Exception){};return true}
                    MotionEvent.ACTION_UP->{prefs.edit().putInt("x",params!!.x).putInt("y",params!!.y).apply();return true}
                };return false
            }
        })
        wm?.addView(card,params); attached=true; refreshContent()
    }

    private fun usageAccessGranted():Boolean {
        val appOps=getSystemService(Context.APP_OPS_SERVICE) as android.app.AppOpsManager
        return try {
            appOps.checkOpNoThrow("android:get_usage_stats", android.os.Process.myUid(), packageName) == android.app.AppOpsManager.MODE_ALLOWED
        } catch (_:Exception) { false }
    }

    private fun isMapsForeground():Boolean {
        return try {
            val usm=getSystemService(Context.USAGE_STATS_SERVICE) as UsageStatsManager
            val end=System.currentTimeMillis()
            val events=usm.queryEvents(end-5000L,end)
            val event=UsageEvents.Event()
            var lastPackage=""
            var lastTime=0L
            while(events.hasNextEvent()) {
                events.getNextEvent(event)
                if(event.eventType==UsageEvents.Event.MOVE_TO_FOREGROUND ||
                   event.eventType==UsageEvents.Event.ACTIVITY_RESUMED) {
                    if(event.timeStamp>=lastTime) {
                        lastTime=event.timeStamp
                        lastPackage=event.packageName ?: ""
                    }
                }
            }
            lastPackage=="com.google.android.apps.maps"
        } catch (_:Exception) { false }
    }

    private fun dp(value:Int):Int = (value * resources.displayMetrics.density + 0.5f).toInt()
    private fun widthForSize()=when(prefs.getInt("size",2)){0->dp(280);1->dp(340);2->dp(420);else->dp(500)}
    private fun updateSize(){
        val c=card?:return; val p=params?:return; p.width=widthForSize()
        val scale=when(prefs.getInt("size",2)){0->0.88f;1->0.96f;2->1.08f;else->1.18f}
        c.setPadding(dp((18*scale).toInt()),dp((14*scale).toInt()),dp((18*scale).toInt()),dp((13*scale).toInt()))
        distance?.textSize=25f*scale; instruction?.textSize=14f*scale; summary?.textSize=17f*scale
        try{wm?.updateViewLayout(c,p)}catch(_:Exception){}
        startProgressAnimation()
    }

    // Decorative indeterminate activity indicator only; it is deliberately not presented as route progress.
    private fun startProgressAnimation(){
        val track=progressTrack ?: return
        val indicator=progressIndicator ?: return
        progressAnimator?.cancel()
        track.post {
            val travel=(track.width-indicator.width).coerceAtLeast(0).toFloat()
            if(travel<=0f) return@post
            progressAnimator=ValueAnimator.ofFloat(0f,travel).apply {
                duration=1250L; repeatCount=ValueAnimator.INFINITE; repeatMode=ValueAnimator.REVERSE
                interpolator=LinearInterpolator()
                addUpdateListener { animator -> indicator.translationX=animator.animatedValue as Float }
                start()
            }
        }
    }

    private fun refreshContent(){
        updateOsmIfNeeded()
        osmInfo?.text=lastOsmText
        val payload=prefs.getString("navigation_text","").orEmpty()
        if(preview){
            distance?.text="600 m"
            instruction?.text="Continue straight"
            summary?.text="Google Maps · Navigation active"
            directionArrow?.text="↑"
            return
        }
        if(payload.isBlank()){
            distance?.text="—"
            instruction?.text="Waiting for Google Maps"
            summary?.text="Start navigation to show route details"
            directionArrow?.text="↑"
            return
        }
        val lines=payload.lines().map { it.trim() }.filter { it.isNotBlank() }.distinct()
        val joined=lines.joinToString(" · ")
        val distanceMatch=Regex("(?i)(\\d+(?:[.,]\\d+)?\\s*(?:m|km|mi|ft|meters?|kilometers?|mètres?|kilomètres?))").find(joined)
        val distanceText=distanceMatch?.value?.replace(Regex("\\s+")," ")
        val instructionLine=lines.firstOrNull { line ->
            line.contains("turn",true) || line.contains("continue",true) || line.contains("head",true) ||
            line.contains("rond-point",true) || line.contains("rond point",true) || line.contains("tournez",true) ||
            line.contains("continuez",true) || line.contains("tourne",true) || line.contains("prenez",true) ||
            line.contains("انحرف") || line.contains("اتجه") || line.contains("استمر") || line.contains("دوار")
        } ?: lines.firstOrNull()
        distance?.text=distanceText ?: lines.firstOrNull()?.take(24) ?: "Navigation"
        instruction?.text=instructionLine?.takeIf { it != distanceText } ?: lines.getOrNull(1) ?: "Google Maps navigation"
        summary?.text=if(lines.size>2) lines.filter { it != instructionLine && it != distanceText }.joinToString(" · ").take(100) else "Navigation active"
        val directionSource=(instructionLine ?: joined).lowercase()
        directionArrow?.text=when {
            listOf("left","gauche","links","يسار","يسارًا").any { directionSource.contains(it) } -> "↰"
            listOf("right","droite","rechts","يمين","يمينًا").any { directionSource.contains(it) } -> "↱"
            listOf("u-turn","demi-tour","demi tour","retournez","استدر").any { directionSource.contains(it) } -> "↶"
            listOf("roundabout","rond-point","rond point","دوار").any { directionSource.contains(it) } -> "⟳"
            else -> "↑"
        }
    }

    private fun updateOsmIfNeeded() {
        if (preview || System.currentTimeMillis() - lastOsmLookup < 30000L) return
        lastOsmLookup = System.currentTimeMillis()
        if (checkSelfPermission(android.Manifest.permission.ACCESS_FINE_LOCATION) != android.content.pm.PackageManager.PERMISSION_GRANTED &&
            checkSelfPermission(android.Manifest.permission.ACCESS_COARSE_LOCATION) != android.content.pm.PackageManager.PERMISSION_GRANTED) {
            lastOsmText = "OSM: enable location permission in NavWidget settings"
            return
        }
        try {
            val lm = getSystemService(LOCATION_SERVICE) as android.location.LocationManager
            val loc = lm.getLastKnownLocation(android.location.LocationManager.GPS_PROVIDER)
                ?: lm.getLastKnownLocation(android.location.LocationManager.NETWORK_PROVIDER)
            if (loc == null) { lastOsmText = "OSM: waiting for GPS location"; return }
            lastOsmText = "OpenStreetMap: checking nearby roads…"
            OsmRoadInfoClient.lookup(loc) { result ->
                handler.post {
                    val parts = mutableListOf<String>()
                    if (result.speedLimit != null) parts.add("Limit ${result.speedLimit}")
                    if (result.trafficSignalDistance != null) parts.add("Traffic light ~${result.trafficSignalDistance} m")
                    lastOsmText = if (parts.isEmpty()) result.status else "OSM · " + parts.joinToString("  |  ")
                    osmInfo?.text = lastOsmText
                }
            }
        } catch (_: SecurityException) { lastOsmText = "OSM: location permission required" }
          catch (_: Exception) { lastOsmText = "OSM: location unavailable" }
    }

    override fun onDestroy(){
        handler.removeCallbacks(foregroundCheck)
        handler.removeCallbacks(osmRefreshLoop)
        progressAnimator?.cancel(); progressAnimator=null
        try{unregisterReceiver(receiver)}catch(_:Exception){}
        try{card?.let{wm?.removeView(it)}}catch(_:Exception){}
        attached=false
        card=null;super.onDestroy()
    }
    override fun onBind(intent:Intent?):IBinder?=null
}
