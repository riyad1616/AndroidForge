package com.riyad.cardualpane

import android.appwidget.AppWidgetHost
import android.appwidget.AppWidgetHostView
import android.appwidget.AppWidgetManager
import android.appwidget.AppWidgetProviderInfo
import android.content.ComponentName
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Bundle
import android.view.View
import android.view.WindowManager
import android.widget.FrameLayout
import android.widget.ImageButton
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.google.android.material.button.MaterialButton

class MainActivity : AppCompatActivity() {

    private lateinit var appWidgetHost: AppWidgetHost
    private lateinit var appWidgetManager: AppWidgetManager
    private val HOST_ID = 1024

    // Known system widgets on this Flyme Auto / ECARX head unit
    private val tirePressureWidget = ComponentName(
        "com.flyme.auto.settings",
        "com.flyme.auto.settings.receiver.TirePressureWidget"
    )
    private val windowsWidget = ComponentName(
        "com.flyme.auto.launcher",
        "com.coolray.vehicle.WindowsWidgetV2"
    )
    private val roofWidget = ComponentName(
        "com.flyme.auto.launcher",
        "com.coolray.vehicle.RoofWidgetV2"
    )
    private val gearWidget = ComponentName(
        "com.flyme.auto.settings",
        "com.flyme.auto.settings.receiver.CurrentGearWidget"
    )
    private val energyWidget = ComponentName(
        "com.flyme.auto.energy",
        "com.flyme.auto.energy.appwidget.DischargingAppWidget"
    )
    private val musicWidget = ComponentName(
        "com.flyme.auto.music",
        "com.flyme.auto.music.ui.appwidget.MusicLinkWidget"
    )

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        // Full immersive mode - hide navigation bar
        window.setFlags(
            WindowManager.LayoutParams.FLAG_FULLSCREEN,
            WindowManager.LayoutParams.FLAG_FULLSCREEN
        )
        hideSystemUI()

        setContentView(R.layout.activity_main)

        appWidgetManager = AppWidgetManager.getInstance(this)
        appWidgetHost = AppWidgetHost(this, HOST_ID)
        appWidgetHost.startListening()

        setupMapsButtons()
        setupGearDisplay()
        tryLoadSystemWidgets()
    }

    private fun hideSystemUI() {
        window.decorView.systemUiVisibility = (
                View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY
                        or View.SYSTEM_UI_FLAG_FULLSCREEN
                        or View.SYSTEM_UI_FLAG_HIDE_NAVIGATION
                        or View.SYSTEM_UI_FLAG_LAYOUT_STABLE
                        or View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN
                        or View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION
                )
    }

    override fun onWindowFocusChanged(hasFocus: Boolean) {
        super.onWindowFocusChanged(hasFocus)
        if (hasFocus) hideSystemUI()
    }

    private fun setupMapsButtons() {
        val btnGoogle = findViewById<MaterialButton>(R.id.btn_google_maps)
        val btnWaze = findViewById<MaterialButton>(R.id.btn_waze)

        btnGoogle.setOnClickListener {
            launchNavigationApp("com.google.android.apps.maps")
        }
        btnWaze.setOnClickListener {
            launchNavigationApp("com.waze")
        }
    }

    private fun launchNavigationApp(packageName: String) {
        try {
            val intent = packageManager.getLaunchIntentForPackage(packageName)
            if (intent != null) {
                intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                // Try to launch in a way that keeps our activity visible if possible
                // On this system, full replace is more reliable
                startActivity(intent)
            } else {
                Toast.makeText(this, "التطبيق غير مثبت: $packageName", Toast.LENGTH_SHORT).show()
            }
        } catch (e: Exception) {
            Toast.makeText(this, "تعذر فتح التطبيق", Toast.LENGTH_SHORT).show()
        }
    }

    private fun setupGearDisplay() {
        // Placeholder values - later can be updated from CarPropertyManager or widget
        val tvGear = findViewById<TextView>(R.id.tv_gear)
        val tvGearLabel = findViewById<TextView>(R.id.tv_gear_label)
        tvGear.text = "D"
        tvGearLabel.text = "Drive"
    }

    private fun tryLoadSystemWidgets() {
        val container = findViewById<FrameLayout>(R.id.widgets_host_container)
        val hint = findViewById<TextView>(R.id.tv_widget_hint)

        // Try to bind the most useful widgets. Order of preference:
        // 1. TirePressure  2. Windows  3. Roof  4. CurrentGear
        val candidates = listOf(
            tirePressureWidget,
            windowsWidget,
            roofWidget,
            gearWidget,
            energyWidget
        )

        var loaded = false
        for (cn in candidates) {
            try {
                val info = appWidgetManager.installedProviders.find {
                    it.provider == cn
                }
                if (info != null) {
                    val appWidgetId = appWidgetHost.allocateAppWidgetId()
                    val success = appWidgetManager.bindAppWidgetIdIfAllowed(appWidgetId, cn)
                    if (success) {
                        val hostView = appWidgetHost.createView(this, appWidgetId, info)
                        hostView.setAppWidget(appWidgetId, info)
                        container.removeAllViews()
                        container.addView(hostView)
                        loaded = true
                        break
                    }
                }
            } catch (e: Exception) {
                // Widget may require system privileges - continue to next
            }
        }

        if (!loaded) {
            hint.visibility = View.VISIBLE
            hint.text = "لم يتم تحميل الودجات النظامية\n(قد تحتاج صلاحيات النظام)\nاضغط للإعدادات لاحقاً"
        } else {
            hint.visibility = View.GONE
        }
    }

    override fun onDestroy() {
        super.onDestroy()
        try {
            appWidgetHost.stopListening()
        } catch (_: Exception) {}
    }
}
