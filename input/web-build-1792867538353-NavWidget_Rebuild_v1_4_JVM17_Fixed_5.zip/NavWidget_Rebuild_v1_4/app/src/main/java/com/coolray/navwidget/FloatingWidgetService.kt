package com.coolray.navwidget

import android.app.Service
import android.app.usage.UsageStatsManager
import android.app.usage.UsageEvents
import android.os.Handler
import android.os.Looper
import android.content.*
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.IBinder
import android.provider.Settings
import android.view.*
import android.widget.*

class FloatingWidgetService : Service() {
    companion object { const val ACTION_REFRESH="com.coolray.navwidget.REFRESH" }
    private var wm:WindowManager?=null
    private var card:LinearLayout?=null
    private var distance:TextView?=null
    private var instruction:TextView?=null
    private var summary:TextView?=null
    private var params:WindowManager.LayoutParams?=null
    private var preview=false
    private var attached=false
    private val handler=Handler(Looper.getMainLooper())
    private val foregroundCheck=object:Runnable {
        override fun run() {
            if (!preview && prefs.getBoolean("hide_maps", false) && usageAccessGranted()) {
                val mapsForeground = isMapsForeground()
                card?.visibility = if (mapsForeground) View.GONE else View.VISIBLE
            } else {
                card?.visibility = View.VISIBLE
            }
            handler.postDelayed(this, 1200L)
        }
    }
    private val prefs by lazy { getSharedPreferences("nav_widget",Context.MODE_PRIVATE) }
    private val receiver=object:BroadcastReceiver(){
        override fun onReceive(context:Context?,intent:Intent?){ refreshContent() }
    }
    override fun onCreate(){
        super.onCreate()
        val filter = IntentFilter(ACTION_REFRESH)
        if (android.os.Build.VERSION.SDK_INT >= 33) {
            registerReceiver(receiver, filter, Context.RECEIVER_NOT_EXPORTED)
        } else {
            @Suppress("DEPRECATION")
            registerReceiver(receiver, filter)
        }
    }

    override fun onStartCommand(intent:Intent?,flags:Int,startId:Int):Int {
        preview=intent?.getBooleanExtra("preview",false)?:false
        if(!Settings.canDrawOverlays(this)){stopSelf();return START_NOT_STICKY}
        if(card==null) createCard() else { updateSize(); refreshContent() }
        handler.removeCallbacks(foregroundCheck)
        handler.post(foregroundCheck)
        return START_STICKY
    }

    private fun createCard(){
        wm=getSystemService(WINDOW_SERVICE) as WindowManager
        card=LinearLayout(this).apply {
            orientation=LinearLayout.VERTICAL; setPadding(18,14,18,13)
            background=GradientDrawable().apply { setColor(Color.rgb(13,21,39));cornerRadius=25f;setStroke(1,Color.rgb(39,59,92)) }
        }
        val line=LinearLayout(this).apply { orientation=LinearLayout.HORIZONTAL;gravity=Gravity.CENTER_VERTICAL }
        line.addView(TextView(this).apply { text="↗";textSize=31f;setTextColor(Color.WHITE);setPadding(0,0,15,0) })
        distance=TextView(this).apply { textSize=25f;typeface=Typeface.DEFAULT_BOLD;setTextColor(Color.WHITE) }
        line.addView(distance);card!!.addView(line)
        instruction=TextView(this).apply { textSize=14f;setTextColor(Color.LTGRAY);setPadding(48,0,0,10) }
        card!!.addView(instruction)
        summary=TextView(this).apply { textSize=17f;typeface=Typeface.DEFAULT_BOLD;setTextColor(Color.WHITE);setPadding(0,8,0,8) }
        card!!.addView(summary)
        val back=FrameLayout(this).apply {
            background=GradientDrawable().apply { setColor(Color.rgb(37,49,70));cornerRadius=6f }
            layoutParams=LinearLayout.LayoutParams(-1,6)
        }
        back.addView(View(this).apply {
            background=GradientDrawable().apply { setColor(Color.rgb(44,117,255));cornerRadius=6f }
            layoutParams=FrameLayout.LayoutParams((widthForSize()*0.62).toInt(),-1,Gravity.START)
        })
        card!!.addView(back)
        params=WindowManager.LayoutParams(widthForSize(),WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
            PixelFormat.TRANSLUCENT).apply {
            gravity=Gravity.TOP or Gravity.START;x=prefs.getInt("x",30);y=prefs.getInt("y",180)
        }
        card!!.setOnTouchListener(object:View.OnTouchListener{
            var sx=0;var sy=0;var tx=0f;var ty=0f
            override fun onTouch(v:View,e:MotionEvent):Boolean{
                when(e.action){
                    MotionEvent.ACTION_DOWN->{sx=params!!.x;sy=params!!.y;tx=e.rawX;ty=e.rawY;return true}
                    MotionEvent.ACTION_MOVE->{params!!.x=sx+(e.rawX-tx).toInt();params!!.y=sy+(e.rawY-ty).toInt();try{wm?.updateViewLayout(card,params)}catch (ignored: Exception){};return true}
                    MotionEvent.ACTION_UP->{prefs.edit().putInt("x",params!!.x).putInt("y",params!!.y).apply();return true}
                };return false
            }
        })
        wm?.addView(card,params); attached=true; refreshContent()
    }

    private fun usageAccessGranted():Boolean {
        val appOps=getSystemService(Context.APP_OPS_SERVICE) as android.app.AppOpsManager
        return try {
            appOps.checkOpNoThrow("android:get_usage_stats", android.os.Process.myUid(), packageName) == android.app.AppOpsManager.MODE_ALLOWED
        } catch (ignored: Exception) { false }
    }

    private fun isMapsForeground():Boolean {
        return try {
            val usm=getSystemService(Context.USAGE_STATS_SERVICE) as UsageStatsManager
            val end=System.currentTimeMillis()
            val events=usm.queryEvents(end-5000L,end)
            val event=UsageEvents.Event()
            var lastPackage=""
            var lastTime=0L
            while(events.hasNextEvent()) {
                events.getNextEvent(event)
                if(event.eventType==UsageEvents.Event.MOVE_TO_FOREGROUND ||
                   event.eventType==UsageEvents.Event.ACTIVITY_RESUMED) {
                    if(event.timeStamp>=lastTime) {
                        lastTime=event.timeStamp
                        lastPackage=event.packageName ?: ""
                    }
                }
            }
            lastPackage=="com.google.android.apps.maps"
        } catch (ignored: Exception) { false }
    }

    private fun widthForSize()=when(prefs.getInt("size",1)){0->240;2->360;else->300}
    private fun updateSize(){ val c=card?:return;val p=params?:return;p.width=widthForSize();try{wm?.updateViewLayout(c,p)}catch (ignored: Exception){} }

    private fun refreshContent(){
        val payload=prefs.getString("navigation_text","").orEmpty()
        if(preview){
            distance?.text="0 m";instruction?.text="Head southeast";summary?.text="Drive 9 min · 3.7 km"
        } else if(payload.isNotBlank()){
            val lines=payload.lines().filter{it.isNotBlank()}
            distance?.text=lines.firstOrNull()?: "Navigation"
            instruction?.text=lines.getOrNull(1)?: "Google Maps navigation"
            summary?.text=lines.drop(2).joinToString(" ").ifBlank{"Navigation active"}
        } else {
            distance?.text="—";instruction?.text="Waiting for Google Maps"
            summary?.text="Start navigation to show route details"
        }
    }
    override fun onDestroy(){
        handler.removeCallbacks(foregroundCheck)
        try{unregisterReceiver(receiver)}catch (ignored: Exception){}
        try{card?.let{wm?.removeView(it)}}catch (ignored: Exception){}
        attached=false
        card=null;super.onDestroy()
    }
    override fun onBind(intent:Intent?):IBinder?=null
}
