package com.coolray.navwidget

import android.app.Activity
import android.content.Context
import android.content.Intent
import android.graphics.Color
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import android.app.AppOpsManager
import android.os.Process
import android.view.Gravity
import android.widget.*

class MainActivity : Activity() {
    private val prefs by lazy { getSharedPreferences("nav_widget", Context.MODE_PRIVATE) }
    private lateinit var root: LinearLayout

    override fun onCreate(savedInstanceState: Bundle?) { super.onCreate(savedInstanceState); render() }
    override fun onResume() { super.onResume(); if (::root.isInitialized) render() }

    private fun render() {
        root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL; setPadding(24,22,24,24)
            setBackgroundColor(Color.rgb(15,23,42))
        }
        fun label(s:String, accent:Boolean=false) = TextView(this).apply {
            text=s; textSize=14f; setTextColor(if(accent) Color.rgb(85,153,255) else Color.LTGRAY)
            setPadding(0,16,0,7)
        }
        fun button(s:String, f:()->Unit) = Button(this).apply { text=s; setOnClickListener { f() } }
        root.addView(TextView(this).apply { text="Nav Widget"; textSize=25f; setTextColor(Color.WHITE) })
        root.addView(TextView(this).apply { text="Floating navigation card"; textSize=14f; setTextColor(Color.LTGRAY) })
        root.addView(label("PERMISSIONS",true))
        root.addView(TextView(this).apply {
            text="Overlay: "+if(Settings.canDrawOverlays(this@MainActivity)) "Allowed" else "Required"
            setTextColor(Color.WHITE)
        })
        root.addView(button("OPEN overlay permission") {
            startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
        })
        root.addView(TextView(this).apply {
            text="Notification access: "+if(notificationAccessEnabled()) "Allowed" else "Required"
            setTextColor(Color.WHITE)
        })
        root.addView(button("OPEN notification access") { startActivity(Intent("android.settings.ACTION_NOTIFICATION_LISTENER_SETTINGS")) })
        root.addView(TextView(this).apply {
            text="Usage access (needed for auto-hide): "+if(usageAccessEnabled()) "Allowed" else "Required"
            setTextColor(Color.WHITE)
        })
        root.addView(button("OPEN usage access") { startActivity(Intent(Settings.ACTION_USAGE_ACCESS_SETTINGS)) })
        root.addView(label("WIDGET",true))
        root.addView(Switch(this).apply {
            text="Show floating card"; setTextColor(Color.WHITE)
            isChecked=prefs.getBoolean("enabled",false)
            setOnCheckedChangeListener { _, checked ->
                prefs.edit().putBoolean("enabled",checked).apply()
                if(checked) startWidget(false) else stopService(Intent(this@MainActivity,FloatingWidgetService::class.java))
            }
        })
        root.addView(Switch(this).apply {
            text="Hide card when Maps is in foreground"; setTextColor(Color.WHITE)
            isChecked=prefs.getBoolean("hide_maps",false)
            setOnCheckedChangeListener { _, checked -> prefs.edit().putBoolean("hide_maps",checked).apply() }
        })
        root.addView(label("SIZE",true))
        val group=RadioGroup(this).apply { orientation=RadioGroup.HORIZONTAL }
        listOf("Small","Normal","Large").forEachIndexed { i,s ->
            group.addView(RadioButton(this).apply { text=s; setTextColor(Color.WHITE); id=200+i; isChecked=prefs.getInt("size",1)==i })
        }
        group.setOnCheckedChangeListener { _, id ->
            prefs.edit().putInt("size",id-200).apply()
            if(prefs.getBoolean("enabled",false)) startWidget(false)
        }
        root.addView(group)
        root.addView(button("PREVIEW") { startWidget(true) })
        root.addView(button("RESET POSITION") {
            prefs.edit().remove("x").remove("y").apply()
            if(Settings.canDrawOverlays(this)) startWidget(true)
        })
        root.addView(label("LAST NAVIGATION NOTICE",true))
        root.addView(TextView(this).apply {
            text=prefs.getString("navigation_text","").orEmpty().ifBlank { "Waiting for a Google Maps navigation notification." }
            setTextColor(Color.LTGRAY); textSize=12f
        })
        setContentView(ScrollView(this).apply { addView(root) })
    }

    private fun notificationAccessEnabled():Boolean {
        val s=Settings.Secure.getString(contentResolver,"enabled_notification_listeners").orEmpty()
        return s.contains(packageName)
    }
    private fun usageAccessEnabled():Boolean {
        val appOps = getSystemService(Context.APP_OPS_SERVICE) as AppOpsManager
        return try {
            appOps.checkOpNoThrow("android:get_usage_stats", android.os.Process.myUid(), packageName) == AppOpsManager.MODE_ALLOWED
        } catch (ignored: Exception) { false }
    }
    private fun startWidget(preview:Boolean) {
        if(!Settings.canDrawOverlays(this)) {
            startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION,Uri.parse("package:$packageName"))); return
        }
        startService(Intent(this,FloatingWidgetService::class.java).putExtra("preview",preview))
    }
}
