package com.onehub.floatgauge;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.PixelFormat;
import android.os.Build;
import android.os.Handler;
import android.os.IBinder;
import android.os.Looper;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.MotionEvent;
import android.view.View;
import android.view.WindowManager;
import android.widget.FrameLayout;
import android.widget.Toast;

import androidx.core.app.NotificationCompat;

/**
 * Floating overlay. Drag + edit bar only after long-press (like OneHub).
 * Short taps on bottom-left / bottom-right of gauge cycle theme / style
 * (matches the two circular buttons drawn by the original engine).
 */
public class FloatService extends Service implements CarDataReader.Listener {

    public static final String ACTION_START = "START";
    public static final String ACTION_STOP = "STOP";
    private static final String CH = "float_gauge";
    private static final int NID = 42;
    private static final String PREFS = "onehub_float";
    private static final long LONG_MS = 450;
    private static final long EDIT_MS = 5000;

    private WindowManager wm;
    private View root;
    private View editBar;
    private WindowManager.LayoutParams params;
    private FrameLayout content;
    private SpeedoView speedo;
    private CarDataReader reader;
    private int baseDp = 280;
    private final Handler handler = new Handler(Looper.getMainLooper());

    private boolean editMode;
    private boolean dragging;
    private int ix, iy;
    private float downX, downY;
    private float itx, ity;
    private final Runnable hideEdit = () -> setEditMode(false);

    @Override
    public IBinder onBind(Intent i) { return null; }

    @Override
    public void onCreate() {
        super.onCreate();
        wm = (WindowManager) getSystemService(WINDOW_SERVICE);
        if (Build.VERSION.SDK_INT >= 26) {
            NotificationChannel c = new NotificationChannel(CH, "OneHub Float", NotificationManager.IMPORTANCE_LOW);
            NotificationManager nm = getSystemService(NotificationManager.class);
            if (nm != null) nm.createNotificationChannel(c);
        }
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        SharedPreferences p = getSharedPreferences(PREFS, MODE_PRIVATE);
        if (intent != null && ACTION_STOP.equals(intent.getAction())) {
            stopAll();
            return START_NOT_STICKY;
        }
        if (root == null) {
            baseDp = p.getInt("size", 280);
            show();
            reader = new CarDataReader(this, this);
            reader.start();
        }
        startForeground(NID, notif());
        return START_STICKY;
    }

    private void show() {
        root = LayoutInflater.from(this).inflate(R.layout.float_root, null);
        content = root.findViewById(R.id.content);
        editBar = root.findViewById(R.id.edit_bar);
        speedo = new SpeedoView(this);
        SharedPreferences p = getSharedPreferences(PREFS, MODE_PRIVATE);
        speedo.setStyle(p.getInt("style", 0));
        speedo.setThemeIndex(p.getInt("theme", 0));
        content.addView(speedo, new FrameLayout.LayoutParams(
                FrameLayout.LayoutParams.MATCH_PARENT, FrameLayout.LayoutParams.MATCH_PARENT));

        int type = Build.VERSION.SDK_INT >= 26
                ? WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
                : WindowManager.LayoutParams.TYPE_PHONE;

        int[] wh = sizeFor();
        params = new WindowManager.LayoutParams(wh[0], wh[1], type,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE | WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
                PixelFormat.TRANSLUCENT);
        params.gravity = Gravity.TOP | Gravity.START;
        params.x = 40;
        params.y = 100;
        applyContentSize(wh[0], wh[1]);

        root.setOnTouchListener(this::onRootTouch);

        root.findViewById(R.id.btn_theme).setOnClickListener(v -> {
            cycleThemeStyle();
            bumpEdit();
        });
        root.findViewById(R.id.btn_bigger).setOnClickListener(v -> { resize(+28); bumpEdit(); });
        root.findViewById(R.id.btn_smaller).setOnClickListener(v -> { resize(-28); bumpEdit(); });
        root.findViewById(R.id.btn_close).setOnClickListener(v -> {
            getSharedPreferences(PREFS, MODE_PRIVATE).edit().putBoolean("on", false).apply();
            stopAll();
        });

        try {
            wm.addView(root, params);
        } catch (Exception e) {
            Toast.makeText(this, "امنح إذن الظهور فوق التطبيقات", Toast.LENGTH_LONG).show();
            stopSelf();
        }
    }

    private boolean onRootTouch(View v, MotionEvent e) {
        switch (e.getActionMasked()) {
            case MotionEvent.ACTION_DOWN:
                downX = e.getX();
                downY = e.getY();
                itx = e.getRawX();
                ity = e.getRawY();
                ix = params.x;
                iy = params.y;
                dragging = false;
                handler.postDelayed(() -> {
                    // long-press → edit mode + allow drag
                    setEditMode(true);
                    dragging = true;
                }, LONG_MS);
                return true;

            case MotionEvent.ACTION_MOVE:
                if (dragging || editMode) {
                    handler.removeCallbacks(hideEdit);
                    params.x = ix + (int) (e.getRawX() - itx);
                    params.y = iy + (int) (e.getRawY() - ity);
                    try { wm.updateViewLayout(root, params); } catch (Exception ignored) {}
                    return true;
                }
                // cancel long-press if moved too much before it fires
                if (Math.hypot(e.getRawX() - itx, e.getRawY() - ity) > dp(12)) {
                    handler.removeCallbacksAndMessages(null);
                }
                return true;

            case MotionEvent.ACTION_UP:
            case MotionEvent.ACTION_CANCEL:
                handler.removeCallbacksAndMessages(null);
                if (!dragging && !editMode) {
                    // short tap: hit-test bottom engine buttons (left theme, right style)
                    handleGaugeTap(downX, downY);
                }
                if (editMode) bumpEdit();
                dragging = false;
                return true;
        }
        return false;
    }

    /** Bottom ~18% of gauge: left half = theme, right half = style (OneHub two dots). */
    private void handleGaugeTap(float x, float y) {
        if (speedo == null) return;
        int w = speedo.getWidth();
        int h = speedo.getHeight();
        if (w <= 0 || h <= 0) return;
        if (y < h * 0.78f) return; // only bottom strip
        if (x < w * 0.5f) {
            speedo.nextTheme();
            getSharedPreferences(PREFS, MODE_PRIVATE).edit()
                    .putInt("theme", speedo.getThemeIndex()).apply();
        } else {
            speedo.nextStyle();
            getSharedPreferences(PREFS, MODE_PRIVATE).edit()
                    .putInt("style", speedo.getStyle()).apply();
            relayout();
        }
    }

    private void cycleThemeStyle() {
        int next = (speedo.getStyle() + 1) % SpeedoView.STYLE_COUNT;
        speedo.setStyle(next);
        if (next == 0) speedo.nextTheme();
        getSharedPreferences(PREFS, MODE_PRIVATE).edit()
                .putInt("style", speedo.getStyle())
                .putInt("theme", speedo.getThemeIndex())
                .apply();
        relayout();
    }

    private void setEditMode(boolean on) {
        editMode = on;
        if (editBar != null) editBar.setVisibility(on ? View.VISIBLE : View.GONE);
        relayout();
        if (on) bumpEdit();
    }

    private void bumpEdit() {
        handler.removeCallbacks(hideEdit);
        handler.postDelayed(hideEdit, EDIT_MS);
    }

    private int[] sizeFor() {
        float[] r = SpeedoEngine.f1038r;
        float[] q = SpeedoEngine.f1037q;
        int si = speedo != null ? speedo.getStyle() : 0;
        float scale = (si >= 0 && si < r.length) ? r[si] : 1f;
        float ratio = (si >= 0 && si < q.length) ? q[si] : 1f;
        // Keep a minimum scale so complex styles are not cropped
        if (scale < 0.7f) scale = 0.7f;
        if (ratio < 0.85f) ratio = 0.85f;
        int extra = (editMode && editBar != null && editBar.getVisibility() == View.VISIBLE) ? dp(52) : dp(8);
        int bw = Math.round(dp(baseDp) * scale);
        int bh = Math.round(bw * ratio);
        // safety margins so dial + native bottom buttons are not clipped
        bw = Math.max(bw, dp(160));
        bh = Math.max(bh, dp(140));
        return new int[]{bw, bh + extra};
    }

    private void applyContentSize(int totalW, int totalH) {
        int extra = (editMode && editBar != null && editBar.getVisibility() == View.VISIBLE) ? dp(52) : dp(8);
        FrameLayout.LayoutParams lp = (FrameLayout.LayoutParams) content.getLayoutParams();
        lp.width = totalW;
        lp.height = Math.max(dp(120), totalH - extra);
        content.setLayoutParams(lp);
    }

    private void relayout() {
        if (params == null || root == null) return;
        int[] wh = sizeFor();
        params.width = wh[0];
        params.height = wh[1];
        applyContentSize(wh[0], wh[1]);
        try { wm.updateViewLayout(root, params); } catch (Exception ignored) {}
    }

    private void resize(int delta) {
        baseDp = Math.max(180, Math.min(440, baseDp + delta));
        getSharedPreferences(PREFS, MODE_PRIVATE).edit().putInt("size", baseDp).apply();
        relayout();
    }

    @Override
    public void onData(float speed, int gearIdx, int batt, int fuel, int powerKw, int tempOut, int tempBatt, boolean fromCar) {
        if (speedo != null) {
            speedo.setData(speed, gearIdx, batt, fuel, powerKw, tempOut, tempBatt);
        }
    }

    private void stopAll() {
        handler.removeCallbacksAndMessages(null);
        if (reader != null) { reader.stop(); reader = null; }
        if (root != null) {
            try { wm.removeView(root); } catch (Exception ignored) {}
            root = null;
        }
        stopForeground(true);
        stopSelf();
    }

    private Notification notif() {
        Intent stop = new Intent(this, FloatService.class).setAction(ACTION_STOP);
        PendingIntent pi = PendingIntent.getService(this, 0, stop,
                PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
        Intent open = new Intent(this, MainActivity.class);
        PendingIntent oi = PendingIntent.getActivity(this, 1, open,
                PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
        String mode = (reader != null && reader.isCarOk()) ? "بيانات السيارة" : "تجريبي: سرعة·بنزين·طاقة·حرارة";
        return new NotificationCompat.Builder(this, CH)
                .setContentTitle("OneHub Float")
                .setContentText(mode)
                .setSmallIcon(android.R.drawable.ic_menu_compass)
                .setContentIntent(oi)
                .addAction(0, "إيقاف", pi)
                .setOngoing(true)
                .setPriority(NotificationCompat.PRIORITY_LOW)
                .build();
    }

    private int dp(int v) {
        return Math.round(v * getResources().getDisplayMetrics().density);
    }

    @Override
    public void onDestroy() {
        handler.removeCallbacksAndMessages(null);
        if (reader != null) reader.stop();
        if (root != null) {
            try { wm.removeView(root); } catch (Exception ignored) {}
        }
        super.onDestroy();
    }
}
