package com.geely.carreceiver

import android.content.Context
import android.os.Build
import java.io.File
import java.io.IOException
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/**
 * Read-only report about this head unit: what Android it runs, whether this app can really become root,
 * what a list of candidate Vehicle HAL properties look like when read directly through android.car from
 * this app's own process (see [VhalAccess]), and (only when root works) what lshal/car_service expose.
 * Send it to whoever adapts the command table. Nothing here changes anything on the car.
 */
object Diagnostics {

    private class Check(val title: String, val command: String)

    /** Checks that need no special rights. */
    private val BASIC = listOf(
        Check("user id", "id"),
        Check("kernel", "uname -a"),
        Check("su binary", "ls -l /system/bin/su /system/xbin/su /sbin/su /su/bin/su /vendor/bin/su 2>&1; ls -Z /system/xbin/su 2>&1"),
        Check(
            "selinux and build flags",
            "getenforce 2>&1; getprop ro.build.type; getprop ro.build.tags; getprop ro.debuggable; getprop ro.secure; " +
                "getprop service.adb.tcp.port; getprop persist.adb.tcp.port; getprop persist.sys.usb.config"
        ),
        Check("listening ports", "netstat -tln 2>&1 | head -n 30"),
        Check(
            "car related properties",
            "getprop | grep -iE 'geely|ecarx|vehicle|flyme|hvac|\\.car\\.|mcu' | grep -v 'log.tag' | head -n 100"
        ),
        Check("all service names", "service list 2>&1 | cut -f2 | cut -d: -f1 | head -n 400"),
        Check(
            "car related permissions (name + protection level)",
            "pm list permissions -f 2>&1 | grep -iE -A4 'permission:.*(\\.car\\.|ecarx|geely|vehicle|hvac)' | " +
                "grep -E 'permission:|protectionLevel' | head -n 120"
        ),
        Check("network", "ip -4 addr 2>&1 | grep -E 'inet |^[0-9]+:' | head -n 20")
    )

    /** Candidate Vehicle HAL properties worth checking from inside this app's own process (no root, no
     *  other app's relay) - found by reading com.geely.controlcenter's and com.flyme.auto.launcher's own
     *  code. None of these (besides the first, which is read-only here too) is confirmed to accept writes
     *  from a plain installed app: most vehicle-body properties need a signature|privileged permission this
     *  app does not hold, so "SecurityException" below for most of them would not be surprising - it is
     *  still the precise answer we need, property by property. */
    private val VHAL_CANDIDATES = listOf(
        "windows/sunroof (confirmed working, but only via the launcher's broadcast - checking direct access too)" to 0x234020AB,
        "mirror fold (areas: left=1, right=2)" to 0x20090200,
        "child safety lock" to 0x21020400,
        "rear door / front trunk (areas: hood=0x10000000, rear=0x20000000)" to 0x16400B01,
        "glove box" to 0x200F0300,
        "fuel tank cap" to 0x11200308,
        "reading lights" to 0x15407050,
        "ambient lighting" to 0x21051000,
        "seat heating" to 356517131,
        "seat ventilation" to 356517139,
        "drive mode" to 0x22010100
    )

    /** Read-only checks that are run as root, and only when su really gives root to this app. */
    private val ROOT_CHECKS = listOf(
        Check("hal services", "lshal 2>&1 | grep -iE 'vehicle|ecarx|geely|car' | head -n 30"),
        Check("vehicle hal help", "lshal debug android.hardware.automotive.vehicle@2.0::IVehicle/default --help 2>&1 | head -n 40"),
        Check("vehicle hal property list", "lshal debug android.hardware.automotive.vehicle@2.0::IVehicle/default --list 2>&1 | head -n 250"),
        Check("car_service dump", "dumpsys car_service 2>&1 | head -n 250")
    )

    private const val CHECK_TIMEOUT_MS = 6000L
    private const val MAX_CHARS = 9000
    private const val MAX_CATALOGUE_LINES = 400

    /** Blocking (up to a minute on a slow unit): call from a background thread. */
    fun run(context: Context): String {
        val sb = StringBuilder()
        sb.append("Geely Receiver diagnostics ").append(SimpleDateFormat("yyyy-MM-dd HH:mm", Locale.US).format(Date())).append("\n\n")
        sb.append("manufacturer: ").append(Build.MANUFACTURER).append('\n')
        sb.append("model: ").append(Build.MODEL).append('\n')
        sb.append("device: ").append(Build.DEVICE).append('\n')
        sb.append("android: ").append(Build.VERSION.RELEASE).append(" (sdk ").append(Build.VERSION.SDK_INT).append(")\n")
        sb.append("build: ").append(Build.DISPLAY).append('\n')
        sb.append("fingerprint: ").append(Build.FINGERPRINT).append("\n\n")

        for (check in BASIC) section(sb, check.title, check.command)

        sb.append(vhalSection(context))

        // Does su really give root to THIS app? (a su binary can exist and still refuse every app)
        val suPath = CommandBackend.SU_PATHS.firstOrNull { File(it).exists() }
        var wrap: ((String) -> String)? = null
        if (suPath == null) {
            sb.append("## su test\n(no su binary found)\n\n")
        } else {
            val dashC = section(sb, "su -c id", "$suPath -c id 2>&1")
            if (dashC.contains("uid=0")) {
                wrap = { inner -> "$suPath -c '$inner' 2>&1" }
            } else {
                val zero = section(sb, "su 0 id", "$suPath 0 id 2>&1")
                if (zero.contains("uid=0")) wrap = { inner -> "$suPath 0 sh -c '$inner' 2>&1" }
            }
        }

        val rootWrap = wrap
        if (rootWrap == null) {
            sb.append("## root-only checks\nskipped: su does not give root to this app (see the su test above)\n\n")
        } else {
            for (check in ROOT_CHECKS) section(sb, "root: " + check.title, rootWrap(check.command))
        }

        sb.append("command table: ").append(File(context.filesDir, CommandBackend.FILE_NAME).absolutePath).append('\n')
        return sb.toString()
    }

    /** Read-only: does this app's own process reach android.car at all, what can it see per candidate
     *  property, and (v2.6) which READ_WRITE properties are enumerable from THIS app without root.
     *  Writes nothing; every failure (SecurityException included) is reported exactly as it happened. */
    private fun vhalSection(context: Context): String {
        val sb = StringBuilder()
        sb.append("## VHAL direct access via android.car (read-only probe, from this app's own process, no root)\n")
        val mgr = VhalAccess.manager(context)
        if (mgr == null) {
            sb.append("android.car unavailable: ").append(VhalAccess.lastError() ?: "unknown reason").append("\n\n")
            return sb.toString()
        }
        for ((name, propId) in VHAL_CANDIDATES) {
            sb.append("- ").append(name).append(" (property=0x").append(propId.toString(16)).append("): ")
                .append(VhalAccess.describeProperty(mgr, propId)).append('\n')
            val areas = VhalAccess.areaIdsOf(mgr, propId)
            if (areas != null && areas.isNotEmpty()) {
                for (area in areas.take(6)) {
                    sb.append("    area=0x").append(area.toString(16)).append(": ")
                        .append(VhalAccess.describeValue(mgr, propId, area)).append('\n')
                }
            } else {
                sb.append("    area=0x0 (guess, no area list available): ")
                    .append(VhalAccess.describeValue(mgr, propId, 0)).append('\n')
            }
        }
        sb.append('\n')
        sb.append(vhalCatalogueSection(mgr))
        return sb.toString()
    }

    /** v2.6: lists every READ_WRITE property enumerable from this app's own process - no root needed.
     *  These are the only candidates a direct VHAL_* write could ever reach; anything not listed here
     *  needs the broadcast-relay route (like the windows/sunroof) or another mechanism entirely. */
    private fun vhalCatalogueSection(mgr: Any): String {
        val sb = StringBuilder()
        sb.append("## VHAL catalogue visible to this app, READ_WRITE only (no root)\n")
        val configs = VhalAccess.allConfigs(mgr)
        if (configs == null) {
            sb.append("(no enumeration API available on this build - compare with the 2026-10-29 root dump instead)\n\n")
            return sb.toString()
        }
        var count = 0
        for (config in configs) {
            if (VhalAccess.accessOf(config) != 3) continue // 3 = READ_WRITE
            val line = VhalAccess.describeConfig(config) ?: continue
            sb.append(line).append('\n')
            count++
            if (count >= MAX_CATALOGUE_LINES) {
                sb.append("(truncated at ").append(MAX_CATALOGUE_LINES).append(" lines)\n")
                break
            }
        }
        if (count == 0) sb.append("(no READ_WRITE property is enumerable from this process)\n")
        sb.append('\n')
        return sb.toString()
    }

    /** Runs one check, appends it to the report and returns its raw output (for decisions). */
    private fun section(sb: StringBuilder, title: String, command: String): String {
        sb.append("## ").append(title).append("\n$ ").append(command).append('\n')
        val out = Shell.run(arrayOf("sh", "-c", command), CHECK_TIMEOUT_MS, MAX_CHARS)
        val failure = out.failure
        when {
            failure != null -> {
                sb.append("[").append(failure).append("]\n")
                if (out.text.isNotEmpty()) sb.append(out.text).append('\n')
            }
            out.text.isEmpty() -> sb.append("(no output, exit=").append(out.exit).append(")\n")
            else -> sb.append(out.text).append('\n')
        }
        sb.append('\n')
        return out.text
    }

    /** @return the path of the saved report, or null when it could not be written. */
    fun save(context: Context, report: String): String? = try {
        val dir = context.getExternalFilesDir(null) ?: context.filesDir
        val file = File(dir, "diagnostics.txt")
        file.writeText(report, Charsets.UTF_8)
        file.absolutePath
    } catch (e: IOException) {
        null
    }
}
