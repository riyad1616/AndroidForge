package com.onehub.floatgauge;

import android.content.Context;
import android.os.Handler;
import android.os.Looper;
import android.util.Log;

import java.lang.reflect.Method;
import java.util.concurrent.Executors;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.atomic.AtomicBoolean;

public class CarDataReader {
    private static final String TAG = "CarDataReader";
    // OneHub property name mapping (ids may vary by platform)
    public static final int PROP_SPEED = 0x11600207;
    public static final int PROP_FUEL = 0x2140a569;

    public interface Listener {
        void onData(float speed, int gearIdx, int batt, int fuel, int powerKw, int tempOut, int tempBatt, boolean fromCar);
    }

    private final Context ctx;
    private final Listener listener;
    private final Handler main = new Handler(Looper.getMainLooper());
    private ScheduledExecutorService exec;
    private final AtomicBoolean running = new AtomicBoolean(false);
    private Object car, pm;
    private Method getFloat, getInt;
    private boolean carOk;
    private float demoSpeed;
    private boolean demoUp = true;

    public CarDataReader(Context c, Listener l) {
        ctx = c.getApplicationContext();
        listener = l;
        initCar();
    }

    private void initCar() {
        try {
            Class<?> carCl = Class.forName("android.car.Car");
            car = carCl.getMethod("createCar", Context.class).invoke(null, ctx);
            if (car == null) return;
            pm = carCl.getMethod("getCarManager", String.class).invoke(car, "property");
            if (pm == null) return;
            getFloat = pm.getClass().getMethod("getFloatProperty", int.class, int.class);
            getInt = pm.getClass().getMethod("getIntProperty", int.class, int.class);
            carOk = true;
        } catch (Throwable t) {
            Log.w(TAG, "Car API unavailable – demo mode");
            carOk = false;
        }
    }

    public boolean isCarOk() { return carOk; }

    public void start() {
        if (running.getAndSet(true)) return;
        exec = Executors.newSingleThreadScheduledExecutor();
        exec.scheduleAtFixedRate(this::poll, 0, 100, TimeUnit.MILLISECONDS);
    }

    public void stop() {
        running.set(false);
        if (exec != null) { exec.shutdownNow(); exec = null; }
    }

    private void poll() {
        if (!running.get()) return;
        float speed = 0;
        int gear = 0, batt = Integer.MIN_VALUE, fuel = Integer.MIN_VALUE;
        int power = Integer.MIN_VALUE, temp = Integer.MIN_VALUE, tbatt = Integer.MIN_VALUE;
        boolean fromCar = false;
        if (carOk && pm != null) {
            try {
                Object f = getFloat.invoke(pm, PROP_SPEED, 0);
                if (f instanceof Float) speed = Math.max(0, (Float) f);
                Object i = getInt.invoke(pm, PROP_FUEL, 0);
                if (i instanceof Integer) {
                    int v = (Integer) i;
                    if (v >= 0 && v <= 100) fuel = v;
                }
                gear = speed > 1f ? 4 : 1; // D or P (OneHub: 1P 2R 3N 4D in n())
                // n() uses 1=P 2=R 3=N 4=D
                fromCar = true;
            } catch (Throwable t) {
                carOk = false;
            }
        }
        if (!fromCar) {
            if (demoUp) {
                demoSpeed += 1.1f;
                if (demoSpeed >= 160f) demoUp = false;
            } else {
                demoSpeed -= 0.9f;
                if (demoSpeed <= 0f) { demoSpeed = 0f; demoUp = true; }
            }
            speed = demoSpeed;
            gear = speed > 2f ? 4 : 1;
            fuel = 68;
            batt = Integer.MIN_VALUE;
            power = speed > 3f ? -1 : 0;
            temp = 92;
            tbatt = 35;
        }
        final float s = speed;
        final int g = gear, ba = batt, fu = fuel, pw = power, te = temp, tb = tbatt;
        final boolean fc = fromCar;
        main.post(() -> {
            if (listener != null) listener.onData(s, g, ba, fu, pw, te, tb, fc);
        });
    }
}
