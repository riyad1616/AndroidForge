package com.onehub.floatgauge;

/** Port of OneHub C0018b2 */
public final class SpeedoData {
    public float f1011a;          // speed
    public boolean b;             // gear drive-ish
    public int f1012c = -1;       // gear index
    public final int[] f1013d;    // 7 telemetry slots
    public int f1014e;            // flash flags

    public SpeedoData() {
        f1013d = new int[7];
        for (int i = 0; i < 7; i++) f1013d[i] = Integer.MIN_VALUE;
    }

    public void set(float speed, int gearIdx, int batt, int fuel, int powerKw, int tempOut, int tempBatt) {
        this.f1011a = speed;
        this.f1012c = gearIdx;
        this.b = gearIdx == 3;
        f1013d[0] = batt;
        f1013d[1] = fuel;
        f1013d[4] = powerKw;
        f1013d[5] = tempOut;
        f1013d[6] = tempBatt;
    }
}
