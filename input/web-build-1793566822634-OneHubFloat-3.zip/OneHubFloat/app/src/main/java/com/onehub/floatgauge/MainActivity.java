package com.onehub.floatgauge;

import android.content.Intent;
import android.content.SharedPreferences;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.provider.Settings;
import android.widget.Switch;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {

    private static final String PREFS = "onehub_float";
    private Switch sw;
    private TextView status;
    private boolean waitPerm;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        sw = findViewById(R.id.switch_float);
        status = findViewById(R.id.status);
        SharedPreferences p = getSharedPreferences(PREFS, MODE_PRIVATE);
        boolean on = p.getBoolean("on", false);
        sw.setChecked(on);
        setStatus(on);
        if (on && canOverlay()) startSvc();
        sw.setOnCheckedChangeListener((b, checked) -> {
            if (checked) enable();
            else disable();
        });
    }

    @Override
    protected void onResume() {
        super.onResume();
        if (waitPerm) {
            waitPerm = false;
            if (canOverlay()) {
                sw.setChecked(true);
                getSharedPreferences(PREFS, MODE_PRIVATE).edit().putBoolean("on", true).apply();
                startSvc();
                setStatus(true);
            } else {
                sw.setChecked(false);
                setStatus(false);
                Toast.makeText(this, "لم يُمنح الإذن", Toast.LENGTH_SHORT).show();
            }
        }
    }

    private void enable() {
        if (!canOverlay()) {
            sw.setOnCheckedChangeListener(null);
            sw.setChecked(false);
            sw.setOnCheckedChangeListener((b, c) -> { if (c) enable(); else disable(); });
            waitPerm = true;
            Toast.makeText(this, "امنح إذن الظهور فوق التطبيقات", Toast.LENGTH_LONG).show();
            startActivity(new Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                    Uri.parse("package:" + getPackageName())));
            return;
        }
        getSharedPreferences(PREFS, MODE_PRIVATE).edit().putBoolean("on", true).apply();
        startSvc();
        setStatus(true);
    }

    private void disable() {
        getSharedPreferences(PREFS, MODE_PRIVATE).edit().putBoolean("on", false).apply();
        startService(new Intent(this, FloatService.class).setAction(FloatService.ACTION_STOP));
        setStatus(false);
    }

    private void startSvc() {
        Intent i = new Intent(this, FloatService.class).setAction(FloatService.ACTION_START);
        if (Build.VERSION.SDK_INT >= 26) startForegroundService(i);
        else startService(i);
    }

    private boolean canOverlay() {
        return Build.VERSION.SDK_INT < 23 || Settings.canDrawOverlays(this);
    }

    private void setStatus(boolean on) {
        status.setText(on ? "العداد ظاهر – محرك OneHub الأصلي (d2)" : "متوقف");
        status.setTextColor(on ? 0xFF4CAF50 : 0xFF888888);
    }
}
