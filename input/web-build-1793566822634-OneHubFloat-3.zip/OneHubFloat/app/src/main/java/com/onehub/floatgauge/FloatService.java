package com.onehub.floatgauge;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.PixelFormat;
import android.os.Build;
import android.os.IBinder;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.MotionEvent;
import android.view.View;
import android.view.WindowManager;
import android.widget.FrameLayout;
import android.widget.Toast;

import androidx.core.app.NotificationCompat;

public class FloatService extends Service implements CarDataReader.Listener {

    public static final String ACTION_START = "START";
    public static final String ACTION_STOP = "STOP";
    private static final String CH = "float_gauge";
    private static final int NID = 42;
    private static final String PREFS = "onehub_float";

    private WindowManager wm;
    private View root;
    private WindowManager.LayoutParams params;
    private FrameLayout content;
    private SpeedoView speedo;
    private CarDataReader reader;
    private int baseDp = 260;
    private int ix, iy;
    private float itx, ity;

    @Override public IBinder onBind(Intent i) { return null; }

    @Override
    public void onCreate() {
        super.onCreate();
        wm = (WindowManager) getSystemService(WINDOW_SERVICE);
        if (Build.VERSION.SDK_INT >= 26) {
            NotificationChannel c = new NotificationChannel(CH, "OneHub Float", NotificationManager.IMPORTANCE_LOW);
            NotificationManager nm = getSystemService(NotificationManager.class);
            if (nm != null) nm.createNotificationChannel(c);
        }
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        SharedPreferences p = getSharedPreferences(PREFS, MODE_PRIVATE);
        if (intent != null && ACTION_STOP.equals(intent.getAction())) {
            stopAll();
            return START_NOT_STICKY;
        }
        if (root == null) {
            baseDp = p.getInt("size", 260);
            show();
            reader = new CarDataReader(this, this);
            reader.start();
        }
        startForeground(NID, notif());
        return START_STICKY;
    }

    private void show() {
        root = LayoutInflater.from(this).inflate(R.layout.float_root, null);
        content = root.findViewById(R.id.content);
        speedo = new SpeedoView(this);
        SharedPreferences p = getSharedPreferences(PREFS, MODE_PRIVATE);
        speedo.setStyle(p.getInt("style", 0));
        speedo.setThemeIndex(p.getInt("theme", 0));
        content.addView(speedo, new FrameLayout.LayoutParams(
                FrameLayout.LayoutParams.MATCH_PARENT, FrameLayout.LayoutParams.MATCH_PARENT));

        int type = Build.VERSION.SDK_INT >= 26
                ? WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
                : WindowManager.LayoutParams.TYPE_PHONE;

        int[] wh = sizeFor();
        params = new WindowManager.LayoutParams(wh[0], wh[1], type,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE | WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
                PixelFormat.TRANSLUCENT);
        params.gravity = Gravity.TOP | Gravity.START;
        params.x = 50;
        params.y = 120;
        applyContentSize(wh[0], wh[1]);

        root.setOnTouchListener((v, e) -> {
            switch (e.getAction()) {
                case MotionEvent.ACTION_DOWN:
                    ix = params.x; iy = params.y;
                    itx = e.getRawX(); ity = e.getRawY();
                    return true;
                case MotionEvent.ACTION_MOVE:
                    params.x = ix + (int) (e.getRawX() - itx);
                    params.y = iy + (int) (e.getRawY() - ity);
                    try { wm.updateViewLayout(root, params); } catch (Exception ignored) {}
                    return true;
            }
            return false;
        });

        root.findViewById(R.id.btn_theme).setOnClickListener(v -> {
            int next = (speedo.getStyle() + 1) % SpeedoView.STYLE_COUNT;
            speedo.setStyle(next);
            if (next == 0) speedo.nextTheme();
            p.edit().putInt("style", speedo.getStyle()).putInt("theme", speedo.getThemeIndex()).apply();
            int[] nwh = sizeFor();
            params.width = nwh[0];
            params.height = nwh[1];
            applyContentSize(nwh[0], nwh[1]);
            try { wm.updateViewLayout(root, params); } catch (Exception ignored) {}
        });
        root.findViewById(R.id.btn_bigger).setOnClickListener(v -> resize(+24));
        root.findViewById(R.id.btn_smaller).setOnClickListener(v -> resize(-24));
        root.findViewById(R.id.btn_close).setOnClickListener(v -> {
            getSharedPreferences(PREFS, MODE_PRIVATE).edit().putBoolean("on", false).apply();
            stopAll();
        });

        try {
            wm.addView(root, params);
        } catch (Exception e) {
            Toast.makeText(this, "امنح إذن الظهور فوق التطبيقات", Toast.LENGTH_LONG).show();
            stopSelf();
        }
    }

    private int[] sizeFor() {
        float aspect = speedo != null ? speedo.aspect() : 1f;
        if (aspect < 0.3f) aspect = 1f;
        // OneHub: width = size * scale, height = width / aspect  (f1037q is height/width ratio stored inverted in our usage)
        // Original: width = size * r[style], height = width * q[style]
        float[] r = SpeedoEngine.f1038r;
        float[] q = SpeedoEngine.f1037q;
        int si = speedo.getStyle();
        float scale = (si >= 0 && si < r.length) ? r[si] : 1f;
        float ratio = (si >= 0 && si < q.length) ? q[si] : 1f;
        int ctrl = dp(44);
        int bw = Math.round(dp(baseDp) * scale);
        int bh = Math.round(bw * ratio);
        return new int[]{Math.max(bw, 80), Math.max(bh, 80) + ctrl};
    }

    private void applyContentSize(int totalW, int totalH) {
        int ctrl = dp(44);
        FrameLayout.LayoutParams lp = (FrameLayout.LayoutParams) content.getLayoutParams();
        lp.width = totalW;
        lp.height = Math.max(40, totalH - ctrl);
        content.setLayoutParams(lp);
    }

    private void resize(int delta) {
        baseDp = Math.max(160, Math.min(420, baseDp + delta));
        getSharedPreferences(PREFS, MODE_PRIVATE).edit().putInt("size", baseDp).apply();
        int[] wh = sizeFor();
        params.width = wh[0];
        params.height = wh[1];
        applyContentSize(wh[0], wh[1]);
        try { wm.updateViewLayout(root, params); } catch (Exception ignored) {}
    }

    @Override
    public void onData(float speed, int gearIdx, int batt, int fuel, int powerKw, int tempOut, int tempBatt, boolean fromCar) {
        if (speedo != null) {
            speedo.setData(speed, gearIdx, batt, fuel, powerKw, tempOut, tempBatt);
        }
    }

    private void stopAll() {
        if (reader != null) { reader.stop(); reader = null; }
        if (root != null) {
            try { wm.removeView(root); } catch (Exception ignored) {}
            root = null;
        }
        stopForeground(true);
        stopSelf();
    }

    private Notification notif() {
        Intent stop = new Intent(this, FloatService.class).setAction(ACTION_STOP);
        PendingIntent pi = PendingIntent.getService(this, 0, stop,
                PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
        Intent open = new Intent(this, MainActivity.class);
        PendingIntent oi = PendingIntent.getActivity(this, 1, open,
                PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
        String mode = (reader != null && reader.isCarOk()) ? "بيانات السيارة" : "وضع تجريبي – محرك OneHub الأصلي";
        return new NotificationCompat.Builder(this, CH)
                .setContentTitle("OneHub Float")
                .setContentText(mode)
                .setSmallIcon(android.R.drawable.ic_menu_compass)
                .setContentIntent(oi)
                .addAction(0, "إيقاف", pi)
                .setOngoing(true)
                .setPriority(NotificationCompat.PRIORITY_LOW)
                .build();
    }

    private int dp(int v) {
        return Math.round(v * getResources().getDisplayMetrics().density);
    }

    @Override
    public void onDestroy() {
        if (reader != null) reader.stop();
        if (root != null) {
            try { wm.removeView(root); } catch (Exception ignored) {}
        }
        super.onDestroy();
    }
}
