package com.onehub.floatgauge;

import android.content.Context;
import android.graphics.Canvas;
import android.util.AttributeSet;
import android.view.View;

/** Custom view that hosts OneHub SpeedoEngine (ported d2 renderer). */
public class SpeedoView extends View {

    public static final int STYLE_COUNT = 10;
    public static final int THEME_COUNT = SpeedoEngine.f1039s.size();

    private final SpeedoEngine engine = new SpeedoEngine();
    private final SpeedoData data = new SpeedoData();
    private int styleIndex = 0;
    private int themeIndex = 0;

    public SpeedoView(Context c) { super(c); }
    public SpeedoView(Context c, AttributeSet a) { super(c, a); }

    public void setStyle(int s) {
        styleIndex = ((s % STYLE_COUNT) + STYLE_COUNT) % STYLE_COUNT;
        requestLayout();
        invalidate();
    }
    public int getStyle() { return styleIndex; }
    public void nextStyle() { setStyle(styleIndex + 1); }

    public void setThemeIndex(int t) {
        themeIndex = ((t % THEME_COUNT) + THEME_COUNT) % THEME_COUNT;
        invalidate();
    }
    public int getThemeIndex() { return themeIndex; }
    public void nextTheme() { setThemeIndex(themeIndex + 1); }

    public void setData(float speed, int gearIdx, int batt, int fuel, int powerKw, int tempOut, int tempBatt) {
        data.set(speed, gearIdx, batt, fuel, powerKw, tempOut, tempBatt);
        invalidate();
    }

    /** Aspect width/height from OneHub C0026d2.f1037q */
    public float aspect() {
        float[] q = SpeedoEngine.f1037q;
        int i = styleIndex;
        if (i < 0 || i >= q.length) return 1f;
        return q[i];
    }

    @Override
    protected void onDraw(Canvas canvas) {
        super.onDraw(canvas);
        float w = getWidth();
        float h = getHeight();
        if (w < 4 || h < 4) return;
        try {
            engine.j(canvas, w, h, styleIndex, themeIndex, data);
        } catch (Throwable t) {
            // keep overlay alive if a style fails
        }
    }
}
