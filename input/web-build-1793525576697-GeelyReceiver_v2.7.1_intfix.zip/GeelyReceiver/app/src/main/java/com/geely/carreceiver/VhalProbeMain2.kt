package com.geely.carreceiver

import android.content.Context
import android.os.Looper

/**
 * Second-generation standalone probe, launched the exact same way as [VhalProbeMain]
 * (`su 1000 app_process -Djava.class.path=<apk> / com.geely.carreceiver.VhalProbeMain2`).
 *
 * [VhalProbeMain] proved that uid=1000 + a bootstrapped system Context lets this code run, but its
 * attempt to reach CarPropertyManager via the normal `android.car.Car.createCar(context)` path failed
 * with a *different* problem than the one we set out to test: ActivityManagerService rejected the
 * underlying `bindService()` call with "Unable to find app for caller" - a process started directly by
 * `app_process` has no ProcessRecord in AMS, so this bind never gets anywhere near the
 * android.car.permission.* check we actually want to test. That failure says nothing about whether
 * uid=1000 can write the blocked properties - the real question is still open.
 *
 * This probe instead goes through [VhalDirectAccess], which fetches the car_service connection
 * straight from ServiceManager (no AMS involved at all), then tries to build a genuine
 * android.car.Car object from it by reflection-probing android.car.Car's real constructors/factory
 * methods on THIS ROM. If that succeeds, it reuses [VhalAccess]'s already-proven describeValue/setBool
 * code unchanged to run the exact same DOME_LIGHT / MIRROR_FOLD read-write-read-restore probe
 * [VhalProbeMain] was meant to run. If it does not succeed, it prints every constructor/method it
 * tried and why, so the next attempt can be built from real data instead of another guess.
 */
object VhalProbeMain2 {

    @JvmStatic
    fun main(args: Array<String>) {
        val watchdog = Thread {
            try {
                Thread.sleep(15_000)
            } catch (ignored: InterruptedException) {
                return@Thread
            }
            System.out.println("WATCHDOG: forcing exit after 15s (nothing should normally take this long)")
            System.out.flush()
            Runtime.getRuntime().halt(1)
        }
        watchdog.isDaemon = true
        watchdog.start()

        println("== VhalProbeMain2 (direct ServiceManager path) ==")
        try {
            println("uid=" + android.os.Process.myUid() + " pid=" + android.os.Process.myPid())

            if (Looper.myLooper() == null) Looper.prepareMainLooper()

            val activityThreadClass = Class.forName("android.app.ActivityThread")
            val systemMain = activityThreadClass.getMethod("systemMain")
            val thread = systemMain.invoke(null)
            val getSystemContext = activityThreadClass.getMethod("getSystemContext")
            val context = getSystemContext.invoke(thread) as Context
            println("context ok: package=" + context.packageName)

            val mgr = VhalDirectAccess.manager(context)
            println("--- VhalDirectAccess log ---")
            println(VhalDirectAccess.lastLog)
            println("-----------------------------")
            if (mgr == null) {
                println("VHAL manager (direct path) FAILED: " + (VhalDirectAccess.lastError ?: "unknown reason"))
                println("== done (no properties tested) ==")
                return
            }
            println("VHAL manager (direct path) OK: " + mgr.javaClass.name)

            probe("DOME_LIGHT (interior light)", mgr, 0x21402069, 0x0)
            probe("MIRROR_FOLD", mgr, 0x21402023, 0x0)

            println("== done ==")
        } catch (e: Throwable) {
            println("FATAL: " + e.javaClass.name + ": " + e.message)
        } finally {
            System.out.flush()
            Runtime.getRuntime().halt(0)
        }
    }

    private fun probe(label: String, mgr: Any, propId: Int, area: Int) {
        println("--- $label (prop=0x${propId.toString(16)} area=0x${area.toString(16)}) ---")
        // The property id's own type bits (bits 0x00ff0000) say this is INT32, not BOOLEAN - the
        // earlier run of this probe used setBooleanProperty/getBooleanProperty on an INT32 property,
        // a type mismatch that CarPropertyManager accepted without throwing (ok=true) but which never
        // actually reached the VHAL as a real value change. describeProperty() below prints this car's
        // own declared type/access/areas for the property, straight from its real CarPropertyConfig,
        // so we are no longer going on the id's bit pattern alone.
        println("config:      " + VhalAccess.describeProperty(mgr, propId))
        println("before:      " + VhalAccess.describeValue(mgr, propId, area))
        val on = VhalAccess.setInt(mgr, propId, area, 1)
        println("set int 1 -> ok=${on.ok}  ${on.message}")
        try { Thread.sleep(600) } catch (ignored: InterruptedException) {}
        println("after 1:     " + VhalAccess.describeValue(mgr, propId, area))
        val off = VhalAccess.setInt(mgr, propId, area, 0)
        println("set int 0 -> ok=${off.ok}  ${off.message}")
        try { Thread.sleep(600) } catch (ignored: InterruptedException) {}
        println("after 0:     " + VhalAccess.describeValue(mgr, propId, area))
    }
}
