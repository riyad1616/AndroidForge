# Geely Dashboard — initial Android Forge project

This is a first-stage native Android prototype for a standalone floating dashboard.

## Current prototype
- Android application module, Java, Gradle Android plugin 8.7.3, compile SDK 35.
- Overlay permission flow and foreground service.
- Floating dashboard mock UI based on the supplied visual direction.
- One-finger drag and two-finger pinch resizing.

## Important integration status
This build is NOT yet connected to vehicle controls, vehicle data, or launcher page lifecycle. The APKs supplied by the owner must be reverse-engineered further to identify supported interfaces and permissions. The launcher includes Android Launcher3 / app-widget host code and a `com.geely.gesture.EdgeEventAPI` string reference; this alone does not establish a public extension API. Coolray Hub contains a `com.Chouaib.PhoneToGeely.LinkService` reference and native `libgeely.so`, which require deeper interface analysis before safe reuse.

Do not ship this prototype as a production vehicle-control app. It currently draws demonstration cards only. Do not embed the supplied platform signing private key in this source tree or share it in project archives. Use a project-owned signing key for development unless the vehicle owner has verified authorization and exact signing requirements.

## Build
Open this folder in Android Forge / Android Studio using Gradle 8.9 or compatible. No Gradle wrapper is included.


## OneUI visual reference assets (integrated)
The OneUI Widget Pack reference assets are staged under `app/src/main/assets/`:
- `oneui_reference/drawable/`: original compiled Android drawable XML resources (binary AXML).
- `oneui_reference/layout_binary/`: original compiled Android layout XML resources (binary AXML).
- `fonts/`: extracted font files.

These are reference/source assets, not directly loadable Android `res` resources. Binary XML must be decoded/recreated before it can be compiled as this app's resources. The original OneUI widget runtime and Android 12+ requirements are intentionally not included. No OneUI code or runtime dependency has been added.

Vehicle controls, live weather/calendar data, and launcher first-page visibility remain unimplemented and must be integrated against verified Geely APIs. This project is still source-only; no APK was built or tested in this environment.
