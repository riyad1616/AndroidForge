package com.coolray.videowallpaper;

import android.app.Activity;
import android.app.WallpaperManager;
import android.content.ComponentName;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.Gravity;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends Activity {
    private static final int PICK_VIDEO = 42;
    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        LinearLayout layout = new LinearLayout(this);
        layout.setOrientation(LinearLayout.VERTICAL);
        layout.setPadding(28, 32, 28, 24);
        layout.setGravity(Gravity.CENTER_HORIZONTAL);
        TextView title = new TextView(this);
        title.setText("Coolray Video Wallpaper\n\nاختبار خلفية الفيديو");
        title.setTextSize(24);
        title.setGravity(Gravity.CENTER);
        layout.addView(title, new LinearLayout.LayoutParams(-1, -2));
        TextView info = new TextView(this);
        info.setText("\n1) اختر ملف فيديو من الجهاز.\n2) افتح معاينة الخلفية واضغط تعيين خلفية.\n\nملاحظة: نجاح عرض الفيديو خلف الودجات يعتمد على دعم Flyme Auto للخلفيات المتحركة.");
        info.setTextSize(17);
        layout.addView(info, new LinearLayout.LayoutParams(-1, -2));
        Button choose = new Button(this);
        choose.setText("اختيار فيديو");
        layout.addView(choose, new LinearLayout.LayoutParams(-1, -2));
        choose.setOnClickListener(v -> {
            Intent i = new Intent(Intent.ACTION_OPEN_DOCUMENT);
            i.addCategory(Intent.CATEGORY_OPENABLE);
            i.setType("video/*");
            startActivityForResult(i, PICK_VIDEO);
        });
        Button preview = new Button(this);
        preview.setText("فتح معاينة / تعيين الخلفية");
        layout.addView(preview, new LinearLayout.LayoutParams(-1, -2));
        preview.setOnClickListener(v -> {
            try {
                Intent i = new Intent(WallpaperManager.ACTION_CHANGE_LIVE_WALLPAPER);
                i.putExtra(WallpaperManager.EXTRA_LIVE_WALLPAPER_COMPONENT,
                    new ComponentName(this, VideoWallpaperService.class));
                startActivity(i);
            } catch (Exception e) {
                Toast.makeText(this, "Flyme Auto لم يفتح معاينة الخلفية: " + e.getMessage(), Toast.LENGTH_LONG).show();
            }
        });
        setContentView(layout);
    }
    @Override protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == PICK_VIDEO && resultCode == RESULT_OK && data != null) {
            Uri uri = data.getData();
            if (uri != null) {
                getContentResolver().takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION);
                getSharedPreferences("video", MODE_PRIVATE).edit().putString("uri", uri.toString()).apply();
                Toast.makeText(this, "تم اختيار الفيديو. افتح معاينة الخلفية.", Toast.LENGTH_LONG).show();
            }
        }
    }
}
