package com.coolray.videowallpaper;

import android.service.wallpaper.WallpaperService;
import android.view.SurfaceHolder;
import android.media.MediaPlayer;
import android.net.Uri;
import android.content.SharedPreferences;
import android.os.Handler;
import android.os.Looper;
import java.io.IOException;

public class VideoWallpaperService extends WallpaperService {
    @Override public Engine onCreateEngine() { return new VideoEngine(); }

    private class VideoEngine extends Engine {
        private MediaPlayer player;
        private boolean visible;
        private final Handler handler = new Handler(Looper.getMainLooper());
        private final Runnable restart = () -> { if (visible) startVideo(); };
        VideoEngine() { super(); }
        @Override public void onVisibilityChanged(boolean isVisible) {
            visible = isVisible;
            if (isVisible) startVideo(); else releasePlayer();
        }
        @Override public void onSurfaceChanged(SurfaceHolder holder, int format, int width, int height) {
            super.onSurfaceChanged(holder, format, width, height);
            if (visible) startVideo();
        }
        @Override public void onSurfaceDestroyed(SurfaceHolder holder) {
            releasePlayer();
            super.onSurfaceDestroyed(holder);
        }
        private void startVideo() {
            releasePlayer();
            String value = getSharedPreferences("video", MODE_PRIVATE).getString("uri", null);
            if (value == null) return;
            try {
                player = new MediaPlayer();
                player.setDataSource(VideoWallpaperService.this, Uri.parse(value));
                player.setSurface(getSurfaceHolder().getSurface());
                player.setLooping(true);
                player.setVolume(0f, 0f);
                player.setOnPreparedListener(mp -> { if (visible) mp.start(); });
                player.setOnErrorListener((mp, what, extra) -> { releasePlayer(); return true; });
                player.prepareAsync();
            } catch (IOException | IllegalStateException e) { releasePlayer(); }
        }
        private void releasePlayer() {
            handler.removeCallbacks(restart);
            if (player != null) {
                try { if (player.isPlaying()) player.stop(); } catch (Exception ignored) {}
                try { player.reset(); player.release(); } catch (Exception ignored) {}
                player = null;
            }
        }
        @Override public void onDestroy() { releasePlayer(); super.onDestroy(); }
    }
}
