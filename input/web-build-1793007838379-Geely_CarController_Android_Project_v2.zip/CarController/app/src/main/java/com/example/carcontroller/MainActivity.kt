package com.example.carcontroller

import android.Manifest
import android.content.ActivityNotFoundException
import android.content.Context
import android.content.Intent
import android.content.SharedPreferences
import android.content.pm.PackageManager
import android.content.res.ColorStateList
import android.os.Bundle
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.view.HapticFeedbackConstants
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import androidx.core.view.ViewCompat
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import com.google.android.material.button.MaterialButton
import com.google.android.material.dialog.MaterialAlertDialogBuilder
import com.google.android.material.textfield.TextInputEditText
import com.journeyapps.barcodescanner.ScanContract
import com.journeyapps.barcodescanner.ScanOptions
import kotlin.concurrent.thread

class MainActivity : AppCompatActivity() {

    private enum class State { IDLE, BUSY, OK, ERROR }

    private lateinit var prefs: SharedPreferences
    private lateinit var etIp: TextInputEditText
    private lateinit var etPin: TextInputEditText
    private lateinit var tvStatus: TextView
    private lateinit var dotStatus: View
    private lateinit var btnVoice: MaterialButton
    private var recognizer: SpeechRecognizer? = null

    private val micPermission =
        registerForActivityResult(ActivityResultContracts.RequestPermission()) { granted ->
            if (granted) startVoice() else toast(getString(R.string.mic_denied), true)
        }

    // fallback when the phone has no in-app recognition service: the system voice dialog
    private val systemVoice =
        registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { result ->
            if (result.resultCode == RESULT_OK) {
                handleVoice(result.data?.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS).orEmpty())
            }
        }

    // QR scanner (zxing-android-embedded): works offline and without Google Play services
    private val qrScanner =
        registerForActivityResult(ScanContract()) { result ->
            val text = result.contents ?: return@registerForActivityResult // null = user cancelled
            val pairing = PairingLink.parse(text)
            if (pairing == null) toast(getString(R.string.qr_invalid), true) else applyPairing(pairing)
        }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        WindowCompat.setDecorFitsSystemWindows(window, false)
        setContentView(R.layout.activity_main)

        prefs = getSharedPreferences(PREFS, Context.MODE_PRIVATE)
        etIp = findViewById(R.id.etCarIp)
        etPin = findViewById(R.id.etPin)
        tvStatus = findViewById(R.id.tvStatus)
        dotStatus = findViewById(R.id.dotStatus)
        btnVoice = findViewById(R.id.btnVoiceCommand)

        applyInsets()
        sizeHero()
        buildSections()

        etIp.setText(prefs.getString(KEY_IP, "").orEmpty())
        etPin.setText(prefs.getString(KEY_PIN, "").orEmpty())
        setStatus(State.IDLE, getString(R.string.status_disconnected))

        findViewById<MaterialButton>(R.id.btnConnect).setOnClickListener { connectAndTest() }
        findViewById<MaterialButton>(R.id.btnScan).setOnClickListener { scanQr() }
        btnVoice.setOnClickListener { onVoiceClicked() }
        findViewById<MaterialButton>(R.id.btnReboot).setOnClickListener { confirmReboot() }

        if (savedInstanceState == null) {
            if (!handlePairingIntent(intent)) autoPing()
        }
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        setIntent(intent)
        handlePairingIntent(intent)
    }

    override fun onDestroy() {
        super.onDestroy()
        recognizer?.destroy()
        recognizer = null
    }

    // ------------------------------------------------------------------ layout helpers

    /** Edge-to-edge: the Coolray photo goes behind the status bar; pad the content instead. */
    private fun applyInsets() {
        val topBar = findViewById<View>(R.id.topBar)
        val scroll = findViewById<View>(R.id.scroll)
        val topPad = topBar.paddingTop
        val bottomPad = scroll.paddingBottom
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.root)) { _, insets ->
            val bars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            topBar.setPadding(topBar.paddingLeft, topPad + bars.top, topBar.paddingRight, topBar.paddingBottom)
            scroll.setPadding(scroll.paddingLeft, scroll.paddingTop, scroll.paddingRight, bottomPad + bars.bottom)
            insets
        }
    }

    /** The photo is 4:3 and as wide as the screen; leave room so the car is visible above the cards. */
    private fun sizeHero() {
        val dm = resources.displayMetrics
        val imageHeight = dm.widthPixels * 3f / 4f
        // in landscape the photo would be taller than the screen: never push the cards below the fold
        val wanted = minOf(imageHeight * 0.74f - 64f * dm.density, dm.heightPixels * 0.30f)
        val px = wanted.toInt().coerceAtLeast((16 * dm.density).toInt())
        val spacer = findViewById<View>(R.id.heroSpace)
        val lp = spacer.layoutParams
        lp.height = px
        spacer.layoutParams = lp
    }

    private fun buildSections() {
        val container = findViewById<LinearLayout>(R.id.sectionsContainer)
        val inflater = LayoutInflater.from(this)
        for (section in Controls.sections) {
            val card = inflater.inflate(R.layout.item_section, container, false)
            card.findViewById<ImageView>(R.id.ivSectionIcon).setImageResource(section.icon)
            card.findViewById<TextView>(R.id.tvSectionTitle).setText(section.title)
            val rows = card.findViewById<LinearLayout>(R.id.rowsContainer)
            for (control in section.items) rows.addView(buildRow(inflater, rows, control))
            container.addView(card)
        }
    }

    private fun buildRow(inflater: LayoutInflater, parent: ViewGroup, c: Control): View {
        val row = inflater.inflate(R.layout.item_control_row, parent, false)
        row.findViewById<ImageView>(R.id.ivIcon).setImageResource(c.icon)
        row.findViewById<TextView>(R.id.tvLabel).setText(c.label)

        val btnA = row.findViewById<MaterialButton>(R.id.btnA)
        btnA.setText(c.aLabel)
        btnA.setOnClickListener { v ->
            v.performHapticFeedback(HapticFeedbackConstants.VIRTUAL_KEY)
            send(c.aCmd, getString(c.label) + " · " + getString(c.aLabel))
        }

        val btnB = row.findViewById<MaterialButton>(R.id.btnB)
        val bLabel = c.bLabel
        val bCmd = c.bCmd
        if (bLabel != null && bCmd != null) {
            btnB.setText(bLabel)
            btnB.setOnClickListener { v ->
                v.performHapticFeedback(HapticFeedbackConstants.VIRTUAL_KEY)
                send(bCmd, getString(c.label) + " · " + getString(bLabel))
            }
        } else {
            btnB.visibility = View.GONE
        }
        return row
    }

    // ------------------------------------------------------------------ status + messages

    private fun setStatus(state: State, text: String) {
        tvStatus.text = text
        val colorRes = when (state) {
            State.IDLE -> R.color.idle
            State.BUSY -> R.color.warning
            State.OK -> R.color.success
            State.ERROR -> R.color.danger
        }
        dotStatus.backgroundTintList = ColorStateList.valueOf(ContextCompat.getColor(this, colorRes))
    }

    private fun toast(message: String, long: Boolean = false) {
        Toast.makeText(this, message, if (long) Toast.LENGTH_LONG else Toast.LENGTH_SHORT).show()
    }

    private fun describe(r: CarClient.Result): String = getString(
        when (r.code) {
            CarClient.Code.OK -> R.string.res_connected
            CarClient.Code.AUTH -> R.string.res_auth
            CarClient.Code.LOCKED -> R.string.res_locked
            CarClient.Code.UNKNOWN -> R.string.res_unknown
            CarClient.Code.EXEC -> R.string.res_exec
            CarClient.Code.FORMAT -> R.string.res_format
            CarClient.Code.UNREACHABLE -> R.string.res_unreachable
            CarClient.Code.TIMEOUT -> R.string.res_timeout
            CarClient.Code.BAD_IP -> R.string.res_bad_ip
            CarClient.Code.NO_REPLY -> R.string.res_no_reply
            CarClient.Code.IO -> R.string.res_io
        }
    )

    private fun showResult(r: CarClient.Result, label: String) {
        if (r.ok) {
            setStatus(State.OK, getString(R.string.res_ok, label))
            return
        }
        val message = describe(r)
        setStatus(State.ERROR, message)
        val full = if (r.code == CarClient.Code.EXEC && r.detail.isNotEmpty()) message + "\n" + r.detail else message
        toast(full, true)
    }

    // ------------------------------------------------------------------ saved connection

    private fun currentIp() = etIp.text?.toString()?.trim().orEmpty()
    private fun currentPin() = etPin.text?.toString()?.trim().orEmpty()
    private fun save(ip: String, pin: String) {
        prefs.edit().putString(KEY_IP, ip).putString(KEY_PIN, pin).apply()
    }

    /** @return true when ip and pin are present, otherwise shows what is missing. */
    private fun requireConnection(): Boolean {
        if (currentIp().isEmpty()) {
            toast(getString(R.string.msg_need_ip), true)
            return false
        }
        if (currentPin().isEmpty()) {
            toast(getString(R.string.msg_need_pin), true)
            return false
        }
        return true
    }

    // ------------------------------------------------------------------ talking to the car

    private fun send(cmd: String, label: String) {
        if (!requireConnection()) return
        val ip = currentIp()
        val pin = currentPin()
        save(ip, pin)
        setStatus(State.BUSY, getString(R.string.status_sending))
        thread {
            val result = CarClient(ip, pin).send(cmd)
            runOnUiThread {
                if (!isFinishing && !isDestroyed) showResult(result, label)
            }
        }
    }

    private fun connectAndTest() {
        if (!requireConnection()) return
        val ip = currentIp()
        val pin = currentPin()
        save(ip, pin)
        setStatus(State.BUSY, getString(R.string.status_sending))
        thread {
            val result = CarClient(ip, pin).ping()
            runOnUiThread {
                if (isFinishing || isDestroyed) return@runOnUiThread
                if (result.ok) {
                    setStatus(State.OK, getString(R.string.status_connected))
                    toast(getString(R.string.res_connected))
                } else {
                    showResult(result, "")
                }
            }
        }
    }

    /** Silent check at start-up so the chip shows the real state. */
    private fun autoPing() {
        val ip = currentIp()
        val pin = currentPin()
        if (ip.isEmpty() || pin.isEmpty()) return
        thread {
            val ok = CarClient(ip, pin).ping().ok
            runOnUiThread {
                if (ok && !isFinishing && !isDestroyed) setStatus(State.OK, getString(R.string.status_connected))
            }
        }
    }

    private fun confirmReboot() {
        MaterialAlertDialogBuilder(this)
            .setTitle(R.string.reboot_title)
            .setMessage(R.string.reboot_msg)
            .setPositiveButton(R.string.reboot_yes) { _, _ -> send(Cmd.REBOOT, getString(R.string.btn_reboot)) }
            .setNegativeButton(R.string.cancel, null)
            .show()
    }

    // ------------------------------------------------------------------ QR pairing

    private fun scanQr() {
        val options = ScanOptions()
            .setDesiredBarcodeFormats(ScanOptions.QR_CODE)
            .setPrompt(getString(R.string.qr_prompt))
            .setBeepEnabled(false)
            .setOrientationLocked(false)
        try {
            qrScanner.launch(options)
        } catch (e: ActivityNotFoundException) {
            toast(getString(R.string.qr_scan_failed), true)
        }
    }

    /** The QR can also be scanned with the phone camera: geelycar://pair?... opens this app. */
    private fun handlePairingIntent(i: Intent?): Boolean {
        if (i == null || i.action != Intent.ACTION_VIEW) return false
        val data = i.data ?: return false
        if (!PairingLink.SCHEME.equals(data.scheme, ignoreCase = true)) return false
        val pairing = PairingLink.parse(data.toString())
        if (pairing == null) {
            toast(getString(R.string.qr_invalid), true)
            return true
        }
        MaterialAlertDialogBuilder(this)
            .setTitle(R.string.pair_dialog_title)
            .setMessage(getString(R.string.pair_dialog_msg, pairing.ips.first()))
            .setPositiveButton(R.string.pair_yes) { _, _ -> applyPairing(pairing) }
            .setNegativeButton(R.string.cancel, null)
            .show()
        return true
    }

    /** Tries every IP from the QR, keeps the first one that answers the authenticated PING. */
    private fun applyPairing(p: PairingLink.Data) {
        setStatus(State.BUSY, getString(R.string.status_sending))
        thread {
            var reachable: String? = null
            for (ip in p.ips) {
                if (CarClient(ip, p.pin).ping().ok) {
                    reachable = ip
                    break
                }
            }
            val chosen = reachable ?: p.ips.first()
            runOnUiThread {
                if (isFinishing || isDestroyed) return@runOnUiThread
                etIp.setText(chosen)
                etPin.setText(p.pin)
                save(chosen, p.pin)
                if (reachable != null) {
                    setStatus(State.OK, getString(R.string.status_connected))
                    toast(getString(R.string.qr_paired, chosen))
                } else {
                    setStatus(State.ERROR, getString(R.string.res_unreachable))
                    toast(getString(R.string.qr_paired_unverified), true)
                }
            }
        }
    }

    // ------------------------------------------------------------------ voice

    private fun onVoiceClicked() {
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.RECORD_AUDIO)
            != PackageManager.PERMISSION_GRANTED
        ) {
            micPermission.launch(Manifest.permission.RECORD_AUDIO)
            return
        }
        startVoice()
    }

    private fun recognizerIntent(): Intent =
        Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            putExtra(RecognizerIntent.EXTRA_LANGUAGE, "ar-SA")
            putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 5)
        }

    private fun startVoice() {
        if (SpeechRecognizer.isRecognitionAvailable(this)) {
            val sr = recognizer ?: SpeechRecognizer.createSpeechRecognizer(this).also {
                it.setRecognitionListener(listener)
                recognizer = it
            }
            sr.startListening(recognizerIntent())
        } else {
            try {
                systemVoice.launch(recognizerIntent())
            } catch (e: ActivityNotFoundException) {
                toast(getString(R.string.voice_unavailable), true)
            }
        }
    }

    private fun setListening(on: Boolean) {
        btnVoice.setText(if (on) R.string.voice_listening else R.string.btn_voice)
    }

    /** Tries every alternative the recogniser returned until one matches a command. */
    private fun handleVoice(texts: List<String>) {
        for (text in texts) {
            val cmd = VoiceCommandParser.parse(text) ?: continue
            toast(getString(R.string.voice_heard, text))
            send(cmd, text)
            return
        }
        toast(
            if (texts.isEmpty()) getString(R.string.voice_no_match)
            else getString(R.string.voice_unknown, texts.first()),
            true
        )
    }

    private val listener = object : RecognitionListener {
        override fun onReadyForSpeech(params: Bundle?) {
            setListening(true)
        }

        override fun onBeginningOfSpeech() {}
        override fun onRmsChanged(rmsdB: Float) {}
        override fun onBufferReceived(buffer: ByteArray?) {}
        override fun onEndOfSpeech() {
            setListening(false)
        }

        override fun onError(error: Int) {
            setListening(false)
            when (error) {
                SpeechRecognizer.ERROR_NO_MATCH,
                SpeechRecognizer.ERROR_SPEECH_TIMEOUT -> toast(getString(R.string.voice_no_match))

                SpeechRecognizer.ERROR_INSUFFICIENT_PERMISSIONS -> toast(getString(R.string.mic_denied), true)
                else -> toast(getString(R.string.voice_error, error), true)
            }
        }

        override fun onResults(results: Bundle) {
            setListening(false)
            handleVoice(results.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION).orEmpty())
        }

        override fun onPartialResults(partialResults: Bundle?) {}
        override fun onEvent(eventType: Int, params: Bundle?) {}
    }

    companion object {
        private const val PREFS = "CarConfig"
        private const val KEY_IP = "CAR_IP"
        private const val KEY_PIN = "CAR_PIN"
    }
}
