package com.example.carcontroller

import androidx.annotation.DrawableRes
import androidx.annotation.StringRes

/** One row in the UI: icon, label and one or two buttons. */
data class Control(
    @DrawableRes val icon: Int,
    @StringRes val label: Int,
    @StringRes val aLabel: Int,
    val aCmd: String,
    @StringRes val bLabel: Int? = null,
    val bCmd: String? = null
)

data class Section(
    @DrawableRes val icon: Int,
    @StringRes val title: Int,
    val items: List<Control>
)

/** All buttons of the app. Command names are the same as in the original project. */
object Controls {
    val sections: List<Section> = listOf(
        Section(
            R.drawable.ic_car, R.string.sec_body, listOf(
                Control(R.drawable.ic_window, R.string.lbl_windows, R.string.act_open, Cmd.WINDOW_OPEN, R.string.act_close, Cmd.WINDOW_CLOSE),
                Control(R.drawable.ic_sunroof, R.string.lbl_sunroof, R.string.act_open, Cmd.SUNROOF_OPEN, R.string.act_close, Cmd.SUNROOF_CLOSE),
                Control(R.drawable.ic_mirror, R.string.lbl_mirrors, R.string.act_open, Cmd.MIRROR_UNFOLD, R.string.act_fold, Cmd.MIRROR_FOLD)
            )
        ),
        Section(
            R.drawable.ic_ac, R.string.sec_climate, listOf(
                Control(R.drawable.ic_ac, R.string.lbl_ac, R.string.act_on, Cmd.AC_ON, R.string.act_off, Cmd.AC_OFF),
                Control(R.drawable.ic_seat_heat, R.string.lbl_seat_heat, R.string.act_on, Cmd.SEAT_HEAT_ON, R.string.act_off, Cmd.SEAT_HEAT_OFF)
            )
        ),
        Section(
            R.drawable.ic_headlight, R.string.sec_lights, listOf(
                Control(R.drawable.ic_headlight, R.string.lbl_headlights, R.string.act_on, Cmd.HEADLIGHTS_ON, R.string.act_lights_off, Cmd.HEADLIGHTS_OFF),
                Control(R.drawable.ic_highbeam, R.string.lbl_highbeam, R.string.act_on, Cmd.HIGHBEAM_ON, R.string.act_lights_off, Cmd.HIGHBEAM_OFF),
                Control(R.drawable.ic_interior, R.string.lbl_interior, R.string.act_on, Cmd.INTERIOR_ON, R.string.act_lights_off, Cmd.INTERIOR_OFF),
                Control(R.drawable.ic_fog, R.string.lbl_fog, R.string.act_on, Cmd.FOG_ON, R.string.act_lights_off, Cmd.FOG_OFF),
                Control(R.drawable.ic_hazard, R.string.lbl_hazard, R.string.act_on, Cmd.HAZARD_ON, R.string.act_off, Cmd.HAZARD_OFF)
            )
        ),
        Section(
            R.drawable.ic_lock, R.string.sec_security, listOf(
                Control(R.drawable.ic_lock, R.string.lbl_doors, R.string.act_open, Cmd.DOOR_UNLOCK, R.string.act_lock, Cmd.DOOR_LOCK),
                Control(R.drawable.ic_car, R.string.lbl_trunk, R.string.act_open, Cmd.TRUNK_OPEN, R.string.act_close, Cmd.TRUNK_CLOSE)
            )
        ),
        Section(
            R.drawable.ic_horn, R.string.sec_sound, listOf(
                Control(R.drawable.ic_horn, R.string.lbl_horn, R.string.act_horn, Cmd.HORN),
                Control(R.drawable.ic_radio, R.string.lbl_radio, R.string.act_on, Cmd.RADIO_ON, R.string.act_off, Cmd.RADIO_OFF)
            )
        )
    )
}
