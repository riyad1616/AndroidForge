package com.example.carcontroller

/**
 * Turns recognised Arabic speech into a car command.
 *
 * Pure Kotlin (no Android imports) so it can be unit-tested on a plain JVM.
 *
 * Why this replaces the old `when { contains(...) }` chain: in the original code the "ON" phrase of a
 * pair was tested before the "OFF" phrase, and the OFF phrase *contains* the ON phrase
 * ("اطفاء الضوء العالي" contains "الضوء العالي"), so turning something off actually turned it on
 * (high beam, fog, hazard, seat heating, interior lights). Here the verb (on/off) and the target
 * (what) are detected separately, and specific targets are tested before generic ones.
 */
object VoiceCommandParser {

    // ---------------------------------------------------------------- normalisation

    /** Lower-case, strip diacritics/tatweel, unify alef/ya/ta-marbuta/hamza forms, drop punctuation. */
    fun normalize(input: String): String {
        val sb = StringBuilder(input.length)
        for (ch in input.lowercase()) {
            when {
                ch in 'ً'..'ٟ' || ch == 'ٰ' || ch == 'ـ' -> Unit // harakat, dagger alef, tatweel
                ch == 'أ' || ch == 'إ' || ch == 'آ' || ch == 'ٱ' -> sb.append('ا')
                ch == 'ى' || ch == 'ئ' -> sb.append('ي')
                ch == 'ة' -> sb.append('ه')
                ch == 'ؤ' -> sb.append('و')
                ch.isLetterOrDigit() || ch == 'ء' -> sb.append(ch)
                else -> sb.append(' ')
            }
        }
        return sb.toString().trim().replace(Regex("\\s+"), " ")
    }

    private fun n(s: String) = normalize(s)

    // ---------------------------------------------------------------- vocabulary

    private val ON_VERBS: Set<String> = listOf(
        "تشغيل", "شغل", "شغلي", "فتح", "افتح", "افتحي", "تفعيل", "فعل", "فعلي", "اوقد", "ايقاد", "فرد", "افرد"
    ).map { n(it) }.toSet()

    private val OFF_VERBS: Set<String> = listOf(
        "اطفاء", "اطفا", "اطفي", "ايقاف", "اوقف", "وقف", "قفل", "اقفل", "اقفال", "غلق", "اغلق", "اغلاق",
        "اغلقي", "اقفلي", "طي", "اطوي", "اطو", "الغاء", "الغي"
    ).map { n(it) }.toSet()

    private val LIGHT_WORDS = listOf(
        "ضوء", "اضواء", "نور", "انوار", "مصابيح", "مصباح", "كشاف", "كشافات", "اضاءه", "لمبه", "لمبات", "فوانيس", "فانوس"
    ).map { n(it) }

    private class Rule(
        /** every group must match; inside a group any entry may match. "=word" means exact token. */
        val groups: List<List<String>>,
        val on: String?,
        val off: String?,
        /** true: the noun alone means "turn on" (e.g. "انوار الضباب"), as in the original app. */
        val defaultOn: Boolean = false,
        /** phrases that force OFF even without an off verb (e.g. "الضوء المنخفض"). */
        val forceOff: List<String> = emptyList(),
        /** single-action rule (horn): never fires when an off verb is present. */
        val single: String? = null
    ) {
        private val g = groups.map { grp -> grp.map { VoiceCommandParser.normalize(it) } }
        private val fo = forceOff.map { VoiceCommandParser.normalize(it) }

        fun matches(text: String, padded: String): Boolean =
            g.all { grp ->
                grp.any { w ->
                    if (w.startsWith("=")) padded.contains(" ${w.substring(1)} ") else text.contains(w)
                }
            }

        fun forcesOff(text: String) = fo.any { text.contains(it) }
    }

    /** Order matters: specific rules first, generic ones last. */
    private val RULES: List<Rule> = listOf(
        Rule(listOf(listOf("نوافذ", "نافذه", "شبابيك", "شباك", "زجاج")), Cmd.WINDOW_OPEN, Cmd.WINDOW_CLOSE),
        Rule(listOf(listOf("سقف", "سنروف", "بانوراما")), Cmd.SUNROOF_OPEN, Cmd.SUNROOF_CLOSE),
        Rule(listOf(listOf("مكيف", "تكييف", "تكيف", "مبرد", "تبريد")), Cmd.AC_ON, Cmd.AC_OFF, defaultOn = true),
        Rule(listOf(listOf("مرايا", "مراه", "مراي")), Cmd.MIRROR_UNFOLD, Cmd.MIRROR_FOLD),
        Rule(
            listOf(
                listOf("مقاعد", "مقعد", "كراسي", "كرسي"),
                listOf("تسخين", "سخن", "تدفي", "دفا", "دفي", "حراره")
            ),
            Cmd.SEAT_HEAT_ON, Cmd.SEAT_HEAT_OFF, defaultOn = true
        ),
        Rule(listOf(listOf("داخل"), LIGHT_WORDS), Cmd.INTERIOR_ON, Cmd.INTERIOR_OFF, defaultOn = true),
        Rule(
            listOf(listOf("عالي", "منخفض", "واطي"), LIGHT_WORDS),
            Cmd.HIGHBEAM_ON, Cmd.HIGHBEAM_OFF, defaultOn = true, forceOff = listOf("منخفض", "واطي")
        ),
        Rule(listOf(listOf("ضباب", "شبوره")), Cmd.FOG_ON, Cmd.FOG_OFF, defaultOn = true),
        Rule(
            listOf(listOf("طواري", "فلاشر", "فلاشرات", "هازرد", "تحذير")),
            Cmd.HAZARD_ON, Cmd.HAZARD_OFF, defaultOn = true
        ),
        Rule(listOf(LIGHT_WORDS), Cmd.HEADLIGHTS_ON, Cmd.HEADLIGHTS_OFF, defaultOn = true),
        Rule(listOf(listOf("صندوق", "شنطه", "حقيبه", "=الخلف")), Cmd.TRUNK_OPEN, Cmd.TRUNK_CLOSE),
        Rule(listOf(listOf("منبه", "بوق", "نفير", "كلاكس", "هورن")), null, null, single = Cmd.HORN),
        Rule(listOf(listOf("راديو", "مذياع", "اذاعه")), Cmd.RADIO_ON, Cmd.RADIO_OFF),
        // doors last: "السيارة" is generic ("شغل مكيف السيارة" must reach the AC rule first)
        Rule(listOf(listOf("باب", "ابواب", "سياره", "عربيه")), Cmd.DOOR_UNLOCK, Cmd.DOOR_LOCK)
    )

    // ---------------------------------------------------------------- parsing

    /** A token is the verb itself or the verb with a one-letter prefix (ب / ل / و). */
    private fun isVerb(token: String, verbs: Set<String>): Boolean {
        if (token in verbs) return true
        if (token.length > 1 && token[0] in "بلو" && token.substring(1) in verbs) return true
        return false
    }

    /** @return a [Cmd] constant, or null when nothing recognisable was said. */
    fun parse(text: String): String? {
        val t = normalize(text)
        if (t.isEmpty()) return null
        val tokens = t.split(' ')
        val padded = " $t "
        val hasOff = tokens.any { isVerb(it, OFF_VERBS) }
        val hasOn = tokens.any { isVerb(it, ON_VERBS) }

        for (rule in RULES) {
            if (!rule.matches(t, padded)) continue
            val off = hasOff || rule.forcesOff(t)
            return when {
                rule.single != null -> if (off) null else rule.single
                off -> rule.off
                hasOn || rule.defaultOn -> rule.on
                else -> null
            }
        }
        return null
    }
}
