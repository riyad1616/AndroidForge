package com.example.carcontroller

/**
 * Command names sent over the socket. They are identical to the original project so the
 * Receiver mapping (and any custom command file on the car) keeps working.
 * Pure Kotlin (no Android imports) so it can be unit-tested on a plain JVM.
 */
object Cmd {
    const val PING = "PING"

    const val WINDOW_OPEN = "CMD_WINDOW_OPEN"
    const val WINDOW_CLOSE = "CMD_WINDOW_CLOSE"
    const val SUNROOF_OPEN = "CMD_SUNROOF_OPEN"
    const val SUNROOF_CLOSE = "CMD_SUNROOF_CLOSE"
    const val AC_ON = "CMD_AC_ON"
    const val AC_OFF = "CMD_AC_OFF"
    const val MIRROR_UNFOLD = "CMD_MIRROR_UNFOLD"
    const val MIRROR_FOLD = "CMD_MIRROR_FOLD"

    const val HEADLIGHTS_ON = "CMD_HEADLIGHTS_ON"
    const val HEADLIGHTS_OFF = "CMD_HEADLIGHTS_OFF"
    const val HIGHBEAM_ON = "CMD_HIGHBEAM_ON"
    const val HIGHBEAM_OFF = "CMD_HIGHBEAM_OFF"
    const val INTERIOR_ON = "CMD_INTERIOR_ON"
    const val INTERIOR_OFF = "CMD_INTERIOR_OFF"
    const val FOG_ON = "CMD_FOG_ON"
    const val FOG_OFF = "CMD_FOG_OFF"

    const val DOOR_UNLOCK = "CMD_DOOR_UNLOCK"
    const val DOOR_LOCK = "CMD_DOOR_LOCK"
    const val TRUNK_OPEN = "CMD_TRUNK_OPEN"
    const val TRUNK_CLOSE = "CMD_TRUNK_CLOSE"

    const val HORN = "CMD_HORN"
    const val RADIO_ON = "CMD_RADIO_ON"
    const val RADIO_OFF = "CMD_RADIO_OFF"

    const val SEAT_HEAT_ON = "CMD_SEAT_HEAT_ON"
    const val SEAT_HEAT_OFF = "CMD_SEAT_HEAT_OFF"
    const val HAZARD_ON = "CMD_HAZARD_ON"
    const val HAZARD_OFF = "CMD_HAZARD_OFF"

    const val REBOOT = "CMD_REBOOT"
}
