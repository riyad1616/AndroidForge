package com.coolray.vradiofavorites;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.RectF;
import android.media.browse.MediaBrowser;
import android.os.Handler;
import android.os.Looper;
import android.util.AttributeSet;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewConfiguration;

import java.util.ArrayList;
import java.util.List;

/**
 * Floating bar matching original Favoris VRadio look:
 * [logo x10] [stop] [status / wave]
 * Long-press anywhere to drag the window.
 */
public class RadioBarView extends View {
    public static final int MAX = 10;

    public interface Listener {
        void onStation(int index);
        void onStop();
        void onThemeCycle();
        void onDrag(float dx, float dy);
        void onDragEnd();
    }

    private final Paint paint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final RectF tmp = new RectF();
    private final List<MediaBrowser.MediaItem> stations = new ArrayList<>();
    private final Bitmap[] logos = new Bitmap[MAX];
    private final String[] titles = new String[MAX];
    private String status = "ARRET";
    private boolean playing;
    private int themeIndex;
    private Listener listener;

    private final Handler handler = new Handler(Looper.getMainLooper());
    private boolean dragging;
    private boolean longPressArmed;
    private float downX, downY, lastX, lastY;
    private final int touchSlop;
    private final Runnable longPress = () -> {
        longPressArmed = false;
        dragging = true;
        if (listener != null) listener.onDrag(0, 0);
    };

    public RadioBarView(Context c) {
        super(c);
        touchSlop = ViewConfiguration.get(c).getScaledTouchSlop();
    }
    public RadioBarView(Context c, AttributeSet a) {
        super(c, a);
        touchSlop = ViewConfiguration.get(c).getScaledTouchSlop();
    }

    public void setListener(Listener l) { listener = l; }

    public void setThemeIndex(int i) {
        themeIndex = ((i % ThemeColors.ALL.length) + ThemeColors.ALL.length) % ThemeColors.ALL.length;
        invalidate();
    }
    public int getThemeIndex() { return themeIndex; }
    public void nextTheme() { setThemeIndex(themeIndex + 1); }

    public void setStations(List<MediaBrowser.MediaItem> list, Bitmap[] logosIn, String[] names) {
        stations.clear();
        if (list != null) stations.addAll(list);
        for (int i = 0; i < MAX; i++) {
            logos[i] = (logosIn != null && i < logosIn.length) ? logosIn[i] : null;
            titles[i] = (names != null && i < names.length) ? names[i] : null;
        }
        invalidate();
    }

    public void setStatus(String s, boolean play) {
        status = s != null ? s : "ARRET";
        playing = play;
        invalidate();
    }

    @Override
    protected void onDraw(Canvas canvas) {
        float w = getWidth();
        float h = getHeight();
        if (w < 4 || h < 4) return;
        ThemeColors th = ThemeColors.ALL[themeIndex];

        // Background like original (dark rounded bar)
        paint.setStyle(Paint.Style.FILL);
        paint.setColor(th.bg);
        tmp.set(0, 0, w, h);
        float radius = h * 0.32f;
        canvas.drawRoundRect(tmp, radius, radius, paint);

        // Cyan border like original widget
        paint.setStyle(Paint.Style.STROKE);
        paint.setStrokeWidth(Math.max(2f, h * 0.035f));
        paint.setColor(th.accent);
        canvas.drawRoundRect(tmp, radius, radius, paint);

        float pad = h * 0.10f;
        float tile = h - pad * 2f;
        float gap = tile * 0.18f;
        float x = pad;

        // 10 station tiles
        for (int i = 0; i < MAX; i++) {
            drawTile(canvas, th, x, pad, tile, i);
            x += tile + gap;
        }

        x += gap * 0.5f;

        // Stop circle (original style)
        float stopR = tile * 0.48f;
        float stopCx = x + stopR;
        float stopCy = h / 2f;
        paint.setStyle(Paint.Style.FILL);
        paint.setColor(th.tile);
        canvas.drawCircle(stopCx, stopCy, stopR, paint);
        paint.setStyle(Paint.Style.STROKE);
        paint.setStrokeWidth(Math.max(2f, h * 0.04f));
        paint.setColor(th.accent);
        canvas.drawCircle(stopCx, stopCy, stopR, paint);
        paint.setStyle(Paint.Style.FILL);
        paint.setColor(Color.WHITE);
        float sq = stopR * 0.55f;
        canvas.drawRect(stopCx - sq / 2f, stopCy - sq / 2f, stopCx + sq / 2f, stopCy + sq / 2f, paint);

        x = stopCx + stopR + gap * 1.2f;

        // Status / visualizer panel
        float statusRight = w - pad;
        if (statusRight > x + 20) {
            paint.setStyle(Paint.Style.FILL);
            paint.setColor(th.tile);
            tmp.set(x, pad, statusRight, h - pad);
            canvas.drawRoundRect(tmp, h * 0.22f, h * 0.22f, paint);
            paint.setStyle(Paint.Style.STROKE);
            paint.setStrokeWidth(Math.max(1.5f, h * 0.03f));
            paint.setColor(th.accent);
            canvas.drawRoundRect(tmp, h * 0.22f, h * 0.22f, paint);

            // Wave lines when playing
            if (playing) {
                int[] cols = {th.accent, th.accent2, Color.rgb(39, 220, 179), Color.rgb(132, 239, 67)};
                float mid = h / 2f;
                long t = System.currentTimeMillis();
                for (int wave = 0; wave < 4; wave++) {
                    paint.setStyle(Paint.Style.STROKE);
                    paint.setStrokeWidth(wave == 0 ? 2.4f : 1.5f);
                    paint.setColor(cols[wave % cols.length]);
                    paint.setAlpha(200);
                    Path path = new Path();
                    boolean first = true;
                    float left = x + 8;
                    float right = statusRight - 8;
                    int steps = 36;
                    for (int i = 0; i < steps; i++) {
                        float px = left + i * (right - left) / (steps - 1f);
                        float amp = (h * 0.16f) * (1f - wave * 0.15f);
                        float py = mid + (float) (Math.sin(i * 0.45 + t / 160.0 + wave) * amp);
                        if (first) { path.moveTo(px, py); first = false; }
                        else path.lineTo(px, py);
                    }
                    canvas.drawPath(path, paint);
                }
                paint.setAlpha(255);
            }

            // Status text
            paint.setStyle(Paint.Style.FILL);
            paint.setColor(th.text);
            float ts = Math.max(13f, h * 0.30f);
            paint.setTextSize(ts);
            paint.setTextAlign(Paint.Align.LEFT);
            paint.setFakeBoldText(true);
            String text = fit(status, paint, statusRight - x - 16);
            canvas.drawText(text, x + 10, h / 2f + ts * 0.35f, paint);
            paint.setFakeBoldText(false);
        }
    }

    private void drawTile(Canvas c, ThemeColors th, float left, float top, float size, int i) {
        // White-ish tile with cyan border like original logos
        paint.setStyle(Paint.Style.FILL);
        paint.setColor(Color.rgb(245, 248, 250));
        tmp.set(left, top, left + size, top + size);
        c.drawRoundRect(tmp, size * 0.22f, size * 0.22f, paint);

        Bitmap logo = logos[i];
        if (logo != null && !logo.isRecycled()) {
            float max = Math.max(size * 0.88f / logo.getWidth(), size * 0.88f / logo.getHeight());
            float bw = logo.getWidth() * max;
            float bh = logo.getHeight() * max;
            float bx = left + (size - bw) / 2f;
            float by = top + (size - bh) / 2f;
            Path clip = new Path();
            clip.addRoundRect(tmp, size * 0.22f, size * 0.22f, Path.Direction.CW);
            c.save();
            c.clipPath(clip);
            c.drawBitmap(logo, null, new RectF(bx, by, bx + bw, by + bh), paint);
            c.restore();
        } else if (titles[i] != null && titles[i].length() > 0) {
            paint.setColor(th.tile);
            c.drawRoundRect(tmp, size * 0.22f, size * 0.22f, paint);
            paint.setColor(th.accent);
            paint.setTextSize(size * 0.22f);
            paint.setTextAlign(Paint.Align.CENTER);
            paint.setFakeBoldText(true);
            String shortT = titles[i].length() > 6 ? titles[i].substring(0, 6) : titles[i];
            c.drawText(shortT, left + size / 2f, top + size * 0.58f, paint);
            paint.setFakeBoldText(false);
        } else {
            paint.setColor(th.tile);
            c.drawRoundRect(tmp, size * 0.22f, size * 0.22f, paint);
            paint.setColor(th.accent);
            paint.setTextSize(size * 0.42f);
            paint.setTextAlign(Paint.Align.CENTER);
            paint.setFakeBoldText(true);
            c.drawText(String.valueOf(i + 1), left + size / 2f, top + size * 0.64f, paint);
            paint.setFakeBoldText(false);
        }

        paint.setStyle(Paint.Style.STROKE);
        paint.setStrokeWidth(Math.max(1.5f, size * 0.04f));
        paint.setColor(th.accent);
        c.drawRoundRect(tmp, size * 0.22f, size * 0.22f, paint);
        paint.setStyle(Paint.Style.FILL);
    }

    private static String fit(String s, Paint p, float maxW) {
        if (s == null) return "ARRET";
        if (p.measureText(s) <= maxW) return s;
        String e = "...";
        int n = p.breakText(s, true, Math.max(0, maxW - p.measureText(e)), null);
        return s.substring(0, Math.max(0, n)).trim() + e;
    }

    @Override
    public boolean onTouchEvent(MotionEvent e) {
        switch (e.getActionMasked()) {
            case MotionEvent.ACTION_DOWN:
                downX = lastX = e.getRawX();
                downY = lastY = e.getRawY();
                dragging = false;
                longPressArmed = true;
                handler.postDelayed(longPress, ViewConfiguration.getLongPressTimeout());
                return true;
            case MotionEvent.ACTION_MOVE:
                float dx = e.getRawX() - lastX;
                float dy = e.getRawY() - lastY;
                if (longPressArmed) {
                    float adx = Math.abs(e.getRawX() - downX);
                    float ady = Math.abs(e.getRawY() - downY);
                    if (adx > touchSlop || ady > touchSlop) {
                        longPressArmed = false;
                        handler.removeCallbacks(longPress);
                    }
                }
                if (dragging && listener != null) {
                    listener.onDrag(dx, dy);
                    lastX = e.getRawX();
                    lastY = e.getRawY();
                }
                return true;
            case MotionEvent.ACTION_UP:
            case MotionEvent.ACTION_CANCEL:
                handler.removeCallbacks(longPress);
                if (dragging) {
                    dragging = false;
                    if (listener != null) listener.onDragEnd();
                    return true;
                }
                if (e.getActionMasked() == MotionEvent.ACTION_UP) {
                    handleTap(e.getX());
                }
                return true;
        }
        return true;
    }

    private void handleTap(float x) {
        if (listener == null) return;
        float h = getHeight();
        float pad = h * 0.10f;
        float tile = h - pad * 2f;
        float gap = tile * 0.18f;
        float cursor = pad;
        for (int i = 0; i < MAX; i++) {
            if (x >= cursor && x <= cursor + tile) {
                listener.onStation(i);
                return;
            }
            cursor += tile + gap;
        }
        cursor += gap * 0.5f;
        float stopR = tile * 0.48f;
        float stopCx = cursor + stopR;
        if (x >= stopCx - stopR && x <= stopCx + stopR) {
            listener.onStop();
            return;
        }
        // status area → theme
        listener.onThemeCycle();
    }
}
