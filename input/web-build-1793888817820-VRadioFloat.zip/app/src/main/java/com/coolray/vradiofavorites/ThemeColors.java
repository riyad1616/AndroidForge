package com.coolray.vradiofavorites;

/** Same palette family as OneHub Float themes. */
public final class ThemeColors {
    public final int bg;
    public final int accent;
    public final int accent2;
    public final int text;
    public final int muted;
    public final int tile;

    public ThemeColors(int bg, int accent, int accent2, int text, int muted, int tile) {
        this.bg = bg; this.accent = accent; this.accent2 = accent2;
        this.text = text; this.muted = muted; this.tile = tile;
    }

    public static final ThemeColors[] ALL = {
        new ThemeColors(0xE00B1419, 0xFF00E5FF, 0xFF0277BD, 0xFFFFFFFF, 0xFF80CBC4, 0xFF173745),
        new ThemeColors(0xE01A0A0A, 0xFFFF1744, 0xFFFF9100, 0xFFFFFFFF, 0xFFFFAB91, 0xFF3E1A1A),
        new ThemeColors(0xE00A1A12, 0xFF00E676, 0xFF00C853, 0xFFFFFFFF, 0xFFA5D6A7, 0xFF143D28),
        new ThemeColors(0xE0120A1A, 0xFFD500F9, 0xFFAA00FF, 0xFFFFFFFF, 0xFFE1BEE7, 0xFF2A1540),
        new ThemeColors(0xE01A1408, 0xFFFFAB00, 0xFFFF6D00, 0xFFFFFFFF, 0xFFFFE082, 0xFF3D3010),
        new ThemeColors(0xE00A1020, 0xFF448AFF, 0xFF2962FF, 0xFFFFFFFF, 0xFF90CAF9, 0xFF152A4A),
        new ThemeColors(0xE0181818, 0xFFFFFFFF, 0xFFB0BEC5, 0xFF111111, 0xFF90A4AE, 0xFF424242),
        new ThemeColors(0xE00E1A1A, 0xFF1DE9B6, 0xFF00BFA5, 0xFFFFFFFF, 0xFF80CBC4, 0xFF0F3D3A),
    };
}
