package com.coolray.vradiofavorites;

import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.media.MediaMetadata;
import android.media.browse.MediaBrowser;
import android.media.session.MediaController;
import android.media.session.PlaybackState;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;

import java.util.ArrayList;
import java.util.List;

final class RadioClient {
    static final ComponentName SERVICE =
            new ComponentName("com.ilv.vradio", "com.ilv.vradio.AutoBrowserService");
    static final int MAX = 10;

    private MediaBrowser browser;
    private MediaController controller;
    private Context appCtx;
    private final Handler main = new Handler(Looper.getMainLooper());

    interface Callback {
        void favorites(List<MediaBrowser.MediaItem> list);
        void error(String msg);
    }

    interface StatusCallback {
        void status(String text, boolean playing);
    }

    static void startBackground(Context context) {
        try {
            Intent intent = new Intent("android.media.browse.MediaBrowserService");
            intent.setComponent(SERVICE);
            context.startService(intent);
        } catch (Exception ignored) {}
        try {
            Intent launch = context.getPackageManager().getLaunchIntentForPackage("com.ilv.vradio");
            // don't auto-open UI, just ensure package exists
        } catch (Exception ignored) {}
    }

    static void open(Context context) {
        try {
            Intent i = context.getPackageManager().getLaunchIntentForPackage("com.ilv.vradio");
            if (i != null) {
                i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                context.startActivity(i);
            }
        } catch (Exception ignored) {}
    }

    void load(Context context, final Callback callback) {
        appCtx = context.getApplicationContext();
        startBackground(appCtx);
        close();
        main.post(() -> connectAndSubscribe(callback, 0));
    }

    private void connectAndSubscribe(final Callback callback, final int attempt) {
        if (attempt > 5) {
            callback.error("VRadio non connecté");
            return;
        }
        try {
            browser = new MediaBrowser(appCtx, SERVICE, new MediaBrowser.ConnectionCallback() {
                @Override
                public void onConnected() {
                    try {
                        String root = browser.getRoot();
                        // Primary: cFavorites (original)
                        browser.subscribe("cFavorites", new MediaBrowser.SubscriptionCallback() {
                            @Override
                            public void onChildrenLoaded(String parentId, List<MediaBrowser.MediaItem> children) {
                                deliver(callback, children);
                                try { browser.unsubscribe(parentId); } catch (Exception ignored) {}
                            }
                            @Override
                            public void onError(String parentId) {
                                // Fallback: try root
                                trySubscribeRoot(callback);
                            }
                        });
                        // Also try root after short delay if cFavorites empty
                        main.postDelayed(() -> {
                            // keep connection for play/status
                        }, 500);
                    } catch (Exception e) {
                        callback.error("Favoris indisponibles");
                    }
                }

                @Override
                public void onConnectionFailed() {
                    main.postDelayed(() -> connectAndSubscribe(callback, attempt + 1), 1500);
                }

                @Override
                public void onConnectionSuspended() {
                    main.postDelayed(() -> connectAndSubscribe(callback, attempt + 1), 2000);
                }
            }, null);
            browser.connect();
        } catch (Exception e) {
            main.postDelayed(() -> connectAndSubscribe(callback, attempt + 1), 1500);
        }
    }

    private void trySubscribeRoot(final Callback callback) {
        try {
            if (browser == null || !browser.isConnected()) {
                callback.error("Favoris indisponibles");
                return;
            }
            String root = browser.getRoot();
            if (root == null) root = "/";
            browser.subscribe(root, new MediaBrowser.SubscriptionCallback() {
                @Override
                public void onChildrenLoaded(String parentId, List<MediaBrowser.MediaItem> children) {
                    // If root returns folders, look for favorites-like items
                    if (children != null) {
                        for (MediaBrowser.MediaItem item : children) {
                            if (item.isBrowsable()) {
                                final String id = item.getMediaId();
                                if (id != null && (id.toLowerCase().contains("fav")
                                        || "cFavorites".equals(id))) {
                                    browser.subscribe(id, new MediaBrowser.SubscriptionCallback() {
                                        @Override
                                        public void onChildrenLoaded(String p, List<MediaBrowser.MediaItem> list) {
                                            deliver(callback, list);
                                        }
                                        @Override public void onError(String p) {
                                            deliver(callback, children);
                                        }
                                    });
                                    return;
                                }
                            }
                        }
                    }
                    deliver(callback, children);
                }
                @Override public void onError(String parentId) {
                    callback.error("Favoris indisponibles");
                }
            });
        } catch (Exception e) {
            callback.error("Favoris indisponibles");
        }
    }

    private void deliver(Callback callback, List<MediaBrowser.MediaItem> children) {
        List<MediaBrowser.MediaItem> out = new ArrayList<>();
        if (children != null) {
            for (int i = 0; i < children.size() && out.size() < MAX; i++) {
                MediaBrowser.MediaItem it = children.get(i);
                if (it != null && it.isPlayable()) out.add(it);
            }
            // if none playable, take any
            if (out.isEmpty()) {
                for (int i = 0; i < children.size() && out.size() < MAX; i++) {
                    if (children.get(i) != null) out.add(children.get(i));
                }
            }
        }
        callback.favorites(out);
    }

    void play(Context context, MediaBrowser.MediaItem item) {
        if (item == null) return;
        appCtx = context.getApplicationContext();
        startBackground(appCtx);
        final String mid = item.getMediaId();
        if (mid == null) return;
        if (browser != null && browser.isConnected()) {
            doPlay(mid);
            return;
        }
        browser = new MediaBrowser(appCtx, SERVICE, new MediaBrowser.ConnectionCallback() {
            @Override public void onConnected() { doPlay(mid); }
            @Override public void onConnectionFailed() {}
            @Override public void onConnectionSuspended() {}
        }, null);
        try { browser.connect(); } catch (Exception ignored) {}
    }

    private void doPlay(String mediaId) {
        try {
            if (browser == null || !browser.isConnected()) return;
            controller = new MediaController(appCtx, browser.getSessionToken());
            controller.getTransportControls().playFromMediaId(mediaId, new Bundle());
        } catch (Exception ignored) {}
    }

    void stop(Context context) {
        try {
            appCtx = context.getApplicationContext();
            if (controller != null) {
                controller.getTransportControls().stop();
            } else if (browser != null && browser.isConnected()) {
                controller = new MediaController(appCtx, browser.getSessionToken());
                controller.getTransportControls().stop();
            }
        } catch (Exception ignored) {}
    }

    void listenStatus(Context context, final StatusCallback cb) {
        appCtx = context.getApplicationContext();
        startBackground(appCtx);
        close();
        browser = new MediaBrowser(appCtx, SERVICE, new MediaBrowser.ConnectionCallback() {
            @Override
            public void onConnected() {
                try {
                    controller = new MediaController(appCtx, browser.getSessionToken());
                    controller.registerCallback(new MediaController.Callback() {
                        @Override public void onPlaybackStateChanged(PlaybackState state) {
                            emit(cb, state, controller.getMetadata());
                        }
                        @Override public void onMetadataChanged(MediaMetadata metadata) {
                            emit(cb, controller.getPlaybackState(), metadata);
                        }
                    });
                    emit(cb, controller.getPlaybackState(), controller.getMetadata());
                } catch (Exception e) {
                    cb.status("ARRET", false);
                }
            }
            @Override public void onConnectionFailed() {
                cb.status("VRadio non connecté", false);
            }
            @Override public void onConnectionSuspended() {
                cb.status("Connexion interrompue", false);
            }
        }, null);
        try { browser.connect(); } catch (Exception e) {
            cb.status("VRadio non connecté", false);
        }
    }

    private static void emit(StatusCallback cb, PlaybackState state, MediaMetadata md) {
        String str = "ARRET";
        boolean playing = false;
        if (state != null) {
            int s = state.getState();
            if (s == PlaybackState.STATE_PLAYING) {
                str = "LECTURE";
                playing = true;
            } else if (s == PlaybackState.STATE_PAUSED) {
                str = "PAUSE";
            } else if (s == PlaybackState.STATE_BUFFERING || s == PlaybackState.STATE_CONNECTING) {
                str = "CHARGEMENT...";
                playing = true;
            }
        }
        if (md != null && md.getDescription() != null && md.getDescription().getTitle() != null) {
            str = str + " - " + md.getDescription().getTitle();
        }
        cb.status(str, playing);
    }

    void close() {
        try {
            if (browser != null && browser.isConnected()) browser.disconnect();
        } catch (Exception ignored) {}
        browser = null;
        controller = null;
    }

    void disconnect() { close(); }
}
