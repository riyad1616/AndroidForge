package com.geely.carreceiver

import android.content.Context
import java.lang.reflect.InvocationTargetException

/**
 * Talks to this head unit's real Vehicle HAL through android.car - the same framework this car's own
 * launcher and control-center apps use - via reflection only. android.car is not part of the public
 * Android SDK (no compileSdk target ships its classes), so this project cannot import or compile against
 * it directly; at runtime the real classes come from the car's own system image, exactly as they do for
 * every other app on this head unit, so nothing extra needs to be installed for this to work.
 *
 * Going through android.car this way does not bypass Android's permission system by itself, unlike the
 * BROADCAST trick in CommandBackend (which runs inside another app's already-privileged process): most
 * vehicle-body properties need a signature|privileged permission this app does not hold, so a call here
 * can simply fail with SecurityException. That failure, reported back verbatim instead of swallowed, is
 * itself the useful answer: it tells us, property by property, whether this app can ever reach that
 * control directly, or must keep looking for another app's broadcast "free lunch" like the one that
 * already works for the windows and the sunroof.
 */
object VhalAccess {

    @Volatile private var cachedMgr: Any? = null
    @Volatile private var cachedError: String? = null
    private val lock = Any()

    fun lastError(): String? = cachedError

    /** The CarPropertyManager instance (cached after the first successful connect), or null with [lastError] set. */
    fun manager(context: Context): Any? = synchronized(lock) {
        cachedMgr?.let { return it }
        try {
            val carClass = Class.forName("android.car.Car")
            val createCar = carClass.getMethod("createCar", Context::class.java)
            val car = createCar.invoke(null, context.applicationContext)
                ?: throw IllegalStateException("Car.createCar(context) returned null")
            val getCarManager = carClass.getMethod("getCarManager", String::class.java)
            val mgr = getCarManager.invoke(car, "property")
                ?: throw IllegalStateException("getCarManager(\"property\") returned null")
            cachedMgr = mgr
            cachedError = null
            mgr
        } catch (e: InvocationTargetException) {
            cachedError = describe(e.targetException ?: e); null
        } catch (e: Exception) {
            cachedError = describe(e); null
        }
    }

    private fun describe(t: Throwable): String {
        val name = t.javaClass.simpleName
        val msg = t.message
        return if (msg.isNullOrBlank()) name else "$name: $msg"
    }

    private fun tryCall(target: Any, method: String): Any? = try {
        target.javaClass.getMethod(method).invoke(target)
    } catch (e: Exception) {
        null
    }

    /** Raw CarPropertyConfig for a property id, or null if not implemented/not visible to this app -
     *  itself can throw (e.g. SecurityException just to look up the config on some units). */
    private fun configOf(mgr: Any, propertyId: Int): Any? {
        val m = mgr.javaClass.getMethod("getCarPropertyConfig", Int::class.javaPrimitiveType)
        return m.invoke(mgr, propertyId)
    }

    /** One line of metadata for a property id: found/not-found, declared type, access level, area ids.
     *  Never writes anything. */
    fun describeProperty(mgr: Any, propertyId: Int): String = try {
        val config = configOf(mgr, propertyId)
        if (config == null) {
            "NOT FOUND (not implemented on this ECU, or hidden from this app)"
        } else {
            val type = tryCall(config, "getPropertyType") ?: "?"
            val access = tryCall(config, "getAccess") ?: "?"
            val areasRaw = tryCall(config, "getAreaIds")
            val areas = (areasRaw as? IntArray)?.joinToString(",") { "0x" + it.toString(16) } ?: areasRaw?.toString() ?: "?"
            "FOUND type=$type access=$access areas=[$areas]"
        }
    } catch (e: InvocationTargetException) {
        describe(e.targetException ?: e)
    } catch (e: Exception) {
        describe(e)
    }

    /** The area ids this property's own config reports, or null if the config could not be read at all. */
    fun areaIdsOf(mgr: Any, propertyId: Int): IntArray? {
        return try {
            val config = configOf(mgr, propertyId) ?: return null
            tryCall(config, "getAreaIds") as? IntArray
        } catch (e: Exception) {
            null
        }
    }

    /** Best-effort current value for one area: tries the int, then boolean, then float typed getters.
     *  Read-only. */
    fun describeValue(mgr: Any, propertyId: Int, areaId: Int): String {
        val errors = StringBuilder()
        try {
            val m = mgr.javaClass.getMethod("getIntProperty", Int::class.javaPrimitiveType, Int::class.javaPrimitiveType)
            return "int=" + m.invoke(mgr, propertyId, areaId)
        } catch (e: InvocationTargetException) {
            errors.append("int:").append(describe(e.targetException ?: e)).append("  ")
        } catch (e: Exception) {
            errors.append("int:").append(describe(e)).append("  ")
        }
        try {
            val m = mgr.javaClass.getMethod("getBooleanProperty", Int::class.javaPrimitiveType, Int::class.javaPrimitiveType)
            return "bool=" + m.invoke(mgr, propertyId, areaId)
        } catch (e: InvocationTargetException) {
            errors.append("bool:").append(describe(e.targetException ?: e)).append("  ")
        } catch (e: Exception) {
            errors.append("bool:").append(describe(e)).append("  ")
        }
        try {
            val m = mgr.javaClass.getMethod("getFloatProperty", Int::class.javaPrimitiveType, Int::class.javaPrimitiveType)
            return "float=" + m.invoke(mgr, propertyId, areaId)
        } catch (e: InvocationTargetException) {
            errors.append("float:").append(describe(e.targetException ?: e)).append("  ")
        } catch (e: Exception) {
            errors.append("float:").append(describe(e)).append("  ")
        }
        return "unreadable (" + errors.toString().trim() + ")"
    }

    /** The full CarPropertyValue (status + timestamp + value), not just the typed value - used when a
     *  set() call reports ok=true but the value never actually changes, which can mean the VHAL itself
     *  reports the property UNAVAILABLE or ERROR (a status the convenience getIntProperty()/
     *  getBooleanProperty() wrappers used by [describeValue] never surface). */
    fun describeFull(mgr: Any, propertyId: Int, areaId: Int): String = try {
        val m = mgr.javaClass.getMethod(
            "getProperty", Class::class.java, Int::class.javaPrimitiveType, Int::class.javaPrimitiveType
        )
        val value = m.invoke(mgr, Integer::class.java, propertyId, areaId)
            ?: throw IllegalStateException("getProperty(Integer::class, ...) returned null")
        val status = tryCall(value, "getStatus")
        val timestamp = tryCall(value, "getTimestamp")
        val v = tryCall(value, "getValue")
        "status=$status timestamp=$timestamp value=$v"
    } catch (e: InvocationTargetException) {
        describe(e.targetException ?: e)
    } catch (e: Exception) {
        describe(e)
    }

    data class SetOutcome(val ok: Boolean, val message: String)

    fun setInt(mgr: Any, propertyId: Int, areaId: Int, value: Int): SetOutcome = try {
        val m = mgr.javaClass.getMethod(
            "setIntProperty", Int::class.javaPrimitiveType, Int::class.javaPrimitiveType, Int::class.javaPrimitiveType
        )
        m.invoke(mgr, propertyId, areaId, value)
        SetOutcome(true, "set OK: prop=0x${propertyId.toString(16)} area=0x${areaId.toString(16)} value=$value (not confirmed physically)")
    } catch (e: InvocationTargetException) {
        SetOutcome(false, describe(e.targetException ?: e))
    } catch (e: Exception) {
        SetOutcome(false, describe(e))
    }

    fun setBool(mgr: Any, propertyId: Int, areaId: Int, value: Boolean): SetOutcome = try {
        val m = mgr.javaClass.getMethod(
            "setBooleanProperty", Int::class.javaPrimitiveType, Int::class.javaPrimitiveType, Boolean::class.javaPrimitiveType
        )
        m.invoke(mgr, propertyId, areaId, value)
        SetOutcome(true, "set OK: prop=0x${propertyId.toString(16)} area=0x${areaId.toString(16)} value=$value (not confirmed physically)")
    } catch (e: InvocationTargetException) {
        SetOutcome(false, describe(e.targetException ?: e))
    } catch (e: Exception) {
        SetOutcome(false, describe(e))
    }
}
