package com.onehub.floatgauge;

import android.app.AppOpsManager;
import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.app.usage.UsageStats;
import android.app.usage.UsageStatsManager;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.PixelFormat;
import android.os.Build;
import android.os.Handler;
import android.os.IBinder;
import android.os.Looper;
import android.os.Process;
import android.provider.Settings;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.MotionEvent;
import android.view.ScaleGestureDetector;
import android.view.View;
import android.view.WindowManager;
import android.widget.FrameLayout;
import android.widget.Toast;

import androidx.core.app.NotificationCompat;

import java.util.HashSet;
import java.util.List;
import java.util.Set;
import java.util.SortedMap;
import java.util.TreeMap;

public class FloatService extends Service implements CarDataReader.Listener {

    public static final String ACTION_START = "START";
    public static final String ACTION_STOP = "STOP";
    private static final String CH = "float_gauge";
    private static final int NID = 42;
    private static final String PREFS = "onehub_float";
    private static final long LONG_MS = 450;
    private static final long EDIT_MS = 6000;

    private WindowManager wm;
    private View root;
    private View editBar;
    private View btnCloseTop;
    private WindowManager.LayoutParams params;
    private FrameLayout content;
    private SpeedoView speedo;
    private CarDataReader reader;
    private int baseDp = 300;
    private float scaleFactor = 1f;
    private final Handler handler = new Handler(Looper.getMainLooper());

    private boolean editMode;
    private boolean dragging;
    private boolean hiddenForApp;
    private int ix, iy;
    private float downX, downY;
    private float itx, ity;
    private ScaleGestureDetector scaleDetector;
    private final Runnable hideEdit = () -> setEditMode(false);
    private final Runnable pollFg = this::checkForegroundApp;

    @Override
    public IBinder onBind(Intent i) { return null; }

    @Override
    public void onCreate() {
        super.onCreate();
        wm = (WindowManager) getSystemService(WINDOW_SERVICE);
        if (Build.VERSION.SDK_INT >= 26) {
            NotificationChannel c = new NotificationChannel(CH, "OneHub Float", NotificationManager.IMPORTANCE_LOW);
            NotificationManager nm = getSystemService(NotificationManager.class);
            if (nm != null) nm.createNotificationChannel(c);
        }
        scaleDetector = new ScaleGestureDetector(this, new ScaleGestureDetector.SimpleOnScaleGestureListener() {
            @Override
            public boolean onScale(ScaleGestureDetector detector) {
                scaleFactor *= detector.getScaleFactor();
                scaleFactor = Math.max(0.55f, Math.min(1.8f, scaleFactor));
                getSharedPreferences(PREFS, MODE_PRIVATE).edit()
                        .putFloat("pinch", scaleFactor).apply();
                relayout();
                return true;
            }
        });
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        SharedPreferences p = getSharedPreferences(PREFS, MODE_PRIVATE);
        if (intent != null && ACTION_STOP.equals(intent.getAction())) {
            stopAll();
            return START_NOT_STICKY;
        }
        if (root == null) {
            baseDp = p.getInt("size", 300);
            scaleFactor = p.getFloat("pinch", 1f);
            show();
            reader = new CarDataReader(this, this);
            reader.start();
            handler.post(pollFg);
        }
        startForeground(NID, notif());
        return START_STICKY;
    }

    private void show() {
        root = LayoutInflater.from(this).inflate(R.layout.float_root, null);
        content = root.findViewById(R.id.content);
        editBar = root.findViewById(R.id.edit_bar);
        btnCloseTop = root.findViewById(R.id.btn_close_top);
        speedo = new SpeedoView(this);
        SharedPreferences p = getSharedPreferences(PREFS, MODE_PRIVATE);
        speedo.setStyle(p.getInt("style", 0));
        speedo.setThemeIndex(p.getInt("theme", 0));
        content.addView(speedo, new FrameLayout.LayoutParams(
                FrameLayout.LayoutParams.MATCH_PARENT, FrameLayout.LayoutParams.MATCH_PARENT));

        int type = Build.VERSION.SDK_INT >= 26
                ? WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
                : WindowManager.LayoutParams.TYPE_PHONE;

        int[] wh = sizeFor();
        params = new WindowManager.LayoutParams(wh[0], wh[1], type,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE | WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
                PixelFormat.TRANSLUCENT);
        params.gravity = Gravity.TOP | Gravity.START;
        params.x = 40;
        params.y = 80;
        applyContentSize(wh[0], wh[1]);

        root.setOnTouchListener(this::onRootTouch);

        if (btnCloseTop != null) {
            btnCloseTop.setOnClickListener(v -> {
                getSharedPreferences(PREFS, MODE_PRIVATE).edit().putBoolean("on", false).apply();
                stopAll();
            });
        }
        View bt = root.findViewById(R.id.btn_theme);
        if (bt != null) bt.setOnClickListener(v -> { cycleThemeStyle(); bumpEdit(); });
        View bb = root.findViewById(R.id.btn_bigger);
        if (bb != null) bb.setOnClickListener(v -> { resize(+24); bumpEdit(); });
        View bs = root.findViewById(R.id.btn_smaller);
        if (bs != null) bs.setOnClickListener(v -> { resize(-24); bumpEdit(); });
        View bc = root.findViewById(R.id.btn_close);
        if (bc != null) bc.setOnClickListener(v -> {
            getSharedPreferences(PREFS, MODE_PRIVATE).edit().putBoolean("on", false).apply();
            stopAll();
        });

        try {
            wm.addView(root, params);
        } catch (Exception e) {
            Toast.makeText(this, "امنح إذن الظهور فوق التطبيقات", Toast.LENGTH_LONG).show();
            stopSelf();
        }
    }

    private boolean onRootTouch(View v, MotionEvent e) {
        scaleDetector.onTouchEvent(e);
        if (scaleDetector.isInProgress()) {
            handler.removeCallbacksAndMessages(null);
            return true;
        }
        switch (e.getActionMasked()) {
            case MotionEvent.ACTION_DOWN:
                downX = e.getX();
                downY = e.getY();
                itx = e.getRawX();
                ity = e.getRawY();
                ix = params.x;
                iy = params.y;
                dragging = false;
                handler.postDelayed(() -> {
                    setEditMode(true);
                    dragging = true;
                }, LONG_MS);
                return true;
            case MotionEvent.ACTION_MOVE:
                if (dragging || editMode) {
                    handler.removeCallbacks(hideEdit);
                    params.x = ix + (int) (e.getRawX() - itx);
                    params.y = iy + (int) (e.getRawY() - ity);
                    try { wm.updateViewLayout(root, params); } catch (Exception ignored) {}
                    return true;
                }
                if (Math.hypot(e.getRawX() - itx, e.getRawY() - ity) > dp(14)) {
                    handler.removeCallbacksAndMessages(null);
                }
                return true;
            case MotionEvent.ACTION_UP:
            case MotionEvent.ACTION_CANCEL:
                handler.removeCallbacksAndMessages(null);
                if (!dragging && !editMode) handleGaugeTap(downX, downY);
                if (editMode) bumpEdit();
                dragging = false;
                return true;
        }
        return false;
    }

    private void handleGaugeTap(float x, float y) {
        if (speedo == null) return;
        int w = speedo.getWidth();
        int h = speedo.getHeight();
        if (w <= 0 || h <= 0) return;
        if (y < h * 0.76f) return;
        if (x < w * 0.5f) {
            speedo.nextTheme();
            getSharedPreferences(PREFS, MODE_PRIVATE).edit()
                    .putInt("theme", speedo.getThemeIndex()).apply();
        } else {
            speedo.nextStyle();
            getSharedPreferences(PREFS, MODE_PRIVATE).edit()
                    .putInt("style", speedo.getStyle()).apply();
            relayout();
        }
    }

    private void cycleThemeStyle() {
        int next = (speedo.getStyle() + 1) % SpeedoView.STYLE_COUNT;
        speedo.setStyle(next);
        if (next == 0) speedo.nextTheme();
        getSharedPreferences(PREFS, MODE_PRIVATE).edit()
                .putInt("style", speedo.getStyle())
                .putInt("theme", speedo.getThemeIndex())
                .apply();
        relayout();
    }

    private void setEditMode(boolean on) {
        editMode = on;
        if (editBar != null) editBar.setVisibility(on ? View.VISIBLE : View.GONE);
        if (btnCloseTop != null) btnCloseTop.setVisibility(on ? View.VISIBLE : View.GONE);
        relayout();
        if (on) bumpEdit();
    }

    private void bumpEdit() {
        handler.removeCallbacks(hideEdit);
        handler.postDelayed(hideEdit, EDIT_MS);
    }

    private int[] sizeFor() {
        float[] r = SpeedoEngine.f1038r;
        float[] q = SpeedoEngine.f1037q;
        int si = speedo != null ? speedo.getStyle() : 0;
        float scale = (si >= 0 && si < r.length) ? r[si] : 1f;
        float ratio = (si >= 0 && si < q.length) ? q[si] : 1f;
        // Avoid cropping: floor scale and add safety margin
        if (scale < 0.85f) scale = 0.85f;
        if (ratio < 1.0f) ratio = 1.0f;
        // Wide styles (horizontal) need more width
        if (ratio > 1.6f) scale = Math.max(scale, 1.0f);

        int padTop = (editMode) ? dp(36) : dp(4);
        int padBot = (editMode) ? dp(56) : dp(10);
        int bw = Math.round(dp(baseDp) * scale * scaleFactor);
        int bh = Math.round(bw * ratio);
        bw = Math.max(bw, dp(200));
        bh = Math.max(bh, dp(160));
        return new int[]{bw, bh + padTop + padBot};
    }

    private void applyContentSize(int totalW, int totalH) {
        int padTop = (editMode) ? dp(36) : dp(4);
        int padBot = (editMode) ? dp(56) : dp(10);
        FrameLayout.LayoutParams lp = (FrameLayout.LayoutParams) content.getLayoutParams();
        lp.width = totalW;
        lp.height = Math.max(dp(140), totalH - padTop - padBot);
        lp.topMargin = padTop;
        content.setLayoutParams(lp);
    }

    private void relayout() {
        if (params == null || root == null) return;
        int[] wh = sizeFor();
        params.width = wh[0];
        params.height = wh[1];
        applyContentSize(wh[0], wh[1]);
        try { wm.updateViewLayout(root, params); } catch (Exception ignored) {}
    }

    private void resize(int delta) {
        baseDp = Math.max(180, Math.min(480, baseDp + delta));
        getSharedPreferences(PREFS, MODE_PRIVATE).edit().putInt("size", baseDp).apply();
        relayout();
    }

    private Set<String> excludedPackages() {
        String raw = getSharedPreferences(PREFS, MODE_PRIVATE).getString("exclude", "");
        Set<String> set = new HashSet<>();
        if (raw != null && !raw.isEmpty()) {
            for (String s : raw.split(",")) {
                s = s.trim();
                if (!s.isEmpty()) set.add(s);
            }
        }
        return set;
    }

    private boolean hasUsageAccess() {
        try {
            AppOpsManager ops = (AppOpsManager) getSystemService(APP_OPS_SERVICE);
            int mode = ops.checkOpNoThrow(AppOpsManager.OPSTR_GET_USAGE_STATS, Process.myUid(), getPackageName());
            return mode == AppOpsManager.MODE_ALLOWED;
        } catch (Throwable t) {
            return false;
        }
    }

    private String foregroundPackage() {
        if (!hasUsageAccess()) return null;
        try {
            UsageStatsManager usm = (UsageStatsManager) getSystemService(USAGE_STATS_SERVICE);
            long now = System.currentTimeMillis();
            List<UsageStats> stats = usm.queryUsageStats(UsageStatsManager.INTERVAL_DAILY, now - 60_000, now);
            if (stats == null || stats.isEmpty()) return null;
            SortedMap<Long, UsageStats> sorted = new TreeMap<>();
            for (UsageStats u : stats) {
                sorted.put(u.getLastTimeUsed(), u);
            }
            if (sorted.isEmpty()) return null;
            return sorted.get(sorted.lastKey()).getPackageName();
        } catch (Throwable t) {
            return null;
        }
    }

    private void checkForegroundApp() {
        try {
            Set<String> ex = excludedPackages();
            if (!ex.isEmpty()) {
                String fg = foregroundPackage();
                boolean hide = fg != null && ex.contains(fg);
                if (hide != hiddenForApp) {
                    hiddenForApp = hide;
                    if (root != null) {
                        root.setVisibility(hide ? View.GONE : View.VISIBLE);
                    }
                }
            } else if (hiddenForApp) {
                hiddenForApp = false;
                if (root != null) root.setVisibility(View.VISIBLE);
            }
        } catch (Throwable ignored) {
        }
        handler.postDelayed(pollFg, 1500);
    }

    @Override
    public void onData(float speed, int gearIdx, int batt, int fuel, int powerKw, int tempOut, int tempBatt, boolean fromCar) {
        if (speedo != null) {
            speedo.setData(speed, gearIdx, batt, fuel, powerKw, tempOut, tempBatt);
        }
    }

    private void stopAll() {
        handler.removeCallbacksAndMessages(null);
        if (reader != null) { reader.stop(); reader = null; }
        if (root != null) {
            try { wm.removeView(root); } catch (Exception ignored) {}
            root = null;
        }
        stopForeground(true);
        stopSelf();
    }

    private Notification notif() {
        Intent stop = new Intent(this, FloatService.class).setAction(ACTION_STOP);
        PendingIntent pi = PendingIntent.getService(this, 0, stop,
                PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
        Intent open = new Intent(this, MainActivity.class);
        PendingIntent oi = PendingIntent.getActivity(this, 1, open,
                PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
        return new NotificationCompat.Builder(this, CH)
                .setContentTitle("OneHub Float")
                .setContentText("قرص للتكبير · ضغط مطوّل للسحب والإغلاق")
                .setSmallIcon(android.R.drawable.ic_menu_compass)
                .setContentIntent(oi)
                .addAction(0, "إيقاف", pi)
                .setOngoing(true)
                .setPriority(NotificationCompat.PRIORITY_LOW)
                .build();
    }

    private int dp(int v) {
        return Math.round(v * getResources().getDisplayMetrics().density);
    }

    @Override
    public void onDestroy() {
        handler.removeCallbacksAndMessages(null);
        if (reader != null) reader.stop();
        if (root != null) {
            try { wm.removeView(root); } catch (Exception ignored) {}
        }
        super.onDestroy();
    }
}
