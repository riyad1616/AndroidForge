.class public final Lcom/example/carcontroller/R$color;
.super Ljava/lang/Object;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/example/carcontroller/R;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x19
    name = "color"
.end annotation


# static fields
.field public static accent:I = 0x7f050019

.field public static bg_dark:I = 0x7f050022

.field public static danger:I = 0x7f050031

.field public static glass:I = 0x7f050060

.field public static glass_stroke:I = 0x7f050061

.field public static glass_stroke_strong:I = 0x7f050062

.field public static idle:I = 0x7f050065

.field public static input_stroke:I = 0x7f050066

.field public static on_accent:I = 0x7f0502f4

.field public static success:I = 0x7f050303

.field public static text_primary:I = 0x7f05030a

.field public static text_secondary:I = 0x7f05030b

.field public static tonal:I = 0x7f05030c

.field public static warning:I = 0x7f05030f


# direct methods
.method private constructor <init>()V
    .locals 0

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method
