.class public final Lcom/example/carcontroller/R$style;
.super Ljava/lang/Object;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/example/carcontroller/R;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x19
    name = "style"
.end annotation


# static fields
.field public static Geely_Button:I = 0x7f110122

.field public static Geely_Button_Danger:I = 0x7f110123

.field public static Geely_Button_Primary:I = 0x7f110124

.field public static Geely_Button_Tonal:I = 0x7f110125

.field public static Geely_Dialog:I = 0x7f110126

.field public static Geely_Input:I = 0x7f110127

.field public static Theme_CarController:I = 0x7f110227


# direct methods
.method private constructor <init>()V
    .locals 0

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method
