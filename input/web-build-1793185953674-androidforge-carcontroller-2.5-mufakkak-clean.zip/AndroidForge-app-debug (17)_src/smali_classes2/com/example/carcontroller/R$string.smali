.class public final Lcom/example/carcontroller/R$string;
.super Ljava/lang/Object;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/example/carcontroller/R;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x19
    name = "string"
.end annotation


# static fields
.field public static act_close:I = 0x7f10001b

.field public static act_fold:I = 0x7f10001c

.field public static act_horn:I = 0x7f10001d

.field public static act_lights_off:I = 0x7f10001e

.field public static act_lock:I = 0x7f10001f

.field public static act_off:I = 0x7f100020

.field public static act_on:I = 0x7f100021

.field public static act_open:I = 0x7f100022

.field public static app_name:I = 0x7f100024

.field public static btn_connect:I = 0x7f10002d

.field public static btn_reboot:I = 0x7f10002e

.field public static btn_scan:I = 0x7f10002f

.field public static btn_voice:I = 0x7f100030

.field public static cancel:I = 0x7f100038

.field public static conn_help:I = 0x7f10003d

.field public static conn_title:I = 0x7f10003e

.field public static footer:I = 0x7f100045

.field public static hint_ip:I = 0x7f100047

.field public static hint_pin:I = 0x7f100048

.field public static lbl_ac:I = 0x7f10004b

.field public static lbl_doors:I = 0x7f10004c

.field public static lbl_fog:I = 0x7f10004d

.field public static lbl_hazard:I = 0x7f10004e

.field public static lbl_headlights:I = 0x7f10004f

.field public static lbl_highbeam:I = 0x7f100050

.field public static lbl_horn:I = 0x7f100051

.field public static lbl_interior:I = 0x7f100052

.field public static lbl_mirrors:I = 0x7f100053

.field public static lbl_radio:I = 0x7f100054

.field public static lbl_seat_heat:I = 0x7f100055

.field public static lbl_sunroof:I = 0x7f100056

.field public static lbl_trunk:I = 0x7f100057

.field public static lbl_windows:I = 0x7f100058

.field public static mic_denied:I = 0x7f100088

.field public static msg_need_ip:I = 0x7f100089

.field public static msg_need_pin:I = 0x7f10008a

.field public static pair_dialog_msg:I = 0x7f1000c9

.field public static pair_dialog_title:I = 0x7f1000ca

.field public static pair_yes:I = 0x7f1000cb

.field public static qr_invalid:I = 0x7f1000d1

.field public static qr_paired:I = 0x7f1000d2

.field public static qr_paired_unverified:I = 0x7f1000d3

.field public static qr_prompt:I = 0x7f1000d4

.field public static qr_scan_failed:I = 0x7f1000d5

.field public static reboot_msg:I = 0x7f1000d6

.field public static reboot_title:I = 0x7f1000d7

.field public static reboot_yes:I = 0x7f1000d8

.field public static res_auth:I = 0x7f1000d9

.field public static res_bad_ip:I = 0x7f1000da

.field public static res_connected:I = 0x7f1000db

.field public static res_exec:I = 0x7f1000dc

.field public static res_format:I = 0x7f1000dd

.field public static res_io:I = 0x7f1000de

.field public static res_locked:I = 0x7f1000df

.field public static res_no_reply:I = 0x7f1000e0

.field public static res_ok:I = 0x7f1000e1

.field public static res_timeout:I = 0x7f1000e2

.field public static res_unknown:I = 0x7f1000e3

.field public static res_unreachable:I = 0x7f1000e4

.field public static sec_body:I = 0x7f1000e9

.field public static sec_climate:I = 0x7f1000ea

.field public static sec_lights:I = 0x7f1000eb

.field public static sec_security:I = 0x7f1000ec

.field public static sec_sound:I = 0x7f1000ed

.field public static status_connected:I = 0x7f1000f1

.field public static status_disconnected:I = 0x7f1000f2

.field public static status_sending:I = 0x7f1000f3

.field public static subtitle:I = 0x7f1000f4

.field public static title:I = 0x7f1000f5

.field public static voice_error:I = 0x7f1000f6

.field public static voice_heard:I = 0x7f1000f7

.field public static voice_listening:I = 0x7f1000f8

.field public static voice_no_match:I = 0x7f1000f9

.field public static voice_unavailable:I = 0x7f1000fa

.field public static voice_unknown:I = 0x7f1000fb


# direct methods
.method private constructor <init>()V
    .locals 0

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method

.field public static sec_vhal:I = 0x7f100100

.field public static lbl_mirror_l:I = 0x7f100101

.field public static lbl_mirror_r:I = 0x7f100102

.field public static lbl_childlock_l:I = 0x7f100103

.field public static lbl_childlock_r:I = 0x7f100104

.field public static lbl_frunk:I = 0x7f100105

.field public static lbl_glovebox:I = 0x7f100106

.field public static lbl_fuelcap:I = 0x7f100107

.field public static lbl_ambient:I = 0x7f100108

.field public static lbl_display:I = 0x7f100109

.field public static lbl_seat_vent:I = 0x7f10010a

.field public static lbl_vhal:I = 0x7f10010b

.field public static act_unfold:I = 0x7f10010c

.field public static act_list:I = 0x7f10010d

.field public static act_read:I = 0x7f10010e

