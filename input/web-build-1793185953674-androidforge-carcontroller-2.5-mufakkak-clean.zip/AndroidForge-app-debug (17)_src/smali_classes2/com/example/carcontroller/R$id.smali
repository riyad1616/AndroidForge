.class public final Lcom/example/carcontroller/R$id;
.super Ljava/lang/Object;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/example/carcontroller/R;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x19
    name = "id"
.end annotation


# static fields
.field public static btnA:I = 0x7f080062

.field public static btnB:I = 0x7f080063

.field public static btnConnect:I = 0x7f080064

.field public static btnReboot:I = 0x7f080065

.field public static btnScan:I = 0x7f080066

.field public static btnVoiceCommand:I = 0x7f080067

.field public static cardConnection:I = 0x7f08006c

.field public static chipStatus:I = 0x7f080078

.field public static content:I = 0x7f080085

.field public static dotStatus:I = 0x7f0800a5

.field public static etCarIp:I = 0x7f0800bc

.field public static etPin:I = 0x7f0800bd

.field public static heroFrame:I = 0x7f0800db

.field public static heroSpace:I = 0x7f0800dc

.field public static ivBackground:I = 0x7f0800f1

.field public static ivIcon:I = 0x7f0800f2

.field public static ivLogo:I = 0x7f0800f3

.field public static ivSectionIcon:I = 0x7f0800f4

.field public static root:I = 0x7f08017d

.field public static rowsContainer:I = 0x7f080180

.field public static scroll:I = 0x7f080186

.field public static sectionsContainer:I = 0x7f080195

.field public static tilIp:I = 0x7f0801dd

.field public static tilPin:I = 0x7f0801de

.field public static topBar:I = 0x7f0801e5

.field public static tvConnHelp:I = 0x7f0801f0

.field public static tvFooter:I = 0x7f0801f1

.field public static tvLabel:I = 0x7f0801f2

.field public static tvSectionTitle:I = 0x7f0801f3

.field public static tvStatus:I = 0x7f0801f4

.field public static tvSubtitle:I = 0x7f0801f5

.field public static tvTitle:I = 0x7f0801f6


# direct methods
.method private constructor <init>()V
    .locals 0

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method
