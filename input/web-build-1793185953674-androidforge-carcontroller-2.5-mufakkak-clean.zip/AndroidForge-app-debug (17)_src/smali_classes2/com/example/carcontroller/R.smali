.class public final Lcom/example/carcontroller/R;
.super Ljava/lang/Object;


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Lcom/example/carcontroller/R$color;,
        Lcom/example/carcontroller/R$drawable;,
        Lcom/example/carcontroller/R$id;,
        Lcom/example/carcontroller/R$layout;,
        Lcom/example/carcontroller/R$mipmap;,
        Lcom/example/carcontroller/R$string;,
        Lcom/example/carcontroller/R$style;
    }
.end annotation


# direct methods
.method private constructor <init>()V
    .locals 0

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method
