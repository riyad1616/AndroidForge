.class public final Lcom/example/carcontroller/R$drawable;
.super Ljava/lang/Object;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/example/carcontroller/R;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x19
    name = "drawable"
.end annotation


# static fields
.field public static bg_card:I = 0x7f070079

.field public static bg_chip:I = 0x7f07007a

.field public static bg_coolray:I = 0x7f07007b

.field public static bg_dot:I = 0x7f07007c

.field public static bg_scrim:I = 0x7f07007d

.field public static geely_logo:I = 0x7f07008b

.field public static ic_ac:I = 0x7f07008c

.field public static ic_car:I = 0x7f070094

.field public static ic_fog:I = 0x7f070097

.field public static ic_hazard:I = 0x7f070098

.field public static ic_headlight:I = 0x7f070099

.field public static ic_highbeam:I = 0x7f07009a

.field public static ic_horn:I = 0x7f07009b

.field public static ic_interior:I = 0x7f07009c

.field public static ic_key:I = 0x7f07009d

.field public static ic_launcher_bg:I = 0x7f07009f

.field public static ic_launcher_fg:I = 0x7f0700a0

.field public static ic_lock:I = 0x7f0700a1

.field public static ic_mic:I = 0x7f0700a5

.field public static ic_mirror:I = 0x7f0700a6

.field public static ic_power:I = 0x7f0700ab

.field public static ic_qr:I = 0x7f0700ac

.field public static ic_radio:I = 0x7f0700ad

.field public static ic_refresh:I = 0x7f0700ae

.field public static ic_seat_heat:I = 0x7f0700b0

.field public static ic_sunroof:I = 0x7f0700b1

.field public static ic_wifi:I = 0x7f0700b2

.field public static ic_window:I = 0x7f0700b3


# direct methods
.method private constructor <init>()V
    .locals 0

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method
