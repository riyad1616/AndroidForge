.class public final Lcom/google/android/material/R$id;
.super Ljava/lang/Object;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/google/android/material/R;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x19
    name = "id"
.end annotation


# static fields
.field public static BOTTOM_END:I = 0x7f080001

.field public static BOTTOM_START:I = 0x7f080002

.field public static NO_DEBUG:I = 0x7f080006

.field public static SHOW_ALL:I = 0x7f080008

.field public static SHOW_PATH:I = 0x7f080009

.field public static SHOW_PROGRESS:I = 0x7f08000a

.field public static TOP_END:I = 0x7f08000c

.field public static TOP_START:I = 0x7f08000d

.field public static accelerate:I = 0x7f08000e

.field public static accessibility_action_clickable_span:I = 0x7f08000f

.field public static accessibility_custom_action_0:I = 0x7f080010

.field public static accessibility_custom_action_1:I = 0x7f080011

.field public static accessibility_custom_action_10:I = 0x7f080012

.field public static accessibility_custom_action_11:I = 0x7f080013

.field public static accessibility_custom_action_12:I = 0x7f080014

.field public static accessibility_custom_action_13:I = 0x7f080015

.field public static accessibility_custom_action_14:I = 0x7f080016

.field public static accessibility_custom_action_15:I = 0x7f080017

.field public static accessibility_custom_action_16:I = 0x7f080018

.field public static accessibility_custom_action_17:I = 0x7f080019

.field public static accessibility_custom_action_18:I = 0x7f08001a

.field public static accessibility_custom_action_19:I = 0x7f08001b

.field public static accessibility_custom_action_2:I = 0x7f08001c

.field public static accessibility_custom_action_20:I = 0x7f08001d

.field public static accessibility_custom_action_21:I = 0x7f08001e

.field public static accessibility_custom_action_22:I = 0x7f08001f

.field public static accessibility_custom_action_23:I = 0x7f080020

.field public static accessibility_custom_action_24:I = 0x7f080021

.field public static accessibility_custom_action_25:I = 0x7f080022

.field public static accessibility_custom_action_26:I = 0x7f080023

.field public static accessibility_custom_action_27:I = 0x7f080024

.field public static accessibility_custom_action_28:I = 0x7f080025

.field public static accessibility_custom_action_29:I = 0x7f080026

.field public static accessibility_custom_action_3:I = 0x7f080027

.field public static accessibility_custom_action_30:I = 0x7f080028

.field public static accessibility_custom_action_31:I = 0x7f080029

.field public static accessibility_custom_action_4:I = 0x7f08002a

.field public static accessibility_custom_action_5:I = 0x7f08002b

.field public static accessibility_custom_action_6:I = 0x7f08002c

.field public static accessibility_custom_action_7:I = 0x7f08002d

.field public static accessibility_custom_action_8:I = 0x7f08002e

.field public static accessibility_custom_action_9:I = 0x7f08002f

.field public static action_bar:I = 0x7f080033

.field public static action_bar_activity_content:I = 0x7f080034

.field public static action_bar_container:I = 0x7f080035

.field public static action_bar_root:I = 0x7f080036

.field public static action_bar_spinner:I = 0x7f080037

.field public static action_bar_subtitle:I = 0x7f080038

.field public static action_bar_title:I = 0x7f080039

.field public static action_container:I = 0x7f08003a

.field public static action_context_bar:I = 0x7f08003b

.field public static action_divider:I = 0x7f08003c

.field public static action_image:I = 0x7f08003d

.field public static action_menu_divider:I = 0x7f08003e

.field public static action_menu_presenter:I = 0x7f08003f

.field public static action_mode_bar:I = 0x7f080040

.field public static action_mode_bar_stub:I = 0x7f080041

.field public static action_mode_close_button:I = 0x7f080042

.field public static action_text:I = 0x7f080043

.field public static actions:I = 0x7f080044

.field public static activity_chooser_view_content:I = 0x7f080045

.field public static add:I = 0x7f080046

.field public static alertTitle:I = 0x7f080047

.field public static aligned:I = 0x7f080048

.field public static animateToEnd:I = 0x7f08004c

.field public static animateToStart:I = 0x7f08004d

.field public static arc:I = 0x7f080050

.field public static asConfigured:I = 0x7f080051

.field public static async:I = 0x7f080052

.field public static auto:I = 0x7f080053

.field public static autoComplete:I = 0x7f080054

.field public static autoCompleteToEnd:I = 0x7f080055

.field public static autoCompleteToStart:I = 0x7f080056

.field public static baseline:I = 0x7f080058

.field public static blocking:I = 0x7f08005c

.field public static bottom:I = 0x7f08005d

.field public static bounce:I = 0x7f08005e

.field public static buttonPanel:I = 0x7f080068

.field public static cancel_button:I = 0x7f08006b

.field public static center:I = 0x7f08006e

.field public static centerCrop:I = 0x7f08006f

.field public static centerInside:I = 0x7f080070

.field public static chain:I = 0x7f080073

.field public static checkbox:I = 0x7f080076

.field public static checked:I = 0x7f080077

.field public static chronometer:I = 0x7f080079

.field public static circle_center:I = 0x7f08007a

.field public static clear_text:I = 0x7f08007b

.field public static clockwise:I = 0x7f08007e

.field public static compress:I = 0x7f080081

.field public static confirm_button:I = 0x7f080082

.field public static container:I = 0x7f080084

.field public static content:I = 0x7f080085

.field public static contentPanel:I = 0x7f080086

.field public static contiguous:I = 0x7f080087

.field public static coordinator:I = 0x7f080089

.field public static cos:I = 0x7f08008a

.field public static counterclockwise:I = 0x7f08008b

.field public static cradle:I = 0x7f08008c

.field public static custom:I = 0x7f08008e

.field public static customPanel:I = 0x7f08008f

.field public static cut:I = 0x7f080090

.field public static date_picker_actions:I = 0x7f080091

.field public static decelerate:I = 0x7f080092

.field public static decelerateAndComplete:I = 0x7f080093

.field public static decor_content_parent:I = 0x7f080094

.field public static default_activity_button:I = 0x7f080095

.field public static deltaRelative:I = 0x7f080096

.field public static design_bottom_sheet:I = 0x7f080098

.field public static design_menu_item_action_area:I = 0x7f080099

.field public static design_menu_item_action_area_stub:I = 0x7f08009a

.field public static design_menu_item_text:I = 0x7f08009b

.field public static design_navigation_view:I = 0x7f08009c

.field public static dialog_button:I = 0x7f08009d

.field public static disjoint:I = 0x7f0800a4

.field public static dragDown:I = 0x7f0800a8

.field public static dragEnd:I = 0x7f0800a9

.field public static dragLeft:I = 0x7f0800aa

.field public static dragRight:I = 0x7f0800ab

.field public static dragStart:I = 0x7f0800ac

.field public static dragUp:I = 0x7f0800ad

.field public static dropdown_menu:I = 0x7f0800ae

.field public static easeIn:I = 0x7f0800af

.field public static easeInOut:I = 0x7f0800b0

.field public static easeOut:I = 0x7f0800b1

.field public static edge:I = 0x7f0800b3

.field public static edit_query:I = 0x7f0800b4

.field public static elastic:I = 0x7f0800b6

.field public static embed:I = 0x7f0800b7

.field public static end:I = 0x7f0800b8

.field public static endToStart:I = 0x7f0800b9

.field public static expand_activities_button:I = 0x7f0800bf

.field public static expanded_menu:I = 0x7f0800c0

.field public static fade:I = 0x7f0800c1

.field public static fill:I = 0x7f0800c2

.field public static filled:I = 0x7f0800c5

.field public static fitCenter:I = 0x7f0800c6

.field public static fitEnd:I = 0x7f0800c7

.field public static fitStart:I = 0x7f0800c8

.field public static fitXY:I = 0x7f0800ca

.field public static fixed:I = 0x7f0800cb

.field public static flip:I = 0x7f0800cc

.field public static floating:I = 0x7f0800cd

.field public static forever:I = 0x7f0800ce

.field public static fragment_container_view_tag:I = 0x7f0800cf

.field public static fullscreen_header:I = 0x7f0800d1

.field public static ghost_view:I = 0x7f0800d2

.field public static ghost_view_holder:I = 0x7f0800d3

.field public static gone:I = 0x7f0800d4

.field public static group_divider:I = 0x7f0800d7

.field public static header_title:I = 0x7f0800da

.field public static home:I = 0x7f0800df

.field public static honorRequest:I = 0x7f0800e1

.field public static icon:I = 0x7f0800e3

.field public static icon_group:I = 0x7f0800e4

.field public static ignore:I = 0x7f0800e6

.field public static ignoreRequest:I = 0x7f0800e7

.field public static image:I = 0x7f0800e8

.field public static indeterminate:I = 0x7f0800eb

.field public static info:I = 0x7f0800ec

.field public static invisible:I = 0x7f0800ed

.field public static inward:I = 0x7f0800ee

.field public static italic:I = 0x7f0800ef

.field public static item_touch_helper_previous_elevation:I = 0x7f0800f0

.field public static jumpToEnd:I = 0x7f0800f5

.field public static jumpToStart:I = 0x7f0800f6

.field public static labeled:I = 0x7f0800f7

.field public static layout:I = 0x7f0800f8

.field public static left:I = 0x7f0800f9

.field public static leftToRight:I = 0x7f0800fa

.field public static legacy:I = 0x7f0800fb

.field public static line1:I = 0x7f0800fc

.field public static line3:I = 0x7f0800fd

.field public static linear:I = 0x7f0800fe

.field public static listMode:I = 0x7f0800ff

.field public static list_item:I = 0x7f080100

.field public static m3_side_sheet:I = 0x7f080101

.field public static marquee:I = 0x7f080102

.field public static masked:I = 0x7f080103

.field public static match_parent:I = 0x7f080105

.field public static material_clock_display:I = 0x7f080106

.field public static material_clock_display_and_toggle:I = 0x7f080107

.field public static material_clock_face:I = 0x7f080108

.field public static material_clock_hand:I = 0x7f080109

.field public static material_clock_level:I = 0x7f08010a

.field public static material_clock_period_am_button:I = 0x7f08010b

.field public static material_clock_period_pm_button:I = 0x7f08010c

.field public static material_clock_period_toggle:I = 0x7f08010d

.field public static material_hour_text_input:I = 0x7f08010e

.field public static material_hour_tv:I = 0x7f08010f

.field public static material_label:I = 0x7f080110

.field public static material_minute_text_input:I = 0x7f080111

.field public static material_minute_tv:I = 0x7f080112

.field public static material_textinput_timepicker:I = 0x7f080113

.field public static material_timepicker_cancel_button:I = 0x7f080114

.field public static material_timepicker_container:I = 0x7f080115

.field public static material_timepicker_mode_button:I = 0x7f080116

.field public static material_timepicker_ok_button:I = 0x7f080117

.field public static material_timepicker_view:I = 0x7f080118

.field public static material_value_index:I = 0x7f080119

.field public static matrix:I = 0x7f08011a

.field public static message:I = 0x7f08011b

.field public static middle:I = 0x7f08011c

.field public static mini:I = 0x7f08011d

.field public static month_grid:I = 0x7f08011e

.field public static month_navigation_bar:I = 0x7f08011f

.field public static month_navigation_fragment_toggle:I = 0x7f080120

.field public static month_navigation_next:I = 0x7f080121

.field public static month_navigation_previous:I = 0x7f080122

.field public static month_title:I = 0x7f080123

.field public static motion_base:I = 0x7f080124

.field public static mtrl_anchor_parent:I = 0x7f080125

.field public static mtrl_calendar_day_selector_frame:I = 0x7f080126

.field public static mtrl_calendar_days_of_week:I = 0x7f080127

.field public static mtrl_calendar_frame:I = 0x7f080128

.field public static mtrl_calendar_main_pane:I = 0x7f080129

.field public static mtrl_calendar_months:I = 0x7f08012a

.field public static mtrl_calendar_selection_frame:I = 0x7f08012b

.field public static mtrl_calendar_text_input_frame:I = 0x7f08012c

.field public static mtrl_calendar_year_selector_frame:I = 0x7f08012d

.field public static mtrl_card_checked_layer_id:I = 0x7f08012e

.field public static mtrl_child_content_container:I = 0x7f08012f

.field public static mtrl_internal_children_alpha_tag:I = 0x7f080130

.field public static mtrl_motion_snapshot_view:I = 0x7f080131

.field public static mtrl_picker_fullscreen:I = 0x7f080132

.field public static mtrl_picker_header:I = 0x7f080133

.field public static mtrl_picker_header_selection_text:I = 0x7f080134

.field public static mtrl_picker_header_title_and_selection:I = 0x7f080135

.field public static mtrl_picker_header_toggle:I = 0x7f080136

.field public static mtrl_picker_text_input_date:I = 0x7f080137

.field public static mtrl_picker_text_input_range_end:I = 0x7f080138

.field public static mtrl_picker_text_input_range_start:I = 0x7f080139

.field public static mtrl_picker_title_text:I = 0x7f08013a

.field public static mtrl_view_tag_bottom_padding:I = 0x7f08013b

.field public static multiply:I = 0x7f08013c

.field public static navigation_bar_item_active_indicator_view:I = 0x7f08013d

.field public static navigation_bar_item_icon_container:I = 0x7f08013e

.field public static navigation_bar_item_icon_view:I = 0x7f08013f

.field public static navigation_bar_item_labels_group:I = 0x7f080140

.field public static navigation_bar_item_large_label_view:I = 0x7f080141

.field public static navigation_bar_item_small_label_view:I = 0x7f080142

.field public static navigation_header_container:I = 0x7f080143

.field public static none:I = 0x7f080149

.field public static normal:I = 0x7f08014a

.field public static notification_background:I = 0x7f08014c

.field public static notification_main_column:I = 0x7f08014d

.field public static notification_main_column_container:I = 0x7f08014e

.field public static off:I = 0x7f08014f

.field public static on:I = 0x7f080150

.field public static open_search_bar_text_view:I = 0x7f080152

.field public static open_search_view_background:I = 0x7f080153

.field public static open_search_view_clear_button:I = 0x7f080154

.field public static open_search_view_content_container:I = 0x7f080155

.field public static open_search_view_divider:I = 0x7f080156

.field public static open_search_view_dummy_toolbar:I = 0x7f080157

.field public static open_search_view_edit_text:I = 0x7f080158

.field public static open_search_view_header_container:I = 0x7f080159

.field public static open_search_view_root:I = 0x7f08015a

.field public static open_search_view_scrim:I = 0x7f08015b

.field public static open_search_view_search_prefix:I = 0x7f08015c

.field public static open_search_view_status_bar_spacer:I = 0x7f08015d

.field public static open_search_view_toolbar:I = 0x7f08015e

.field public static open_search_view_toolbar_container:I = 0x7f08015f

.field public static outline:I = 0x7f080160

.field public static outward:I = 0x7f080161

.field public static packed:I = 0x7f080163

.field public static parallax:I = 0x7f080164

.field public static parent:I = 0x7f080165

.field public static parentPanel:I = 0x7f080166

.field public static parentRelative:I = 0x7f080167

.field public static parent_matrix:I = 0x7f080168

.field public static password_toggle:I = 0x7f080169

.field public static path:I = 0x7f08016a

.field public static pathRelative:I = 0x7f08016b

.field public static percent:I = 0x7f08016d

.field public static pin:I = 0x7f08016e

.field public static position:I = 0x7f08016f

.field public static postLayout:I = 0x7f080170

.field public static pressed:I = 0x7f080171

.field public static progress_circular:I = 0x7f080172

.field public static progress_horizontal:I = 0x7f080173

.field public static radio:I = 0x7f080174

.field public static rectangles:I = 0x7f080176

.field public static report_drawn:I = 0x7f080177

.field public static reverseSawtooth:I = 0x7f080178

.field public static right:I = 0x7f080179

.field public static rightToLeft:I = 0x7f08017a

.field public static right_icon:I = 0x7f08017b

.field public static right_side:I = 0x7f08017c

.field public static rounded:I = 0x7f08017e

.field public static row_index_key:I = 0x7f08017f

.field public static save_non_transition_alpha:I = 0x7f080181

.field public static save_overlay_view:I = 0x7f080182

.field public static sawtooth:I = 0x7f080183

.field public static scale:I = 0x7f080184

.field public static screen:I = 0x7f080185

.field public static scrollIndicatorDown:I = 0x7f080187

.field public static scrollIndicatorUp:I = 0x7f080188

.field public static scrollView:I = 0x7f080189

.field public static scrollable:I = 0x7f08018a

.field public static search_badge:I = 0x7f08018b

.field public static search_bar:I = 0x7f08018c

.field public static search_button:I = 0x7f08018d

.field public static search_close_btn:I = 0x7f08018e

.field public static search_edit_frame:I = 0x7f08018f

.field public static search_go_btn:I = 0x7f080190

.field public static search_mag_icon:I = 0x7f080191

.field public static search_plate:I = 0x7f080192

.field public static search_src_text:I = 0x7f080193

.field public static search_voice_btn:I = 0x7f080194

.field public static select_dialog_listview:I = 0x7f080196

.field public static selected:I = 0x7f080197

.field public static selection_type:I = 0x7f080198

.field public static shortcut:I = 0x7f08019b

.field public static sin:I = 0x7f08019f

.field public static slide:I = 0x7f0801a2

.field public static snackbar_action:I = 0x7f0801a3

.field public static snackbar_text:I = 0x7f0801a4

.field public static spacer:I = 0x7f0801a8

.field public static special_effects_controller_view_tag:I = 0x7f0801a9

.field public static spline:I = 0x7f0801aa

.field public static split_action_bar:I = 0x7f0801ab

.field public static spread:I = 0x7f0801ac

.field public static spread_inside:I = 0x7f0801ad

.field public static square:I = 0x7f0801af

.field public static src_atop:I = 0x7f0801b0

.field public static src_in:I = 0x7f0801b1

.field public static src_over:I = 0x7f0801b2

.field public static standard:I = 0x7f0801b3

.field public static start:I = 0x7f0801b4

.field public static startHorizontal:I = 0x7f0801b5

.field public static startToEnd:I = 0x7f0801b6

.field public static startVertical:I = 0x7f0801b7

.field public static staticLayout:I = 0x7f0801b8

.field public static staticPostLayout:I = 0x7f0801b9

.field public static stop:I = 0x7f0801ba

.field public static stretch:I = 0x7f0801bb

.field public static submenuarrow:I = 0x7f0801bc

.field public static submit_area:I = 0x7f0801bd

.field public static tabMode:I = 0x7f0801bf

.field public static tag_accessibility_actions:I = 0x7f0801c0

.field public static tag_accessibility_clickable_spans:I = 0x7f0801c1

.field public static tag_accessibility_heading:I = 0x7f0801c2

.field public static tag_accessibility_pane_title:I = 0x7f0801c3

.field public static tag_on_apply_window_listener:I = 0x7f0801c4

.field public static tag_on_receive_content_listener:I = 0x7f0801c5

.field public static tag_on_receive_content_mime_types:I = 0x7f0801c6

.field public static tag_screen_reader_focusable:I = 0x7f0801c7

.field public static tag_state_description:I = 0x7f0801c8

.field public static tag_transition_group:I = 0x7f0801c9

.field public static tag_unhandled_key_event_manager:I = 0x7f0801ca

.field public static tag_unhandled_key_listeners:I = 0x7f0801cb

.field public static tag_window_insets_animation_callback:I = 0x7f0801cc

.field public static text:I = 0x7f0801cd

.field public static text2:I = 0x7f0801ce

.field public static textSpacerNoButtons:I = 0x7f0801d0

.field public static textSpacerNoTitle:I = 0x7f0801d1

.field public static text_input_end_icon:I = 0x7f0801d4

.field public static text_input_error_icon:I = 0x7f0801d5

.field public static text_input_start_icon:I = 0x7f0801d6

.field public static textinput_counter:I = 0x7f0801d7

.field public static textinput_error:I = 0x7f0801d8

.field public static textinput_helper_text:I = 0x7f0801d9

.field public static textinput_placeholder:I = 0x7f0801da

.field public static textinput_prefix_text:I = 0x7f0801db

.field public static textinput_suffix_text:I = 0x7f0801dc

.field public static time:I = 0x7f0801df

.field public static title:I = 0x7f0801e0

.field public static titleDividerNoCustom:I = 0x7f0801e1

.field public static title_template:I = 0x7f0801e2

.field public static top:I = 0x7f0801e4

.field public static topPanel:I = 0x7f0801e6

.field public static touch_outside:I = 0x7f0801e7

.field public static transition_current_scene:I = 0x7f0801ea

.field public static transition_layout_save:I = 0x7f0801eb

.field public static transition_position:I = 0x7f0801ec

.field public static transition_scene_layoutid_cache:I = 0x7f0801ed

.field public static transition_transform:I = 0x7f0801ee

.field public static triangle:I = 0x7f0801ef

.field public static unchecked:I = 0x7f0801f7

.field public static uniform:I = 0x7f0801f8

.field public static unlabeled:I = 0x7f0801f9

.field public static up:I = 0x7f0801fa

.field public static view_offset_helper:I = 0x7f0801fd

.field public static view_tree_lifecycle_owner:I = 0x7f0801ff

.field public static view_tree_on_back_pressed_dispatcher_owner:I = 0x7f080200

.field public static view_tree_saved_state_registry_owner:I = 0x7f080201

.field public static view_tree_view_model_store_owner:I = 0x7f080202

.field public static visible:I = 0x7f080203

.field public static visible_removing_fragment_view_tag:I = 0x7f080204

.field public static with_icon:I = 0x7f080207

.field public static withinBounds:I = 0x7f080208

.field public static wrap:I = 0x7f080209

.field public static wrap_content:I = 0x7f08020a


# direct methods
.method private constructor <init>()V
    .locals 0

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method
