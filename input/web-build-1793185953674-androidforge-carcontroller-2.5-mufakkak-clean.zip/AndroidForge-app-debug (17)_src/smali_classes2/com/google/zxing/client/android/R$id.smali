.class public final Lcom/google/zxing/client/android/R$id;
.super Ljava/lang/Object;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/google/zxing/client/android/R;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x19
    name = "id"
.end annotation


# static fields
.field public static accessibility_action_clickable_span:I = 0x7f08000f

.field public static accessibility_custom_action_0:I = 0x7f080010

.field public static accessibility_custom_action_1:I = 0x7f080011

.field public static accessibility_custom_action_10:I = 0x7f080012

.field public static accessibility_custom_action_11:I = 0x7f080013

.field public static accessibility_custom_action_12:I = 0x7f080014

.field public static accessibility_custom_action_13:I = 0x7f080015

.field public static accessibility_custom_action_14:I = 0x7f080016

.field public static accessibility_custom_action_15:I = 0x7f080017

.field public static accessibility_custom_action_16:I = 0x7f080018

.field public static accessibility_custom_action_17:I = 0x7f080019

.field public static accessibility_custom_action_18:I = 0x7f08001a

.field public static accessibility_custom_action_19:I = 0x7f08001b

.field public static accessibility_custom_action_2:I = 0x7f08001c

.field public static accessibility_custom_action_20:I = 0x7f08001d

.field public static accessibility_custom_action_21:I = 0x7f08001e

.field public static accessibility_custom_action_22:I = 0x7f08001f

.field public static accessibility_custom_action_23:I = 0x7f080020

.field public static accessibility_custom_action_24:I = 0x7f080021

.field public static accessibility_custom_action_25:I = 0x7f080022

.field public static accessibility_custom_action_26:I = 0x7f080023

.field public static accessibility_custom_action_27:I = 0x7f080024

.field public static accessibility_custom_action_28:I = 0x7f080025

.field public static accessibility_custom_action_29:I = 0x7f080026

.field public static accessibility_custom_action_3:I = 0x7f080027

.field public static accessibility_custom_action_30:I = 0x7f080028

.field public static accessibility_custom_action_31:I = 0x7f080029

.field public static accessibility_custom_action_4:I = 0x7f08002a

.field public static accessibility_custom_action_5:I = 0x7f08002b

.field public static accessibility_custom_action_6:I = 0x7f08002c

.field public static accessibility_custom_action_7:I = 0x7f08002d

.field public static accessibility_custom_action_8:I = 0x7f08002e

.field public static accessibility_custom_action_9:I = 0x7f08002f

.field public static action_container:I = 0x7f08003a

.field public static action_divider:I = 0x7f08003c

.field public static action_image:I = 0x7f08003d

.field public static action_text:I = 0x7f080043

.field public static actions:I = 0x7f080044

.field public static async:I = 0x7f080052

.field public static blocking:I = 0x7f08005c

.field public static centerCrop:I = 0x7f08006f

.field public static chronometer:I = 0x7f080079

.field public static dialog_button:I = 0x7f08009d

.field public static fitCenter:I = 0x7f0800c6

.field public static fitXY:I = 0x7f0800ca

.field public static forever:I = 0x7f0800ce

.field public static fragment_container_view_tag:I = 0x7f0800cf

.field public static icon:I = 0x7f0800e3

.field public static icon_group:I = 0x7f0800e4

.field public static info:I = 0x7f0800ec

.field public static italic:I = 0x7f0800ef

.field public static line1:I = 0x7f0800fc

.field public static line3:I = 0x7f0800fd

.field public static normal:I = 0x7f08014a

.field public static notification_background:I = 0x7f08014c

.field public static notification_main_column:I = 0x7f08014d

.field public static notification_main_column_container:I = 0x7f08014e

.field public static right_icon:I = 0x7f08017b

.field public static right_side:I = 0x7f08017c

.field public static special_effects_controller_view_tag:I = 0x7f0801a9

.field public static tag_accessibility_actions:I = 0x7f0801c0

.field public static tag_accessibility_clickable_spans:I = 0x7f0801c1

.field public static tag_accessibility_heading:I = 0x7f0801c2

.field public static tag_accessibility_pane_title:I = 0x7f0801c3

.field public static tag_on_apply_window_listener:I = 0x7f0801c4

.field public static tag_on_receive_content_listener:I = 0x7f0801c5

.field public static tag_on_receive_content_mime_types:I = 0x7f0801c6

.field public static tag_screen_reader_focusable:I = 0x7f0801c7

.field public static tag_state_description:I = 0x7f0801c8

.field public static tag_transition_group:I = 0x7f0801c9

.field public static tag_unhandled_key_event_manager:I = 0x7f0801ca

.field public static tag_unhandled_key_listeners:I = 0x7f0801cb

.field public static tag_window_insets_animation_callback:I = 0x7f0801cc

.field public static text:I = 0x7f0801cd

.field public static text2:I = 0x7f0801ce

.field public static time:I = 0x7f0801df

.field public static title:I = 0x7f0801e0

.field public static view_tree_lifecycle_owner:I = 0x7f0801ff

.field public static view_tree_saved_state_registry_owner:I = 0x7f080201

.field public static view_tree_view_model_store_owner:I = 0x7f080202

.field public static visible_removing_fragment_view_tag:I = 0x7f080204

.field public static zxing_back_button:I = 0x7f08020e

.field public static zxing_barcode_scanner:I = 0x7f08020f

.field public static zxing_barcode_surface:I = 0x7f080210

.field public static zxing_camera_closed:I = 0x7f080211

.field public static zxing_camera_error:I = 0x7f080212

.field public static zxing_decode:I = 0x7f080213

.field public static zxing_decode_failed:I = 0x7f080214

.field public static zxing_decode_succeeded:I = 0x7f080215

.field public static zxing_possible_result_points:I = 0x7f080216

.field public static zxing_preview_failed:I = 0x7f080217

.field public static zxing_prewiew_size_ready:I = 0x7f080218

.field public static zxing_status_view:I = 0x7f080219

.field public static zxing_viewfinder_view:I = 0x7f08021a


# direct methods
.method private constructor <init>()V
    .locals 0

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method
