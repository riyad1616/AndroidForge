.class public final Lcom/google/zxing/client/android/R$string;
.super Ljava/lang/Object;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/google/zxing/client/android/R;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x19
    name = "string"
.end annotation


# static fields
.field public static app_version:I = 0x7f100025

.field public static define_zxingandroidembedded:I = 0x7f10003f

.field public static library_zxingandroidembedded_author:I = 0x7f100059

.field public static library_zxingandroidembedded_authorWebsite:I = 0x7f10005a

.field public static library_zxingandroidembedded_isOpenSource:I = 0x7f10005b

.field public static library_zxingandroidembedded_libraryDescription:I = 0x7f10005c

.field public static library_zxingandroidembedded_libraryName:I = 0x7f10005d

.field public static library_zxingandroidembedded_libraryVersion:I = 0x7f10005e

.field public static library_zxingandroidembedded_libraryWebsite:I = 0x7f10005f

.field public static library_zxingandroidembedded_licenseId:I = 0x7f100060

.field public static library_zxingandroidembedded_repositoryLink:I = 0x7f100061

.field public static status_bar_notification_info_overflow:I = 0x7f1000f0

.field public static zxing_app_name:I = 0x7f1000fc

.field public static zxing_button_ok:I = 0x7f1000fd

.field public static zxing_msg_camera_framework_bug:I = 0x7f1000fe

.field public static zxing_msg_default_status:I = 0x7f1000ff


# direct methods
.method private constructor <init>()V
    .locals 0

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method
