.class public final Landroidx/drawerlayout/R$drawable;
.super Ljava/lang/Object;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Landroidx/drawerlayout/R;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x19
    name = "drawable"
.end annotation


# static fields
.field public static notification_action_background:I = 0x7f0700ef

.field public static notification_bg:I = 0x7f0700f0

.field public static notification_bg_low:I = 0x7f0700f1

.field public static notification_bg_low_normal:I = 0x7f0700f2

.field public static notification_bg_low_pressed:I = 0x7f0700f3

.field public static notification_bg_normal:I = 0x7f0700f4

.field public static notification_bg_normal_pressed:I = 0x7f0700f5

.field public static notification_icon_background:I = 0x7f0700f6

.field public static notification_template_icon_bg:I = 0x7f0700f8

.field public static notification_template_icon_low_bg:I = 0x7f0700f9

.field public static notification_tile_bg:I = 0x7f0700fa

.field public static notify_panel_notification_icon_bg:I = 0x7f0700fb


# direct methods
.method private constructor <init>()V
    .locals 0

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method
