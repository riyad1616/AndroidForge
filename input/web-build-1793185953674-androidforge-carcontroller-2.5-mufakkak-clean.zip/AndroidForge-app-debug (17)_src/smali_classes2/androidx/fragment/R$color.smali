.class public final Landroidx/fragment/R$color;
.super Ljava/lang/Object;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Landroidx/fragment/R;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x19
    name = "color"
.end annotation


# static fields
.field public static notification_action_color_filter:I = 0x7f0502f2

.field public static notification_icon_bg_color:I = 0x7f0502f3

.field public static ripple_material_light:I = 0x7f0502fe

.field public static secondary_text_default_material_light:I = 0x7f050300


# direct methods
.method private constructor <init>()V
    .locals 0

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method
