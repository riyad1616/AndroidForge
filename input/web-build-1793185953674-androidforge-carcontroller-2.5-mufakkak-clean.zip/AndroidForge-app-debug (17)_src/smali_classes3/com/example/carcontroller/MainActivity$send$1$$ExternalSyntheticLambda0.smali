.class public final synthetic Lcom/example/carcontroller/MainActivity$send$1$$ExternalSyntheticLambda0;
.super Ljava/lang/Object;
.source "D8$$SyntheticClass"

# interfaces
.implements Ljava/lang/Runnable;


# instance fields
.field public final synthetic f$0:Lcom/example/carcontroller/MainActivity;

.field public final synthetic f$1:Lcom/example/carcontroller/CarClient$Result;

.field public final synthetic f$2:Ljava/lang/String;


# direct methods
.method public synthetic constructor <init>(Lcom/example/carcontroller/MainActivity;Lcom/example/carcontroller/CarClient$Result;Ljava/lang/String;)V
    .locals 0

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Lcom/example/carcontroller/MainActivity$send$1$$ExternalSyntheticLambda0;->f$0:Lcom/example/carcontroller/MainActivity;

    iput-object p2, p0, Lcom/example/carcontroller/MainActivity$send$1$$ExternalSyntheticLambda0;->f$1:Lcom/example/carcontroller/CarClient$Result;

    iput-object p3, p0, Lcom/example/carcontroller/MainActivity$send$1$$ExternalSyntheticLambda0;->f$2:Ljava/lang/String;

    return-void
.end method


# virtual methods
.method public final run()V
    .locals 3

    iget-object v0, p0, Lcom/example/carcontroller/MainActivity$send$1$$ExternalSyntheticLambda0;->f$0:Lcom/example/carcontroller/MainActivity;

    iget-object v1, p0, Lcom/example/carcontroller/MainActivity$send$1$$ExternalSyntheticLambda0;->f$1:Lcom/example/carcontroller/CarClient$Result;

    iget-object v2, p0, Lcom/example/carcontroller/MainActivity$send$1$$ExternalSyntheticLambda0;->f$2:Ljava/lang/String;

    invoke-static {v0, v1, v2}, Lcom/example/carcontroller/MainActivity$send$1;->$r8$lambda$9d2XSGQfWIOa-mtw8kK2S-sVWRo(Lcom/example/carcontroller/MainActivity;Lcom/example/carcontroller/CarClient$Result;Ljava/lang/String;)V

    return-void
.end method
