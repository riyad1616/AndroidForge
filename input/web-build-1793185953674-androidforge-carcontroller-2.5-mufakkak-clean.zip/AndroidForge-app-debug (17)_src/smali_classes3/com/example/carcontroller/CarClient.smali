.class public final Lcom/example/carcontroller/CarClient;
.super Ljava/lang/Object;
.source "CarClient.kt"


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Lcom/example/carcontroller/CarClient$Code;,
        Lcom/example/carcontroller/CarClient$Companion;,
        Lcom/example/carcontroller/CarClient$Result;
    }
.end annotation

.annotation system Ldalvik/annotation/SourceDebugExtension;
    value = "SMAP\nCarClient.kt\nKotlin\n*S Kotlin\n*F\n+ 1 CarClient.kt\ncom/example/carcontroller/CarClient\n+ 2 _Strings.kt\nkotlin/text/StringsKt___StringsKt\n*L\n1#1,86:1\n429#2:87\n502#2,5:88\n*S KotlinDebug\n*F\n+ 1 CarClient.kt\ncom/example/carcontroller/CarClient\n*L\n43#1:87\n43#1:88,5\n*E\n"
.end annotation

.annotation runtime Lkotlin/Metadata;
    d1 = {
        "\u0000\"\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0000\n\u0002\u0010\u000e\n\u0002\u0008\u0002\n\u0002\u0010\u0008\n\u0002\u0008\u0002\n\u0002\u0018\u0002\n\u0002\u0008\u0006\u0018\u0000 \r2\u00020\u0001:\u0003\u000c\r\u000eB\u001f\u0012\u0006\u0010\u0002\u001a\u00020\u0003\u0012\u0006\u0010\u0004\u001a\u00020\u0003\u0012\u0008\u0008\u0002\u0010\u0005\u001a\u00020\u0006\u00a2\u0006\u0002\u0010\u0007J\u0006\u0010\u0008\u001a\u00020\tJ\u000e\u0010\n\u001a\u00020\t2\u0006\u0010\u000b\u001a\u00020\u0003R\u000e\u0010\u0002\u001a\u00020\u0003X\u0082\u0004\u00a2\u0006\u0002\n\u0000R\u000e\u0010\u0004\u001a\u00020\u0003X\u0082\u0004\u00a2\u0006\u0002\n\u0000R\u000e\u0010\u0005\u001a\u00020\u0006X\u0082\u0004\u00a2\u0006\u0002\n\u0000\u00a8\u0006\u000f"
    }
    d2 = {
        "Lcom/example/carcontroller/CarClient;",
        "",
        "host",
        "",
        "pin",
        "port",
        "",
        "(Ljava/lang/String;Ljava/lang/String;I)V",
        "ping",
        "Lcom/example/carcontroller/CarClient$Result;",
        "send",
        "cmd",
        "Code",
        "Companion",
        "Result",
        "app_debug"
    }
    k = 0x1
    mv = {
        0x1,
        0x9,
        0x0
    }
    xi = 0x30
.end annotation


# static fields
.field public static final CONNECT_TIMEOUT_MS:I = 0xbb8

.field public static final Companion:Lcom/example/carcontroller/CarClient$Companion;

.field public static final DEFAULT_PORT:I = 0x22b8

.field public static final READ_TIMEOUT_MS:I = 0x1f40


# instance fields
.field private final host:Ljava/lang/String;

.field private final pin:Ljava/lang/String;

.field private final port:I


# direct methods
.method static constructor <clinit>()V
    .locals 2

    new-instance v0, Lcom/example/carcontroller/CarClient$Companion;

    const/4 v1, 0x0

    invoke-direct {v0, v1}, Lcom/example/carcontroller/CarClient$Companion;-><init>(Lkotlin/jvm/internal/DefaultConstructorMarker;)V

    sput-object v0, Lcom/example/carcontroller/CarClient;->Companion:Lcom/example/carcontroller/CarClient$Companion;

    return-void
.end method

.method public constructor <init>(Ljava/lang/String;Ljava/lang/String;I)V
    .locals 1
    .param p1, "host"    # Ljava/lang/String;
    .param p2, "pin"    # Ljava/lang/String;
    .param p3, "port"    # I

    const-string v0, "host"

    invoke-static {p1, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    const-string v0, "pin"

    invoke-static {p2, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 22
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 23
    iput-object p1, p0, Lcom/example/carcontroller/CarClient;->host:Ljava/lang/String;

    .line 24
    iput-object p2, p0, Lcom/example/carcontroller/CarClient;->pin:Ljava/lang/String;

    .line 25
    iput p3, p0, Lcom/example/carcontroller/CarClient;->port:I

    .line 22
    return-void
.end method

.method public synthetic constructor <init>(Ljava/lang/String;Ljava/lang/String;IILkotlin/jvm/internal/DefaultConstructorMarker;)V
    .locals 0

    .line 22
    and-int/lit8 p4, p4, 0x4

    if-eqz p4, :cond_0

    .line 25
    const/16 p3, 0x22b8

    .line 22
    :cond_0
    invoke-direct {p0, p1, p2, p3}, Lcom/example/carcontroller/CarClient;-><init>(Ljava/lang/String;Ljava/lang/String;I)V

    .line 85
    return-void
.end method


# virtual methods
.method public final ping()Lcom/example/carcontroller/CarClient$Result;
    .locals 1

    .line 33
    const-string v0, "PING"

    invoke-virtual {p0, v0}, Lcom/example/carcontroller/CarClient;->send(Ljava/lang/String;)Lcom/example/carcontroller/CarClient$Result;

    move-result-object v0

    return-object v0
.end method

.method public final send(Ljava/lang/String;)Lcom/example/carcontroller/CarClient$Result;
    .locals 18
    .param p1, "cmd"    # Ljava/lang/String;

    move-object/from16 v1, p0

    move-object/from16 v2, p1

    const-string v3, ""

    const-string v0, "cmd"

    invoke-static {v2, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 36
    new-instance v0, Ljava/net/Socket;

    invoke-direct {v0}, Ljava/net/Socket;-><init>()V

    move-object v4, v0

    .line 37
    .local v4, "socket":Ljava/net/Socket;
    nop

    .line 38
    const/4 v5, 0x2

    const/4 v6, 0x0

    :try_start_0
    new-instance v0, Ljava/net/InetSocketAddress;

    iget-object v7, v1, Lcom/example/carcontroller/CarClient;->host:Ljava/lang/String;

    iget v8, v1, Lcom/example/carcontroller/CarClient;->port:I

    invoke-direct {v0, v7, v8}, Ljava/net/InetSocketAddress;-><init>(Ljava/lang/String;I)V

    move-object v7, v0

    .line 39
    .local v7, "address":Ljava/net/InetSocketAddress;
    invoke-virtual {v7}, Ljava/net/InetSocketAddress;->isUnresolved()Z

    move-result v0

    if-eqz v0, :cond_0

    new-instance v8, Lcom/example/carcontroller/CarClient$Result;

    sget-object v0, Lcom/example/carcontroller/CarClient$Code;->BAD_IP:Lcom/example/carcontroller/CarClient$Code;

    invoke-direct {v8, v0, v6, v5, v6}, Lcom/example/carcontroller/CarClient$Result;-><init>(Lcom/example/carcontroller/CarClient$Code;Ljava/lang/String;ILkotlin/jvm/internal/DefaultConstructorMarker;)V
    :try_end_0
    .catch Ljava/net/SocketTimeoutException; {:try_start_0 .. :try_end_0} :catch_b
    .catch Ljava/net/UnknownHostException; {:try_start_0 .. :try_end_0} :catch_9
    .catch Ljava/net/ConnectException; {:try_start_0 .. :try_end_0} :catch_7
    .catch Ljava/net/NoRouteToHostException; {:try_start_0 .. :try_end_0} :catch_5
    .catch Ljava/io/IOException; {:try_start_0 .. :try_end_0} :catch_3
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    .line 62
    .end local v7    # "address":Ljava/net/InetSocketAddress;
    nop

    .line 63
    :try_start_1
    invoke-virtual {v4}, Ljava/net/Socket;->close()V
    :try_end_1
    .catch Ljava/io/IOException; {:try_start_1 .. :try_end_1} :catch_0

    move-object v0, v7

    .local v0, "address":Ljava/net/InetSocketAddress;
    goto :goto_0

    .line 64
    .end local v0    # "address":Ljava/net/InetSocketAddress;
    :catch_0
    move-exception v0

    move-object v0, v7

    .line 39
    .restart local v0    # "address":Ljava/net/InetSocketAddress;
    :goto_0
    return-object v8

    .line 40
    .end local v0    # "address":Ljava/net/InetSocketAddress;
    .restart local v7    # "address":Ljava/net/InetSocketAddress;
    :cond_0
    :try_start_2
    move-object v0, v7

    check-cast v0, Ljava/net/SocketAddress;

    const/16 v8, 0xbb8

    invoke-virtual {v4, v0, v8}, Ljava/net/Socket;->connect(Ljava/net/SocketAddress;I)V

    .line 41
    const/16 v0, 0x1f40

    invoke-virtual {v4, v0}, Ljava/net/Socket;->setSoTimeout(I)V

    .line 43
    iget-object v0, v1, Lcom/example/carcontroller/CarClient;->pin:Ljava/lang/String;

    .local v0, "$this$filter$iv":Ljava/lang/String;
    const/4 v8, 0x0

    .line 87
    .local v8, "$i$f$filter":I
    move-object v9, v0

    check-cast v9, Ljava/lang/CharSequence;

    new-instance v10, Ljava/lang/StringBuilder;

    invoke-direct {v10}, Ljava/lang/StringBuilder;-><init>()V

    check-cast v10, Ljava/lang/Appendable;

    .local v9, "$this$filterTo$iv$iv":Ljava/lang/CharSequence;
    .local v10, "destination$iv$iv":Ljava/lang/Appendable;
    const/4 v11, 0x0

    .line 88
    .local v11, "$i$f$filterTo":I
    const/4 v12, 0x0

    .local v12, "index$iv$iv":I
    invoke-interface {v9}, Ljava/lang/CharSequence;->length()I

    move-result v13

    :goto_1
    if-ge v12, v13, :cond_2

    .line 89
    invoke-interface {v9, v12}, Ljava/lang/CharSequence;->charAt(I)C

    move-result v14

    .line 90
    .local v14, "element$iv$iv":C
    move v15, v14

    .local v15, "it":C
    const/16 v16, 0x0

    .line 43
    .local v16, "$i$a$-filter-CarClient$send$cleanPin$1":I
    invoke-static {v15}, Lkotlin/text/CharsKt;->isWhitespace(C)Z

    move-result v17

    .line 90
    .end local v15    # "it":C
    .end local v16    # "$i$a$-filter-CarClient$send$cleanPin$1":I
    xor-int/lit8 v15, v17, 0x1

    if-eqz v15, :cond_1

    invoke-interface {v10, v14}, Ljava/lang/Appendable;->append(C)Ljava/lang/Appendable;

    .line 88
    .end local v14    # "element$iv$iv":C
    :cond_1
    add-int/lit8 v12, v12, 0x1

    goto :goto_1

    .line 92
    .end local v12    # "index$iv$iv":I
    :cond_2
    nop

    .end local v9    # "$this$filterTo$iv$iv":Ljava/lang/CharSequence;
    .end local v10    # "destination$iv$iv":Ljava/lang/Appendable;
    .end local v11    # "$i$f$filterTo":I
    move-object v9, v10

    check-cast v9, Ljava/lang/StringBuilder;

    .line 87
    invoke-virtual {v9}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v9

    const-string v10, "toString(...)"

    invoke-static {v9, v10}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    .line 43
    .end local v0    # "$this$filter$iv":Ljava/lang/String;
    .end local v8    # "$i$f$filter":I
    move-object v8, v9

    .line 44
    .local v8, "cleanPin":Ljava/lang/String;
    new-instance v0, Ljava/io/OutputStreamWriter;

    invoke-virtual {v4}, Ljava/net/Socket;->getOutputStream()Ljava/io/OutputStream;

    move-result-object v9

    sget-object v10, Lkotlin/text/Charsets;->UTF_8:Ljava/nio/charset/Charset;

    invoke-direct {v0, v9, v10}, Ljava/io/OutputStreamWriter;-><init>(Ljava/io/OutputStream;Ljava/nio/charset/Charset;)V

    move-object v9, v0

    .line 45
    .local v9, "out":Ljava/io/OutputStreamWriter;
    new-instance v0, Ljava/lang/StringBuilder;

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    const-string v10, "AUTH "

    invoke-virtual {v0, v10}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    invoke-virtual {v0, v8}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    const/16 v10, 0x20

    invoke-virtual {v0, v10}, Ljava/lang/StringBuilder;->append(C)Ljava/lang/StringBuilder;

    move-result-object v0

    invoke-virtual {v0, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    const/16 v10, 0xa

    invoke-virtual {v0, v10}, Ljava/lang/StringBuilder;->append(C)Ljava/lang/StringBuilder;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    invoke-virtual {v9, v0}, Ljava/io/OutputStreamWriter;->write(Ljava/lang/String;)V

    .line 46
    invoke-virtual {v9}, Ljava/io/OutputStreamWriter;->flush()V

    .line 48
    new-instance v0, Ljava/io/BufferedReader;

    new-instance v10, Ljava/io/InputStreamReader;

    invoke-virtual {v4}, Ljava/net/Socket;->getInputStream()Ljava/io/InputStream;

    move-result-object v11

    sget-object v12, Lkotlin/text/Charsets;->UTF_8:Ljava/nio/charset/Charset;

    invoke-direct {v10, v11, v12}, Ljava/io/InputStreamReader;-><init>(Ljava/io/InputStream;Ljava/nio/charset/Charset;)V

    check-cast v10, Ljava/io/Reader;

    invoke-direct {v0, v10}, Ljava/io/BufferedReader;-><init>(Ljava/io/Reader;)V

    move-object v10, v0

    .line 49
    .local v10, "reader":Ljava/io/BufferedReader;
    invoke-virtual {v10}, Ljava/io/BufferedReader;->readLine()Ljava/lang/String;

    move-result-object v0

    if-eqz v0, :cond_4

    check-cast v0, Ljava/lang/CharSequence;

    invoke-static {v0}, Lkotlin/text/StringsKt;->trim(Ljava/lang/CharSequence;)Ljava/lang/CharSequence;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/Object;->toString()Ljava/lang/String;

    move-result-object v0

    if-nez v0, :cond_3

    goto :goto_2

    .line 50
    .local v0, "line":Ljava/lang/String;
    :cond_3
    sget-object v11, Lcom/example/carcontroller/CarClient;->Companion:Lcom/example/carcontroller/CarClient$Companion;

    invoke-virtual {v11, v0}, Lcom/example/carcontroller/CarClient$Companion;->parseReply(Ljava/lang/String;)Lcom/example/carcontroller/CarClient$Result;

    move-result-object v3
    :try_end_2
    .catch Ljava/net/SocketTimeoutException; {:try_start_2 .. :try_end_2} :catch_b
    .catch Ljava/net/UnknownHostException; {:try_start_2 .. :try_end_2} :catch_9
    .catch Ljava/net/ConnectException; {:try_start_2 .. :try_end_2} :catch_7
    .catch Ljava/net/NoRouteToHostException; {:try_start_2 .. :try_end_2} :catch_5
    .catch Ljava/io/IOException; {:try_start_2 .. :try_end_2} :catch_3
    .catchall {:try_start_2 .. :try_end_2} :catchall_0

    .line 62
    .end local v0    # "line":Ljava/lang/String;
    .end local v7    # "address":Ljava/net/InetSocketAddress;
    .end local v8    # "cleanPin":Ljava/lang/String;
    .end local v9    # "out":Ljava/io/OutputStreamWriter;
    .end local v10    # "reader":Ljava/io/BufferedReader;
    nop

    .line 63
    :try_start_3
    invoke-virtual {v4}, Ljava/net/Socket;->close()V
    :try_end_3
    .catch Ljava/io/IOException; {:try_start_3 .. :try_end_3} :catch_1

    goto/16 :goto_8

    .line 64
    :catch_1
    move-exception v0

    goto/16 :goto_8

    .line 49
    .restart local v7    # "address":Ljava/net/InetSocketAddress;
    .restart local v8    # "cleanPin":Ljava/lang/String;
    .restart local v9    # "out":Ljava/io/OutputStreamWriter;
    .restart local v10    # "reader":Ljava/io/BufferedReader;
    :cond_4
    :goto_2
    :try_start_4
    new-instance v11, Lcom/example/carcontroller/CarClient$Result;

    sget-object v0, Lcom/example/carcontroller/CarClient$Code;->NO_REPLY:Lcom/example/carcontroller/CarClient$Code;

    invoke-direct {v11, v0, v6, v5, v6}, Lcom/example/carcontroller/CarClient$Result;-><init>(Lcom/example/carcontroller/CarClient$Code;Ljava/lang/String;ILkotlin/jvm/internal/DefaultConstructorMarker;)V
    :try_end_4
    .catch Ljava/net/SocketTimeoutException; {:try_start_4 .. :try_end_4} :catch_b
    .catch Ljava/net/UnknownHostException; {:try_start_4 .. :try_end_4} :catch_9
    .catch Ljava/net/ConnectException; {:try_start_4 .. :try_end_4} :catch_7
    .catch Ljava/net/NoRouteToHostException; {:try_start_4 .. :try_end_4} :catch_5
    .catch Ljava/io/IOException; {:try_start_4 .. :try_end_4} :catch_3
    .catchall {:try_start_4 .. :try_end_4} :catchall_0

    .line 62
    .end local v7    # "address":Ljava/net/InetSocketAddress;
    .end local v8    # "cleanPin":Ljava/lang/String;
    .end local v9    # "out":Ljava/io/OutputStreamWriter;
    .end local v10    # "reader":Ljava/io/BufferedReader;
    nop

    .line 63
    :try_start_5
    invoke-virtual {v4}, Ljava/net/Socket;->close()V
    :try_end_5
    .catch Ljava/io/IOException; {:try_start_5 .. :try_end_5} :catch_2

    move-object v0, v10

    .local v0, "reader":Ljava/io/BufferedReader;
    move-object v3, v8

    .local v3, "cleanPin":Ljava/lang/String;
    move-object v5, v7

    .local v5, "address":Ljava/net/InetSocketAddress;
    move-object v6, v9

    .local v6, "out":Ljava/io/OutputStreamWriter;
    goto :goto_3

    .line 64
    .end local v0    # "reader":Ljava/io/BufferedReader;
    .end local v3    # "cleanPin":Ljava/lang/String;
    .end local v5    # "address":Ljava/net/InetSocketAddress;
    .end local v6    # "out":Ljava/io/OutputStreamWriter;
    :catch_2
    move-exception v0

    move-object v0, v10

    .restart local v0    # "reader":Ljava/io/BufferedReader;
    move-object v3, v8

    .restart local v3    # "cleanPin":Ljava/lang/String;
    move-object v5, v7

    .restart local v5    # "address":Ljava/net/InetSocketAddress;
    move-object v6, v9

    .line 49
    .restart local v6    # "out":Ljava/io/OutputStreamWriter;
    :goto_3
    return-object v11

    .line 62
    .end local v0    # "reader":Ljava/io/BufferedReader;
    .end local v3    # "cleanPin":Ljava/lang/String;
    .end local v5    # "address":Ljava/net/InetSocketAddress;
    .end local v6    # "out":Ljava/io/OutputStreamWriter;
    :catchall_0
    move-exception v0

    move-object v3, v0

    goto/16 :goto_a

    .line 59
    :catch_3
    move-exception v0

    .line 60
    .local v0, "e":Ljava/io/IOException;
    :try_start_6
    new-instance v5, Lcom/example/carcontroller/CarClient$Result;

    sget-object v6, Lcom/example/carcontroller/CarClient$Code;->IO:Lcom/example/carcontroller/CarClient$Code;

    invoke-virtual {v0}, Ljava/io/IOException;->getMessage()Ljava/lang/String;

    move-result-object v7

    if-nez v7, :cond_5

    goto :goto_4

    :cond_5
    move-object v3, v7

    :goto_4
    invoke-direct {v5, v6, v3}, Lcom/example/carcontroller/CarClient$Result;-><init>(Lcom/example/carcontroller/CarClient$Code;Ljava/lang/String;)V
    :try_end_6
    .catchall {:try_start_6 .. :try_end_6} :catchall_0

    .line 62
    .end local v0    # "e":Ljava/io/IOException;
    nop

    .line 63
    :try_start_7
    invoke-virtual {v4}, Ljava/net/Socket;->close()V
    :try_end_7
    .catch Ljava/io/IOException; {:try_start_7 .. :try_end_7} :catch_4

    goto :goto_7

    .line 64
    :catch_4
    move-exception v0

    goto :goto_7

    .line 57
    :catch_5
    move-exception v0

    .line 58
    .local v0, "e":Ljava/net/NoRouteToHostException;
    :try_start_8
    new-instance v5, Lcom/example/carcontroller/CarClient$Result;

    sget-object v6, Lcom/example/carcontroller/CarClient$Code;->UNREACHABLE:Lcom/example/carcontroller/CarClient$Code;

    invoke-virtual {v0}, Ljava/net/NoRouteToHostException;->getMessage()Ljava/lang/String;

    move-result-object v7

    if-nez v7, :cond_6

    goto :goto_5

    :cond_6
    move-object v3, v7

    :goto_5
    invoke-direct {v5, v6, v3}, Lcom/example/carcontroller/CarClient$Result;-><init>(Lcom/example/carcontroller/CarClient$Code;Ljava/lang/String;)V
    :try_end_8
    .catchall {:try_start_8 .. :try_end_8} :catchall_0

    .line 62
    .end local v0    # "e":Ljava/net/NoRouteToHostException;
    nop

    .line 63
    :try_start_9
    invoke-virtual {v4}, Ljava/net/Socket;->close()V
    :try_end_9
    .catch Ljava/io/IOException; {:try_start_9 .. :try_end_9} :catch_6

    goto :goto_7

    .line 64
    :catch_6
    move-exception v0

    goto :goto_7

    .line 55
    :catch_7
    move-exception v0

    .line 56
    .local v0, "e":Ljava/net/ConnectException;
    :try_start_a
    new-instance v5, Lcom/example/carcontroller/CarClient$Result;

    sget-object v6, Lcom/example/carcontroller/CarClient$Code;->UNREACHABLE:Lcom/example/carcontroller/CarClient$Code;

    invoke-virtual {v0}, Ljava/net/ConnectException;->getMessage()Ljava/lang/String;

    move-result-object v7

    if-nez v7, :cond_7

    goto :goto_6

    :cond_7
    move-object v3, v7

    :goto_6
    invoke-direct {v5, v6, v3}, Lcom/example/carcontroller/CarClient$Result;-><init>(Lcom/example/carcontroller/CarClient$Code;Ljava/lang/String;)V
    :try_end_a
    .catchall {:try_start_a .. :try_end_a} :catchall_0

    .line 62
    .end local v0    # "e":Ljava/net/ConnectException;
    nop

    .line 63
    :try_start_b
    invoke-virtual {v4}, Ljava/net/Socket;->close()V
    :try_end_b
    .catch Ljava/io/IOException; {:try_start_b .. :try_end_b} :catch_8

    goto :goto_7

    .line 64
    :catch_8
    move-exception v0

    .line 67
    :goto_7
    move-object v3, v5

    goto :goto_9

    .line 53
    :catch_9
    move-exception v0

    .line 54
    .local v0, "e":Ljava/net/UnknownHostException;
    :try_start_c
    new-instance v3, Lcom/example/carcontroller/CarClient$Result;

    sget-object v7, Lcom/example/carcontroller/CarClient$Code;->BAD_IP:Lcom/example/carcontroller/CarClient$Code;

    invoke-direct {v3, v7, v6, v5, v6}, Lcom/example/carcontroller/CarClient$Result;-><init>(Lcom/example/carcontroller/CarClient$Code;Ljava/lang/String;ILkotlin/jvm/internal/DefaultConstructorMarker;)V
    :try_end_c
    .catchall {:try_start_c .. :try_end_c} :catchall_0

    .line 62
    .end local v0    # "e":Ljava/net/UnknownHostException;
    nop

    .line 63
    :try_start_d
    invoke-virtual {v4}, Ljava/net/Socket;->close()V
    :try_end_d
    .catch Ljava/io/IOException; {:try_start_d .. :try_end_d} :catch_a

    goto :goto_8

    .line 64
    :catch_a
    move-exception v0

    goto :goto_8

    .line 51
    :catch_b
    move-exception v0

    .line 52
    .local v0, "e":Ljava/net/SocketTimeoutException;
    :try_start_e
    new-instance v3, Lcom/example/carcontroller/CarClient$Result;

    sget-object v7, Lcom/example/carcontroller/CarClient$Code;->TIMEOUT:Lcom/example/carcontroller/CarClient$Code;

    invoke-direct {v3, v7, v6, v5, v6}, Lcom/example/carcontroller/CarClient$Result;-><init>(Lcom/example/carcontroller/CarClient$Code;Ljava/lang/String;ILkotlin/jvm/internal/DefaultConstructorMarker;)V
    :try_end_e
    .catchall {:try_start_e .. :try_end_e} :catchall_0

    .line 62
    .end local v0    # "e":Ljava/net/SocketTimeoutException;
    nop

    .line 63
    :try_start_f
    invoke-virtual {v4}, Ljava/net/Socket;->close()V
    :try_end_f
    .catch Ljava/io/IOException; {:try_start_f .. :try_end_f} :catch_c

    goto :goto_8

    .line 64
    :catch_c
    move-exception v0

    .line 67
    :goto_8
    nop

    .line 37
    :goto_9
    return-object v3

    .line 63
    :goto_a
    :try_start_10
    invoke-virtual {v4}, Ljava/net/Socket;->close()V
    :try_end_10
    .catch Ljava/io/IOException; {:try_start_10 .. :try_end_10} :catch_d

    goto :goto_b

    .line 64
    :catch_d
    move-exception v0

    :goto_b
    throw v3
.end method
