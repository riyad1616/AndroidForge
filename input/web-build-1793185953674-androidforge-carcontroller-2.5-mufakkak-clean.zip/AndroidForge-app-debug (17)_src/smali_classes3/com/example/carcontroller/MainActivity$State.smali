.class final enum Lcom/example/carcontroller/MainActivity$State;
.super Ljava/lang/Enum;
.source "MainActivity.kt"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/example/carcontroller/MainActivity;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x401a
    name = "State"
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "Ljava/lang/Enum<",
        "Lcom/example/carcontroller/MainActivity$State;",
        ">;"
    }
.end annotation

.annotation runtime Lkotlin/Metadata;
    d1 = {
        "\u0000\u000c\n\u0002\u0018\u0002\n\u0002\u0010\u0010\n\u0002\u0008\u0006\u0008\u0082\u0081\u0002\u0018\u00002\u0008\u0012\u0004\u0012\u00020\u00000\u0001B\u0007\u0008\u0002\u00a2\u0006\u0002\u0010\u0002j\u0002\u0008\u0003j\u0002\u0008\u0004j\u0002\u0008\u0005j\u0002\u0008\u0006\u00a8\u0006\u0007"
    }
    d2 = {
        "Lcom/example/carcontroller/MainActivity$State;",
        "",
        "(Ljava/lang/String;I)V",
        "IDLE",
        "BUSY",
        "OK",
        "ERROR",
        "app_debug"
    }
    k = 0x1
    mv = {
        0x1,
        0x9,
        0x0
    }
    xi = 0x30
.end annotation


# static fields
.field private static final synthetic $ENTRIES:Lkotlin/enums/EnumEntries;

.field private static final synthetic $VALUES:[Lcom/example/carcontroller/MainActivity$State;

.field public static final enum BUSY:Lcom/example/carcontroller/MainActivity$State;

.field public static final enum ERROR:Lcom/example/carcontroller/MainActivity$State;

.field public static final enum IDLE:Lcom/example/carcontroller/MainActivity$State;

.field public static final enum OK:Lcom/example/carcontroller/MainActivity$State;


# direct methods
.method private static final synthetic $values()[Lcom/example/carcontroller/MainActivity$State;
    .locals 4

    sget-object v0, Lcom/example/carcontroller/MainActivity$State;->IDLE:Lcom/example/carcontroller/MainActivity$State;

    sget-object v1, Lcom/example/carcontroller/MainActivity$State;->BUSY:Lcom/example/carcontroller/MainActivity$State;

    sget-object v2, Lcom/example/carcontroller/MainActivity$State;->OK:Lcom/example/carcontroller/MainActivity$State;

    sget-object v3, Lcom/example/carcontroller/MainActivity$State;->ERROR:Lcom/example/carcontroller/MainActivity$State;

    filled-new-array {v0, v1, v2, v3}, [Lcom/example/carcontroller/MainActivity$State;

    move-result-object v0

    return-object v0
.end method

.method static constructor <clinit>()V
    .locals 3

    .line 37
    new-instance v0, Lcom/example/carcontroller/MainActivity$State;

    const-string v1, "IDLE"

    const/4 v2, 0x0

    invoke-direct {v0, v1, v2}, Lcom/example/carcontroller/MainActivity$State;-><init>(Ljava/lang/String;I)V

    sput-object v0, Lcom/example/carcontroller/MainActivity$State;->IDLE:Lcom/example/carcontroller/MainActivity$State;

    new-instance v0, Lcom/example/carcontroller/MainActivity$State;

    const-string v1, "BUSY"

    const/4 v2, 0x1

    invoke-direct {v0, v1, v2}, Lcom/example/carcontroller/MainActivity$State;-><init>(Ljava/lang/String;I)V

    sput-object v0, Lcom/example/carcontroller/MainActivity$State;->BUSY:Lcom/example/carcontroller/MainActivity$State;

    new-instance v0, Lcom/example/carcontroller/MainActivity$State;

    const-string v1, "OK"

    const/4 v2, 0x2

    invoke-direct {v0, v1, v2}, Lcom/example/carcontroller/MainActivity$State;-><init>(Ljava/lang/String;I)V

    sput-object v0, Lcom/example/carcontroller/MainActivity$State;->OK:Lcom/example/carcontroller/MainActivity$State;

    new-instance v0, Lcom/example/carcontroller/MainActivity$State;

    const-string v1, "ERROR"

    const/4 v2, 0x3

    invoke-direct {v0, v1, v2}, Lcom/example/carcontroller/MainActivity$State;-><init>(Ljava/lang/String;I)V

    sput-object v0, Lcom/example/carcontroller/MainActivity$State;->ERROR:Lcom/example/carcontroller/MainActivity$State;

    invoke-static {}, Lcom/example/carcontroller/MainActivity$State;->$values()[Lcom/example/carcontroller/MainActivity$State;

    move-result-object v0

    sput-object v0, Lcom/example/carcontroller/MainActivity$State;->$VALUES:[Lcom/example/carcontroller/MainActivity$State;

    check-cast v0, [Ljava/lang/Enum;

    invoke-static {v0}, Lkotlin/enums/EnumEntriesKt;->enumEntries([Ljava/lang/Enum;)Lkotlin/enums/EnumEntries;

    move-result-object v0

    sput-object v0, Lcom/example/carcontroller/MainActivity$State;->$ENTRIES:Lkotlin/enums/EnumEntries;

    return-void
.end method

.method private constructor <init>(Ljava/lang/String;I)V
    .locals 0
    .param p1, "$enum$name"    # Ljava/lang/String;
    .param p2, "$enum$ordinal"    # I
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()V"
        }
    .end annotation

    .line 37
    invoke-direct {p0, p1, p2}, Ljava/lang/Enum;-><init>(Ljava/lang/String;I)V

    return-void
.end method

.method public static getEntries()Lkotlin/enums/EnumEntries;
    .locals 1
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Lkotlin/enums/EnumEntries<",
            "Lcom/example/carcontroller/MainActivity$State;",
            ">;"
        }
    .end annotation

    sget-object v0, Lcom/example/carcontroller/MainActivity$State;->$ENTRIES:Lkotlin/enums/EnumEntries;

    return-object v0
.end method

.method public static valueOf(Ljava/lang/String;)Lcom/example/carcontroller/MainActivity$State;
    .locals 1

    const-class v0, Lcom/example/carcontroller/MainActivity$State;

    invoke-static {v0, p0}, Ljava/lang/Enum;->valueOf(Ljava/lang/Class;Ljava/lang/String;)Ljava/lang/Enum;

    move-result-object v0

    check-cast v0, Lcom/example/carcontroller/MainActivity$State;

    return-object v0
.end method

.method public static values()[Lcom/example/carcontroller/MainActivity$State;
    .locals 1

    sget-object v0, Lcom/example/carcontroller/MainActivity$State;->$VALUES:[Lcom/example/carcontroller/MainActivity$State;

    invoke-virtual {v0}, [Ljava/lang/Object;->clone()Ljava/lang/Object;

    move-result-object v0

    check-cast v0, [Lcom/example/carcontroller/MainActivity$State;

    return-object v0
.end method
