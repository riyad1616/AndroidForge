.class public final Lcom/example/carcontroller/Controls;
.super Ljava/lang/Object;
.source "Controls.kt"


# annotations
.annotation runtime Lkotlin/Metadata;
    d1 = {
        "\u0000\u0018\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0002\u0008\u0002\n\u0002\u0010 \n\u0002\u0018\u0002\n\u0002\u0008\u0003\u0008\u00c6\u0002\u0018\u00002\u00020\u0001B\u0007\u0008\u0002\u00a2\u0006\u0002\u0010\u0002R\u0017\u0010\u0003\u001a\u0008\u0012\u0004\u0012\u00020\u00050\u0004\u00a2\u0006\u0008\n\u0000\u001a\u0004\u0008\u0006\u0010\u0007\u00a8\u0006\u0008"
    }
    d2 = {
        "Lcom/example/carcontroller/Controls;",
        "",
        "()V",
        "sections",
        "",
        "Lcom/example/carcontroller/Section;",
        "getSections",
        "()Ljava/util/List;",
        "app_debug"
    }
    k = 0x1
    mv = {
        0x1,
        0x9,
        0x0
    }
    xi = 0x30
.end annotation


# static fields
.field public static final INSTANCE:Lcom/example/carcontroller/Controls;

.field private static final sections:Ljava/util/List;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/List<",
            "Lcom/example/carcontroller/Section;",
            ">;"
        }
    .end annotation
.end field


# direct methods
.method static constructor <clinit>()V
    .locals 26

    new-instance v0, Lcom/example/carcontroller/Controls;

    invoke-direct {v0}, Lcom/example/carcontroller/Controls;-><init>()V

    sput-object v0, Lcom/example/carcontroller/Controls;->INSTANCE:Lcom/example/carcontroller/Controls;

    .line 24
    nop

    .line 25
    const/4 v0, 0x6

    new-array v1, v0, [Lcom/example/carcontroller/Section;

    new-instance v2, Lcom/example/carcontroller/Section;

    .line 26
    sget v3, Lcom/example/carcontroller/R$drawable;->ic_car:I

    sget v4, Lcom/example/carcontroller/R$string;->sec_body:I

    .line 27
    const/4 v5, 0x3

    new-array v6, v5, [Lcom/example/carcontroller/Control;

    new-instance v14, Lcom/example/carcontroller/Control;

    sget v8, Lcom/example/carcontroller/R$drawable;->ic_window:I

    sget v9, Lcom/example/carcontroller/R$string;->lbl_windows:I

    sget v10, Lcom/example/carcontroller/R$string;->act_open:I

    const-string v11, "CMD_WINDOW_OPEN"

    sget v7, Lcom/example/carcontroller/R$string;->act_close:I

    invoke-static {v7}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v12

    const-string v13, "CMD_WINDOW_CLOSE"

    move-object v7, v14

    invoke-direct/range {v7 .. v13}, Lcom/example/carcontroller/Control;-><init>(IIILjava/lang/String;Ljava/lang/Integer;Ljava/lang/String;)V

    const/4 v7, 0x0

    aput-object v14, v6, v7

    .line 28
    new-instance v8, Lcom/example/carcontroller/Control;

    sget v16, Lcom/example/carcontroller/R$drawable;->ic_sunroof:I

    sget v17, Lcom/example/carcontroller/R$string;->lbl_sunroof:I

    sget v18, Lcom/example/carcontroller/R$string;->act_open:I

    const-string v19, "CMD_SUNROOF_OPEN"

    sget v9, Lcom/example/carcontroller/R$string;->act_close:I

    invoke-static {v9}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v20

    const-string v21, "CMD_SUNROOF_CLOSE"

    move-object v15, v8

    invoke-direct/range {v15 .. v21}, Lcom/example/carcontroller/Control;-><init>(IIILjava/lang/String;Ljava/lang/Integer;Ljava/lang/String;)V

    const/4 v9, 0x1

    aput-object v8, v6, v9

    .line 27
    nop

    .line 29
    new-instance v8, Lcom/example/carcontroller/Control;

    sget v11, Lcom/example/carcontroller/R$drawable;->ic_mirror:I

    sget v12, Lcom/example/carcontroller/R$string;->lbl_mirrors:I

    sget v13, Lcom/example/carcontroller/R$string;->act_open:I

    const-string v14, "CMD_MIRROR_UNFOLD"

    sget v10, Lcom/example/carcontroller/R$string;->act_fold:I

    invoke-static {v10}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v15

    const-string v16, "CMD_MIRROR_FOLD"

    move-object v10, v8

    invoke-direct/range {v10 .. v16}, Lcom/example/carcontroller/Control;-><init>(IIILjava/lang/String;Ljava/lang/Integer;Ljava/lang/String;)V

    const/4 v10, 0x2

    aput-object v8, v6, v10

    .line 27
    nop

    .line 26
    invoke-static {v6}, Lkotlin/collections/CollectionsKt;->listOf([Ljava/lang/Object;)Ljava/util/List;

    move-result-object v6

    .line 25
    invoke-direct {v2, v3, v4, v6}, Lcom/example/carcontroller/Section;-><init>(IILjava/util/List;)V

    aput-object v2, v1, v7

    .line 32
    new-instance v2, Lcom/example/carcontroller/Section;

    .line 33
    sget v3, Lcom/example/carcontroller/R$drawable;->ic_ac:I

    sget v4, Lcom/example/carcontroller/R$string;->sec_climate:I

    .line 34
    new-array v6, v10, [Lcom/example/carcontroller/Control;

    new-instance v8, Lcom/example/carcontroller/Control;

    sget v12, Lcom/example/carcontroller/R$drawable;->ic_ac:I

    sget v13, Lcom/example/carcontroller/R$string;->lbl_ac:I

    sget v14, Lcom/example/carcontroller/R$string;->act_on:I

    const-string v15, "CMD_AC_ON"

    sget v11, Lcom/example/carcontroller/R$string;->act_off:I

    invoke-static {v11}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v16

    const-string v17, "CMD_AC_OFF"

    move-object v11, v8

    invoke-direct/range {v11 .. v17}, Lcom/example/carcontroller/Control;-><init>(IIILjava/lang/String;Ljava/lang/Integer;Ljava/lang/String;)V

    aput-object v8, v6, v7

    .line 35
    new-instance v8, Lcom/example/carcontroller/Control;

    sget v19, Lcom/example/carcontroller/R$drawable;->ic_seat_heat:I

    sget v20, Lcom/example/carcontroller/R$string;->lbl_seat_heat:I

    sget v21, Lcom/example/carcontroller/R$string;->act_on:I

    const-string v22, "CMD_SEAT_HEAT_ON"

    sget v11, Lcom/example/carcontroller/R$string;->act_off:I

    invoke-static {v11}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v23

    const-string v24, "CMD_SEAT_HEAT_OFF"

    move-object/from16 v18, v8

    invoke-direct/range {v18 .. v24}, Lcom/example/carcontroller/Control;-><init>(IIILjava/lang/String;Ljava/lang/Integer;Ljava/lang/String;)V

    aput-object v8, v6, v9

    .line 34
    nop

    .line 33
    invoke-static {v6}, Lkotlin/collections/CollectionsKt;->listOf([Ljava/lang/Object;)Ljava/util/List;

    move-result-object v6

    .line 32
    invoke-direct {v2, v3, v4, v6}, Lcom/example/carcontroller/Section;-><init>(IILjava/util/List;)V

    aput-object v2, v1, v9

    .line 25
    nop

    .line 38
    new-instance v2, Lcom/example/carcontroller/Section;

    .line 39
    sget v3, Lcom/example/carcontroller/R$drawable;->ic_headlight:I

    sget v4, Lcom/example/carcontroller/R$string;->sec_lights:I

    .line 40
    new-array v0, v0, [Lcom/example/carcontroller/Control;

    new-instance v6, Lcom/example/carcontroller/Control;

    sget v12, Lcom/example/carcontroller/R$drawable;->ic_headlight:I

    sget v13, Lcom/example/carcontroller/R$string;->lbl_headlights:I

    sget v14, Lcom/example/carcontroller/R$string;->act_on:I

    const-string v15, "CMD_HEADLIGHTS_ON"

    sget v8, Lcom/example/carcontroller/R$string;->act_lights_off:I

    invoke-static {v8}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v16

    const-string v17, "CMD_HEADLIGHTS_OFF"

    move-object v11, v6

    invoke-direct/range {v11 .. v17}, Lcom/example/carcontroller/Control;-><init>(IIILjava/lang/String;Ljava/lang/Integer;Ljava/lang/String;)V

    aput-object v6, v0, v7

    .line 41
    new-instance v6, Lcom/example/carcontroller/Control;

    sget v19, Lcom/example/carcontroller/R$drawable;->ic_highbeam:I

    sget v20, Lcom/example/carcontroller/R$string;->lbl_highbeam:I

    sget v21, Lcom/example/carcontroller/R$string;->act_on:I

    const-string v22, "CMD_HIGHBEAM_ON"

    sget v8, Lcom/example/carcontroller/R$string;->act_lights_off:I

    invoke-static {v8}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v23

    const-string v24, "CMD_HIGHBEAM_OFF"

    move-object/from16 v18, v6

    invoke-direct/range {v18 .. v24}, Lcom/example/carcontroller/Control;-><init>(IIILjava/lang/String;Ljava/lang/Integer;Ljava/lang/String;)V

    aput-object v6, v0, v9

    .line 40
    nop

    .line 42
    new-instance v6, Lcom/example/carcontroller/Control;

    sget v12, Lcom/example/carcontroller/R$drawable;->ic_interior:I

    sget v13, Lcom/example/carcontroller/R$string;->lbl_interior:I

    sget v14, Lcom/example/carcontroller/R$string;->act_on:I

    const-string v15, "CMD_INTERIOR_ON"

    sget v8, Lcom/example/carcontroller/R$string;->act_lights_off:I

    invoke-static {v8}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v16

    const-string v17, "CMD_INTERIOR_OFF"

    move-object v11, v6

    invoke-direct/range {v11 .. v17}, Lcom/example/carcontroller/Control;-><init>(IIILjava/lang/String;Ljava/lang/Integer;Ljava/lang/String;)V

    aput-object v6, v0, v10

    .line 40
    nop

    .line 43
    new-instance v6, Lcom/example/carcontroller/Control;

    sget v19, Lcom/example/carcontroller/R$drawable;->ic_fog:I

    sget v20, Lcom/example/carcontroller/R$string;->lbl_fog:I

    sget v21, Lcom/example/carcontroller/R$string;->act_on:I

    const-string v22, "CMD_FOG_ON"

    sget v8, Lcom/example/carcontroller/R$string;->act_lights_off:I

    invoke-static {v8}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v23

    const-string v24, "CMD_FOG_OFF"

    move-object/from16 v18, v6

    invoke-direct/range {v18 .. v24}, Lcom/example/carcontroller/Control;-><init>(IIILjava/lang/String;Ljava/lang/Integer;Ljava/lang/String;)V

    aput-object v6, v0, v5

    .line 40
    nop

    .line 44
    new-instance v6, Lcom/example/carcontroller/Control;

    sget v12, Lcom/example/carcontroller/R$drawable;->ic_hazard:I

    sget v13, Lcom/example/carcontroller/R$string;->lbl_hazard:I

    sget v14, Lcom/example/carcontroller/R$string;->act_on:I

    const-string v15, "CMD_HAZARD_ON"

    sget v8, Lcom/example/carcontroller/R$string;->act_off:I

    invoke-static {v8}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v16

    const-string v17, "CMD_HAZARD_OFF"

    move-object v11, v6

    invoke-direct/range {v11 .. v17}, Lcom/example/carcontroller/Control;-><init>(IIILjava/lang/String;Ljava/lang/Integer;Ljava/lang/String;)V

    const/4 v8, 0x4

    aput-object v6, v0, v8

    .line 40
    nop

    .line 39
    invoke-static {v0}, Lkotlin/collections/CollectionsKt;->listOf([Ljava/lang/Object;)Ljava/util/List;

    move-result-object v0

    .line 38
    invoke-direct {v2, v3, v4, v0}, Lcom/example/carcontroller/Section;-><init>(IILjava/util/List;)V

    aput-object v2, v1, v10

    .line 25
    nop

    .line 47
    new-instance v0, Lcom/example/carcontroller/Section;

    .line 48
    sget v2, Lcom/example/carcontroller/R$drawable;->ic_lock:I

    sget v3, Lcom/example/carcontroller/R$string;->sec_security:I

    .line 49
    new-array v4, v10, [Lcom/example/carcontroller/Control;

    new-instance v6, Lcom/example/carcontroller/Control;

    sget v12, Lcom/example/carcontroller/R$drawable;->ic_lock:I

    sget v13, Lcom/example/carcontroller/R$string;->lbl_doors:I

    sget v14, Lcom/example/carcontroller/R$string;->act_open:I

    const-string v15, "CMD_DOOR_UNLOCK"

    sget v11, Lcom/example/carcontroller/R$string;->act_lock:I

    invoke-static {v11}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v16

    const-string v17, "CMD_DOOR_LOCK"

    move-object v11, v6

    invoke-direct/range {v11 .. v17}, Lcom/example/carcontroller/Control;-><init>(IIILjava/lang/String;Ljava/lang/Integer;Ljava/lang/String;)V

    aput-object v6, v4, v7

    .line 50
    new-instance v6, Lcom/example/carcontroller/Control;

    sget v19, Lcom/example/carcontroller/R$drawable;->ic_car:I

    sget v20, Lcom/example/carcontroller/R$string;->lbl_trunk:I

    sget v21, Lcom/example/carcontroller/R$string;->act_open:I

    const-string v22, "CMD_TRUNK_OPEN"

    sget v11, Lcom/example/carcontroller/R$string;->act_close:I

    invoke-static {v11}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v23

    const-string v24, "CMD_TRUNK_CLOSE"

    move-object/from16 v18, v6

    invoke-direct/range {v18 .. v24}, Lcom/example/carcontroller/Control;-><init>(IIILjava/lang/String;Ljava/lang/Integer;Ljava/lang/String;)V

    aput-object v6, v4, v9

    .line 49
    nop

    .line 48
    invoke-static {v4}, Lkotlin/collections/CollectionsKt;->listOf([Ljava/lang/Object;)Ljava/util/List;

    move-result-object v4

    .line 47
    invoke-direct {v0, v2, v3, v4}, Lcom/example/carcontroller/Section;-><init>(IILjava/util/List;)V

    aput-object v0, v1, v5

    .line 25
    nop

    .line 53
    new-instance v0, Lcom/example/carcontroller/Section;

    .line 54
    sget v2, Lcom/example/carcontroller/R$drawable;->ic_horn:I

    sget v3, Lcom/example/carcontroller/R$string;->sec_sound:I

    .line 55
    new-array v4, v10, [Lcom/example/carcontroller/Control;

    new-instance v5, Lcom/example/carcontroller/Control;

    sget v11, Lcom/example/carcontroller/R$drawable;->ic_horn:I

    sget v12, Lcom/example/carcontroller/R$string;->lbl_horn:I

    sget v13, Lcom/example/carcontroller/R$string;->act_horn:I

    const-string v14, "CMD_HORN"

    const/4 v15, 0x0

    const/16 v16, 0x0

    const/16 v17, 0x30

    const/16 v18, 0x0

    move-object v10, v5

    invoke-direct/range {v10 .. v18}, Lcom/example/carcontroller/Control;-><init>(IIILjava/lang/String;Ljava/lang/Integer;Ljava/lang/String;ILkotlin/jvm/internal/DefaultConstructorMarker;)V

    aput-object v5, v4, v7

    .line 56
    new-instance v5, Lcom/example/carcontroller/Control;

    sget v20, Lcom/example/carcontroller/R$drawable;->ic_radio:I

    sget v21, Lcom/example/carcontroller/R$string;->lbl_radio:I

    sget v22, Lcom/example/carcontroller/R$string;->act_on:I

    const-string v23, "CMD_RADIO_ON"

    sget v6, Lcom/example/carcontroller/R$string;->act_off:I

    invoke-static {v6}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v24

    const-string v25, "CMD_RADIO_OFF"

    move-object/from16 v19, v5

    invoke-direct/range {v19 .. v25}, Lcom/example/carcontroller/Control;-><init>(IIILjava/lang/String;Ljava/lang/Integer;Ljava/lang/String;)V

    aput-object v5, v4, v9

    .line 55
    nop

    .line 54
    invoke-static {v4}, Lkotlin/collections/CollectionsKt;->listOf([Ljava/lang/Object;)Ljava/util/List;

    move-result-object v4

    .line 53
    invoke-direct {v0, v2, v3, v4}, Lcom/example/carcontroller/Section;-><init>(IILjava/util/List;)V

    .line 60
    new-instance v0, Lcom/example/carcontroller/Section;

    .line 61
    sget v2, Lcom/example/carcontroller/R$drawable;->ic_mirror:I

    sget v3, Lcom/example/carcontroller/R$string;->sec_vhal:I

    .line 62
    const/16 v4, 0xb

    new-array v4, v4, [Lcom/example/carcontroller/Control;
    new-instance v5, Lcom/example/carcontroller/Control;

    sget v20, Lcom/example/carcontroller/R$drawable;->ic_mirror:I

    sget v21, Lcom/example/carcontroller/R$string;->lbl_mirror_l:I

    sget v22, Lcom/example/carcontroller/R$string;->act_fold:I

    const-string v23, "CMD_MIRROR_FOLD_L"

    sget v6, Lcom/example/carcontroller/R$string;->act_unfold:I

    invoke-static {v6}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v24

    const-string v25, "CMD_MIRROR_UNFOLD_L"

    move-object/from16 v19, v5

    invoke-direct/range {v19 .. v25}, Lcom/example/carcontroller/Control;-><init>(IIILjava/lang/String;Ljava/lang/Integer;Ljava/lang/String;)V

    const/16 v6, 0x0

    aput-object v5, v4, v6

    .line 61
    nop

    new-instance v5, Lcom/example/carcontroller/Control;

    sget v20, Lcom/example/carcontroller/R$drawable;->ic_mirror:I

    sget v21, Lcom/example/carcontroller/R$string;->lbl_mirror_r:I

    sget v22, Lcom/example/carcontroller/R$string;->act_fold:I

    const-string v23, "CMD_MIRROR_FOLD_R"

    sget v6, Lcom/example/carcontroller/R$string;->act_unfold:I

    invoke-static {v6}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v24

    const-string v25, "CMD_MIRROR_UNFOLD_R"

    move-object/from16 v19, v5

    invoke-direct/range {v19 .. v25}, Lcom/example/carcontroller/Control;-><init>(IIILjava/lang/String;Ljava/lang/Integer;Ljava/lang/String;)V

    const/16 v6, 0x1

    aput-object v5, v4, v6

    .line 61
    nop

    new-instance v5, Lcom/example/carcontroller/Control;

    sget v20, Lcom/example/carcontroller/R$drawable;->ic_lock:I

    sget v21, Lcom/example/carcontroller/R$string;->lbl_childlock_l:I

    sget v22, Lcom/example/carcontroller/R$string;->act_on:I

    const-string v23, "CMD_CHILDLOCK_L_ON"

    sget v6, Lcom/example/carcontroller/R$string;->act_off:I

    invoke-static {v6}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v24

    const-string v25, "CMD_CHILDLOCK_L_OFF"

    move-object/from16 v19, v5

    invoke-direct/range {v19 .. v25}, Lcom/example/carcontroller/Control;-><init>(IIILjava/lang/String;Ljava/lang/Integer;Ljava/lang/String;)V

    const/16 v6, 0x2

    aput-object v5, v4, v6

    .line 61
    nop

    new-instance v5, Lcom/example/carcontroller/Control;

    sget v20, Lcom/example/carcontroller/R$drawable;->ic_lock:I

    sget v21, Lcom/example/carcontroller/R$string;->lbl_childlock_r:I

    sget v22, Lcom/example/carcontroller/R$string;->act_on:I

    const-string v23, "CMD_CHILDLOCK_R_ON"

    sget v6, Lcom/example/carcontroller/R$string;->act_off:I

    invoke-static {v6}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v24

    const-string v25, "CMD_CHILDLOCK_R_OFF"

    move-object/from16 v19, v5

    invoke-direct/range {v19 .. v25}, Lcom/example/carcontroller/Control;-><init>(IIILjava/lang/String;Ljava/lang/Integer;Ljava/lang/String;)V

    const/16 v6, 0x3

    aput-object v5, v4, v6

    .line 61
    nop

    new-instance v5, Lcom/example/carcontroller/Control;

    sget v20, Lcom/example/carcontroller/R$drawable;->ic_car:I

    sget v21, Lcom/example/carcontroller/R$string;->lbl_frunk:I

    sget v22, Lcom/example/carcontroller/R$string;->act_open:I

    const-string v23, "CMD_FRONTTRUNK_OPEN"

    sget v6, Lcom/example/carcontroller/R$string;->act_close:I

    invoke-static {v6}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v24

    const-string v25, "CMD_FRONTTRUNK_CLOSE"

    move-object/from16 v19, v5

    invoke-direct/range {v19 .. v25}, Lcom/example/carcontroller/Control;-><init>(IIILjava/lang/String;Ljava/lang/Integer;Ljava/lang/String;)V

    const/16 v6, 0x4

    aput-object v5, v4, v6

    .line 61
    nop

    new-instance v5, Lcom/example/carcontroller/Control;

    sget v20, Lcom/example/carcontroller/R$drawable;->ic_key:I

    sget v21, Lcom/example/carcontroller/R$string;->lbl_glovebox:I

    sget v22, Lcom/example/carcontroller/R$string;->act_open:I

    const-string v23, "CMD_GLOVEBOX_OPEN"

    sget v6, Lcom/example/carcontroller/R$string;->act_close:I

    invoke-static {v6}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v24

    const-string v25, "CMD_GLOVEBOX_CLOSE"

    move-object/from16 v19, v5

    invoke-direct/range {v19 .. v25}, Lcom/example/carcontroller/Control;-><init>(IIILjava/lang/String;Ljava/lang/Integer;Ljava/lang/String;)V

    const/16 v6, 0x5

    aput-object v5, v4, v6

    .line 61
    nop

    new-instance v5, Lcom/example/carcontroller/Control;

    sget v20, Lcom/example/carcontroller/R$drawable;->ic_car:I

    sget v21, Lcom/example/carcontroller/R$string;->lbl_fuelcap:I

    sget v22, Lcom/example/carcontroller/R$string;->act_open:I

    const-string v23, "CMD_FUELCAP_OPEN"

    sget v6, Lcom/example/carcontroller/R$string;->act_close:I

    invoke-static {v6}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v24

    const-string v25, "CMD_FUELCAP_CLOSE"

    move-object/from16 v19, v5

    invoke-direct/range {v19 .. v25}, Lcom/example/carcontroller/Control;-><init>(IIILjava/lang/String;Ljava/lang/Integer;Ljava/lang/String;)V

    const/16 v6, 0x6

    aput-object v5, v4, v6

    .line 61
    nop

    new-instance v5, Lcom/example/carcontroller/Control;

    sget v20, Lcom/example/carcontroller/R$drawable;->ic_interior:I

    sget v21, Lcom/example/carcontroller/R$string;->lbl_ambient:I

    sget v22, Lcom/example/carcontroller/R$string;->act_on:I

    const-string v23, "CMD_AMBIENT_ON"

    sget v6, Lcom/example/carcontroller/R$string;->act_off:I

    invoke-static {v6}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v24

    const-string v25, "CMD_AMBIENT_OFF"

    move-object/from16 v19, v5

    invoke-direct/range {v19 .. v25}, Lcom/example/carcontroller/Control;-><init>(IIILjava/lang/String;Ljava/lang/Integer;Ljava/lang/String;)V

    const/16 v6, 0x7

    aput-object v5, v4, v6

    .line 61
    nop

    new-instance v5, Lcom/example/carcontroller/Control;

    sget v20, Lcom/example/carcontroller/R$drawable;->ic_car:I

    sget v21, Lcom/example/carcontroller/R$string;->lbl_display:I

    sget v22, Lcom/example/carcontroller/R$string;->act_off:I

    const-string v23, "CMD_DISPLAY_OFF"

    sget v6, Lcom/example/carcontroller/R$string;->act_on:I

    invoke-static {v6}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v24

    const-string v25, "CMD_DISPLAY_ON"

    move-object/from16 v19, v5

    invoke-direct/range {v19 .. v25}, Lcom/example/carcontroller/Control;-><init>(IIILjava/lang/String;Ljava/lang/Integer;Ljava/lang/String;)V

    const/16 v6, 0x8

    aput-object v5, v4, v6

    .line 61
    nop

    new-instance v5, Lcom/example/carcontroller/Control;

    sget v20, Lcom/example/carcontroller/R$drawable;->ic_seat_heat:I

    sget v21, Lcom/example/carcontroller/R$string;->lbl_seat_vent:I

    sget v22, Lcom/example/carcontroller/R$string;->act_on:I

    const-string v23, "CMD_SEAT_VENT_ON"

    sget v6, Lcom/example/carcontroller/R$string;->act_off:I

    invoke-static {v6}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v24

    const-string v25, "CMD_SEAT_VENT_OFF"

    move-object/from16 v19, v5

    invoke-direct/range {v19 .. v25}, Lcom/example/carcontroller/Control;-><init>(IIILjava/lang/String;Ljava/lang/Integer;Ljava/lang/String;)V

    const/16 v6, 0x9

    aput-object v5, v4, v6

    .line 61
    nop

    new-instance v5, Lcom/example/carcontroller/Control;

    sget v20, Lcom/example/carcontroller/R$drawable;->ic_car:I

    sget v21, Lcom/example/carcontroller/R$string;->lbl_vhal:I

    sget v22, Lcom/example/carcontroller/R$string;->act_list:I

    const-string v23, "CMD_VHAL_LIST"

    sget v6, Lcom/example/carcontroller/R$string;->act_read:I

    invoke-static {v6}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v24

    const-string v25, "CMD_VHAL_PING"

    move-object/from16 v19, v5

    invoke-direct/range {v19 .. v25}, Lcom/example/carcontroller/Control;-><init>(IIILjava/lang/String;Ljava/lang/Integer;Ljava/lang/String;)V

    const/16 v6, 0xa

    aput-object v5, v4, v6

    .line 61
    nop

    .line 60
    invoke-static {v4}, Lkotlin/collections/CollectionsKt;->listOf([Ljava/lang/Object;)Ljava/util/List;

    move-result-object v4

    .line 59
    invoke-direct {v0, v2, v3, v4}, Lcom/example/carcontroller/Section;-><init>(IILjava/util/List;)V

    const/16 v8, 0x5

    aput-object v0, v1, v8

    .line 25
    nop

    .line 24
    invoke-static {v1}, Lkotlin/collections/CollectionsKt;->listOf([Ljava/lang/Object;)Ljava/util/List;

    move-result-object v0

    sput-object v0, Lcom/example/carcontroller/Controls;->sections:Ljava/util/List;

    return-void
.end method

.method private constructor <init>()V
    .locals 0

    .line 23
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public final getSections()Ljava/util/List;
    .locals 1
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Ljava/util/List<",
            "Lcom/example/carcontroller/Section;",
            ">;"
        }
    .end annotation

    .line 24
    sget-object v0, Lcom/example/carcontroller/Controls;->sections:Ljava/util/List;

    return-object v0
.end method
