.class public final synthetic Lcom/example/carcontroller/MainActivity$autoPing$1$$ExternalSyntheticLambda0;
.super Ljava/lang/Object;
.source "D8$$SyntheticClass"

# interfaces
.implements Ljava/lang/Runnable;


# instance fields
.field public final synthetic f$0:Z

.field public final synthetic f$1:Lcom/example/carcontroller/MainActivity;


# direct methods
.method public synthetic constructor <init>(ZLcom/example/carcontroller/MainActivity;)V
    .locals 0

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-boolean p1, p0, Lcom/example/carcontroller/MainActivity$autoPing$1$$ExternalSyntheticLambda0;->f$0:Z

    iput-object p2, p0, Lcom/example/carcontroller/MainActivity$autoPing$1$$ExternalSyntheticLambda0;->f$1:Lcom/example/carcontroller/MainActivity;

    return-void
.end method


# virtual methods
.method public final run()V
    .locals 2

    iget-boolean v0, p0, Lcom/example/carcontroller/MainActivity$autoPing$1$$ExternalSyntheticLambda0;->f$0:Z

    iget-object v1, p0, Lcom/example/carcontroller/MainActivity$autoPing$1$$ExternalSyntheticLambda0;->f$1:Lcom/example/carcontroller/MainActivity;

    invoke-static {v0, v1}, Lcom/example/carcontroller/MainActivity$autoPing$1;->$r8$lambda$ANJKr8dUHnApsbp72I-SeL4pjNo(ZLcom/example/carcontroller/MainActivity;)V

    return-void
.end method
