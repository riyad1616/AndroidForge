.class public final synthetic Lcom/example/carcontroller/MainActivity$connectAndTest$1$$ExternalSyntheticLambda0;
.super Ljava/lang/Object;
.source "D8$$SyntheticClass"

# interfaces
.implements Ljava/lang/Runnable;


# instance fields
.field public final synthetic f$0:Lcom/example/carcontroller/MainActivity;

.field public final synthetic f$1:Lcom/example/carcontroller/CarClient$Result;


# direct methods
.method public synthetic constructor <init>(Lcom/example/carcontroller/MainActivity;Lcom/example/carcontroller/CarClient$Result;)V
    .locals 0

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Lcom/example/carcontroller/MainActivity$connectAndTest$1$$ExternalSyntheticLambda0;->f$0:Lcom/example/carcontroller/MainActivity;

    iput-object p2, p0, Lcom/example/carcontroller/MainActivity$connectAndTest$1$$ExternalSyntheticLambda0;->f$1:Lcom/example/carcontroller/CarClient$Result;

    return-void
.end method


# virtual methods
.method public final run()V
    .locals 2

    iget-object v0, p0, Lcom/example/carcontroller/MainActivity$connectAndTest$1$$ExternalSyntheticLambda0;->f$0:Lcom/example/carcontroller/MainActivity;

    iget-object v1, p0, Lcom/example/carcontroller/MainActivity$connectAndTest$1$$ExternalSyntheticLambda0;->f$1:Lcom/example/carcontroller/CarClient$Result;

    invoke-static {v0, v1}, Lcom/example/carcontroller/MainActivity$connectAndTest$1;->$r8$lambda$pNN5WJaOHApDGfZyZTQlo2MKYzY(Lcom/example/carcontroller/MainActivity;Lcom/example/carcontroller/CarClient$Result;)V

    return-void
.end method
