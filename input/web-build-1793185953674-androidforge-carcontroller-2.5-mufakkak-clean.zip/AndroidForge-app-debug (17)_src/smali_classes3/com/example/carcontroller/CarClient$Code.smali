.class public final enum Lcom/example/carcontroller/CarClient$Code;
.super Ljava/lang/Enum;
.source "CarClient.kt"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/example/carcontroller/CarClient;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x4019
    name = "Code"
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "Ljava/lang/Enum<",
        "Lcom/example/carcontroller/CarClient$Code;",
        ">;"
    }
.end annotation

.annotation runtime Lkotlin/Metadata;
    d1 = {
        "\u0000\u000c\n\u0002\u0018\u0002\n\u0002\u0010\u0010\n\u0002\u0008\r\u0008\u0086\u0081\u0002\u0018\u00002\u0008\u0012\u0004\u0012\u00020\u00000\u0001B\u0007\u0008\u0002\u00a2\u0006\u0002\u0010\u0002j\u0002\u0008\u0003j\u0002\u0008\u0004j\u0002\u0008\u0005j\u0002\u0008\u0006j\u0002\u0008\u0007j\u0002\u0008\u0008j\u0002\u0008\tj\u0002\u0008\nj\u0002\u0008\u000bj\u0002\u0008\u000cj\u0002\u0008\r\u00a8\u0006\u000e"
    }
    d2 = {
        "Lcom/example/carcontroller/CarClient$Code;",
        "",
        "(Ljava/lang/String;I)V",
        "OK",
        "AUTH",
        "LOCKED",
        "UNKNOWN",
        "EXEC",
        "FORMAT",
        "UNREACHABLE",
        "TIMEOUT",
        "BAD_IP",
        "NO_REPLY",
        "IO",
        "app_debug"
    }
    k = 0x1
    mv = {
        0x1,
        0x9,
        0x0
    }
    xi = 0x30
.end annotation


# static fields
.field private static final synthetic $ENTRIES:Lkotlin/enums/EnumEntries;

.field private static final synthetic $VALUES:[Lcom/example/carcontroller/CarClient$Code;

.field public static final enum AUTH:Lcom/example/carcontroller/CarClient$Code;

.field public static final enum BAD_IP:Lcom/example/carcontroller/CarClient$Code;

.field public static final enum EXEC:Lcom/example/carcontroller/CarClient$Code;

.field public static final enum FORMAT:Lcom/example/carcontroller/CarClient$Code;

.field public static final enum IO:Lcom/example/carcontroller/CarClient$Code;

.field public static final enum LOCKED:Lcom/example/carcontroller/CarClient$Code;

.field public static final enum NO_REPLY:Lcom/example/carcontroller/CarClient$Code;

.field public static final enum OK:Lcom/example/carcontroller/CarClient$Code;

.field public static final enum TIMEOUT:Lcom/example/carcontroller/CarClient$Code;

.field public static final enum UNKNOWN:Lcom/example/carcontroller/CarClient$Code;

.field public static final enum UNREACHABLE:Lcom/example/carcontroller/CarClient$Code;


# direct methods
.method private static final synthetic $values()[Lcom/example/carcontroller/CarClient$Code;
    .locals 11

    sget-object v0, Lcom/example/carcontroller/CarClient$Code;->OK:Lcom/example/carcontroller/CarClient$Code;

    sget-object v1, Lcom/example/carcontroller/CarClient$Code;->AUTH:Lcom/example/carcontroller/CarClient$Code;

    sget-object v2, Lcom/example/carcontroller/CarClient$Code;->LOCKED:Lcom/example/carcontroller/CarClient$Code;

    sget-object v3, Lcom/example/carcontroller/CarClient$Code;->UNKNOWN:Lcom/example/carcontroller/CarClient$Code;

    sget-object v4, Lcom/example/carcontroller/CarClient$Code;->EXEC:Lcom/example/carcontroller/CarClient$Code;

    sget-object v5, Lcom/example/carcontroller/CarClient$Code;->FORMAT:Lcom/example/carcontroller/CarClient$Code;

    sget-object v6, Lcom/example/carcontroller/CarClient$Code;->UNREACHABLE:Lcom/example/carcontroller/CarClient$Code;

    sget-object v7, Lcom/example/carcontroller/CarClient$Code;->TIMEOUT:Lcom/example/carcontroller/CarClient$Code;

    sget-object v8, Lcom/example/carcontroller/CarClient$Code;->BAD_IP:Lcom/example/carcontroller/CarClient$Code;

    sget-object v9, Lcom/example/carcontroller/CarClient$Code;->NO_REPLY:Lcom/example/carcontroller/CarClient$Code;

    sget-object v10, Lcom/example/carcontroller/CarClient$Code;->IO:Lcom/example/carcontroller/CarClient$Code;

    filled-new-array/range {v0 .. v10}, [Lcom/example/carcontroller/CarClient$Code;

    move-result-object v0

    return-object v0
.end method

.method static constructor <clinit>()V
    .locals 3

    .line 27
    new-instance v0, Lcom/example/carcontroller/CarClient$Code;

    const-string v1, "OK"

    const/4 v2, 0x0

    invoke-direct {v0, v1, v2}, Lcom/example/carcontroller/CarClient$Code;-><init>(Ljava/lang/String;I)V

    sput-object v0, Lcom/example/carcontroller/CarClient$Code;->OK:Lcom/example/carcontroller/CarClient$Code;

    new-instance v0, Lcom/example/carcontroller/CarClient$Code;

    const-string v1, "AUTH"

    const/4 v2, 0x1

    invoke-direct {v0, v1, v2}, Lcom/example/carcontroller/CarClient$Code;-><init>(Ljava/lang/String;I)V

    sput-object v0, Lcom/example/carcontroller/CarClient$Code;->AUTH:Lcom/example/carcontroller/CarClient$Code;

    new-instance v0, Lcom/example/carcontroller/CarClient$Code;

    const-string v1, "LOCKED"

    const/4 v2, 0x2

    invoke-direct {v0, v1, v2}, Lcom/example/carcontroller/CarClient$Code;-><init>(Ljava/lang/String;I)V

    sput-object v0, Lcom/example/carcontroller/CarClient$Code;->LOCKED:Lcom/example/carcontroller/CarClient$Code;

    new-instance v0, Lcom/example/carcontroller/CarClient$Code;

    const-string v1, "UNKNOWN"

    const/4 v2, 0x3

    invoke-direct {v0, v1, v2}, Lcom/example/carcontroller/CarClient$Code;-><init>(Ljava/lang/String;I)V

    sput-object v0, Lcom/example/carcontroller/CarClient$Code;->UNKNOWN:Lcom/example/carcontroller/CarClient$Code;

    new-instance v0, Lcom/example/carcontroller/CarClient$Code;

    const-string v1, "EXEC"

    const/4 v2, 0x4

    invoke-direct {v0, v1, v2}, Lcom/example/carcontroller/CarClient$Code;-><init>(Ljava/lang/String;I)V

    sput-object v0, Lcom/example/carcontroller/CarClient$Code;->EXEC:Lcom/example/carcontroller/CarClient$Code;

    new-instance v0, Lcom/example/carcontroller/CarClient$Code;

    const-string v1, "FORMAT"

    const/4 v2, 0x5

    invoke-direct {v0, v1, v2}, Lcom/example/carcontroller/CarClient$Code;-><init>(Ljava/lang/String;I)V

    sput-object v0, Lcom/example/carcontroller/CarClient$Code;->FORMAT:Lcom/example/carcontroller/CarClient$Code;

    new-instance v0, Lcom/example/carcontroller/CarClient$Code;

    const-string v1, "UNREACHABLE"

    const/4 v2, 0x6

    invoke-direct {v0, v1, v2}, Lcom/example/carcontroller/CarClient$Code;-><init>(Ljava/lang/String;I)V

    sput-object v0, Lcom/example/carcontroller/CarClient$Code;->UNREACHABLE:Lcom/example/carcontroller/CarClient$Code;

    new-instance v0, Lcom/example/carcontroller/CarClient$Code;

    const-string v1, "TIMEOUT"

    const/4 v2, 0x7

    invoke-direct {v0, v1, v2}, Lcom/example/carcontroller/CarClient$Code;-><init>(Ljava/lang/String;I)V

    sput-object v0, Lcom/example/carcontroller/CarClient$Code;->TIMEOUT:Lcom/example/carcontroller/CarClient$Code;

    new-instance v0, Lcom/example/carcontroller/CarClient$Code;

    const-string v1, "BAD_IP"

    const/16 v2, 0x8

    invoke-direct {v0, v1, v2}, Lcom/example/carcontroller/CarClient$Code;-><init>(Ljava/lang/String;I)V

    sput-object v0, Lcom/example/carcontroller/CarClient$Code;->BAD_IP:Lcom/example/carcontroller/CarClient$Code;

    new-instance v0, Lcom/example/carcontroller/CarClient$Code;

    const-string v1, "NO_REPLY"

    const/16 v2, 0x9

    invoke-direct {v0, v1, v2}, Lcom/example/carcontroller/CarClient$Code;-><init>(Ljava/lang/String;I)V

    sput-object v0, Lcom/example/carcontroller/CarClient$Code;->NO_REPLY:Lcom/example/carcontroller/CarClient$Code;

    new-instance v0, Lcom/example/carcontroller/CarClient$Code;

    const-string v1, "IO"

    const/16 v2, 0xa

    invoke-direct {v0, v1, v2}, Lcom/example/carcontroller/CarClient$Code;-><init>(Ljava/lang/String;I)V

    sput-object v0, Lcom/example/carcontroller/CarClient$Code;->IO:Lcom/example/carcontroller/CarClient$Code;

    invoke-static {}, Lcom/example/carcontroller/CarClient$Code;->$values()[Lcom/example/carcontroller/CarClient$Code;

    move-result-object v0

    sput-object v0, Lcom/example/carcontroller/CarClient$Code;->$VALUES:[Lcom/example/carcontroller/CarClient$Code;

    check-cast v0, [Ljava/lang/Enum;

    invoke-static {v0}, Lkotlin/enums/EnumEntriesKt;->enumEntries([Ljava/lang/Enum;)Lkotlin/enums/EnumEntries;

    move-result-object v0

    sput-object v0, Lcom/example/carcontroller/CarClient$Code;->$ENTRIES:Lkotlin/enums/EnumEntries;

    return-void
.end method

.method private constructor <init>(Ljava/lang/String;I)V
    .locals 0
    .param p1, "$enum$name"    # Ljava/lang/String;
    .param p2, "$enum$ordinal"    # I
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()V"
        }
    .end annotation

    .line 27
    invoke-direct {p0, p1, p2}, Ljava/lang/Enum;-><init>(Ljava/lang/String;I)V

    return-void
.end method

.method public static getEntries()Lkotlin/enums/EnumEntries;
    .locals 1
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Lkotlin/enums/EnumEntries<",
            "Lcom/example/carcontroller/CarClient$Code;",
            ">;"
        }
    .end annotation

    sget-object v0, Lcom/example/carcontroller/CarClient$Code;->$ENTRIES:Lkotlin/enums/EnumEntries;

    return-object v0
.end method

.method public static valueOf(Ljava/lang/String;)Lcom/example/carcontroller/CarClient$Code;
    .locals 1

    const-class v0, Lcom/example/carcontroller/CarClient$Code;

    invoke-static {v0, p0}, Ljava/lang/Enum;->valueOf(Ljava/lang/Class;Ljava/lang/String;)Ljava/lang/Enum;

    move-result-object v0

    check-cast v0, Lcom/example/carcontroller/CarClient$Code;

    return-object v0
.end method

.method public static values()[Lcom/example/carcontroller/CarClient$Code;
    .locals 1

    sget-object v0, Lcom/example/carcontroller/CarClient$Code;->$VALUES:[Lcom/example/carcontroller/CarClient$Code;

    invoke-virtual {v0}, [Ljava/lang/Object;->clone()Ljava/lang/Object;

    move-result-object v0

    check-cast v0, [Lcom/example/carcontroller/CarClient$Code;

    return-object v0
.end method
