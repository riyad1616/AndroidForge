.class public final synthetic Lcom/example/carcontroller/MainActivity$applyPairing$1$$ExternalSyntheticLambda0;
.super Ljava/lang/Object;
.source "D8$$SyntheticClass"

# interfaces
.implements Ljava/lang/Runnable;


# instance fields
.field public final synthetic f$0:Lcom/example/carcontroller/MainActivity;

.field public final synthetic f$1:Ljava/lang/String;

.field public final synthetic f$2:Lcom/example/carcontroller/PairingLink$Data;

.field public final synthetic f$3:Lkotlin/jvm/internal/Ref$ObjectRef;


# direct methods
.method public synthetic constructor <init>(Lcom/example/carcontroller/MainActivity;Ljava/lang/String;Lcom/example/carcontroller/PairingLink$Data;Lkotlin/jvm/internal/Ref$ObjectRef;)V
    .locals 0

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Lcom/example/carcontroller/MainActivity$applyPairing$1$$ExternalSyntheticLambda0;->f$0:Lcom/example/carcontroller/MainActivity;

    iput-object p2, p0, Lcom/example/carcontroller/MainActivity$applyPairing$1$$ExternalSyntheticLambda0;->f$1:Ljava/lang/String;

    iput-object p3, p0, Lcom/example/carcontroller/MainActivity$applyPairing$1$$ExternalSyntheticLambda0;->f$2:Lcom/example/carcontroller/PairingLink$Data;

    iput-object p4, p0, Lcom/example/carcontroller/MainActivity$applyPairing$1$$ExternalSyntheticLambda0;->f$3:Lkotlin/jvm/internal/Ref$ObjectRef;

    return-void
.end method


# virtual methods
.method public final run()V
    .locals 4

    iget-object v0, p0, Lcom/example/carcontroller/MainActivity$applyPairing$1$$ExternalSyntheticLambda0;->f$0:Lcom/example/carcontroller/MainActivity;

    iget-object v1, p0, Lcom/example/carcontroller/MainActivity$applyPairing$1$$ExternalSyntheticLambda0;->f$1:Ljava/lang/String;

    iget-object v2, p0, Lcom/example/carcontroller/MainActivity$applyPairing$1$$ExternalSyntheticLambda0;->f$2:Lcom/example/carcontroller/PairingLink$Data;

    iget-object v3, p0, Lcom/example/carcontroller/MainActivity$applyPairing$1$$ExternalSyntheticLambda0;->f$3:Lkotlin/jvm/internal/Ref$ObjectRef;

    invoke-static {v0, v1, v2, v3}, Lcom/example/carcontroller/MainActivity$applyPairing$1;->$r8$lambda$FWrt3RkOejGtIVq7hJ2n3bbm8Lo(Lcom/example/carcontroller/MainActivity;Ljava/lang/String;Lcom/example/carcontroller/PairingLink$Data;Lkotlin/jvm/internal/Ref$ObjectRef;)V

    return-void
.end method
