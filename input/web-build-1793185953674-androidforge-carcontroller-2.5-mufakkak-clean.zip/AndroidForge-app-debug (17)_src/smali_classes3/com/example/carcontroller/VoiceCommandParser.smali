.class public final Lcom/example/carcontroller/VoiceCommandParser;
.super Ljava/lang/Object;
.source "VoiceCommandParser.kt"


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Lcom/example/carcontroller/VoiceCommandParser$Rule;
    }
.end annotation

.annotation system Ldalvik/annotation/SourceDebugExtension;
    value = "SMAP\nVoiceCommandParser.kt\nKotlin\n*S Kotlin\n*F\n+ 1 VoiceCommandParser.kt\ncom/example/carcontroller/VoiceCommandParser\n+ 2 _Collections.kt\nkotlin/collections/CollectionsKt___CollectionsKt\n*L\n1#1,139:1\n1747#2,3:140\n1747#2,3:143\n1549#2:146\n1620#2,3:147\n1549#2:150\n1620#2,3:151\n1549#2:154\n1620#2,3:155\n*S KotlinDebug\n*F\n+ 1 VoiceCommandParser.kt\ncom/example/carcontroller/VoiceCommandParser\n*L\n123#1:140,3\n124#1:143,3\n41#1:146\n41#1:147,3\n46#1:150\n46#1:151,3\n50#1:154\n50#1:155,3\n*E\n"
.end annotation

.annotation runtime Lkotlin/Metadata;
    d1 = {
        "\u0000,\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0002\u0008\u0002\n\u0002\u0010 \n\u0002\u0010\u000e\n\u0000\n\u0002\u0010\"\n\u0002\u0008\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u000b\n\u0002\u0008\n\u0008\u00c6\u0002\u0018\u00002\u00020\u0001:\u0001\u0015B\u0007\u0008\u0002\u00a2\u0006\u0002\u0010\u0002J\u001e\u0010\u000b\u001a\u00020\u000c2\u0006\u0010\r\u001a\u00020\u00052\u000c\u0010\u000e\u001a\u0008\u0012\u0004\u0012\u00020\u00050\u0007H\u0002J\u0010\u0010\u000f\u001a\u00020\u00052\u0006\u0010\u0010\u001a\u00020\u0005H\u0002J\u000e\u0010\u0011\u001a\u00020\u00052\u0006\u0010\u0012\u001a\u00020\u0005J\u0010\u0010\u0013\u001a\u0004\u0018\u00010\u00052\u0006\u0010\u0014\u001a\u00020\u0005R\u0014\u0010\u0003\u001a\u0008\u0012\u0004\u0012\u00020\u00050\u0004X\u0082\u0004\u00a2\u0006\u0002\n\u0000R\u0014\u0010\u0006\u001a\u0008\u0012\u0004\u0012\u00020\u00050\u0007X\u0082\u0004\u00a2\u0006\u0002\n\u0000R\u0014\u0010\u0008\u001a\u0008\u0012\u0004\u0012\u00020\u00050\u0007X\u0082\u0004\u00a2\u0006\u0002\n\u0000R\u0014\u0010\t\u001a\u0008\u0012\u0004\u0012\u00020\n0\u0004X\u0082\u0004\u00a2\u0006\u0002\n\u0000\u00a8\u0006\u0016"
    }
    d2 = {
        "Lcom/example/carcontroller/VoiceCommandParser;",
        "",
        "()V",
        "LIGHT_WORDS",
        "",
        "",
        "OFF_VERBS",
        "",
        "ON_VERBS",
        "RULES",
        "Lcom/example/carcontroller/VoiceCommandParser$Rule;",
        "isVerb",
        "",
        "token",
        "verbs",
        "n",
        "s",
        "normalize",
        "input",
        "parse",
        "text",
        "Rule",
        "app_debug"
    }
    k = 0x1
    mv = {
        0x1,
        0x9,
        0x0
    }
    xi = 0x30
.end annotation


# static fields
.field public static final INSTANCE:Lcom/example/carcontroller/VoiceCommandParser;

.field private static final LIGHT_WORDS:Ljava/util/List;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/List<",
            "Ljava/lang/String;",
            ">;"
        }
    .end annotation
.end field

.field private static final OFF_VERBS:Ljava/util/Set;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/Set<",
            "Ljava/lang/String;",
            ">;"
        }
    .end annotation
.end field

.field private static final ON_VERBS:Ljava/util/Set;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/Set<",
            "Ljava/lang/String;",
            ">;"
        }
    .end annotation
.end field

.field private static final RULES:Ljava/util/List;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/List<",
            "Lcom/example/carcontroller/VoiceCommandParser$Rule;",
            ">;"
        }
    .end annotation
.end field


# direct methods
.method static constructor <clinit>()V
    .locals 23

    new-instance v0, Lcom/example/carcontroller/VoiceCommandParser;

    invoke-direct {v0}, Lcom/example/carcontroller/VoiceCommandParser;-><init>()V

    sput-object v0, Lcom/example/carcontroller/VoiceCommandParser;->INSTANCE:Lcom/example/carcontroller/VoiceCommandParser;

    .line 41
    nop

    .line 40
    const-string v1, "\u062a\u0634\u063a\u064a\u0644"

    const-string v2, "\u0634\u063a\u0644"

    const-string v3, "\u0634\u063a\u0644\u064a"

    const-string v4, "\u0641\u062a\u062d"

    const-string v5, "\u0627\u0641\u062a\u062d"

    const-string v6, "\u0627\u0641\u062a\u062d\u064a"

    const-string v7, "\u062a\u0641\u0639\u064a\u0644"

    const-string v8, "\u0641\u0639\u0644"

    const-string v9, "\u0641\u0639\u0644\u064a"

    const-string v10, "\u0627\u0648\u0642\u062f"

    const-string v11, "\u0627\u064a\u0642\u0627\u062f"

    const-string v12, "\u0641\u0631\u062f"

    const-string v13, "\u0627\u0641\u0631\u062f"

    filled-new-array/range {v1 .. v13}, [Ljava/lang/String;

    move-result-object v0

    .line 39
    invoke-static {v0}, Lkotlin/collections/CollectionsKt;->listOf([Ljava/lang/Object;)Ljava/util/List;

    move-result-object v0

    check-cast v0, Ljava/lang/Iterable;

    .line 41
    nop

    .local v0, "$this$map$iv":Ljava/lang/Iterable;
    const/4 v1, 0x0

    .line 146
    .local v1, "$i$f$map":I
    new-instance v2, Ljava/util/ArrayList;

    const/16 v3, 0xa

    invoke-static {v0, v3}, Lkotlin/collections/CollectionsKt;->collectionSizeOrDefault(Ljava/lang/Iterable;I)I

    move-result v4

    invoke-direct {v2, v4}, Ljava/util/ArrayList;-><init>(I)V

    check-cast v2, Ljava/util/Collection;

    .local v2, "destination$iv$iv":Ljava/util/Collection;
    move-object v4, v0

    .local v4, "$this$mapTo$iv$iv":Ljava/lang/Iterable;
    const/4 v5, 0x0

    .line 147
    .local v5, "$i$f$mapTo":I
    invoke-interface {v4}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    move-result-object v6

    :goto_0
    invoke-interface {v6}, Ljava/util/Iterator;->hasNext()Z

    move-result v7

    if-eqz v7, :cond_0

    invoke-interface {v6}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v7

    .line 148
    .local v7, "item$iv$iv":Ljava/lang/Object;
    move-object v8, v7

    check-cast v8, Ljava/lang/String;

    .local v8, "it":Ljava/lang/String;
    const/4 v9, 0x0

    .line 41
    .local v9, "$i$a$-map-VoiceCommandParser$ON_VERBS$1":I
    sget-object v10, Lcom/example/carcontroller/VoiceCommandParser;->INSTANCE:Lcom/example/carcontroller/VoiceCommandParser;

    invoke-direct {v10, v8}, Lcom/example/carcontroller/VoiceCommandParser;->n(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v8

    .line 148
    .end local v8    # "it":Ljava/lang/String;
    .end local v9    # "$i$a$-map-VoiceCommandParser$ON_VERBS$1":I
    invoke-interface {v2, v8}, Ljava/util/Collection;->add(Ljava/lang/Object;)Z

    goto :goto_0

    .line 149
    .end local v7    # "item$iv$iv":Ljava/lang/Object;
    :cond_0
    nop

    .end local v2    # "destination$iv$iv":Ljava/util/Collection;
    .end local v4    # "$this$mapTo$iv$iv":Ljava/lang/Iterable;
    .end local v5    # "$i$f$mapTo":I
    check-cast v2, Ljava/util/List;

    .line 146
    nop

    .end local v0    # "$this$map$iv":Ljava/lang/Iterable;
    .end local v1    # "$i$f$map":I
    check-cast v2, Ljava/lang/Iterable;

    .line 41
    invoke-static {v2}, Lkotlin/collections/CollectionsKt;->toSet(Ljava/lang/Iterable;)Ljava/util/Set;

    move-result-object v0

    sput-object v0, Lcom/example/carcontroller/VoiceCommandParser;->ON_VERBS:Ljava/util/Set;

    .line 46
    nop

    .line 44
    const-string v4, "\u0627\u0637\u0641\u0627\u0621"

    const-string v5, "\u0627\u0637\u0641\u0627"

    const-string v6, "\u0627\u0637\u0641\u064a"

    const-string v7, "\u0627\u064a\u0642\u0627\u0641"

    const-string v8, "\u0627\u0648\u0642\u0641"

    const-string v9, "\u0648\u0642\u0641"

    const-string v10, "\u0642\u0641\u0644"

    const-string v11, "\u0627\u0642\u0641\u0644"

    const-string v12, "\u0627\u0642\u0641\u0627\u0644"

    const-string v13, "\u063a\u0644\u0642"

    const-string v14, "\u0627\u063a\u0644\u0642"

    const-string v15, "\u0627\u063a\u0644\u0627\u0642"

    .line 45
    const-string v16, "\u0627\u063a\u0644\u0642\u064a"

    .line 44
    nop

    .line 45
    const-string v17, "\u0627\u0642\u0641\u0644\u064a"

    .line 44
    nop

    .line 45
    const-string v18, "\u0637\u064a"

    .line 44
    nop

    .line 45
    const-string v19, "\u0627\u0637\u0648\u064a"

    .line 44
    nop

    .line 45
    const-string v20, "\u0627\u0637\u0648"

    .line 44
    nop

    .line 45
    const-string v21, "\u0627\u0644\u063a\u0627\u0621"

    .line 44
    nop

    .line 45
    const-string v22, "\u0627\u0644\u063a\u064a"

    filled-new-array/range {v4 .. v22}, [Ljava/lang/String;

    move-result-object v0

    .line 44
    nop

    .line 43
    invoke-static {v0}, Lkotlin/collections/CollectionsKt;->listOf([Ljava/lang/Object;)Ljava/util/List;

    move-result-object v0

    check-cast v0, Ljava/lang/Iterable;

    .line 46
    nop

    .restart local v0    # "$this$map$iv":Ljava/lang/Iterable;
    const/4 v1, 0x0

    .line 150
    .restart local v1    # "$i$f$map":I
    new-instance v2, Ljava/util/ArrayList;

    invoke-static {v0, v3}, Lkotlin/collections/CollectionsKt;->collectionSizeOrDefault(Ljava/lang/Iterable;I)I

    move-result v4

    invoke-direct {v2, v4}, Ljava/util/ArrayList;-><init>(I)V

    check-cast v2, Ljava/util/Collection;

    .restart local v2    # "destination$iv$iv":Ljava/util/Collection;
    move-object v4, v0

    .restart local v4    # "$this$mapTo$iv$iv":Ljava/lang/Iterable;
    const/4 v5, 0x0

    .line 151
    .restart local v5    # "$i$f$mapTo":I
    invoke-interface {v4}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    move-result-object v6

    :goto_1
    invoke-interface {v6}, Ljava/util/Iterator;->hasNext()Z

    move-result v7

    if-eqz v7, :cond_1

    invoke-interface {v6}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v7

    .line 152
    .restart local v7    # "item$iv$iv":Ljava/lang/Object;
    move-object v8, v7

    check-cast v8, Ljava/lang/String;

    .restart local v8    # "it":Ljava/lang/String;
    const/4 v9, 0x0

    .line 46
    .local v9, "$i$a$-map-VoiceCommandParser$OFF_VERBS$1":I
    sget-object v10, Lcom/example/carcontroller/VoiceCommandParser;->INSTANCE:Lcom/example/carcontroller/VoiceCommandParser;

    invoke-direct {v10, v8}, Lcom/example/carcontroller/VoiceCommandParser;->n(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v8

    .line 152
    .end local v8    # "it":Ljava/lang/String;
    .end local v9    # "$i$a$-map-VoiceCommandParser$OFF_VERBS$1":I
    invoke-interface {v2, v8}, Ljava/util/Collection;->add(Ljava/lang/Object;)Z

    goto :goto_1

    .line 153
    .end local v7    # "item$iv$iv":Ljava/lang/Object;
    :cond_1
    nop

    .end local v2    # "destination$iv$iv":Ljava/util/Collection;
    .end local v4    # "$this$mapTo$iv$iv":Ljava/lang/Iterable;
    .end local v5    # "$i$f$mapTo":I
    check-cast v2, Ljava/util/List;

    .line 150
    nop

    .end local v0    # "$this$map$iv":Ljava/lang/Iterable;
    .end local v1    # "$i$f$map":I
    check-cast v2, Ljava/lang/Iterable;

    .line 46
    invoke-static {v2}, Lkotlin/collections/CollectionsKt;->toSet(Ljava/lang/Iterable;)Ljava/util/Set;

    move-result-object v0

    sput-object v0, Lcom/example/carcontroller/VoiceCommandParser;->OFF_VERBS:Ljava/util/Set;

    .line 50
    nop

    .line 49
    const-string v4, "\u0636\u0648\u0621"

    const-string v5, "\u0627\u0636\u0648\u0627\u0621"

    const-string v6, "\u0646\u0648\u0631"

    const-string v7, "\u0627\u0646\u0648\u0627\u0631"

    const-string v8, "\u0645\u0635\u0627\u0628\u064a\u062d"

    const-string v9, "\u0645\u0635\u0628\u0627\u062d"

    const-string v10, "\u0643\u0634\u0627\u0641"

    const-string v11, "\u0643\u0634\u0627\u0641\u0627\u062a"

    const-string v12, "\u0627\u0636\u0627\u0621\u0647"

    const-string v13, "\u0644\u0645\u0628\u0647"

    const-string v14, "\u0644\u0645\u0628\u0627\u062a"

    const-string v15, "\u0641\u0648\u0627\u0646\u064a\u0633"

    const-string v16, "\u0641\u0627\u0646\u0648\u0633"

    filled-new-array/range {v4 .. v16}, [Ljava/lang/String;

    move-result-object v0

    .line 48
    invoke-static {v0}, Lkotlin/collections/CollectionsKt;->listOf([Ljava/lang/Object;)Ljava/util/List;

    move-result-object v0

    check-cast v0, Ljava/lang/Iterable;

    .line 50
    nop

    .restart local v0    # "$this$map$iv":Ljava/lang/Iterable;
    const/4 v1, 0x0

    .line 154
    .restart local v1    # "$i$f$map":I
    new-instance v2, Ljava/util/ArrayList;

    invoke-static {v0, v3}, Lkotlin/collections/CollectionsKt;->collectionSizeOrDefault(Ljava/lang/Iterable;I)I

    move-result v4

    invoke-direct {v2, v4}, Ljava/util/ArrayList;-><init>(I)V

    check-cast v2, Ljava/util/Collection;

    .restart local v2    # "destination$iv$iv":Ljava/util/Collection;
    move-object v4, v0

    .restart local v4    # "$this$mapTo$iv$iv":Ljava/lang/Iterable;
    const/4 v5, 0x0

    .line 155
    .restart local v5    # "$i$f$mapTo":I
    invoke-interface {v4}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    move-result-object v6

    :goto_2
    invoke-interface {v6}, Ljava/util/Iterator;->hasNext()Z

    move-result v7

    if-eqz v7, :cond_2

    invoke-interface {v6}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v7

    .line 156
    .restart local v7    # "item$iv$iv":Ljava/lang/Object;
    move-object v8, v7

    check-cast v8, Ljava/lang/String;

    .restart local v8    # "it":Ljava/lang/String;
    const/4 v9, 0x0

    .line 50
    .local v9, "$i$a$-map-VoiceCommandParser$LIGHT_WORDS$1":I
    sget-object v10, Lcom/example/carcontroller/VoiceCommandParser;->INSTANCE:Lcom/example/carcontroller/VoiceCommandParser;

    invoke-direct {v10, v8}, Lcom/example/carcontroller/VoiceCommandParser;->n(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v8

    .line 156
    .end local v8    # "it":Ljava/lang/String;
    .end local v9    # "$i$a$-map-VoiceCommandParser$LIGHT_WORDS$1":I
    invoke-interface {v2, v8}, Ljava/util/Collection;->add(Ljava/lang/Object;)Z

    goto :goto_2

    .line 157
    .end local v7    # "item$iv$iv":Ljava/lang/Object;
    :cond_2
    nop

    .end local v2    # "destination$iv$iv":Ljava/util/Collection;
    .end local v4    # "$this$mapTo$iv$iv":Ljava/lang/Iterable;
    .end local v5    # "$i$f$mapTo":I
    check-cast v2, Ljava/util/List;

    .line 154
    nop

    .line 50
    .end local v0    # "$this$map$iv":Ljava/lang/Iterable;
    .end local v1    # "$i$f$map":I
    sput-object v2, Lcom/example/carcontroller/VoiceCommandParser;->LIGHT_WORDS:Ljava/util/List;

    .line 78
    nop

    .line 79
    const/16 v0, 0xe

    new-array v0, v0, [Lcom/example/carcontroller/VoiceCommandParser$Rule;

    new-instance v1, Lcom/example/carcontroller/VoiceCommandParser$Rule;

    const-string v4, "\u0634\u0628\u0627\u0643"

    const-string v5, "\u0632\u062c\u0627\u062c"

    const-string v6, "\u0646\u0648\u0627\u0641\u0630"

    const-string v7, "\u0646\u0627\u0641\u0630\u0647"

    const-string v8, "\u0634\u0628\u0627\u0628\u064a\u0643"

    filled-new-array {v6, v7, v8, v4, v5}, [Ljava/lang/String;

    move-result-object v4

    invoke-static {v4}, Lkotlin/collections/CollectionsKt;->listOf([Ljava/lang/Object;)Ljava/util/List;

    move-result-object v4

    invoke-static {v4}, Lkotlin/collections/CollectionsKt;->listOf(Ljava/lang/Object;)Ljava/util/List;

    move-result-object v5

    const-string v6, "CMD_WINDOW_OPEN"

    const-string v7, "CMD_WINDOW_CLOSE"

    const/4 v8, 0x0

    const/4 v9, 0x0

    const/4 v10, 0x0

    const/16 v11, 0x38

    const/4 v12, 0x0

    move-object v4, v1

    invoke-direct/range {v4 .. v12}, Lcom/example/carcontroller/VoiceCommandParser$Rule;-><init>(Ljava/util/List;Ljava/lang/String;Ljava/lang/String;ZLjava/util/List;Ljava/lang/String;ILkotlin/jvm/internal/DefaultConstructorMarker;)V

    const/4 v4, 0x0

    aput-object v1, v0, v4

    .line 80
    new-instance v1, Lcom/example/carcontroller/VoiceCommandParser$Rule;

    const-string v5, "\u0633\u0646\u0631\u0648\u0641"

    const-string v6, "\u0628\u0627\u0646\u0648\u0631\u0627\u0645\u0627"

    const-string v7, "\u0633\u0642\u0641"

    filled-new-array {v7, v5, v6}, [Ljava/lang/String;

    move-result-object v5

    invoke-static {v5}, Lkotlin/collections/CollectionsKt;->listOf([Ljava/lang/Object;)Ljava/util/List;

    move-result-object v5

    invoke-static {v5}, Lkotlin/collections/CollectionsKt;->listOf(Ljava/lang/Object;)Ljava/util/List;

    move-result-object v6

    const-string v7, "CMD_SUNROOF_OPEN"

    const-string v8, "CMD_SUNROOF_CLOSE"

    const/4 v9, 0x0

    const/4 v11, 0x0

    const/16 v12, 0x38

    const/4 v13, 0x0

    move-object v5, v1

    invoke-direct/range {v5 .. v13}, Lcom/example/carcontroller/VoiceCommandParser$Rule;-><init>(Ljava/util/List;Ljava/lang/String;Ljava/lang/String;ZLjava/util/List;Ljava/lang/String;ILkotlin/jvm/internal/DefaultConstructorMarker;)V

    const/4 v5, 0x1

    aput-object v1, v0, v5

    .line 79
    nop

    .line 81
    new-instance v1, Lcom/example/carcontroller/VoiceCommandParser$Rule;

    const-string v6, "\u0645\u0628\u0631\u062f"

    const-string v7, "\u062a\u0628\u0631\u064a\u062f"

    const-string v8, "\u0645\u0643\u064a\u0641"

    const-string v9, "\u062a\u0643\u064a\u064a\u0641"

    const-string v10, "\u062a\u0643\u064a\u0641"

    filled-new-array {v8, v9, v10, v6, v7}, [Ljava/lang/String;

    move-result-object v6

    invoke-static {v6}, Lkotlin/collections/CollectionsKt;->listOf([Ljava/lang/Object;)Ljava/util/List;

    move-result-object v6

    invoke-static {v6}, Lkotlin/collections/CollectionsKt;->listOf(Ljava/lang/Object;)Ljava/util/List;

    move-result-object v7

    const-string v8, "CMD_AC_ON"

    const-string v9, "CMD_AC_OFF"

    const/4 v10, 0x1

    const/4 v12, 0x0

    const/16 v13, 0x30

    const/4 v14, 0x0

    move-object v6, v1

    invoke-direct/range {v6 .. v14}, Lcom/example/carcontroller/VoiceCommandParser$Rule;-><init>(Ljava/util/List;Ljava/lang/String;Ljava/lang/String;ZLjava/util/List;Ljava/lang/String;ILkotlin/jvm/internal/DefaultConstructorMarker;)V

    const/4 v6, 0x2

    aput-object v1, v0, v6

    .line 79
    nop

    .line 82
    new-instance v1, Lcom/example/carcontroller/VoiceCommandParser$Rule;

    const-string v7, "\u0645\u0631\u0627\u0647"

    const-string v8, "\u0645\u0631\u0627\u064a"

    const-string v9, "\u0645\u0631\u0627\u064a\u0627"

    filled-new-array {v9, v7, v8}, [Ljava/lang/String;

    move-result-object v7

    invoke-static {v7}, Lkotlin/collections/CollectionsKt;->listOf([Ljava/lang/Object;)Ljava/util/List;

    move-result-object v7

    invoke-static {v7}, Lkotlin/collections/CollectionsKt;->listOf(Ljava/lang/Object;)Ljava/util/List;

    move-result-object v8

    const-string v9, "CMD_MIRROR_UNFOLD"

    const-string v10, "CMD_MIRROR_FOLD"

    const/4 v11, 0x0

    const/4 v13, 0x0

    const/16 v14, 0x38

    const/4 v15, 0x0

    move-object v7, v1

    invoke-direct/range {v7 .. v15}, Lcom/example/carcontroller/VoiceCommandParser$Rule;-><init>(Ljava/util/List;Ljava/lang/String;Ljava/lang/String;ZLjava/util/List;Ljava/lang/String;ILkotlin/jvm/internal/DefaultConstructorMarker;)V

    const/4 v7, 0x3

    aput-object v1, v0, v7

    .line 79
    nop

    .line 83
    new-instance v1, Lcom/example/carcontroller/VoiceCommandParser$Rule;

    .line 85
    new-array v7, v6, [Ljava/util/List;

    const-string v8, "\u0643\u0631\u0627\u0633\u064a"

    const-string v9, "\u0643\u0631\u0633\u064a"

    const-string v10, "\u0645\u0642\u0627\u0639\u062f"

    const-string v11, "\u0645\u0642\u0639\u062f"

    filled-new-array {v10, v11, v8, v9}, [Ljava/lang/String;

    move-result-object v8

    invoke-static {v8}, Lkotlin/collections/CollectionsKt;->listOf([Ljava/lang/Object;)Ljava/util/List;

    move-result-object v8

    aput-object v8, v7, v4

    .line 86
    const-string v9, "\u062a\u0633\u062e\u064a\u0646"

    const-string v10, "\u0633\u062e\u0646"

    const-string v11, "\u062a\u062f\u0641\u064a"

    const-string v12, "\u062f\u0641\u0627"

    const-string v13, "\u062f\u0641\u064a"

    const-string v14, "\u062d\u0631\u0627\u0631\u0647"

    filled-new-array/range {v9 .. v14}, [Ljava/lang/String;

    move-result-object v8

    invoke-static {v8}, Lkotlin/collections/CollectionsKt;->listOf([Ljava/lang/Object;)Ljava/util/List;

    move-result-object v8

    aput-object v8, v7, v5

    .line 85
    nop

    .line 84
    invoke-static {v7}, Lkotlin/collections/CollectionsKt;->listOf([Ljava/lang/Object;)Ljava/util/List;

    move-result-object v9

    .line 88
    const-string v10, "CMD_SEAT_HEAT_ON"

    const-string v11, "CMD_SEAT_HEAT_OFF"

    const/4 v12, 0x1

    .line 83
    const/4 v13, 0x0

    const/4 v14, 0x0

    const/16 v15, 0x30

    const/16 v16, 0x0

    move-object v8, v1

    invoke-direct/range {v8 .. v16}, Lcom/example/carcontroller/VoiceCommandParser$Rule;-><init>(Ljava/util/List;Ljava/lang/String;Ljava/lang/String;ZLjava/util/List;Ljava/lang/String;ILkotlin/jvm/internal/DefaultConstructorMarker;)V

    const/4 v7, 0x4

    aput-object v1, v0, v7

    .line 79
    nop

    .line 90
    new-instance v1, Lcom/example/carcontroller/VoiceCommandParser$Rule;

    new-array v7, v6, [Ljava/util/List;

    const-string v8, "\u062f\u0627\u062e\u0644"

    invoke-static {v8}, Lkotlin/collections/CollectionsKt;->listOf(Ljava/lang/Object;)Ljava/util/List;

    move-result-object v8

    aput-object v8, v7, v4

    aput-object v2, v7, v5

    invoke-static {v7}, Lkotlin/collections/CollectionsKt;->listOf([Ljava/lang/Object;)Ljava/util/List;

    move-result-object v9

    const-string v10, "CMD_INTERIOR_ON"

    const-string v11, "CMD_INTERIOR_OFF"

    move-object v8, v1

    invoke-direct/range {v8 .. v16}, Lcom/example/carcontroller/VoiceCommandParser$Rule;-><init>(Ljava/util/List;Ljava/lang/String;Ljava/lang/String;ZLjava/util/List;Ljava/lang/String;ILkotlin/jvm/internal/DefaultConstructorMarker;)V

    const/4 v7, 0x5

    aput-object v1, v0, v7

    .line 79
    nop

    .line 91
    new-instance v1, Lcom/example/carcontroller/VoiceCommandParser$Rule;

    .line 92
    new-array v6, v6, [Ljava/util/List;

    const-string v7, "\u0639\u0627\u0644\u064a"

    const-string v8, "\u0645\u0646\u062e\u0641\u0636"

    const-string v9, "\u0648\u0627\u0637\u064a"

    filled-new-array {v7, v8, v9}, [Ljava/lang/String;

    move-result-object v7

    invoke-static {v7}, Lkotlin/collections/CollectionsKt;->listOf([Ljava/lang/Object;)Ljava/util/List;

    move-result-object v7

    aput-object v7, v6, v4

    aput-object v2, v6, v5

    invoke-static {v6}, Lkotlin/collections/CollectionsKt;->listOf([Ljava/lang/Object;)Ljava/util/List;

    move-result-object v4

    .line 93
    const-string v10, "CMD_HIGHBEAM_ON"

    const-string v11, "CMD_HIGHBEAM_OFF"

    filled-new-array {v8, v9}, [Ljava/lang/String;

    move-result-object v5

    invoke-static {v5}, Lkotlin/collections/CollectionsKt;->listOf([Ljava/lang/Object;)Ljava/util/List;

    move-result-object v13

    .line 91
    const/16 v15, 0x20

    move-object v8, v1

    move-object v9, v4

    invoke-direct/range {v8 .. v16}, Lcom/example/carcontroller/VoiceCommandParser$Rule;-><init>(Ljava/util/List;Ljava/lang/String;Ljava/lang/String;ZLjava/util/List;Ljava/lang/String;ILkotlin/jvm/internal/DefaultConstructorMarker;)V

    const/4 v4, 0x6

    aput-object v1, v0, v4

    .line 79
    nop

    .line 95
    new-instance v1, Lcom/example/carcontroller/VoiceCommandParser$Rule;

    const-string v4, "\u0636\u0628\u0627\u0628"

    const-string v5, "\u0634\u0628\u0648\u0631\u0647"

    filled-new-array {v4, v5}, [Ljava/lang/String;

    move-result-object v4

    invoke-static {v4}, Lkotlin/collections/CollectionsKt;->listOf([Ljava/lang/Object;)Ljava/util/List;

    move-result-object v4

    invoke-static {v4}, Lkotlin/collections/CollectionsKt;->listOf(Ljava/lang/Object;)Ljava/util/List;

    move-result-object v6

    const-string v7, "CMD_FOG_ON"

    const-string v8, "CMD_FOG_OFF"

    const/4 v9, 0x1

    const/4 v10, 0x0

    const/4 v11, 0x0

    const/16 v12, 0x30

    const/4 v13, 0x0

    move-object v5, v1

    invoke-direct/range {v5 .. v13}, Lcom/example/carcontroller/VoiceCommandParser$Rule;-><init>(Ljava/util/List;Ljava/lang/String;Ljava/lang/String;ZLjava/util/List;Ljava/lang/String;ILkotlin/jvm/internal/DefaultConstructorMarker;)V

    const/4 v4, 0x7

    aput-object v1, v0, v4

    .line 79
    nop

    .line 96
    new-instance v1, Lcom/example/carcontroller/VoiceCommandParser$Rule;

    .line 97
    const-string v4, "\u0647\u0627\u0632\u0631\u062f"

    const-string v5, "\u062a\u062d\u0630\u064a\u0631"

    const-string v6, "\u0637\u0648\u0627\u0631\u064a"

    const-string v7, "\u0641\u0644\u0627\u0634\u0631"

    const-string v8, "\u0641\u0644\u0627\u0634\u0631\u0627\u062a"

    filled-new-array {v6, v7, v8, v4, v5}, [Ljava/lang/String;

    move-result-object v4

    invoke-static {v4}, Lkotlin/collections/CollectionsKt;->listOf([Ljava/lang/Object;)Ljava/util/List;

    move-result-object v4

    invoke-static {v4}, Lkotlin/collections/CollectionsKt;->listOf(Ljava/lang/Object;)Ljava/util/List;

    move-result-object v6

    .line 98
    const-string v7, "CMD_HAZARD_ON"

    const-string v8, "CMD_HAZARD_OFF"

    .line 96
    move-object v5, v1

    invoke-direct/range {v5 .. v13}, Lcom/example/carcontroller/VoiceCommandParser$Rule;-><init>(Ljava/util/List;Ljava/lang/String;Ljava/lang/String;ZLjava/util/List;Ljava/lang/String;ILkotlin/jvm/internal/DefaultConstructorMarker;)V

    const/16 v4, 0x8

    aput-object v1, v0, v4

    .line 79
    nop

    .line 100
    new-instance v1, Lcom/example/carcontroller/VoiceCommandParser$Rule;

    invoke-static {v2}, Lkotlin/collections/CollectionsKt;->listOf(Ljava/lang/Object;)Ljava/util/List;

    move-result-object v6

    const-string v7, "CMD_HEADLIGHTS_ON"

    const-string v8, "CMD_HEADLIGHTS_OFF"

    move-object v5, v1

    invoke-direct/range {v5 .. v13}, Lcom/example/carcontroller/VoiceCommandParser$Rule;-><init>(Ljava/util/List;Ljava/lang/String;Ljava/lang/String;ZLjava/util/List;Ljava/lang/String;ILkotlin/jvm/internal/DefaultConstructorMarker;)V

    const/16 v2, 0x9

    aput-object v1, v0, v2

    .line 79
    nop

    .line 101
    new-instance v1, Lcom/example/carcontroller/VoiceCommandParser$Rule;

    const-string v2, "\u062d\u0642\u064a\u0628\u0647"

    const-string v4, "=\u0627\u0644\u062e\u0644\u0641"

    const-string v5, "\u0635\u0646\u062f\u0648\u0642"

    const-string v6, "\u0634\u0646\u0637\u0647"

    filled-new-array {v5, v6, v2, v4}, [Ljava/lang/String;

    move-result-object v2

    invoke-static {v2}, Lkotlin/collections/CollectionsKt;->listOf([Ljava/lang/Object;)Ljava/util/List;

    move-result-object v2

    invoke-static {v2}, Lkotlin/collections/CollectionsKt;->listOf(Ljava/lang/Object;)Ljava/util/List;

    move-result-object v5

    const-string v6, "CMD_TRUNK_OPEN"

    const-string v7, "CMD_TRUNK_CLOSE"

    const/4 v8, 0x0

    const/4 v9, 0x0

    const/16 v11, 0x38

    const/4 v12, 0x0

    move-object v4, v1

    invoke-direct/range {v4 .. v12}, Lcom/example/carcontroller/VoiceCommandParser$Rule;-><init>(Ljava/util/List;Ljava/lang/String;Ljava/lang/String;ZLjava/util/List;Ljava/lang/String;ILkotlin/jvm/internal/DefaultConstructorMarker;)V

    aput-object v1, v0, v3

    .line 79
    nop

    .line 102
    new-instance v1, Lcom/example/carcontroller/VoiceCommandParser$Rule;

    const-string v2, "\u0643\u0644\u0627\u0643\u0633"

    const-string v3, "\u0647\u0648\u0631\u0646"

    const-string v4, "\u0645\u0646\u0628\u0647"

    const-string v5, "\u0628\u0648\u0642"

    const-string v6, "\u0646\u0641\u064a\u0631"

    filled-new-array {v4, v5, v6, v2, v3}, [Ljava/lang/String;

    move-result-object v2

    invoke-static {v2}, Lkotlin/collections/CollectionsKt;->listOf([Ljava/lang/Object;)Ljava/util/List;

    move-result-object v2

    invoke-static {v2}, Lkotlin/collections/CollectionsKt;->listOf(Ljava/lang/Object;)Ljava/util/List;

    move-result-object v14

    const/4 v15, 0x0

    const/16 v17, 0x0

    const/16 v18, 0x0

    const-string v19, "CMD_HORN"

    const/16 v20, 0x18

    const/16 v21, 0x0

    move-object v13, v1

    invoke-direct/range {v13 .. v21}, Lcom/example/carcontroller/VoiceCommandParser$Rule;-><init>(Ljava/util/List;Ljava/lang/String;Ljava/lang/String;ZLjava/util/List;Ljava/lang/String;ILkotlin/jvm/internal/DefaultConstructorMarker;)V

    const/16 v2, 0xb

    aput-object v1, v0, v2

    .line 79
    nop

    .line 103
    new-instance v1, Lcom/example/carcontroller/VoiceCommandParser$Rule;

    const-string v2, "\u0645\u0630\u064a\u0627\u0639"

    const-string v3, "\u0627\u0630\u0627\u0639\u0647"

    const-string v4, "\u0631\u0627\u062f\u064a\u0648"

    filled-new-array {v4, v2, v3}, [Ljava/lang/String;

    move-result-object v2

    invoke-static {v2}, Lkotlin/collections/CollectionsKt;->listOf([Ljava/lang/Object;)Ljava/util/List;

    move-result-object v2

    invoke-static {v2}, Lkotlin/collections/CollectionsKt;->listOf(Ljava/lang/Object;)Ljava/util/List;

    move-result-object v4

    const-string v5, "CMD_RADIO_ON"

    const-string v6, "CMD_RADIO_OFF"

    const/4 v7, 0x0

    const/4 v8, 0x0

    const/16 v10, 0x38

    const/4 v11, 0x0

    move-object v3, v1

    invoke-direct/range {v3 .. v11}, Lcom/example/carcontroller/VoiceCommandParser$Rule;-><init>(Ljava/util/List;Ljava/lang/String;Ljava/lang/String;ZLjava/util/List;Ljava/lang/String;ILkotlin/jvm/internal/DefaultConstructorMarker;)V

    const/16 v2, 0xc

    aput-object v1, v0, v2

    .line 79
    nop

    .line 105
    new-instance v1, Lcom/example/carcontroller/VoiceCommandParser$Rule;

    const-string v2, "\u0633\u064a\u0627\u0631\u0647"

    const-string v3, "\u0639\u0631\u0628\u064a\u0647"

    const-string v4, "\u0628\u0627\u0628"

    const-string v5, "\u0627\u0628\u0648\u0627\u0628"

    filled-new-array {v4, v5, v2, v3}, [Ljava/lang/String;

    move-result-object v2

    invoke-static {v2}, Lkotlin/collections/CollectionsKt;->listOf([Ljava/lang/Object;)Ljava/util/List;

    move-result-object v2

    invoke-static {v2}, Lkotlin/collections/CollectionsKt;->listOf(Ljava/lang/Object;)Ljava/util/List;

    move-result-object v4

    const-string v5, "CMD_DOOR_UNLOCK"

    const-string v6, "CMD_DOOR_LOCK"

    move-object v3, v1

    invoke-direct/range {v3 .. v11}, Lcom/example/carcontroller/VoiceCommandParser$Rule;-><init>(Ljava/util/List;Ljava/lang/String;Ljava/lang/String;ZLjava/util/List;Ljava/lang/String;ILkotlin/jvm/internal/DefaultConstructorMarker;)V

    const/16 v2, 0xd

    aput-object v1, v0, v2

    .line 79
    nop

    .line 78
    invoke-static {v0}, Lkotlin/collections/CollectionsKt;->listOf([Ljava/lang/Object;)Ljava/util/List;

    move-result-object v0

    sput-object v0, Lcom/example/carcontroller/VoiceCommandParser;->RULES:Ljava/util/List;

    return-void
.end method

.method private constructor <init>()V
    .locals 0

    .line 14
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method

.method private final isVerb(Ljava/lang/String;Ljava/util/Set;)Z
    .locals 6
    .param p1, "token"    # Ljava/lang/String;
    .param p2, "verbs"    # Ljava/util/Set;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/lang/String;",
            "Ljava/util/Set<",
            "Ljava/lang/String;",
            ">;)Z"
        }
    .end annotation

    .line 112
    invoke-interface {p2, p1}, Ljava/util/Set;->contains(Ljava/lang/Object;)Z

    move-result v0

    const/4 v1, 0x1

    if-eqz v0, :cond_0

    return v1

    .line 113
    :cond_0
    invoke-virtual {p1}, Ljava/lang/String;->length()I

    move-result v0

    const/4 v2, 0x0

    if-le v0, v1, :cond_1

    const-string v0, "\u0628\u0644\u0648"

    check-cast v0, Ljava/lang/CharSequence;

    invoke-virtual {p1, v2}, Ljava/lang/String;->charAt(I)C

    move-result v3

    const/4 v4, 0x2

    const/4 v5, 0x0

    invoke-static {v0, v3, v2, v4, v5}, Lkotlin/text/StringsKt;->contains$default(Ljava/lang/CharSequence;CZILjava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_1

    invoke-virtual {p1, v1}, Ljava/lang/String;->substring(I)Ljava/lang/String;

    move-result-object v0

    const-string v3, "substring(...)"

    invoke-static {v0, v3}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    invoke-interface {p2, v0}, Ljava/util/Set;->contains(Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_1

    return v1

    .line 114
    :cond_1
    return v2
.end method

.method private final n(Ljava/lang/String;)Ljava/lang/String;
    .locals 1
    .param p1, "s"    # Ljava/lang/String;

    .line 35
    invoke-virtual {p0, p1}, Lcom/example/carcontroller/VoiceCommandParser;->normalize(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    return-object v0
.end method


# virtual methods
.method public final normalize(Ljava/lang/String;)Ljava/lang/String;
    .locals 7
    .param p1, "input"    # Ljava/lang/String;

    const-string v0, "input"

    invoke-static {p1, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 20
    new-instance v0, Ljava/lang/StringBuilder;

    invoke-virtual {p1}, Ljava/lang/String;->length()I

    move-result v1

    invoke-direct {v0, v1}, Ljava/lang/StringBuilder;-><init>(I)V

    .line 21
    .local v0, "sb":Ljava/lang/StringBuilder;
    sget-object v1, Ljava/util/Locale;->ROOT:Ljava/util/Locale;

    invoke-virtual {p1, v1}, Ljava/lang/String;->toLowerCase(Ljava/util/Locale;)Ljava/lang/String;

    move-result-object v1

    const-string v2, "toLowerCase(...)"

    invoke-static {v1, v2}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    invoke-virtual {v1}, Ljava/lang/String;->length()I

    move-result v2

    const/4 v3, 0x0

    move v4, v3

    :goto_0
    if-ge v4, v2, :cond_b

    invoke-virtual {v1, v4}, Ljava/lang/String;->charAt(I)C

    move-result v5

    .line 22
    .local v5, "ch":C
    nop

    .line 23
    const/16 v6, 0x64b

    if-gt v6, v5, :cond_0

    const/16 v6, 0x660

    if-ge v5, v6, :cond_0

    const/4 v6, 0x1

    goto :goto_1

    :cond_0
    move v6, v3

    :goto_1
    if-nez v6, :cond_a

    const/16 v6, 0x670

    if-eq v5, v6, :cond_a

    const/16 v6, 0x640

    if-ne v5, v6, :cond_1

    goto :goto_5

    .line 24
    :cond_1
    const/16 v6, 0x623

    if-eq v5, v6, :cond_9

    const/16 v6, 0x625

    if-eq v5, v6, :cond_9

    const/16 v6, 0x622

    if-eq v5, v6, :cond_9

    const/16 v6, 0x671

    if-ne v5, v6, :cond_2

    goto :goto_4

    .line 25
    :cond_2
    const/16 v6, 0x649

    if-eq v5, v6, :cond_8

    const/16 v6, 0x626

    if-ne v5, v6, :cond_3

    goto :goto_3

    .line 26
    :cond_3
    const/16 v6, 0x629

    if-ne v5, v6, :cond_4

    const/16 v6, 0x647

    invoke-virtual {v0, v6}, Ljava/lang/StringBuilder;->append(C)Ljava/lang/StringBuilder;

    goto :goto_5

    .line 27
    :cond_4
    const/16 v6, 0x624

    if-ne v5, v6, :cond_5

    const/16 v6, 0x648

    invoke-virtual {v0, v6}, Ljava/lang/StringBuilder;->append(C)Ljava/lang/StringBuilder;

    goto :goto_5

    .line 28
    :cond_5
    invoke-static {v5}, Ljava/lang/Character;->isLetterOrDigit(C)Z

    move-result v6

    if-nez v6, :cond_7

    const/16 v6, 0x621

    if-ne v5, v6, :cond_6

    goto :goto_2

    .line 29
    :cond_6
    const/16 v6, 0x20

    invoke-virtual {v0, v6}, Ljava/lang/StringBuilder;->append(C)Ljava/lang/StringBuilder;

    goto :goto_5

    .line 28
    :cond_7
    :goto_2
    invoke-virtual {v0, v5}, Ljava/lang/StringBuilder;->append(C)Ljava/lang/StringBuilder;

    goto :goto_5

    .line 25
    :cond_8
    :goto_3
    const/16 v6, 0x64a

    invoke-virtual {v0, v6}, Ljava/lang/StringBuilder;->append(C)Ljava/lang/StringBuilder;

    goto :goto_5

    .line 24
    :cond_9
    :goto_4
    const/16 v6, 0x627

    invoke-virtual {v0, v6}, Ljava/lang/StringBuilder;->append(C)Ljava/lang/StringBuilder;

    .line 21
    .end local v5    # "ch":C
    :cond_a
    :goto_5
    add-int/lit8 v4, v4, 0x1

    goto :goto_0

    .line 32
    :cond_b
    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    const-string v2, "toString(...)"

    invoke-static {v1, v2}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    check-cast v1, Ljava/lang/CharSequence;

    invoke-static {v1}, Lkotlin/text/StringsKt;->trim(Ljava/lang/CharSequence;)Ljava/lang/CharSequence;

    move-result-object v1

    invoke-virtual {v1}, Ljava/lang/Object;->toString()Ljava/lang/String;

    move-result-object v1

    check-cast v1, Ljava/lang/CharSequence;

    new-instance v2, Lkotlin/text/Regex;

    const-string v3, "\\s+"

    invoke-direct {v2, v3}, Lkotlin/text/Regex;-><init>(Ljava/lang/String;)V

    const-string v3, " "

    invoke-virtual {v2, v1, v3}, Lkotlin/text/Regex;->replace(Ljava/lang/CharSequence;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v1

    return-object v1
.end method

.method public final parse(Ljava/lang/String;)Ljava/lang/String;
    .locals 16
    .param p1, "text"    # Ljava/lang/String;

    const-string v0, "text"

    move-object/from16 v1, p1

    invoke-static {v1, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 119
    invoke-virtual/range {p0 .. p1}, Lcom/example/carcontroller/VoiceCommandParser;->normalize(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    .line 120
    .local v0, "t":Ljava/lang/String;
    move-object v2, v0

    check-cast v2, Ljava/lang/CharSequence;

    invoke-interface {v2}, Ljava/lang/CharSequence;->length()I

    move-result v2

    const/4 v3, 0x1

    const/4 v4, 0x0

    if-nez v2, :cond_0

    move v2, v3

    goto :goto_0

    :cond_0
    move v2, v4

    :goto_0
    const/4 v5, 0x0

    if-eqz v2, :cond_1

    return-object v5

    .line 121
    :cond_1
    move-object v6, v0

    check-cast v6, Ljava/lang/CharSequence;

    new-array v7, v3, [C

    const/16 v2, 0x20

    aput-char v2, v7, v4

    const/4 v8, 0x0

    const/4 v9, 0x0

    const/4 v10, 0x6

    const/4 v11, 0x0

    invoke-static/range {v6 .. v11}, Lkotlin/text/StringsKt;->split$default(Ljava/lang/CharSequence;[CZIILjava/lang/Object;)Ljava/util/List;

    move-result-object v6

    .line 122
    .local v6, "tokens":Ljava/util/List;
    new-instance v7, Ljava/lang/StringBuilder;

    invoke-direct {v7}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v7, v2}, Ljava/lang/StringBuilder;->append(C)Ljava/lang/StringBuilder;

    move-result-object v7

    invoke-virtual {v7, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v7

    invoke-virtual {v7, v2}, Ljava/lang/StringBuilder;->append(C)Ljava/lang/StringBuilder;

    move-result-object v2

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v2

    .line 123
    .local v2, "padded":Ljava/lang/String;
    move-object v7, v6

    check-cast v7, Ljava/lang/Iterable;

    .local v7, "$this$any$iv":Ljava/lang/Iterable;
    const/4 v8, 0x0

    .line 140
    .local v8, "$i$f$any":I
    instance-of v9, v7, Ljava/util/Collection;

    if-eqz v9, :cond_2

    move-object v9, v7

    check-cast v9, Ljava/util/Collection;

    invoke-interface {v9}, Ljava/util/Collection;->isEmpty()Z

    move-result v9

    if-eqz v9, :cond_2

    move v7, v4

    goto :goto_1

    .line 141
    :cond_2
    invoke-interface {v7}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    move-result-object v9

    :cond_3
    invoke-interface {v9}, Ljava/util/Iterator;->hasNext()Z

    move-result v10

    if-eqz v10, :cond_4

    invoke-interface {v9}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v10

    .local v10, "element$iv":Ljava/lang/Object;
    move-object v11, v10

    check-cast v11, Ljava/lang/String;

    .local v11, "it":Ljava/lang/String;
    const/4 v12, 0x0

    .line 123
    .local v12, "$i$a$-any-VoiceCommandParser$parse$hasOff$1":I
    sget-object v13, Lcom/example/carcontroller/VoiceCommandParser;->INSTANCE:Lcom/example/carcontroller/VoiceCommandParser;

    sget-object v14, Lcom/example/carcontroller/VoiceCommandParser;->OFF_VERBS:Ljava/util/Set;

    invoke-direct {v13, v11, v14}, Lcom/example/carcontroller/VoiceCommandParser;->isVerb(Ljava/lang/String;Ljava/util/Set;)Z

    move-result v11

    .line 141
    .end local v11    # "it":Ljava/lang/String;
    .end local v12    # "$i$a$-any-VoiceCommandParser$parse$hasOff$1":I
    if-eqz v11, :cond_3

    move v7, v3

    goto :goto_1

    .line 142
    .end local v10    # "element$iv":Ljava/lang/Object;
    :cond_4
    move v7, v4

    .line 123
    .end local v7    # "$this$any$iv":Ljava/lang/Iterable;
    .end local v8    # "$i$f$any":I
    :goto_1
    nop

    .line 124
    .local v7, "hasOff":Z
    move-object v8, v6

    check-cast v8, Ljava/lang/Iterable;

    .local v8, "$this$any$iv":Ljava/lang/Iterable;
    const/4 v9, 0x0

    .line 143
    .local v9, "$i$f$any":I
    instance-of v10, v8, Ljava/util/Collection;

    if-eqz v10, :cond_5

    move-object v10, v8

    check-cast v10, Ljava/util/Collection;

    invoke-interface {v10}, Ljava/util/Collection;->isEmpty()Z

    move-result v10

    if-eqz v10, :cond_5

    move v8, v4

    goto :goto_2

    .line 144
    :cond_5
    invoke-interface {v8}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    move-result-object v10

    :cond_6
    invoke-interface {v10}, Ljava/util/Iterator;->hasNext()Z

    move-result v11

    if-eqz v11, :cond_7

    invoke-interface {v10}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v11

    .local v11, "element$iv":Ljava/lang/Object;
    move-object v12, v11

    check-cast v12, Ljava/lang/String;

    .local v12, "it":Ljava/lang/String;
    const/4 v13, 0x0

    .line 124
    .local v13, "$i$a$-any-VoiceCommandParser$parse$hasOn$1":I
    sget-object v14, Lcom/example/carcontroller/VoiceCommandParser;->INSTANCE:Lcom/example/carcontroller/VoiceCommandParser;

    sget-object v15, Lcom/example/carcontroller/VoiceCommandParser;->ON_VERBS:Ljava/util/Set;

    invoke-direct {v14, v12, v15}, Lcom/example/carcontroller/VoiceCommandParser;->isVerb(Ljava/lang/String;Ljava/util/Set;)Z

    move-result v12

    .line 144
    .end local v12    # "it":Ljava/lang/String;
    .end local v13    # "$i$a$-any-VoiceCommandParser$parse$hasOn$1":I
    if-eqz v12, :cond_6

    move v8, v3

    goto :goto_2

    .line 145
    .end local v11    # "element$iv":Ljava/lang/Object;
    :cond_7
    move v8, v4

    .line 124
    .end local v8    # "$this$any$iv":Ljava/lang/Iterable;
    .end local v9    # "$i$f$any":I
    :goto_2
    nop

    .line 126
    .local v8, "hasOn":Z
    sget-object v9, Lcom/example/carcontroller/VoiceCommandParser;->RULES:Ljava/util/List;

    invoke-interface {v9}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    move-result-object v9

    :cond_8
    invoke-interface {v9}, Ljava/util/Iterator;->hasNext()Z

    move-result v10

    if-eqz v10, :cond_10

    invoke-interface {v9}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v10

    check-cast v10, Lcom/example/carcontroller/VoiceCommandParser$Rule;

    .line 127
    .local v10, "rule":Lcom/example/carcontroller/VoiceCommandParser$Rule;
    invoke-virtual {v10, v0, v2}, Lcom/example/carcontroller/VoiceCommandParser$Rule;->matches(Ljava/lang/String;Ljava/lang/String;)Z

    move-result v11

    if-eqz v11, :cond_8

    .line 128
    if-nez v7, :cond_a

    invoke-virtual {v10, v0}, Lcom/example/carcontroller/VoiceCommandParser$Rule;->forcesOff(Ljava/lang/String;)Z

    move-result v9

    if-eqz v9, :cond_9

    goto :goto_3

    :cond_9
    move v3, v4

    .line 129
    .local v3, "off":Z
    :cond_a
    :goto_3
    nop

    .line 130
    invoke-virtual {v10}, Lcom/example/carcontroller/VoiceCommandParser$Rule;->getSingle()Ljava/lang/String;

    move-result-object v4

    if-eqz v4, :cond_c

    if-eqz v3, :cond_b

    goto :goto_5

    :cond_b
    invoke-virtual {v10}, Lcom/example/carcontroller/VoiceCommandParser$Rule;->getSingle()Ljava/lang/String;

    move-result-object v5

    goto :goto_5

    .line 131
    :cond_c
    if-eqz v3, :cond_d

    invoke-virtual {v10}, Lcom/example/carcontroller/VoiceCommandParser$Rule;->getOff()Ljava/lang/String;

    move-result-object v5

    goto :goto_5

    .line 132
    :cond_d
    if-nez v8, :cond_f

    invoke-virtual {v10}, Lcom/example/carcontroller/VoiceCommandParser$Rule;->getDefaultOn()Z

    move-result v4

    if-eqz v4, :cond_e

    goto :goto_4

    .line 133
    :cond_e
    goto :goto_5

    .line 132
    :cond_f
    :goto_4
    invoke-virtual {v10}, Lcom/example/carcontroller/VoiceCommandParser$Rule;->getOn()Ljava/lang/String;

    move-result-object v5

    .line 129
    :goto_5
    return-object v5

    .line 136
    .end local v3    # "off":Z
    .end local v10    # "rule":Lcom/example/carcontroller/VoiceCommandParser$Rule;
    :cond_10
    return-object v5
.end method
