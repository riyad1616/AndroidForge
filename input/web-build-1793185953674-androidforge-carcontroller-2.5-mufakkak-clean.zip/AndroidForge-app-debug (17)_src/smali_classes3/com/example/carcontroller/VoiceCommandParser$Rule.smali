.class final Lcom/example/carcontroller/VoiceCommandParser$Rule;
.super Ljava/lang/Object;
.source "VoiceCommandParser.kt"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/example/carcontroller/VoiceCommandParser;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x1a
    name = "Rule"
.end annotation

.annotation system Ldalvik/annotation/SourceDebugExtension;
    value = "SMAP\nVoiceCommandParser.kt\nKotlin\n*S Kotlin\n*F\n+ 1 VoiceCommandParser.kt\ncom/example/carcontroller/VoiceCommandParser$Rule\n+ 2 _Collections.kt\nkotlin/collections/CollectionsKt___CollectionsKt\n*L\n1#1,139:1\n1549#2:140\n1620#2,3:141\n1549#2:144\n1620#2,3:145\n1726#2,2:148\n1747#2,3:150\n1728#2:153\n1747#2,3:154\n*S KotlinDebug\n*F\n+ 1 VoiceCommandParser.kt\ncom/example/carcontroller/VoiceCommandParser$Rule\n*L\n64#1:140\n64#1:141,3\n65#1:144\n65#1:145,3\n68#1:148,2\n69#1:150,3\n68#1:153\n74#1:154,3\n*E\n"
.end annotation

.annotation runtime Lkotlin/Metadata;
    d1 = {
        "\u0000\u001e\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0000\n\u0002\u0010 \n\u0002\u0010\u000e\n\u0002\u0008\u0003\n\u0002\u0010\u000b\n\u0002\u0008\u0013\u0008\u0002\u0018\u00002\u00020\u0001BS\u0012\u0012\u0010\u0002\u001a\u000e\u0012\n\u0012\u0008\u0012\u0004\u0012\u00020\u00040\u00030\u0003\u0012\u0008\u0010\u0005\u001a\u0004\u0018\u00010\u0004\u0012\u0008\u0010\u0006\u001a\u0004\u0018\u00010\u0004\u0012\u0008\u0008\u0002\u0010\u0007\u001a\u00020\u0008\u0012\u000e\u0008\u0002\u0010\t\u001a\u0008\u0012\u0004\u0012\u00020\u00040\u0003\u0012\n\u0008\u0002\u0010\n\u001a\u0004\u0018\u00010\u0004\u00a2\u0006\u0002\u0010\u000bJ\u000e\u0010\u0017\u001a\u00020\u00082\u0006\u0010\u0018\u001a\u00020\u0004J\u0016\u0010\u0019\u001a\u00020\u00082\u0006\u0010\u0018\u001a\u00020\u00042\u0006\u0010\u001a\u001a\u00020\u0004R\u0011\u0010\u0007\u001a\u00020\u0008\u00a2\u0006\u0008\n\u0000\u001a\u0004\u0008\u000c\u0010\rR\u0014\u0010\u000e\u001a\u0008\u0012\u0004\u0012\u00020\u00040\u0003X\u0082\u0004\u00a2\u0006\u0002\n\u0000R\u0017\u0010\t\u001a\u0008\u0012\u0004\u0012\u00020\u00040\u0003\u00a2\u0006\u0008\n\u0000\u001a\u0004\u0008\u000f\u0010\u0010R\u001a\u0010\u0011\u001a\u000e\u0012\n\u0012\u0008\u0012\u0004\u0012\u00020\u00040\u00030\u0003X\u0082\u0004\u00a2\u0006\u0002\n\u0000R\u001d\u0010\u0002\u001a\u000e\u0012\n\u0012\u0008\u0012\u0004\u0012\u00020\u00040\u00030\u0003\u00a2\u0006\u0008\n\u0000\u001a\u0004\u0008\u0012\u0010\u0010R\u0013\u0010\u0006\u001a\u0004\u0018\u00010\u0004\u00a2\u0006\u0008\n\u0000\u001a\u0004\u0008\u0013\u0010\u0014R\u0013\u0010\u0005\u001a\u0004\u0018\u00010\u0004\u00a2\u0006\u0008\n\u0000\u001a\u0004\u0008\u0015\u0010\u0014R\u0013\u0010\n\u001a\u0004\u0018\u00010\u0004\u00a2\u0006\u0008\n\u0000\u001a\u0004\u0008\u0016\u0010\u0014\u00a8\u0006\u001b"
    }
    d2 = {
        "Lcom/example/carcontroller/VoiceCommandParser$Rule;",
        "",
        "groups",
        "",
        "",
        "on",
        "off",
        "defaultOn",
        "",
        "forceOff",
        "single",
        "(Ljava/util/List;Ljava/lang/String;Ljava/lang/String;ZLjava/util/List;Ljava/lang/String;)V",
        "getDefaultOn",
        "()Z",
        "fo",
        "getForceOff",
        "()Ljava/util/List;",
        "g",
        "getGroups",
        "getOff",
        "()Ljava/lang/String;",
        "getOn",
        "getSingle",
        "forcesOff",
        "text",
        "matches",
        "padded",
        "app_debug"
    }
    k = 0x1
    mv = {
        0x1,
        0x9,
        0x0
    }
    xi = 0x30
.end annotation


# instance fields
.field private final defaultOn:Z

.field private final fo:Ljava/util/List;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/List<",
            "Ljava/lang/String;",
            ">;"
        }
    .end annotation
.end field

.field private final forceOff:Ljava/util/List;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/List<",
            "Ljava/lang/String;",
            ">;"
        }
    .end annotation
.end field

.field private final g:Ljava/util/List;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/List<",
            "Ljava/util/List<",
            "Ljava/lang/String;",
            ">;>;"
        }
    .end annotation
.end field

.field private final groups:Ljava/util/List;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/List<",
            "Ljava/util/List<",
            "Ljava/lang/String;",
            ">;>;"
        }
    .end annotation
.end field

.field private final off:Ljava/lang/String;

.field private final on:Ljava/lang/String;

.field private final single:Ljava/lang/String;


# direct methods
.method public constructor <init>(Ljava/util/List;Ljava/lang/String;Ljava/lang/String;ZLjava/util/List;Ljava/lang/String;)V
    .locals 23
    .param p1, "groups"    # Ljava/util/List;
    .param p2, "on"    # Ljava/lang/String;
    .param p3, "off"    # Ljava/lang/String;
    .param p4, "defaultOn"    # Z
    .param p5, "forceOff"    # Ljava/util/List;
    .param p6, "single"    # Ljava/lang/String;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/util/List<",
            "+",
            "Ljava/util/List<",
            "Ljava/lang/String;",
            ">;>;",
            "Ljava/lang/String;",
            "Ljava/lang/String;",
            "Z",
            "Ljava/util/List<",
            "Ljava/lang/String;",
            ">;",
            "Ljava/lang/String;",
            ")V"
        }
    .end annotation

    move-object/from16 v0, p0

    move-object/from16 v1, p1

    move-object/from16 v2, p5

    const-string v3, "groups"

    invoke-static {v1, v3}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    const-string v3, "forceOff"

    invoke-static {v2, v3}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 52
    invoke-direct/range {p0 .. p0}, Ljava/lang/Object;-><init>()V

    .line 54
    iput-object v1, v0, Lcom/example/carcontroller/VoiceCommandParser$Rule;->groups:Ljava/util/List;

    .line 55
    move-object/from16 v3, p2

    iput-object v3, v0, Lcom/example/carcontroller/VoiceCommandParser$Rule;->on:Ljava/lang/String;

    .line 56
    move-object/from16 v4, p3

    iput-object v4, v0, Lcom/example/carcontroller/VoiceCommandParser$Rule;->off:Ljava/lang/String;

    .line 58
    move/from16 v5, p4

    iput-boolean v5, v0, Lcom/example/carcontroller/VoiceCommandParser$Rule;->defaultOn:Z

    .line 60
    iput-object v2, v0, Lcom/example/carcontroller/VoiceCommandParser$Rule;->forceOff:Ljava/util/List;

    .line 62
    move-object/from16 v6, p6

    iput-object v6, v0, Lcom/example/carcontroller/VoiceCommandParser$Rule;->single:Ljava/lang/String;

    .line 64
    move-object v7, v1

    check-cast v7, Ljava/lang/Iterable;

    .local v7, "$this$map$iv":Ljava/lang/Iterable;
    const/4 v8, 0x0

    .line 140
    .local v8, "$i$f$map":I
    new-instance v9, Ljava/util/ArrayList;

    const/16 v10, 0xa

    invoke-static {v7, v10}, Lkotlin/collections/CollectionsKt;->collectionSizeOrDefault(Ljava/lang/Iterable;I)I

    move-result v11

    invoke-direct {v9, v11}, Ljava/util/ArrayList;-><init>(I)V

    check-cast v9, Ljava/util/Collection;

    .local v9, "destination$iv$iv":Ljava/util/Collection;
    move-object v11, v7

    .local v11, "$this$mapTo$iv$iv":Ljava/lang/Iterable;
    const/4 v12, 0x0

    .line 141
    .local v12, "$i$f$mapTo":I
    invoke-interface {v11}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    move-result-object v13

    :goto_0
    invoke-interface {v13}, Ljava/util/Iterator;->hasNext()Z

    move-result v14

    if-eqz v14, :cond_1

    invoke-interface {v13}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v14

    .line 142
    .local v14, "item$iv$iv":Ljava/lang/Object;
    move-object v15, v14

    check-cast v15, Ljava/util/List;

    .local v15, "grp":Ljava/util/List;
    const/16 v16, 0x0

    .line 64
    .local v16, "$i$a$-map-VoiceCommandParser$Rule$g$1":I
    move-object v10, v15

    check-cast v10, Ljava/lang/Iterable;

    .local v10, "$this$map$iv":Ljava/lang/Iterable;
    const/16 v17, 0x0

    .line 140
    .local v17, "$i$f$map":I
    new-instance v1, Ljava/util/ArrayList;

    const/16 v2, 0xa

    invoke-static {v10, v2}, Lkotlin/collections/CollectionsKt;->collectionSizeOrDefault(Ljava/lang/Iterable;I)I

    move-result v3

    invoke-direct {v1, v3}, Ljava/util/ArrayList;-><init>(I)V

    check-cast v1, Ljava/util/Collection;

    .local v1, "destination$iv$iv":Ljava/util/Collection;
    move-object v2, v10

    .local v2, "$this$mapTo$iv$iv":Ljava/lang/Iterable;
    const/4 v3, 0x0

    .line 141
    .local v3, "$i$f$mapTo":I
    invoke-interface {v2}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    move-result-object v18

    :goto_1
    invoke-interface/range {v18 .. v18}, Ljava/util/Iterator;->hasNext()Z

    move-result v19

    if-eqz v19, :cond_0

    invoke-interface/range {v18 .. v18}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v19

    .line 142
    .local v19, "item$iv$iv":Ljava/lang/Object;
    move-object/from16 v20, v2

    .end local v2    # "$this$mapTo$iv$iv":Ljava/lang/Iterable;
    .local v20, "$this$mapTo$iv$iv":Ljava/lang/Iterable;
    move-object/from16 v2, v19

    check-cast v2, Ljava/lang/String;

    .local v2, "it":Ljava/lang/String;
    const/16 v21, 0x0

    .line 64
    .local v21, "$i$a$-map-VoiceCommandParser$Rule$g$1$1":I
    move/from16 v22, v3

    .end local v3    # "$i$f$mapTo":I
    .local v22, "$i$f$mapTo":I
    sget-object v3, Lcom/example/carcontroller/VoiceCommandParser;->INSTANCE:Lcom/example/carcontroller/VoiceCommandParser;

    invoke-virtual {v3, v2}, Lcom/example/carcontroller/VoiceCommandParser;->normalize(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v2

    .line 142
    .end local v2    # "it":Ljava/lang/String;
    .end local v21    # "$i$a$-map-VoiceCommandParser$Rule$g$1$1":I
    invoke-interface {v1, v2}, Ljava/util/Collection;->add(Ljava/lang/Object;)Z

    move-object/from16 v2, v20

    move/from16 v3, v22

    goto :goto_1

    .line 143
    .end local v19    # "item$iv$iv":Ljava/lang/Object;
    .end local v20    # "$this$mapTo$iv$iv":Ljava/lang/Iterable;
    .end local v22    # "$i$f$mapTo":I
    .local v2, "$this$mapTo$iv$iv":Ljava/lang/Iterable;
    .restart local v3    # "$i$f$mapTo":I
    :cond_0
    move-object/from16 v20, v2

    move/from16 v22, v3

    .end local v1    # "destination$iv$iv":Ljava/util/Collection;
    .end local v2    # "$this$mapTo$iv$iv":Ljava/lang/Iterable;
    .end local v3    # "$i$f$mapTo":I
    check-cast v1, Ljava/util/List;

    .line 140
    nop

    .line 64
    .end local v10    # "$this$map$iv":Ljava/lang/Iterable;
    .end local v17    # "$i$f$map":I
    nop

    .line 142
    .end local v15    # "grp":Ljava/util/List;
    .end local v16    # "$i$a$-map-VoiceCommandParser$Rule$g$1":I
    invoke-interface {v9, v1}, Ljava/util/Collection;->add(Ljava/lang/Object;)Z

    move-object/from16 v1, p1

    move-object/from16 v3, p2

    move-object/from16 v2, p5

    const/16 v10, 0xa

    goto :goto_0

    .line 143
    .end local v14    # "item$iv$iv":Ljava/lang/Object;
    :cond_1
    nop

    .end local v9    # "destination$iv$iv":Ljava/util/Collection;
    .end local v11    # "$this$mapTo$iv$iv":Ljava/lang/Iterable;
    .end local v12    # "$i$f$mapTo":I
    move-object v1, v9

    check-cast v1, Ljava/util/List;

    .line 140
    nop

    .line 64
    .end local v7    # "$this$map$iv":Ljava/lang/Iterable;
    .end local v8    # "$i$f$map":I
    iput-object v1, v0, Lcom/example/carcontroller/VoiceCommandParser$Rule;->g:Ljava/util/List;

    .line 65
    iget-object v1, v0, Lcom/example/carcontroller/VoiceCommandParser$Rule;->forceOff:Ljava/util/List;

    check-cast v1, Ljava/lang/Iterable;

    .local v1, "$this$map$iv":Ljava/lang/Iterable;
    const/4 v2, 0x0

    .line 144
    .local v2, "$i$f$map":I
    new-instance v3, Ljava/util/ArrayList;

    const/16 v7, 0xa

    invoke-static {v1, v7}, Lkotlin/collections/CollectionsKt;->collectionSizeOrDefault(Ljava/lang/Iterable;I)I

    move-result v7

    invoke-direct {v3, v7}, Ljava/util/ArrayList;-><init>(I)V

    check-cast v3, Ljava/util/Collection;

    .local v3, "destination$iv$iv":Ljava/util/Collection;
    move-object v7, v1

    .local v7, "$this$mapTo$iv$iv":Ljava/lang/Iterable;
    const/4 v8, 0x0

    .line 145
    .local v8, "$i$f$mapTo":I
    invoke-interface {v7}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    move-result-object v9

    :goto_2
    invoke-interface {v9}, Ljava/util/Iterator;->hasNext()Z

    move-result v10

    if-eqz v10, :cond_2

    invoke-interface {v9}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v10

    .line 146
    .local v10, "item$iv$iv":Ljava/lang/Object;
    move-object v11, v10

    check-cast v11, Ljava/lang/String;

    .local v11, "it":Ljava/lang/String;
    const/4 v12, 0x0

    .line 65
    .local v12, "$i$a$-map-VoiceCommandParser$Rule$fo$1":I
    sget-object v13, Lcom/example/carcontroller/VoiceCommandParser;->INSTANCE:Lcom/example/carcontroller/VoiceCommandParser;

    invoke-virtual {v13, v11}, Lcom/example/carcontroller/VoiceCommandParser;->normalize(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v11

    .line 146
    .end local v11    # "it":Ljava/lang/String;
    .end local v12    # "$i$a$-map-VoiceCommandParser$Rule$fo$1":I
    invoke-interface {v3, v11}, Ljava/util/Collection;->add(Ljava/lang/Object;)Z

    goto :goto_2

    .line 147
    .end local v10    # "item$iv$iv":Ljava/lang/Object;
    :cond_2
    nop

    .end local v3    # "destination$iv$iv":Ljava/util/Collection;
    .end local v7    # "$this$mapTo$iv$iv":Ljava/lang/Iterable;
    .end local v8    # "$i$f$mapTo":I
    check-cast v3, Ljava/util/List;

    .line 144
    nop

    .line 65
    .end local v1    # "$this$map$iv":Ljava/lang/Iterable;
    .end local v2    # "$i$f$map":I
    iput-object v3, v0, Lcom/example/carcontroller/VoiceCommandParser$Rule;->fo:Ljava/util/List;

    .line 52
    return-void
.end method

.method public synthetic constructor <init>(Ljava/util/List;Ljava/lang/String;Ljava/lang/String;ZLjava/util/List;Ljava/lang/String;ILkotlin/jvm/internal/DefaultConstructorMarker;)V
    .locals 7

    .line 52
    and-int/lit8 p8, p7, 0x8

    if-eqz p8, :cond_0

    .line 58
    const/4 p4, 0x0

    move v4, p4

    goto :goto_0

    .line 52
    :cond_0
    move v4, p4

    :goto_0
    and-int/lit8 p4, p7, 0x10

    if-eqz p4, :cond_1

    .line 60
    invoke-static {}, Lkotlin/collections/CollectionsKt;->emptyList()Ljava/util/List;

    move-result-object p5

    move-object v5, p5

    goto :goto_1

    .line 52
    :cond_1
    move-object v5, p5

    :goto_1
    and-int/lit8 p4, p7, 0x20

    if-eqz p4, :cond_2

    .line 62
    const/4 p6, 0x0

    move-object v6, p6

    goto :goto_2

    .line 52
    :cond_2
    move-object v6, p6

    :goto_2
    move-object v0, p0

    move-object v1, p1

    move-object v2, p2

    move-object v3, p3

    invoke-direct/range {v0 .. v6}, Lcom/example/carcontroller/VoiceCommandParser$Rule;-><init>(Ljava/util/List;Ljava/lang/String;Ljava/lang/String;ZLjava/util/List;Ljava/lang/String;)V

    .line 75
    return-void
.end method


# virtual methods
.method public final forcesOff(Ljava/lang/String;)Z
    .locals 11
    .param p1, "text"    # Ljava/lang/String;

    const-string v0, "text"

    invoke-static {p1, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 74
    iget-object v0, p0, Lcom/example/carcontroller/VoiceCommandParser$Rule;->fo:Ljava/util/List;

    check-cast v0, Ljava/lang/Iterable;

    .local v0, "$this$any$iv":Ljava/lang/Iterable;
    const/4 v1, 0x0

    .line 154
    .local v1, "$i$f$any":I
    instance-of v2, v0, Ljava/util/Collection;

    const/4 v3, 0x0

    if-eqz v2, :cond_0

    move-object v2, v0

    check-cast v2, Ljava/util/Collection;

    invoke-interface {v2}, Ljava/util/Collection;->isEmpty()Z

    move-result v2

    if-eqz v2, :cond_0

    goto :goto_0

    .line 155
    :cond_0
    invoke-interface {v0}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    move-result-object v2

    :cond_1
    invoke-interface {v2}, Ljava/util/Iterator;->hasNext()Z

    move-result v4

    if-eqz v4, :cond_2

    invoke-interface {v2}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v4

    .local v4, "element$iv":Ljava/lang/Object;
    move-object v5, v4

    check-cast v5, Ljava/lang/String;

    .local v5, "it":Ljava/lang/String;
    const/4 v6, 0x0

    .line 74
    .local v6, "$i$a$-any-VoiceCommandParser$Rule$forcesOff$1":I
    move-object v7, p1

    check-cast v7, Ljava/lang/CharSequence;

    move-object v8, v5

    check-cast v8, Ljava/lang/CharSequence;

    const/4 v9, 0x2

    const/4 v10, 0x0

    invoke-static {v7, v8, v3, v9, v10}, Lkotlin/text/StringsKt;->contains$default(Ljava/lang/CharSequence;Ljava/lang/CharSequence;ZILjava/lang/Object;)Z

    move-result v5

    .line 155
    .end local v5    # "it":Ljava/lang/String;
    .end local v6    # "$i$a$-any-VoiceCommandParser$Rule$forcesOff$1":I
    if-eqz v5, :cond_1

    const/4 v3, 0x1

    goto :goto_0

    .line 156
    .end local v4    # "element$iv":Ljava/lang/Object;
    :cond_2
    nop

    .line 74
    .end local v0    # "$this$any$iv":Ljava/lang/Iterable;
    .end local v1    # "$i$f$any":I
    :goto_0
    return v3
.end method

.method public final getDefaultOn()Z
    .locals 1

    .line 58
    iget-boolean v0, p0, Lcom/example/carcontroller/VoiceCommandParser$Rule;->defaultOn:Z

    return v0
.end method

.method public final getForceOff()Ljava/util/List;
    .locals 1
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Ljava/util/List<",
            "Ljava/lang/String;",
            ">;"
        }
    .end annotation

    .line 60
    iget-object v0, p0, Lcom/example/carcontroller/VoiceCommandParser$Rule;->forceOff:Ljava/util/List;

    return-object v0
.end method

.method public final getGroups()Ljava/util/List;
    .locals 1
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Ljava/util/List<",
            "Ljava/util/List<",
            "Ljava/lang/String;",
            ">;>;"
        }
    .end annotation

    .line 54
    iget-object v0, p0, Lcom/example/carcontroller/VoiceCommandParser$Rule;->groups:Ljava/util/List;

    return-object v0
.end method

.method public final getOff()Ljava/lang/String;
    .locals 1

    .line 56
    iget-object v0, p0, Lcom/example/carcontroller/VoiceCommandParser$Rule;->off:Ljava/lang/String;

    return-object v0
.end method

.method public final getOn()Ljava/lang/String;
    .locals 1

    .line 55
    iget-object v0, p0, Lcom/example/carcontroller/VoiceCommandParser$Rule;->on:Ljava/lang/String;

    return-object v0
.end method

.method public final getSingle()Ljava/lang/String;
    .locals 1

    .line 62
    iget-object v0, p0, Lcom/example/carcontroller/VoiceCommandParser$Rule;->single:Ljava/lang/String;

    return-object v0
.end method

.method public final matches(Ljava/lang/String;Ljava/lang/String;)Z
    .locals 18
    .param p1, "text"    # Ljava/lang/String;
    .param p2, "padded"    # Ljava/lang/String;

    move-object/from16 v0, p1

    move-object/from16 v1, p2

    const-string v2, "text"

    invoke-static {v0, v2}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    const-string v2, "padded"

    invoke-static {v1, v2}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 68
    move-object/from16 v2, p0

    iget-object v3, v2, Lcom/example/carcontroller/VoiceCommandParser$Rule;->g:Ljava/util/List;

    check-cast v3, Ljava/lang/Iterable;

    .local v3, "$this$all$iv":Ljava/lang/Iterable;
    const/4 v4, 0x0

    .line 148
    .local v4, "$i$f$all":I
    instance-of v5, v3, Ljava/util/Collection;

    if-eqz v5, :cond_0

    move-object v5, v3

    check-cast v5, Ljava/util/Collection;

    invoke-interface {v5}, Ljava/util/Collection;->isEmpty()Z

    move-result v5

    if-eqz v5, :cond_0

    const/4 v6, 0x1

    goto/16 :goto_4

    .line 149
    :cond_0
    invoke-interface {v3}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    move-result-object v5

    :goto_0
    invoke-interface {v5}, Ljava/util/Iterator;->hasNext()Z

    move-result v7

    if-eqz v7, :cond_6

    invoke-interface {v5}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v7

    .local v7, "element$iv":Ljava/lang/Object;
    move-object v8, v7

    check-cast v8, Ljava/util/List;

    .local v8, "grp":Ljava/util/List;
    const/4 v9, 0x0

    .line 69
    .local v9, "$i$a$-all-VoiceCommandParser$Rule$matches$1":I
    move-object v10, v8

    check-cast v10, Ljava/lang/Iterable;

    .local v10, "$this$any$iv":Ljava/lang/Iterable;
    const/4 v11, 0x0

    .line 150
    .local v11, "$i$f$any":I
    instance-of v12, v10, Ljava/util/Collection;

    const/4 v13, 0x0

    if-eqz v12, :cond_1

    move-object v12, v10

    check-cast v12, Ljava/util/Collection;

    invoke-interface {v12}, Ljava/util/Collection;->isEmpty()Z

    move-result v12

    if-eqz v12, :cond_1

    move-object/from16 v17, v3

    move v1, v13

    goto/16 :goto_3

    .line 151
    :cond_1
    invoke-interface {v10}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    move-result-object v12

    :goto_1
    invoke-interface {v12}, Ljava/util/Iterator;->hasNext()Z

    move-result v14

    if-eqz v14, :cond_4

    invoke-interface {v12}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v14

    .local v14, "element$iv":Ljava/lang/Object;
    move-object v15, v14

    check-cast v15, Ljava/lang/String;

    .local v15, "w":Ljava/lang/String;
    const/16 v16, 0x0

    .line 70
    .local v16, "$i$a$-any-VoiceCommandParser$Rule$matches$1$1":I
    const-string v6, "="

    const/4 v2, 0x2

    move-object/from16 v17, v3

    .end local v3    # "$this$all$iv":Ljava/lang/Iterable;
    .local v17, "$this$all$iv":Ljava/lang/Iterable;
    const/4 v3, 0x0

    invoke-static {v15, v6, v13, v2, v3}, Lkotlin/text/StringsKt;->startsWith$default(Ljava/lang/String;Ljava/lang/String;ZILjava/lang/Object;)Z

    move-result v6

    if-eqz v6, :cond_2

    move-object v6, v1

    check-cast v6, Ljava/lang/CharSequence;

    new-instance v2, Ljava/lang/StringBuilder;

    invoke-direct {v2}, Ljava/lang/StringBuilder;-><init>()V

    const/16 v3, 0x20

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(C)Ljava/lang/StringBuilder;

    move-result-object v2

    const/4 v13, 0x1

    invoke-virtual {v15, v13}, Ljava/lang/String;->substring(I)Ljava/lang/String;

    move-result-object v3

    const-string v13, "substring(...)"

    invoke-static {v3, v13}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    const/16 v3, 0x20

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(C)Ljava/lang/StringBuilder;

    move-result-object v2

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v2

    check-cast v2, Ljava/lang/CharSequence;

    const/4 v1, 0x0

    const/4 v3, 0x0

    const/4 v13, 0x2

    invoke-static {v6, v2, v1, v13, v3}, Lkotlin/text/StringsKt;->contains$default(Ljava/lang/CharSequence;Ljava/lang/CharSequence;ZILjava/lang/Object;)Z

    move-result v2

    goto :goto_2

    :cond_2
    move v1, v13

    move v13, v2

    move-object v2, v0

    check-cast v2, Ljava/lang/CharSequence;

    move-object v6, v15

    check-cast v6, Ljava/lang/CharSequence;

    invoke-static {v2, v6, v1, v13, v3}, Lkotlin/text/StringsKt;->contains$default(Ljava/lang/CharSequence;Ljava/lang/CharSequence;ZILjava/lang/Object;)Z

    move-result v2

    .line 151
    .end local v15    # "w":Ljava/lang/String;
    .end local v16    # "$i$a$-any-VoiceCommandParser$Rule$matches$1$1":I
    :goto_2
    if-eqz v2, :cond_3

    const/4 v13, 0x1

    goto :goto_3

    :cond_3
    move-object/from16 v2, p0

    move v13, v1

    move-object/from16 v3, v17

    move-object/from16 v1, p2

    goto :goto_1

    .line 152
    .end local v14    # "element$iv":Ljava/lang/Object;
    .end local v17    # "$this$all$iv":Ljava/lang/Iterable;
    .restart local v3    # "$this$all$iv":Ljava/lang/Iterable;
    :cond_4
    move-object/from16 v17, v3

    move v1, v13

    .line 69
    .end local v3    # "$this$all$iv":Ljava/lang/Iterable;
    .end local v10    # "$this$any$iv":Ljava/lang/Iterable;
    .end local v11    # "$i$f$any":I
    .restart local v17    # "$this$all$iv":Ljava/lang/Iterable;
    :goto_3
    nop

    .line 149
    .end local v8    # "grp":Ljava/util/List;
    .end local v9    # "$i$a$-all-VoiceCommandParser$Rule$matches$1":I
    if-nez v13, :cond_5

    move v6, v1

    goto :goto_4

    :cond_5
    move-object/from16 v2, p0

    move-object/from16 v1, p2

    move-object/from16 v3, v17

    goto/16 :goto_0

    .line 153
    .end local v7    # "element$iv":Ljava/lang/Object;
    .end local v17    # "$this$all$iv":Ljava/lang/Iterable;
    .restart local v3    # "$this$all$iv":Ljava/lang/Iterable;
    :cond_6
    move-object/from16 v17, v3

    .end local v3    # "$this$all$iv":Ljava/lang/Iterable;
    .restart local v17    # "$this$all$iv":Ljava/lang/Iterable;
    const/4 v6, 0x1

    .line 72
    .end local v4    # "$i$f$all":I
    .end local v17    # "$this$all$iv":Ljava/lang/Iterable;
    :goto_4
    return v6
.end method
