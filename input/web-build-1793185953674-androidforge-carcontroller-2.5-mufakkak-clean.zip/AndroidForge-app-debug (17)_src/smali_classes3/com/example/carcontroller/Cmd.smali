.class public final Lcom/example/carcontroller/Cmd;
.super Ljava/lang/Object;
.source "Cmd.kt"


# annotations
.annotation runtime Lkotlin/Metadata;
    d1 = {
        "\u0000\u0014\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0002\u0008\u0002\n\u0002\u0010\u000e\n\u0002\u0008\u001d\u0008\u00c6\u0002\u0018\u00002\u00020\u0001B\u0007\u0008\u0002\u00a2\u0006\u0002\u0010\u0002R\u000e\u0010\u0003\u001a\u00020\u0004X\u0086T\u00a2\u0006\u0002\n\u0000R\u000e\u0010\u0005\u001a\u00020\u0004X\u0086T\u00a2\u0006\u0002\n\u0000R\u000e\u0010\u0006\u001a\u00020\u0004X\u0086T\u00a2\u0006\u0002\n\u0000R\u000e\u0010\u0007\u001a\u00020\u0004X\u0086T\u00a2\u0006\u0002\n\u0000R\u000e\u0010\u0008\u001a\u00020\u0004X\u0086T\u00a2\u0006\u0002\n\u0000R\u000e\u0010\t\u001a\u00020\u0004X\u0086T\u00a2\u0006\u0002\n\u0000R\u000e\u0010\n\u001a\u00020\u0004X\u0086T\u00a2\u0006\u0002\n\u0000R\u000e\u0010\u000b\u001a\u00020\u0004X\u0086T\u00a2\u0006\u0002\n\u0000R\u000e\u0010\u000c\u001a\u00020\u0004X\u0086T\u00a2\u0006\u0002\n\u0000R\u000e\u0010\r\u001a\u00020\u0004X\u0086T\u00a2\u0006\u0002\n\u0000R\u000e\u0010\u000e\u001a\u00020\u0004X\u0086T\u00a2\u0006\u0002\n\u0000R\u000e\u0010\u000f\u001a\u00020\u0004X\u0086T\u00a2\u0006\u0002\n\u0000R\u000e\u0010\u0010\u001a\u00020\u0004X\u0086T\u00a2\u0006\u0002\n\u0000R\u000e\u0010\u0011\u001a\u00020\u0004X\u0086T\u00a2\u0006\u0002\n\u0000R\u000e\u0010\u0012\u001a\u00020\u0004X\u0086T\u00a2\u0006\u0002\n\u0000R\u000e\u0010\u0013\u001a\u00020\u0004X\u0086T\u00a2\u0006\u0002\n\u0000R\u000e\u0010\u0014\u001a\u00020\u0004X\u0086T\u00a2\u0006\u0002\n\u0000R\u000e\u0010\u0015\u001a\u00020\u0004X\u0086T\u00a2\u0006\u0002\n\u0000R\u000e\u0010\u0016\u001a\u00020\u0004X\u0086T\u00a2\u0006\u0002\n\u0000R\u000e\u0010\u0017\u001a\u00020\u0004X\u0086T\u00a2\u0006\u0002\n\u0000R\u000e\u0010\u0018\u001a\u00020\u0004X\u0086T\u00a2\u0006\u0002\n\u0000R\u000e\u0010\u0019\u001a\u00020\u0004X\u0086T\u00a2\u0006\u0002\n\u0000R\u000e\u0010\u001a\u001a\u00020\u0004X\u0086T\u00a2\u0006\u0002\n\u0000R\u000e\u0010\u001b\u001a\u00020\u0004X\u0086T\u00a2\u0006\u0002\n\u0000R\u000e\u0010\u001c\u001a\u00020\u0004X\u0086T\u00a2\u0006\u0002\n\u0000R\u000e\u0010\u001d\u001a\u00020\u0004X\u0086T\u00a2\u0006\u0002\n\u0000R\u000e\u0010\u001e\u001a\u00020\u0004X\u0086T\u00a2\u0006\u0002\n\u0000R\u000e\u0010\u001f\u001a\u00020\u0004X\u0086T\u00a2\u0006\u0002\n\u0000R\u000e\u0010 \u001a\u00020\u0004X\u0086T\u00a2\u0006\u0002\n\u0000\u00a8\u0006!"
    }
    d2 = {
        "Lcom/example/carcontroller/Cmd;",
        "",
        "()V",
        "AC_OFF",
        "",
        "AC_ON",
        "DOOR_LOCK",
        "DOOR_UNLOCK",
        "FOG_OFF",
        "FOG_ON",
        "HAZARD_OFF",
        "HAZARD_ON",
        "HEADLIGHTS_OFF",
        "HEADLIGHTS_ON",
        "HIGHBEAM_OFF",
        "HIGHBEAM_ON",
        "HORN",
        "INTERIOR_OFF",
        "INTERIOR_ON",
        "MIRROR_FOLD",
        "MIRROR_UNFOLD",
        "PING",
        "RADIO_OFF",
        "RADIO_ON",
        "REBOOT",
        "SEAT_HEAT_OFF",
        "SEAT_HEAT_ON",
        "SUNROOF_CLOSE",
        "SUNROOF_OPEN",
        "TRUNK_CLOSE",
        "TRUNK_OPEN",
        "WINDOW_CLOSE",
        "WINDOW_OPEN",
        "app_debug"
    }
    k = 0x1
    mv = {
        0x1,
        0x9,
        0x0
    }
    xi = 0x30
.end annotation


# static fields
.field public static final AC_OFF:Ljava/lang/String; = "CMD_AC_OFF"

.field public static final AC_ON:Ljava/lang/String; = "CMD_AC_ON"

.field public static final DOOR_LOCK:Ljava/lang/String; = "CMD_DOOR_LOCK"

.field public static final DOOR_UNLOCK:Ljava/lang/String; = "CMD_DOOR_UNLOCK"

.field public static final FOG_OFF:Ljava/lang/String; = "CMD_FOG_OFF"

.field public static final FOG_ON:Ljava/lang/String; = "CMD_FOG_ON"

.field public static final HAZARD_OFF:Ljava/lang/String; = "CMD_HAZARD_OFF"

.field public static final HAZARD_ON:Ljava/lang/String; = "CMD_HAZARD_ON"

.field public static final HEADLIGHTS_OFF:Ljava/lang/String; = "CMD_HEADLIGHTS_OFF"

.field public static final HEADLIGHTS_ON:Ljava/lang/String; = "CMD_HEADLIGHTS_ON"

.field public static final HIGHBEAM_OFF:Ljava/lang/String; = "CMD_HIGHBEAM_OFF"

.field public static final HIGHBEAM_ON:Ljava/lang/String; = "CMD_HIGHBEAM_ON"

.field public static final HORN:Ljava/lang/String; = "CMD_HORN"

.field public static final INSTANCE:Lcom/example/carcontroller/Cmd;

.field public static final INTERIOR_OFF:Ljava/lang/String; = "CMD_INTERIOR_OFF"

.field public static final INTERIOR_ON:Ljava/lang/String; = "CMD_INTERIOR_ON"

.field public static final MIRROR_FOLD:Ljava/lang/String; = "CMD_MIRROR_FOLD"

.field public static final MIRROR_UNFOLD:Ljava/lang/String; = "CMD_MIRROR_UNFOLD"

.field public static final PING:Ljava/lang/String; = "PING"

.field public static final RADIO_OFF:Ljava/lang/String; = "CMD_RADIO_OFF"

.field public static final RADIO_ON:Ljava/lang/String; = "CMD_RADIO_ON"

.field public static final REBOOT:Ljava/lang/String; = "CMD_REBOOT"

.field public static final SEAT_HEAT_OFF:Ljava/lang/String; = "CMD_SEAT_HEAT_OFF"

.field public static final SEAT_HEAT_ON:Ljava/lang/String; = "CMD_SEAT_HEAT_ON"

.field public static final SUNROOF_CLOSE:Ljava/lang/String; = "CMD_SUNROOF_CLOSE"

.field public static final SUNROOF_OPEN:Ljava/lang/String; = "CMD_SUNROOF_OPEN"

.field public static final TRUNK_CLOSE:Ljava/lang/String; = "CMD_TRUNK_CLOSE"

.field public static final TRUNK_OPEN:Ljava/lang/String; = "CMD_TRUNK_OPEN"

.field public static final WINDOW_CLOSE:Ljava/lang/String; = "CMD_WINDOW_CLOSE"

.field public static final WINDOW_OPEN:Ljava/lang/String; = "CMD_WINDOW_OPEN"


# direct methods
.method static constructor <clinit>()V
    .locals 1

    new-instance v0, Lcom/example/carcontroller/Cmd;

    invoke-direct {v0}, Lcom/example/carcontroller/Cmd;-><init>()V

    sput-object v0, Lcom/example/carcontroller/Cmd;->INSTANCE:Lcom/example/carcontroller/Cmd;

    return-void
.end method

.method private constructor <init>()V
    .locals 0

    .line 8
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method
