.class public final Lcom/example/carcontroller/CarClient$Result;
.super Ljava/lang/Object;
.source "CarClient.kt"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/example/carcontroller/CarClient;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x19
    name = "Result"
.end annotation

.annotation runtime Lkotlin/Metadata;
    d1 = {
        "\u0000(\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u000e\n\u0002\u0008\u0006\n\u0002\u0010\u000b\n\u0002\u0008\u0008\n\u0002\u0010\u0008\n\u0002\u0008\u0002\u0008\u0086\u0008\u0018\u00002\u00020\u0001B\u0017\u0012\u0006\u0010\u0002\u001a\u00020\u0003\u0012\u0008\u0008\u0002\u0010\u0004\u001a\u00020\u0005\u00a2\u0006\u0002\u0010\u0006J\t\u0010\u000f\u001a\u00020\u0003H\u00c6\u0003J\t\u0010\u0010\u001a\u00020\u0005H\u00c6\u0003J\u001d\u0010\u0011\u001a\u00020\u00002\u0008\u0008\u0002\u0010\u0002\u001a\u00020\u00032\u0008\u0008\u0002\u0010\u0004\u001a\u00020\u0005H\u00c6\u0001J\u0013\u0010\u0012\u001a\u00020\u000c2\u0008\u0010\u0013\u001a\u0004\u0018\u00010\u0001H\u00d6\u0003J\t\u0010\u0014\u001a\u00020\u0015H\u00d6\u0001J\t\u0010\u0016\u001a\u00020\u0005H\u00d6\u0001R\u0011\u0010\u0002\u001a\u00020\u0003\u00a2\u0006\u0008\n\u0000\u001a\u0004\u0008\u0007\u0010\u0008R\u0011\u0010\u0004\u001a\u00020\u0005\u00a2\u0006\u0008\n\u0000\u001a\u0004\u0008\t\u0010\nR\u0011\u0010\u000b\u001a\u00020\u000c8F\u00a2\u0006\u0006\u001a\u0004\u0008\r\u0010\u000e\u00a8\u0006\u0017"
    }
    d2 = {
        "Lcom/example/carcontroller/CarClient$Result;",
        "",
        "code",
        "Lcom/example/carcontroller/CarClient$Code;",
        "detail",
        "",
        "(Lcom/example/carcontroller/CarClient$Code;Ljava/lang/String;)V",
        "getCode",
        "()Lcom/example/carcontroller/CarClient$Code;",
        "getDetail",
        "()Ljava/lang/String;",
        "ok",
        "",
        "getOk",
        "()Z",
        "component1",
        "component2",
        "copy",
        "equals",
        "other",
        "hashCode",
        "",
        "toString",
        "app_debug"
    }
    k = 0x1
    mv = {
        0x1,
        0x9,
        0x0
    }
    xi = 0x30
.end annotation


# instance fields
.field private final code:Lcom/example/carcontroller/CarClient$Code;

.field private final detail:Ljava/lang/String;


# direct methods
.method public constructor <init>(Lcom/example/carcontroller/CarClient$Code;Ljava/lang/String;)V
    .locals 1
    .param p1, "code"    # Lcom/example/carcontroller/CarClient$Code;
    .param p2, "detail"    # Ljava/lang/String;

    const-string v0, "code"

    invoke-static {p1, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    const-string v0, "detail"

    invoke-static {p2, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 29
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Lcom/example/carcontroller/CarClient$Result;->code:Lcom/example/carcontroller/CarClient$Code;

    iput-object p2, p0, Lcom/example/carcontroller/CarClient$Result;->detail:Ljava/lang/String;

    return-void
.end method

.method public synthetic constructor <init>(Lcom/example/carcontroller/CarClient$Code;Ljava/lang/String;ILkotlin/jvm/internal/DefaultConstructorMarker;)V
    .locals 0

    .line 29
    and-int/lit8 p3, p3, 0x2

    if-eqz p3, :cond_0

    const-string p2, ""

    :cond_0
    invoke-direct {p0, p1, p2}, Lcom/example/carcontroller/CarClient$Result;-><init>(Lcom/example/carcontroller/CarClient$Code;Ljava/lang/String;)V

    .line 31
    return-void
.end method

.method public static synthetic copy$default(Lcom/example/carcontroller/CarClient$Result;Lcom/example/carcontroller/CarClient$Code;Ljava/lang/String;ILjava/lang/Object;)Lcom/example/carcontroller/CarClient$Result;
    .locals 0

    and-int/lit8 p4, p3, 0x1

    if-eqz p4, :cond_0

    iget-object p1, p0, Lcom/example/carcontroller/CarClient$Result;->code:Lcom/example/carcontroller/CarClient$Code;

    :cond_0
    and-int/lit8 p3, p3, 0x2

    if-eqz p3, :cond_1

    iget-object p2, p0, Lcom/example/carcontroller/CarClient$Result;->detail:Ljava/lang/String;

    :cond_1
    invoke-virtual {p0, p1, p2}, Lcom/example/carcontroller/CarClient$Result;->copy(Lcom/example/carcontroller/CarClient$Code;Ljava/lang/String;)Lcom/example/carcontroller/CarClient$Result;

    move-result-object p0

    return-object p0
.end method


# virtual methods
.method public final component1()Lcom/example/carcontroller/CarClient$Code;
    .locals 1

    iget-object v0, p0, Lcom/example/carcontroller/CarClient$Result;->code:Lcom/example/carcontroller/CarClient$Code;

    return-object v0
.end method

.method public final component2()Ljava/lang/String;
    .locals 1

    iget-object v0, p0, Lcom/example/carcontroller/CarClient$Result;->detail:Ljava/lang/String;

    return-object v0
.end method

.method public final copy(Lcom/example/carcontroller/CarClient$Code;Ljava/lang/String;)Lcom/example/carcontroller/CarClient$Result;
    .locals 1

    const-string v0, "code"

    invoke-static {p1, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    const-string v0, "detail"

    invoke-static {p2, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    new-instance v0, Lcom/example/carcontroller/CarClient$Result;

    invoke-direct {v0, p1, p2}, Lcom/example/carcontroller/CarClient$Result;-><init>(Lcom/example/carcontroller/CarClient$Code;Ljava/lang/String;)V

    return-object v0
.end method

.method public equals(Ljava/lang/Object;)Z
    .locals 5

    const/4 v0, 0x1

    if-ne p0, p1, :cond_0

    return v0

    :cond_0
    instance-of v1, p1, Lcom/example/carcontroller/CarClient$Result;

    const/4 v2, 0x0

    if-nez v1, :cond_1

    return v2

    :cond_1
    move-object v1, p1

    check-cast v1, Lcom/example/carcontroller/CarClient$Result;

    iget-object v3, p0, Lcom/example/carcontroller/CarClient$Result;->code:Lcom/example/carcontroller/CarClient$Code;

    iget-object v4, v1, Lcom/example/carcontroller/CarClient$Result;->code:Lcom/example/carcontroller/CarClient$Code;

    if-eq v3, v4, :cond_2

    return v2

    :cond_2
    iget-object v3, p0, Lcom/example/carcontroller/CarClient$Result;->detail:Ljava/lang/String;

    iget-object v1, v1, Lcom/example/carcontroller/CarClient$Result;->detail:Ljava/lang/String;

    invoke-static {v3, v1}, Lkotlin/jvm/internal/Intrinsics;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v1

    if-nez v1, :cond_3

    return v2

    :cond_3
    return v0
.end method

.method public final getCode()Lcom/example/carcontroller/CarClient$Code;
    .locals 1

    .line 29
    iget-object v0, p0, Lcom/example/carcontroller/CarClient$Result;->code:Lcom/example/carcontroller/CarClient$Code;

    return-object v0
.end method

.method public final getDetail()Ljava/lang/String;
    .locals 1

    .line 29
    iget-object v0, p0, Lcom/example/carcontroller/CarClient$Result;->detail:Ljava/lang/String;

    return-object v0
.end method

.method public final getOk()Z
    .locals 2

    .line 30
    iget-object v0, p0, Lcom/example/carcontroller/CarClient$Result;->code:Lcom/example/carcontroller/CarClient$Code;

    sget-object v1, Lcom/example/carcontroller/CarClient$Code;->OK:Lcom/example/carcontroller/CarClient$Code;

    if-ne v0, v1, :cond_0

    const/4 v0, 0x1

    goto :goto_0

    :cond_0
    const/4 v0, 0x0

    :goto_0
    return v0
.end method

.method public hashCode()I
    .locals 3

    iget-object v0, p0, Lcom/example/carcontroller/CarClient$Result;->code:Lcom/example/carcontroller/CarClient$Code;

    invoke-virtual {v0}, Lcom/example/carcontroller/CarClient$Code;->hashCode()I

    move-result v0

    mul-int/lit8 v1, v0, 0x1f

    iget-object v2, p0, Lcom/example/carcontroller/CarClient$Result;->detail:Ljava/lang/String;

    invoke-virtual {v2}, Ljava/lang/String;->hashCode()I

    move-result v2

    add-int/2addr v1, v2

    return v1
.end method

.method public toString()Ljava/lang/String;
    .locals 2

    new-instance v0, Ljava/lang/StringBuilder;

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    const-string v1, "Result(code="

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    iget-object v1, p0, Lcom/example/carcontroller/CarClient$Result;->code:Lcom/example/carcontroller/CarClient$Code;

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    move-result-object v0

    const-string v1, ", detail="

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    iget-object v1, p0, Lcom/example/carcontroller/CarClient$Result;->detail:Ljava/lang/String;

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    const/16 v1, 0x29

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(C)Ljava/lang/StringBuilder;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    return-object v0
.end method
