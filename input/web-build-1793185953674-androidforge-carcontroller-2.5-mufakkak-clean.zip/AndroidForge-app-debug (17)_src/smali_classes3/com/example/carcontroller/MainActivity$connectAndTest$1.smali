.class final Lcom/example/carcontroller/MainActivity$connectAndTest$1;
.super Lkotlin/jvm/internal/Lambda;
.source "MainActivity.kt"

# interfaces
.implements Lkotlin/jvm/functions/Function0;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lcom/example/carcontroller/MainActivity;->connectAndTest()V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x18
    name = null
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "Lkotlin/jvm/internal/Lambda;",
        "Lkotlin/jvm/functions/Function0<",
        "Lkotlin/Unit;",
        ">;"
    }
.end annotation

.annotation runtime Lkotlin/Metadata;
    d1 = {
        "\u0000\u0008\n\u0000\n\u0002\u0010\u0002\n\u0000\u0010\u0000\u001a\u00020\u0001H\n\u00a2\u0006\u0002\u0008\u0002"
    }
    d2 = {
        "<anonymous>",
        "",
        "invoke"
    }
    k = 0x3
    mv = {
        0x1,
        0x9,
        0x0
    }
    xi = 0x30
.end annotation


# instance fields
.field final synthetic $ip:Ljava/lang/String;

.field final synthetic $pin:Ljava/lang/String;

.field final synthetic this$0:Lcom/example/carcontroller/MainActivity;


# direct methods
.method public static synthetic $r8$lambda$pNN5WJaOHApDGfZyZTQlo2MKYzY(Lcom/example/carcontroller/MainActivity;Lcom/example/carcontroller/CarClient$Result;)V
    .locals 0

    invoke-static {p0, p1}, Lcom/example/carcontroller/MainActivity$connectAndTest$1;->invoke$lambda$0(Lcom/example/carcontroller/MainActivity;Lcom/example/carcontroller/CarClient$Result;)V

    return-void
.end method

.method constructor <init>(Ljava/lang/String;Ljava/lang/String;Lcom/example/carcontroller/MainActivity;)V
    .locals 1

    iput-object p1, p0, Lcom/example/carcontroller/MainActivity$connectAndTest$1;->$ip:Ljava/lang/String;

    iput-object p2, p0, Lcom/example/carcontroller/MainActivity$connectAndTest$1;->$pin:Ljava/lang/String;

    iput-object p3, p0, Lcom/example/carcontroller/MainActivity$connectAndTest$1;->this$0:Lcom/example/carcontroller/MainActivity;

    const/4 v0, 0x0

    invoke-direct {p0, v0}, Lkotlin/jvm/internal/Lambda;-><init>(I)V

    return-void
.end method

.method private static final invoke$lambda$0(Lcom/example/carcontroller/MainActivity;Lcom/example/carcontroller/CarClient$Result;)V
    .locals 4
    .param p0, "this$0"    # Lcom/example/carcontroller/MainActivity;
    .param p1, "$result"    # Lcom/example/carcontroller/CarClient$Result;

    const-string v0, "this$0"

    invoke-static {p0, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    const-string v0, "$result"

    invoke-static {p1, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 269
    invoke-virtual {p0}, Lcom/example/carcontroller/MainActivity;->isFinishing()Z

    move-result v0

    if-nez v0, :cond_2

    invoke-virtual {p0}, Lcom/example/carcontroller/MainActivity;->isDestroyed()Z

    move-result v0

    if-eqz v0, :cond_0

    goto :goto_1

    .line 270
    :cond_0
    invoke-virtual {p1}, Lcom/example/carcontroller/CarClient$Result;->getOk()Z

    move-result v0

    if-eqz v0, :cond_1

    .line 271
    sget-object v0, Lcom/example/carcontroller/MainActivity$State;->OK:Lcom/example/carcontroller/MainActivity$State;

    sget v1, Lcom/example/carcontroller/R$string;->status_connected:I

    invoke-virtual {p0, v1}, Lcom/example/carcontroller/MainActivity;->getString(I)Ljava/lang/String;

    move-result-object v1

    const-string v2, "getString(...)"

    invoke-static {v1, v2}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    invoke-static {p0, v0, v1}, Lcom/example/carcontroller/MainActivity;->access$setStatus(Lcom/example/carcontroller/MainActivity;Lcom/example/carcontroller/MainActivity$State;Ljava/lang/String;)V

    .line 272
    sget v0, Lcom/example/carcontroller/R$string;->res_connected:I

    invoke-virtual {p0, v0}, Lcom/example/carcontroller/MainActivity;->getString(I)Ljava/lang/String;

    move-result-object v0

    invoke-static {v0, v2}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    const/4 v1, 0x2

    const/4 v2, 0x0

    const/4 v3, 0x0

    invoke-static {p0, v0, v3, v1, v2}, Lcom/example/carcontroller/MainActivity;->toast$default(Lcom/example/carcontroller/MainActivity;Ljava/lang/String;ZILjava/lang/Object;)V

    goto :goto_0

    .line 274
    :cond_1
    const-string v0, ""

    invoke-static {p0, p1, v0}, Lcom/example/carcontroller/MainActivity;->access$showResult(Lcom/example/carcontroller/MainActivity;Lcom/example/carcontroller/CarClient$Result;Ljava/lang/String;)V

    .line 276
    :goto_0
    return-void

    .line 269
    :cond_2
    :goto_1
    return-void
.end method


# virtual methods
.method public bridge synthetic invoke()Ljava/lang/Object;
    .locals 1

    .line 266
    invoke-virtual {p0}, Lcom/example/carcontroller/MainActivity$connectAndTest$1;->invoke()V

    sget-object v0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    return-object v0
.end method

.method public final invoke()V
    .locals 7

    .line 267
    new-instance v6, Lcom/example/carcontroller/CarClient;

    iget-object v1, p0, Lcom/example/carcontroller/MainActivity$connectAndTest$1;->$ip:Ljava/lang/String;

    iget-object v2, p0, Lcom/example/carcontroller/MainActivity$connectAndTest$1;->$pin:Ljava/lang/String;

    const/4 v3, 0x0

    const/4 v4, 0x4

    const/4 v5, 0x0

    move-object v0, v6

    invoke-direct/range {v0 .. v5}, Lcom/example/carcontroller/CarClient;-><init>(Ljava/lang/String;Ljava/lang/String;IILkotlin/jvm/internal/DefaultConstructorMarker;)V

    invoke-virtual {v6}, Lcom/example/carcontroller/CarClient;->ping()Lcom/example/carcontroller/CarClient$Result;

    move-result-object v0

    .line 268
    .local v0, "result":Lcom/example/carcontroller/CarClient$Result;
    iget-object v1, p0, Lcom/example/carcontroller/MainActivity$connectAndTest$1;->this$0:Lcom/example/carcontroller/MainActivity;

    new-instance v2, Lcom/example/carcontroller/MainActivity$connectAndTest$1$$ExternalSyntheticLambda0;

    invoke-direct {v2, v1, v0}, Lcom/example/carcontroller/MainActivity$connectAndTest$1$$ExternalSyntheticLambda0;-><init>(Lcom/example/carcontroller/MainActivity;Lcom/example/carcontroller/CarClient$Result;)V

    invoke-virtual {v1, v2}, Lcom/example/carcontroller/MainActivity;->runOnUiThread(Ljava/lang/Runnable;)V

    .line 277
    return-void
.end method
