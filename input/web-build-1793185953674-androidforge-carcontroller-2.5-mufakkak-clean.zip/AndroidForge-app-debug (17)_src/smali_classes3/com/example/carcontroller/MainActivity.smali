.class public final Lcom/example/carcontroller/MainActivity;
.super Landroidx/appcompat/app/AppCompatActivity;
.source "MainActivity.kt"


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Lcom/example/carcontroller/MainActivity$Companion;,
        Lcom/example/carcontroller/MainActivity$State;,
        Lcom/example/carcontroller/MainActivity$WhenMappings;
    }
.end annotation

.annotation runtime Lkotlin/Metadata;
    d1 = {
        "\u0000\u009b\u0001\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0008\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\u0008\u0002\n\u0002\u0008\u0003\n\u0002\u0018\u0002\n\u0002\u0010\u000e\n\u0002\u0008\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u0002\n\u0002\u0008\u0002\n\u0002\u0018\u0002\n\u0002\u0008\u0003\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\u0008\u0007\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u000b\n\u0002\u0008\u0003\n\u0002\u0010 \n\u0002\u0008\u0002\n\u0002\u0018\u0002\n\u0002\u0008\u0011\n\u0002\u0018\u0002\n\u0002\u0008\n*\u0001\u000b\u0018\u0000 R2\u00020\u0001:\u0002RSB\u0005\u00a2\u0006\u0002\u0010\u0002J\u0008\u0010\u001b\u001a\u00020\u001cH\u0002J\u0010\u0010\u001d\u001a\u00020\u001c2\u0006\u0010\u001e\u001a\u00020\u001fH\u0002J\u0008\u0010 \u001a\u00020\u001cH\u0002J \u0010!\u001a\u00020\u00062\u0006\u0010\"\u001a\u00020#2\u0006\u0010$\u001a\u00020%2\u0006\u0010&\u001a\u00020\'H\u0002J\u0008\u0010(\u001a\u00020\u001cH\u0002J\u0008\u0010)\u001a\u00020\u001cH\u0002J\u0008\u0010*\u001a\u00020\u001cH\u0002J\u0008\u0010+\u001a\u00020\u000fH\u0002J\u0008\u0010,\u001a\u00020\u000fH\u0002J\u0010\u0010-\u001a\u00020\u000f2\u0006\u0010.\u001a\u00020/H\u0002J\u0012\u00100\u001a\u0002012\u0008\u00102\u001a\u0004\u0018\u00010\u0018H\u0002J\u0016\u00103\u001a\u00020\u001c2\u000c\u00104\u001a\u0008\u0012\u0004\u0012\u00020\u000f05H\u0002J\u0012\u00106\u001a\u00020\u001c2\u0008\u00107\u001a\u0004\u0018\u000108H\u0014J\u0008\u00109\u001a\u00020\u001cH\u0014J\u0010\u0010:\u001a\u00020\u001c2\u0006\u0010;\u001a\u00020\u0018H\u0014J\u0008\u0010<\u001a\u00020\u001cH\u0002J\u0008\u0010=\u001a\u00020\u0018H\u0002J\u0008\u0010>\u001a\u000201H\u0002J\u0018\u0010?\u001a\u00020\u001c2\u0006\u0010@\u001a\u00020\u000f2\u0006\u0010A\u001a\u00020\u000fH\u0002J\u0008\u0010B\u001a\u00020\u001cH\u0002J\u0018\u0010C\u001a\u00020\u001c2\u0006\u0010D\u001a\u00020\u000f2\u0006\u0010E\u001a\u00020\u000fH\u0002J\u0010\u0010F\u001a\u00020\u001c2\u0006\u0010G\u001a\u000201H\u0002J\u0018\u0010H\u001a\u00020\u001c2\u0006\u0010I\u001a\u00020J2\u0006\u0010K\u001a\u00020\u000fH\u0002J\u0018\u0010L\u001a\u00020\u001c2\u0006\u0010.\u001a\u00020/2\u0006\u0010E\u001a\u00020\u000fH\u0002J\u0008\u0010M\u001a\u00020\u001cH\u0002J\u0008\u0010N\u001a\u00020\u001cH\u0002J\u001a\u0010O\u001a\u00020\u001c2\u0006\u0010P\u001a\u00020\u000f2\u0008\u0008\u0002\u0010Q\u001a\u000201H\u0002R\u000e\u0010\u0003\u001a\u00020\u0004X\u0082.\u00a2\u0006\u0002\n\u0000R\u000e\u0010\u0005\u001a\u00020\u0006X\u0082.\u00a2\u0006\u0002\n\u0000R\u000e\u0010\u0007\u001a\u00020\u0008X\u0082.\u00a2\u0006\u0002\n\u0000R\u000e\u0010\t\u001a\u00020\u0008X\u0082.\u00a2\u0006\u0002\n\u0000R\u0010\u0010\n\u001a\u00020\u000bX\u0082\u0004\u00a2\u0006\u0004\n\u0002\u0010\u000cR\u001c\u0010\r\u001a\u0010\u0012\u000c\u0012\n \u0010*\u0004\u0018\u00010\u000f0\u000f0\u000eX\u0082\u0004\u00a2\u0006\u0002\n\u0000R\u000e\u0010\u0011\u001a\u00020\u0012X\u0082.\u00a2\u0006\u0002\n\u0000R\u001c\u0010\u0013\u001a\u0010\u0012\u000c\u0012\n \u0010*\u0004\u0018\u00010\u00140\u00140\u000eX\u0082\u0004\u00a2\u0006\u0002\n\u0000R\u0010\u0010\u0015\u001a\u0004\u0018\u00010\u0016X\u0082\u000e\u00a2\u0006\u0002\n\u0000R\u001c\u0010\u0017\u001a\u0010\u0012\u000c\u0012\n \u0010*\u0004\u0018\u00010\u00180\u00180\u000eX\u0082\u0004\u00a2\u0006\u0002\n\u0000R\u000e\u0010\u0019\u001a\u00020\u001aX\u0082.\u00a2\u0006\u0002\n\u0000\u00a8\u0006T"
    }
    d2 = {
        "Lcom/example/carcontroller/MainActivity;",
        "Landroidx/appcompat/app/AppCompatActivity;",
        "()V",
        "btnVoice",
        "Lcom/google/android/material/button/MaterialButton;",
        "dotStatus",
        "Landroid/view/View;",
        "etIp",
        "Lcom/google/android/material/textfield/TextInputEditText;",
        "etPin",
        "listener",
        "com/example/carcontroller/MainActivity$listener$1",
        "Lcom/example/carcontroller/MainActivity$listener$1;",
        "micPermission",
        "Landroidx/activity/result/ActivityResultLauncher;",
        "",
        "kotlin.jvm.PlatformType",
        "prefs",
        "Landroid/content/SharedPreferences;",
        "qrScanner",
        "Lcom/journeyapps/barcodescanner/ScanOptions;",
        "recognizer",
        "Landroid/speech/SpeechRecognizer;",
        "systemVoice",
        "Landroid/content/Intent;",
        "tvStatus",
        "Landroid/widget/TextView;",
        "applyInsets",
        "",
        "applyPairing",
        "p",
        "Lcom/example/carcontroller/PairingLink$Data;",
        "autoPing",
        "buildRow",
        "inflater",
        "Landroid/view/LayoutInflater;",
        "parent",
        "Landroid/view/ViewGroup;",
        "c",
        "Lcom/example/carcontroller/Control;",
        "buildSections",
        "confirmReboot",
        "connectAndTest",
        "currentIp",
        "currentPin",
        "describe",
        "r",
        "Lcom/example/carcontroller/CarClient$Result;",
        "handlePairingIntent",
        "",
        "i",
        "handleVoice",
        "texts",
        "",
        "onCreate",
        "savedInstanceState",
        "Landroid/os/Bundle;",
        "onDestroy",
        "onNewIntent",
        "intent",
        "onVoiceClicked",
        "recognizerIntent",
        "requireConnection",
        "save",
        "ip",
        "pin",
        "scanQr",
        "send",
        "cmd",
        "label",
        "setListening",
        "on",
        "setStatus",
        "state",
        "Lcom/example/carcontroller/MainActivity$State;",
        "text",
        "showResult",
        "sizeHero",
        "startVoice",
        "toast",
        "message",
        "long",
        "Companion",
        "State",
        "app_debug"
    }
    k = 0x1
    mv = {
        0x1,
        0x9,
        0x0
    }
    xi = 0x30
.end annotation


# static fields
.field public static final Companion:Lcom/example/carcontroller/MainActivity$Companion;

.field private static final KEY_IP:Ljava/lang/String; = "CAR_IP"

.field private static final KEY_PIN:Ljava/lang/String; = "CAR_PIN"

.field private static final PREFS:Ljava/lang/String; = "CarConfig"


# instance fields
.field private btnVoice:Lcom/google/android/material/button/MaterialButton;

.field private dotStatus:Landroid/view/View;

.field private etIp:Lcom/google/android/material/textfield/TextInputEditText;

.field private etPin:Lcom/google/android/material/textfield/TextInputEditText;

.field private final listener:Lcom/example/carcontroller/MainActivity$listener$1;

.field private final micPermission:Landroidx/activity/result/ActivityResultLauncher;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Landroidx/activity/result/ActivityResultLauncher<",
            "Ljava/lang/String;",
            ">;"
        }
    .end annotation
.end field

.field private prefs:Landroid/content/SharedPreferences;

.field private final qrScanner:Landroidx/activity/result/ActivityResultLauncher;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Landroidx/activity/result/ActivityResultLauncher<",
            "Lcom/journeyapps/barcodescanner/ScanOptions;",
            ">;"
        }
    .end annotation
.end field

.field private recognizer:Landroid/speech/SpeechRecognizer;

.field private final systemVoice:Landroidx/activity/result/ActivityResultLauncher;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Landroidx/activity/result/ActivityResultLauncher<",
            "Landroid/content/Intent;",
            ">;"
        }
    .end annotation
.end field

.field private tvStatus:Landroid/widget/TextView;


# direct methods
.method public static synthetic $r8$lambda$5cDgd-2bDRHQxX8U80P0rcr-wzo(Landroid/view/View;ILandroid/view/View;ILandroid/view/View;Landroidx/core/view/WindowInsetsCompat;)Landroidx/core/view/WindowInsetsCompat;
    .locals 0

    invoke-static/range {p0 .. p5}, Lcom/example/carcontroller/MainActivity;->applyInsets$lambda$7(Landroid/view/View;ILandroid/view/View;ILandroid/view/View;Landroidx/core/view/WindowInsetsCompat;)Landroidx/core/view/WindowInsetsCompat;

    move-result-object p0

    return-object p0
.end method

.method public static synthetic $r8$lambda$83AHvS0doiFLTIMUrX0RQ1CJ38A(Lcom/example/carcontroller/MainActivity;Landroid/view/View;)V
    .locals 0

    invoke-static {p0, p1}, Lcom/example/carcontroller/MainActivity;->onCreate$lambda$3(Lcom/example/carcontroller/MainActivity;Landroid/view/View;)V

    return-void
.end method

.method public static synthetic $r8$lambda$G74EyzD3O-pS4yEPIDNflujjj4U(Lcom/example/carcontroller/MainActivity;Landroid/content/DialogInterface;I)V
    .locals 0

    invoke-static {p0, p1, p2}, Lcom/example/carcontroller/MainActivity;->confirmReboot$lambda$10(Lcom/example/carcontroller/MainActivity;Landroid/content/DialogInterface;I)V

    return-void
.end method

.method public static synthetic $r8$lambda$JB7w35urldXJ6-znvSb1F1PneEY(Lcom/example/carcontroller/MainActivity;Landroidx/activity/result/ActivityResult;)V
    .locals 0

    invoke-static {p0, p1}, Lcom/example/carcontroller/MainActivity;->systemVoice$lambda$1(Lcom/example/carcontroller/MainActivity;Landroidx/activity/result/ActivityResult;)V

    return-void
.end method

.method public static synthetic $r8$lambda$LFy-qU9eJ5QkJmq5KK2Y5OtI2xk(Lcom/example/carcontroller/MainActivity;Landroid/view/View;)V
    .locals 0

    invoke-static {p0, p1}, Lcom/example/carcontroller/MainActivity;->onCreate$lambda$5(Lcom/example/carcontroller/MainActivity;Landroid/view/View;)V

    return-void
.end method

.method public static synthetic $r8$lambda$LnE0wCIj3pRW1NKt18A4YiBSb2A(Lcom/example/carcontroller/MainActivity;Landroid/view/View;)V
    .locals 0

    invoke-static {p0, p1}, Lcom/example/carcontroller/MainActivity;->onCreate$lambda$6(Lcom/example/carcontroller/MainActivity;Landroid/view/View;)V

    return-void
.end method

.method public static synthetic $r8$lambda$RRndRWyIFQlOcn5bobNxpxjiVZo(Lcom/example/carcontroller/MainActivity;Landroid/view/View;)V
    .locals 0

    invoke-static {p0, p1}, Lcom/example/carcontroller/MainActivity;->onCreate$lambda$4(Lcom/example/carcontroller/MainActivity;Landroid/view/View;)V

    return-void
.end method

.method public static synthetic $r8$lambda$UuzjDZW5vZChflqxjYVX1hekApA(Lcom/example/carcontroller/MainActivity;Lcom/example/carcontroller/Control;Landroid/view/View;)V
    .locals 0

    invoke-static {p0, p1, p2}, Lcom/example/carcontroller/MainActivity;->buildRow$lambda$8(Lcom/example/carcontroller/MainActivity;Lcom/example/carcontroller/Control;Landroid/view/View;)V

    return-void
.end method

.method public static synthetic $r8$lambda$YOcAbRHVO555Xsi6Td69FI5saps(Lcom/example/carcontroller/MainActivity;Lcom/journeyapps/barcodescanner/ScanIntentResult;)V
    .locals 0

    invoke-static {p0, p1}, Lcom/example/carcontroller/MainActivity;->qrScanner$lambda$2(Lcom/example/carcontroller/MainActivity;Lcom/journeyapps/barcodescanner/ScanIntentResult;)V

    return-void
.end method

.method public static synthetic $r8$lambda$YhpC8PtvEtB9dgpMQWuyuso_pCA(Lcom/example/carcontroller/MainActivity;Ljava/lang/String;Lcom/example/carcontroller/Control;Ljava/lang/Integer;Landroid/view/View;)V
    .locals 0

    invoke-static {p0, p1, p2, p3, p4}, Lcom/example/carcontroller/MainActivity;->buildRow$lambda$9(Lcom/example/carcontroller/MainActivity;Ljava/lang/String;Lcom/example/carcontroller/Control;Ljava/lang/Integer;Landroid/view/View;)V

    return-void
.end method

.method public static synthetic $r8$lambda$_oVjOg1VnLnPnWmZxnK7wIfpI_0(Lcom/example/carcontroller/MainActivity;Ljava/lang/Boolean;)V
    .locals 0

    invoke-static {p0, p1}, Lcom/example/carcontroller/MainActivity;->micPermission$lambda$0(Lcom/example/carcontroller/MainActivity;Ljava/lang/Boolean;)V

    return-void
.end method

.method public static synthetic $r8$lambda$zQ46SAyN-qmJIB6Wnh8faEIYO-8(Lcom/example/carcontroller/MainActivity;Lcom/example/carcontroller/PairingLink$Data;Landroid/content/DialogInterface;I)V
    .locals 0

    invoke-static {p0, p1, p2, p3}, Lcom/example/carcontroller/MainActivity;->handlePairingIntent$lambda$11(Lcom/example/carcontroller/MainActivity;Lcom/example/carcontroller/PairingLink$Data;Landroid/content/DialogInterface;I)V

    return-void
.end method

.method static constructor <clinit>()V
    .locals 2

    new-instance v0, Lcom/example/carcontroller/MainActivity$Companion;

    const/4 v1, 0x0

    invoke-direct {v0, v1}, Lcom/example/carcontroller/MainActivity$Companion;-><init>(Lkotlin/jvm/internal/DefaultConstructorMarker;)V

    sput-object v0, Lcom/example/carcontroller/MainActivity;->Companion:Lcom/example/carcontroller/MainActivity$Companion;

    return-void
.end method

.method public constructor <init>()V
    .locals 3

    .line 35
    invoke-direct {p0}, Landroidx/appcompat/app/AppCompatActivity;-><init>()V

    .line 48
    new-instance v0, Landroidx/activity/result/contract/ActivityResultContracts$RequestPermission;

    invoke-direct {v0}, Landroidx/activity/result/contract/ActivityResultContracts$RequestPermission;-><init>()V

    check-cast v0, Landroidx/activity/result/contract/ActivityResultContract;

    new-instance v1, Lcom/example/carcontroller/MainActivity$$ExternalSyntheticLambda11;

    invoke-direct {v1, p0}, Lcom/example/carcontroller/MainActivity$$ExternalSyntheticLambda11;-><init>(Lcom/example/carcontroller/MainActivity;)V

    invoke-virtual {p0, v0, v1}, Lcom/example/carcontroller/MainActivity;->registerForActivityResult(Landroidx/activity/result/contract/ActivityResultContract;Landroidx/activity/result/ActivityResultCallback;)Landroidx/activity/result/ActivityResultLauncher;

    move-result-object v0

    const-string v1, "registerForActivityResult(...)"

    invoke-static {v0, v1}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    iput-object v0, p0, Lcom/example/carcontroller/MainActivity;->micPermission:Landroidx/activity/result/ActivityResultLauncher;

    .line 54
    new-instance v0, Landroidx/activity/result/contract/ActivityResultContracts$StartActivityForResult;

    invoke-direct {v0}, Landroidx/activity/result/contract/ActivityResultContracts$StartActivityForResult;-><init>()V

    check-cast v0, Landroidx/activity/result/contract/ActivityResultContract;

    new-instance v2, Lcom/example/carcontroller/MainActivity$$ExternalSyntheticLambda1;

    invoke-direct {v2, p0}, Lcom/example/carcontroller/MainActivity$$ExternalSyntheticLambda1;-><init>(Lcom/example/carcontroller/MainActivity;)V

    invoke-virtual {p0, v0, v2}, Lcom/example/carcontroller/MainActivity;->registerForActivityResult(Landroidx/activity/result/contract/ActivityResultContract;Landroidx/activity/result/ActivityResultCallback;)Landroidx/activity/result/ActivityResultLauncher;

    move-result-object v0

    invoke-static {v0, v1}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    iput-object v0, p0, Lcom/example/carcontroller/MainActivity;->systemVoice:Landroidx/activity/result/ActivityResultLauncher;

    .line 62
    new-instance v0, Lcom/journeyapps/barcodescanner/ScanContract;

    invoke-direct {v0}, Lcom/journeyapps/barcodescanner/ScanContract;-><init>()V

    check-cast v0, Landroidx/activity/result/contract/ActivityResultContract;

    new-instance v2, Lcom/example/carcontroller/MainActivity$$ExternalSyntheticLambda2;

    invoke-direct {v2, p0}, Lcom/example/carcontroller/MainActivity$$ExternalSyntheticLambda2;-><init>(Lcom/example/carcontroller/MainActivity;)V

    invoke-virtual {p0, v0, v2}, Lcom/example/carcontroller/MainActivity;->registerForActivityResult(Landroidx/activity/result/contract/ActivityResultContract;Landroidx/activity/result/ActivityResultCallback;)Landroidx/activity/result/ActivityResultLauncher;

    move-result-object v0

    invoke-static {v0, v1}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    iput-object v0, p0, Lcom/example/carcontroller/MainActivity;->qrScanner:Landroidx/activity/result/ActivityResultLauncher;

    .line 418
    new-instance v0, Lcom/example/carcontroller/MainActivity$listener$1;

    invoke-direct {v0, p0}, Lcom/example/carcontroller/MainActivity$listener$1;-><init>(Lcom/example/carcontroller/MainActivity;)V

    iput-object v0, p0, Lcom/example/carcontroller/MainActivity;->listener:Lcom/example/carcontroller/MainActivity$listener$1;

    .line 35
    return-void
.end method

.method public static final synthetic access$getEtIp$p(Lcom/example/carcontroller/MainActivity;)Lcom/google/android/material/textfield/TextInputEditText;
    .locals 1
    .param p0, "$this"    # Lcom/example/carcontroller/MainActivity;

    .line 35
    iget-object v0, p0, Lcom/example/carcontroller/MainActivity;->etIp:Lcom/google/android/material/textfield/TextInputEditText;

    return-object v0
.end method

.method public static final synthetic access$getEtPin$p(Lcom/example/carcontroller/MainActivity;)Lcom/google/android/material/textfield/TextInputEditText;
    .locals 1
    .param p0, "$this"    # Lcom/example/carcontroller/MainActivity;

    .line 35
    iget-object v0, p0, Lcom/example/carcontroller/MainActivity;->etPin:Lcom/google/android/material/textfield/TextInputEditText;

    return-object v0
.end method

.method public static final synthetic access$handleVoice(Lcom/example/carcontroller/MainActivity;Ljava/util/List;)V
    .locals 0
    .param p0, "$this"    # Lcom/example/carcontroller/MainActivity;
    .param p1, "texts"    # Ljava/util/List;

    .line 35
    invoke-direct {p0, p1}, Lcom/example/carcontroller/MainActivity;->handleVoice(Ljava/util/List;)V

    return-void
.end method

.method public static final synthetic access$save(Lcom/example/carcontroller/MainActivity;Ljava/lang/String;Ljava/lang/String;)V
    .locals 0
    .param p0, "$this"    # Lcom/example/carcontroller/MainActivity;
    .param p1, "ip"    # Ljava/lang/String;
    .param p2, "pin"    # Ljava/lang/String;

    .line 35
    invoke-direct {p0, p1, p2}, Lcom/example/carcontroller/MainActivity;->save(Ljava/lang/String;Ljava/lang/String;)V

    return-void
.end method

.method public static final synthetic access$setListening(Lcom/example/carcontroller/MainActivity;Z)V
    .locals 0
    .param p0, "$this"    # Lcom/example/carcontroller/MainActivity;
    .param p1, "on"    # Z

    .line 35
    invoke-direct {p0, p1}, Lcom/example/carcontroller/MainActivity;->setListening(Z)V

    return-void
.end method

.method public static final synthetic access$setStatus(Lcom/example/carcontroller/MainActivity;Lcom/example/carcontroller/MainActivity$State;Ljava/lang/String;)V
    .locals 0
    .param p0, "$this"    # Lcom/example/carcontroller/MainActivity;
    .param p1, "state"    # Lcom/example/carcontroller/MainActivity$State;
    .param p2, "text"    # Ljava/lang/String;

    .line 35
    invoke-direct {p0, p1, p2}, Lcom/example/carcontroller/MainActivity;->setStatus(Lcom/example/carcontroller/MainActivity$State;Ljava/lang/String;)V

    return-void
.end method

.method public static final synthetic access$showResult(Lcom/example/carcontroller/MainActivity;Lcom/example/carcontroller/CarClient$Result;Ljava/lang/String;)V
    .locals 0
    .param p0, "$this"    # Lcom/example/carcontroller/MainActivity;
    .param p1, "r"    # Lcom/example/carcontroller/CarClient$Result;
    .param p2, "label"    # Ljava/lang/String;

    .line 35
    invoke-direct {p0, p1, p2}, Lcom/example/carcontroller/MainActivity;->showResult(Lcom/example/carcontroller/CarClient$Result;Ljava/lang/String;)V

    return-void
.end method

.method public static final synthetic access$toast(Lcom/example/carcontroller/MainActivity;Ljava/lang/String;Z)V
    .locals 0
    .param p0, "$this"    # Lcom/example/carcontroller/MainActivity;
    .param p1, "message"    # Ljava/lang/String;
    .param p2, "long"    # Z

    .line 35
    invoke-direct {p0, p1, p2}, Lcom/example/carcontroller/MainActivity;->toast(Ljava/lang/String;Z)V

    return-void
.end method

.method private final applyInsets()V
    .locals 6

    .line 114
    sget v0, Lcom/example/carcontroller/R$id;->topBar:I

    invoke-virtual {p0, v0}, Lcom/example/carcontroller/MainActivity;->findViewById(I)Landroid/view/View;

    move-result-object v0

    .line 115
    .local v0, "topBar":Landroid/view/View;
    sget v1, Lcom/example/carcontroller/R$id;->scroll:I

    invoke-virtual {p0, v1}, Lcom/example/carcontroller/MainActivity;->findViewById(I)Landroid/view/View;

    move-result-object v1

    .line 116
    .local v1, "scroll":Landroid/view/View;
    invoke-virtual {v0}, Landroid/view/View;->getPaddingTop()I

    move-result v2

    .line 117
    .local v2, "topPad":I
    invoke-virtual {v1}, Landroid/view/View;->getPaddingBottom()I

    move-result v3

    .line 118
    .local v3, "bottomPad":I
    sget v4, Lcom/example/carcontroller/R$id;->root:I

    invoke-virtual {p0, v4}, Lcom/example/carcontroller/MainActivity;->findViewById(I)Landroid/view/View;

    move-result-object v4

    new-instance v5, Lcom/example/carcontroller/MainActivity$$ExternalSyntheticLambda0;

    invoke-direct {v5, v0, v2, v1, v3}, Lcom/example/carcontroller/MainActivity$$ExternalSyntheticLambda0;-><init>(Landroid/view/View;ILandroid/view/View;I)V

    invoke-static {v4, v5}, Landroidx/core/view/ViewCompat;->setOnApplyWindowInsetsListener(Landroid/view/View;Landroidx/core/view/OnApplyWindowInsetsListener;)V

    .line 124
    return-void
.end method

.method private static final applyInsets$lambda$7(Landroid/view/View;ILandroid/view/View;ILandroid/view/View;Landroidx/core/view/WindowInsetsCompat;)Landroidx/core/view/WindowInsetsCompat;
    .locals 4
    .param p0, "$topBar"    # Landroid/view/View;
    .param p1, "$topPad"    # I
    .param p2, "$scroll"    # Landroid/view/View;
    .param p3, "$bottomPad"    # I
    .param p5, "insets"    # Landroidx/core/view/WindowInsetsCompat;

    const-string v0, "<anonymous parameter 0>"

    invoke-static {p4, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    const-string p4, "insets"

    invoke-static {p5, p4}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 119
    invoke-static {}, Landroidx/core/view/WindowInsetsCompat$Type;->systemBars()I

    move-result p4

    invoke-virtual {p5, p4}, Landroidx/core/view/WindowInsetsCompat;->getInsets(I)Landroidx/core/graphics/Insets;

    move-result-object p4

    const-string v0, "getInsets(...)"

    invoke-static {p4, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    .line 120
    .local p4, "bars":Landroidx/core/graphics/Insets;
    invoke-virtual {p0}, Landroid/view/View;->getPaddingLeft()I

    move-result v0

    iget v1, p4, Landroidx/core/graphics/Insets;->top:I

    add-int/2addr v1, p1

    invoke-virtual {p0}, Landroid/view/View;->getPaddingRight()I

    move-result v2

    invoke-virtual {p0}, Landroid/view/View;->getPaddingBottom()I

    move-result v3

    invoke-virtual {p0, v0, v1, v2, v3}, Landroid/view/View;->setPadding(IIII)V

    .line 121
    invoke-virtual {p2}, Landroid/view/View;->getPaddingLeft()I

    move-result v0

    invoke-virtual {p2}, Landroid/view/View;->getPaddingTop()I

    move-result v1

    invoke-virtual {p2}, Landroid/view/View;->getPaddingRight()I

    move-result v2

    iget v3, p4, Landroidx/core/graphics/Insets;->bottom:I

    add-int/2addr v3, p3

    invoke-virtual {p2, v0, v1, v2, v3}, Landroid/view/View;->setPadding(IIII)V

    .line 122
    return-object p5
.end method

.method private final applyPairing(Lcom/example/carcontroller/PairingLink$Data;)V
    .locals 11
    .param p1, "p"    # Lcom/example/carcontroller/PairingLink$Data;

    .line 338
    sget-object v0, Lcom/example/carcontroller/MainActivity$State;->BUSY:Lcom/example/carcontroller/MainActivity$State;

    sget v1, Lcom/example/carcontroller/R$string;->status_sending:I

    invoke-virtual {p0, v1}, Lcom/example/carcontroller/MainActivity;->getString(I)Ljava/lang/String;

    move-result-object v1

    const-string v2, "getString(...)"

    invoke-static {v1, v2}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    invoke-direct {p0, v0, v1}, Lcom/example/carcontroller/MainActivity;->setStatus(Lcom/example/carcontroller/MainActivity$State;Ljava/lang/String;)V

    .line 339
    const/4 v3, 0x0

    const/4 v4, 0x0

    const/4 v5, 0x0

    const/4 v6, 0x0

    const/4 v7, 0x0

    new-instance v0, Lcom/example/carcontroller/MainActivity$applyPairing$1;

    invoke-direct {v0, p1, p0}, Lcom/example/carcontroller/MainActivity$applyPairing$1;-><init>(Lcom/example/carcontroller/PairingLink$Data;Lcom/example/carcontroller/MainActivity;)V

    move-object v8, v0

    check-cast v8, Lkotlin/jvm/functions/Function0;

    const/16 v9, 0x1f

    const/4 v10, 0x0

    invoke-static/range {v3 .. v10}, Lkotlin/concurrent/ThreadsKt;->thread$default(ZZLjava/lang/ClassLoader;Ljava/lang/String;ILkotlin/jvm/functions/Function0;ILjava/lang/Object;)Ljava/lang/Thread;

    .line 362
    return-void
.end method

.method private final autoPing()V
    .locals 12

    .line 282
    invoke-direct {p0}, Lcom/example/carcontroller/MainActivity;->currentIp()Ljava/lang/String;

    move-result-object v0

    .line 283
    .local v0, "ip":Ljava/lang/String;
    invoke-direct {p0}, Lcom/example/carcontroller/MainActivity;->currentPin()Ljava/lang/String;

    move-result-object v1

    .line 284
    .local v1, "pin":Ljava/lang/String;
    move-object v2, v0

    check-cast v2, Ljava/lang/CharSequence;

    invoke-interface {v2}, Ljava/lang/CharSequence;->length()I

    move-result v2

    const/4 v3, 0x1

    const/4 v4, 0x0

    if-nez v2, :cond_0

    move v2, v3

    goto :goto_0

    :cond_0
    move v2, v4

    :goto_0
    if-nez v2, :cond_3

    move-object v2, v1

    check-cast v2, Ljava/lang/CharSequence;

    invoke-interface {v2}, Ljava/lang/CharSequence;->length()I

    move-result v2

    if-nez v2, :cond_1

    goto :goto_1

    :cond_1
    move v3, v4

    :goto_1
    if-eqz v3, :cond_2

    goto :goto_2

    .line 285
    :cond_2
    const/4 v4, 0x0

    const/4 v5, 0x0

    const/4 v6, 0x0

    const/4 v7, 0x0

    const/4 v8, 0x0

    new-instance v2, Lcom/example/carcontroller/MainActivity$autoPing$1;

    invoke-direct {v2, v0, v1, p0}, Lcom/example/carcontroller/MainActivity$autoPing$1;-><init>(Ljava/lang/String;Ljava/lang/String;Lcom/example/carcontroller/MainActivity;)V

    move-object v9, v2

    check-cast v9, Lkotlin/jvm/functions/Function0;

    const/16 v10, 0x1f

    const/4 v11, 0x0

    invoke-static/range {v4 .. v11}, Lkotlin/concurrent/ThreadsKt;->thread$default(ZZLjava/lang/ClassLoader;Ljava/lang/String;ILkotlin/jvm/functions/Function0;ILjava/lang/Object;)Ljava/lang/Thread;

    .line 291
    return-void

    .line 284
    :cond_3
    :goto_2
    return-void
.end method

.method private final buildRow(Landroid/view/LayoutInflater;Landroid/view/ViewGroup;Lcom/example/carcontroller/Control;)Landroid/view/View;
    .locals 6
    .param p1, "inflater"    # Landroid/view/LayoutInflater;
    .param p2, "parent"    # Landroid/view/ViewGroup;
    .param p3, "c"    # Lcom/example/carcontroller/Control;

    .line 153
    sget v0, Lcom/example/carcontroller/R$layout;->item_control_row:I

    const/4 v1, 0x0

    invoke-virtual {p1, v0, p2, v1}, Landroid/view/LayoutInflater;->inflate(ILandroid/view/ViewGroup;Z)Landroid/view/View;

    move-result-object v0

    .line 154
    .local v0, "row":Landroid/view/View;
    sget v1, Lcom/example/carcontroller/R$id;->ivIcon:I

    invoke-virtual {v0, v1}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    move-result-object v1

    check-cast v1, Landroid/widget/ImageView;

    invoke-virtual {p3}, Lcom/example/carcontroller/Control;->getIcon()I

    move-result v2

    invoke-virtual {v1, v2}, Landroid/widget/ImageView;->setImageResource(I)V

    .line 155
    sget v1, Lcom/example/carcontroller/R$id;->tvLabel:I

    invoke-virtual {v0, v1}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    move-result-object v1

    check-cast v1, Landroid/widget/TextView;

    invoke-virtual {p3}, Lcom/example/carcontroller/Control;->getLabel()I

    move-result v2

    invoke-virtual {v1, v2}, Landroid/widget/TextView;->setText(I)V

    .line 157
    sget v1, Lcom/example/carcontroller/R$id;->btnA:I

    invoke-virtual {v0, v1}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    move-result-object v1

    check-cast v1, Lcom/google/android/material/button/MaterialButton;

    .line 158
    .local v1, "btnA":Lcom/google/android/material/button/MaterialButton;
    invoke-virtual {p3}, Lcom/example/carcontroller/Control;->getALabel()I

    move-result v2

    invoke-virtual {v1, v2}, Lcom/google/android/material/button/MaterialButton;->setText(I)V

    .line 159
    new-instance v2, Lcom/example/carcontroller/MainActivity$$ExternalSyntheticLambda8;

    invoke-direct {v2, p0, p3}, Lcom/example/carcontroller/MainActivity$$ExternalSyntheticLambda8;-><init>(Lcom/example/carcontroller/MainActivity;Lcom/example/carcontroller/Control;)V

    invoke-virtual {v1, v2}, Lcom/google/android/material/button/MaterialButton;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    .line 164
    sget v2, Lcom/example/carcontroller/R$id;->btnB:I

    invoke-virtual {v0, v2}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    move-result-object v2

    check-cast v2, Lcom/google/android/material/button/MaterialButton;

    .line 165
    .local v2, "btnB":Lcom/google/android/material/button/MaterialButton;
    invoke-virtual {p3}, Lcom/example/carcontroller/Control;->getBLabel()Ljava/lang/Integer;

    move-result-object v3

    .line 166
    .local v3, "bLabel":Ljava/lang/Integer;
    invoke-virtual {p3}, Lcom/example/carcontroller/Control;->getBCmd()Ljava/lang/String;

    move-result-object v4

    .line 167
    .local v4, "bCmd":Ljava/lang/String;
    if-eqz v3, :cond_0

    if-eqz v4, :cond_0

    .line 168
    invoke-virtual {v3}, Ljava/lang/Integer;->intValue()I

    move-result v5

    invoke-virtual {v2, v5}, Lcom/google/android/material/button/MaterialButton;->setText(I)V

    .line 169
    new-instance v5, Lcom/example/carcontroller/MainActivity$$ExternalSyntheticLambda9;

    invoke-direct {v5, p0, v4, p3, v3}, Lcom/example/carcontroller/MainActivity$$ExternalSyntheticLambda9;-><init>(Lcom/example/carcontroller/MainActivity;Ljava/lang/String;Lcom/example/carcontroller/Control;Ljava/lang/Integer;)V

    invoke-virtual {v2, v5}, Lcom/google/android/material/button/MaterialButton;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    goto :goto_0

    .line 174
    :cond_0
    const/16 v5, 0x8

    invoke-virtual {v2, v5}, Lcom/google/android/material/button/MaterialButton;->setVisibility(I)V

    .line 176
    :goto_0
    invoke-static {v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNull(Ljava/lang/Object;)V

    return-object v0
.end method

.method private static final buildRow$lambda$8(Lcom/example/carcontroller/MainActivity;Lcom/example/carcontroller/Control;Landroid/view/View;)V
    .locals 3
    .param p0, "this$0"    # Lcom/example/carcontroller/MainActivity;
    .param p1, "$c"    # Lcom/example/carcontroller/Control;
    .param p2, "v"    # Landroid/view/View;

    const-string v0, "this$0"

    invoke-static {p0, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    const-string v0, "$c"

    invoke-static {p1, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 160
    const/4 v0, 0x1

    invoke-virtual {p2, v0}, Landroid/view/View;->performHapticFeedback(I)Z

    .line 161
    invoke-virtual {p1}, Lcom/example/carcontroller/Control;->getACmd()Ljava/lang/String;

    move-result-object v0

    new-instance v1, Ljava/lang/StringBuilder;

    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {p1}, Lcom/example/carcontroller/Control;->getLabel()I

    move-result v2

    invoke-virtual {p0, v2}, Lcom/example/carcontroller/MainActivity;->getString(I)Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    const-string v2, " \u00b7 "

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    invoke-virtual {p1}, Lcom/example/carcontroller/Control;->getALabel()I

    move-result v2

    invoke-virtual {p0, v2}, Lcom/example/carcontroller/MainActivity;->getString(I)Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    invoke-direct {p0, v0, v1}, Lcom/example/carcontroller/MainActivity;->send(Ljava/lang/String;Ljava/lang/String;)V

    .line 162
    return-void
.end method

.method private static final buildRow$lambda$9(Lcom/example/carcontroller/MainActivity;Ljava/lang/String;Lcom/example/carcontroller/Control;Ljava/lang/Integer;Landroid/view/View;)V
    .locals 2
    .param p0, "this$0"    # Lcom/example/carcontroller/MainActivity;
    .param p1, "$bCmd"    # Ljava/lang/String;
    .param p2, "$c"    # Lcom/example/carcontroller/Control;
    .param p3, "$bLabel"    # Ljava/lang/Integer;
    .param p4, "v"    # Landroid/view/View;

    const-string v0, "this$0"

    invoke-static {p0, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    const-string v0, "$c"

    invoke-static {p2, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 170
    const/4 v0, 0x1

    invoke-virtual {p4, v0}, Landroid/view/View;->performHapticFeedback(I)Z

    .line 171
    new-instance v0, Ljava/lang/StringBuilder;

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {p2}, Lcom/example/carcontroller/Control;->getLabel()I

    move-result v1

    invoke-virtual {p0, v1}, Lcom/example/carcontroller/MainActivity;->getString(I)Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    const-string v1, " \u00b7 "

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    invoke-virtual {p3}, Ljava/lang/Integer;->intValue()I

    move-result v1

    invoke-virtual {p0, v1}, Lcom/example/carcontroller/MainActivity;->getString(I)Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    invoke-direct {p0, p1, v0}, Lcom/example/carcontroller/MainActivity;->send(Ljava/lang/String;Ljava/lang/String;)V

    .line 172
    return-void
.end method

.method private final buildSections()V
    .locals 9

    .line 140
    sget v0, Lcom/example/carcontroller/R$id;->sectionsContainer:I

    invoke-virtual {p0, v0}, Lcom/example/carcontroller/MainActivity;->findViewById(I)Landroid/view/View;

    move-result-object v0

    check-cast v0, Landroid/widget/LinearLayout;

    .line 141
    .local v0, "container":Landroid/widget/LinearLayout;
    move-object v1, p0

    check-cast v1, Landroid/content/Context;

    invoke-static {v1}, Landroid/view/LayoutInflater;->from(Landroid/content/Context;)Landroid/view/LayoutInflater;

    move-result-object v1

    .line 142
    .local v1, "inflater":Landroid/view/LayoutInflater;
    sget-object v2, Lcom/example/carcontroller/Controls;->INSTANCE:Lcom/example/carcontroller/Controls;

    invoke-virtual {v2}, Lcom/example/carcontroller/Controls;->getSections()Ljava/util/List;

    move-result-object v2

    invoke-interface {v2}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    move-result-object v2

    :goto_0
    invoke-interface {v2}, Ljava/util/Iterator;->hasNext()Z

    move-result v3

    if-eqz v3, :cond_1

    invoke-interface {v2}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v3

    check-cast v3, Lcom/example/carcontroller/Section;

    .line 143
    .local v3, "section":Lcom/example/carcontroller/Section;
    sget v4, Lcom/example/carcontroller/R$layout;->item_section:I

    move-object v5, v0

    check-cast v5, Landroid/view/ViewGroup;

    const/4 v6, 0x0

    invoke-virtual {v1, v4, v5, v6}, Landroid/view/LayoutInflater;->inflate(ILandroid/view/ViewGroup;Z)Landroid/view/View;

    move-result-object v4

    .line 144
    .local v4, "card":Landroid/view/View;
    sget v5, Lcom/example/carcontroller/R$id;->ivSectionIcon:I

    invoke-virtual {v4, v5}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    move-result-object v5

    check-cast v5, Landroid/widget/ImageView;

    invoke-virtual {v3}, Lcom/example/carcontroller/Section;->getIcon()I

    move-result v6

    invoke-virtual {v5, v6}, Landroid/widget/ImageView;->setImageResource(I)V

    .line 145
    sget v5, Lcom/example/carcontroller/R$id;->tvSectionTitle:I

    invoke-virtual {v4, v5}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    move-result-object v5

    check-cast v5, Landroid/widget/TextView;

    invoke-virtual {v3}, Lcom/example/carcontroller/Section;->getTitle()I

    move-result v6

    invoke-virtual {v5, v6}, Landroid/widget/TextView;->setText(I)V

    .line 146
    sget v5, Lcom/example/carcontroller/R$id;->rowsContainer:I

    invoke-virtual {v4, v5}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    move-result-object v5

    check-cast v5, Landroid/widget/LinearLayout;

    .line 147
    .local v5, "rows":Landroid/widget/LinearLayout;
    invoke-virtual {v3}, Lcom/example/carcontroller/Section;->getItems()Ljava/util/List;

    move-result-object v6

    invoke-interface {v6}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    move-result-object v6

    :goto_1
    invoke-interface {v6}, Ljava/util/Iterator;->hasNext()Z

    move-result v7

    if-eqz v7, :cond_0

    invoke-interface {v6}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v7

    check-cast v7, Lcom/example/carcontroller/Control;

    .local v7, "control":Lcom/example/carcontroller/Control;
    invoke-static {v1}, Lkotlin/jvm/internal/Intrinsics;->checkNotNull(Ljava/lang/Object;)V

    invoke-static {v5}, Lkotlin/jvm/internal/Intrinsics;->checkNotNull(Ljava/lang/Object;)V

    move-object v8, v5

    check-cast v8, Landroid/view/ViewGroup;

    invoke-direct {p0, v1, v8, v7}, Lcom/example/carcontroller/MainActivity;->buildRow(Landroid/view/LayoutInflater;Landroid/view/ViewGroup;Lcom/example/carcontroller/Control;)Landroid/view/View;

    move-result-object v8

    invoke-virtual {v5, v8}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;)V

    .end local v7    # "control":Lcom/example/carcontroller/Control;
    goto :goto_1

    .line 148
    :cond_0
    invoke-virtual {v0, v4}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;)V

    .end local v3    # "section":Lcom/example/carcontroller/Section;
    .end local v4    # "card":Landroid/view/View;
    .end local v5    # "rows":Landroid/widget/LinearLayout;
    goto :goto_0

    .line 150
    :cond_1
    return-void
.end method

.method private final confirmReboot()V
    .locals 3

    .line 294
    new-instance v0, Lcom/google/android/material/dialog/MaterialAlertDialogBuilder;

    move-object v1, p0

    check-cast v1, Landroid/content/Context;

    invoke-direct {v0, v1}, Lcom/google/android/material/dialog/MaterialAlertDialogBuilder;-><init>(Landroid/content/Context;)V

    .line 295
    sget v1, Lcom/example/carcontroller/R$string;->reboot_title:I

    invoke-virtual {v0, v1}, Lcom/google/android/material/dialog/MaterialAlertDialogBuilder;->setTitle(I)Lcom/google/android/material/dialog/MaterialAlertDialogBuilder;

    move-result-object v0

    .line 296
    sget v1, Lcom/example/carcontroller/R$string;->reboot_msg:I

    invoke-virtual {v0, v1}, Lcom/google/android/material/dialog/MaterialAlertDialogBuilder;->setMessage(I)Lcom/google/android/material/dialog/MaterialAlertDialogBuilder;

    move-result-object v0

    .line 297
    sget v1, Lcom/example/carcontroller/R$string;->reboot_yes:I

    new-instance v2, Lcom/example/carcontroller/MainActivity$$ExternalSyntheticLambda7;

    invoke-direct {v2, p0}, Lcom/example/carcontroller/MainActivity$$ExternalSyntheticLambda7;-><init>(Lcom/example/carcontroller/MainActivity;)V

    invoke-virtual {v0, v1, v2}, Lcom/google/android/material/dialog/MaterialAlertDialogBuilder;->setPositiveButton(ILandroid/content/DialogInterface$OnClickListener;)Lcom/google/android/material/dialog/MaterialAlertDialogBuilder;

    move-result-object v0

    .line 298
    sget v1, Lcom/example/carcontroller/R$string;->cancel:I

    const/4 v2, 0x0

    invoke-virtual {v0, v1, v2}, Lcom/google/android/material/dialog/MaterialAlertDialogBuilder;->setNegativeButton(ILandroid/content/DialogInterface$OnClickListener;)Lcom/google/android/material/dialog/MaterialAlertDialogBuilder;

    move-result-object v0

    .line 299
    invoke-virtual {v0}, Lcom/google/android/material/dialog/MaterialAlertDialogBuilder;->show()Landroidx/appcompat/app/AlertDialog;

    .line 300
    return-void
.end method

.method private static final confirmReboot$lambda$10(Lcom/example/carcontroller/MainActivity;Landroid/content/DialogInterface;I)V
    .locals 0
    .param p0, "this$0"    # Lcom/example/carcontroller/MainActivity;

    const-string p1, "this$0"

    invoke-static {p0, p1}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 297
    sget p1, Lcom/example/carcontroller/R$string;->btn_reboot:I

    invoke-virtual {p0, p1}, Lcom/example/carcontroller/MainActivity;->getString(I)Ljava/lang/String;

    move-result-object p1

    const-string p2, "getString(...)"

    invoke-static {p1, p2}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    const-string p2, "CMD_REBOOT"

    invoke-direct {p0, p2, p1}, Lcom/example/carcontroller/MainActivity;->send(Ljava/lang/String;Ljava/lang/String;)V

    return-void
.end method

.method private final connectAndTest()V
    .locals 13

    .line 261
    invoke-direct {p0}, Lcom/example/carcontroller/MainActivity;->requireConnection()Z

    move-result v0

    if-nez v0, :cond_0

    return-void

    .line 262
    :cond_0
    invoke-direct {p0}, Lcom/example/carcontroller/MainActivity;->currentIp()Ljava/lang/String;

    move-result-object v0

    .line 263
    .local v0, "ip":Ljava/lang/String;
    invoke-direct {p0}, Lcom/example/carcontroller/MainActivity;->currentPin()Ljava/lang/String;

    move-result-object v1

    .line 264
    .local v1, "pin":Ljava/lang/String;
    invoke-direct {p0, v0, v1}, Lcom/example/carcontroller/MainActivity;->save(Ljava/lang/String;Ljava/lang/String;)V

    .line 265
    sget-object v2, Lcom/example/carcontroller/MainActivity$State;->BUSY:Lcom/example/carcontroller/MainActivity$State;

    sget v3, Lcom/example/carcontroller/R$string;->status_sending:I

    invoke-virtual {p0, v3}, Lcom/example/carcontroller/MainActivity;->getString(I)Ljava/lang/String;

    move-result-object v3

    const-string v4, "getString(...)"

    invoke-static {v3, v4}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    invoke-direct {p0, v2, v3}, Lcom/example/carcontroller/MainActivity;->setStatus(Lcom/example/carcontroller/MainActivity$State;Ljava/lang/String;)V

    .line 266
    const/4 v5, 0x0

    const/4 v6, 0x0

    const/4 v7, 0x0

    const/4 v8, 0x0

    const/4 v9, 0x0

    new-instance v2, Lcom/example/carcontroller/MainActivity$connectAndTest$1;

    invoke-direct {v2, v0, v1, p0}, Lcom/example/carcontroller/MainActivity$connectAndTest$1;-><init>(Ljava/lang/String;Ljava/lang/String;Lcom/example/carcontroller/MainActivity;)V

    move-object v10, v2

    check-cast v10, Lkotlin/jvm/functions/Function0;

    const/16 v11, 0x1f

    const/4 v12, 0x0

    invoke-static/range {v5 .. v12}, Lkotlin/concurrent/ThreadsKt;->thread$default(ZZLjava/lang/ClassLoader;Ljava/lang/String;ILkotlin/jvm/functions/Function0;ILjava/lang/Object;)Ljava/lang/Thread;

    .line 278
    return-void
.end method

.method private final currentIp()Ljava/lang/String;
    .locals 2

    .line 225
    iget-object v0, p0, Lcom/example/carcontroller/MainActivity;->etIp:Lcom/google/android/material/textfield/TextInputEditText;

    const/4 v1, 0x0

    if-nez v0, :cond_0

    const-string v0, "etIp"

    invoke-static {v0}, Lkotlin/jvm/internal/Intrinsics;->throwUninitializedPropertyAccessException(Ljava/lang/String;)V

    move-object v0, v1

    :cond_0
    invoke-virtual {v0}, Lcom/google/android/material/textfield/TextInputEditText;->getText()Landroid/text/Editable;

    move-result-object v0

    if-eqz v0, :cond_1

    invoke-virtual {v0}, Ljava/lang/Object;->toString()Ljava/lang/String;

    move-result-object v0

    if-eqz v0, :cond_1

    check-cast v0, Ljava/lang/CharSequence;

    invoke-static {v0}, Lkotlin/text/StringsKt;->trim(Ljava/lang/CharSequence;)Ljava/lang/CharSequence;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/Object;->toString()Ljava/lang/String;

    move-result-object v1

    :cond_1
    if-nez v1, :cond_2

    const-string v1, ""

    :cond_2
    return-object v1
.end method

.method private final currentPin()Ljava/lang/String;
    .locals 2

    .line 226
    iget-object v0, p0, Lcom/example/carcontroller/MainActivity;->etPin:Lcom/google/android/material/textfield/TextInputEditText;

    const/4 v1, 0x0

    if-nez v0, :cond_0

    const-string v0, "etPin"

    invoke-static {v0}, Lkotlin/jvm/internal/Intrinsics;->throwUninitializedPropertyAccessException(Ljava/lang/String;)V

    move-object v0, v1

    :cond_0
    invoke-virtual {v0}, Lcom/google/android/material/textfield/TextInputEditText;->getText()Landroid/text/Editable;

    move-result-object v0

    if-eqz v0, :cond_1

    invoke-virtual {v0}, Ljava/lang/Object;->toString()Ljava/lang/String;

    move-result-object v0

    if-eqz v0, :cond_1

    check-cast v0, Ljava/lang/CharSequence;

    invoke-static {v0}, Lkotlin/text/StringsKt;->trim(Ljava/lang/CharSequence;)Ljava/lang/CharSequence;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/Object;->toString()Ljava/lang/String;

    move-result-object v1

    :cond_1
    if-nez v1, :cond_2

    const-string v1, ""

    :cond_2
    return-object v1
.end method

.method private final describe(Lcom/example/carcontroller/CarClient$Result;)Ljava/lang/String;
    .locals 2
    .param p1, "r"    # Lcom/example/carcontroller/CarClient$Result;

    .line 196
    nop

    .line 197
    invoke-virtual {p1}, Lcom/example/carcontroller/CarClient$Result;->getCode()Lcom/example/carcontroller/CarClient$Code;

    move-result-object v0

    sget-object v1, Lcom/example/carcontroller/MainActivity$WhenMappings;->$EnumSwitchMapping$1:[I

    invoke-virtual {v0}, Lcom/example/carcontroller/CarClient$Code;->ordinal()I

    move-result v0

    aget v0, v1, v0

    packed-switch v0, :pswitch_data_0

    .line 208
    new-instance v0, Lkotlin/NoWhenBranchMatchedException;

    invoke-direct {v0}, Lkotlin/NoWhenBranchMatchedException;-><init>()V

    throw v0

    :pswitch_0
    sget v0, Lcom/example/carcontroller/R$string;->res_io:I

    goto :goto_0

    .line 207
    :pswitch_1
    sget v0, Lcom/example/carcontroller/R$string;->res_no_reply:I

    goto :goto_0

    .line 206
    :pswitch_2
    sget v0, Lcom/example/carcontroller/R$string;->res_bad_ip:I

    goto :goto_0

    .line 205
    :pswitch_3
    sget v0, Lcom/example/carcontroller/R$string;->res_timeout:I

    goto :goto_0

    .line 204
    :pswitch_4
    sget v0, Lcom/example/carcontroller/R$string;->res_unreachable:I

    goto :goto_0

    .line 203
    :pswitch_5
    sget v0, Lcom/example/carcontroller/R$string;->res_format:I

    goto :goto_0

    .line 202
    :pswitch_6
    sget v0, Lcom/example/carcontroller/R$string;->res_exec:I

    goto :goto_0

    .line 201
    :pswitch_7
    sget v0, Lcom/example/carcontroller/R$string;->res_unknown:I

    goto :goto_0

    .line 200
    :pswitch_8
    sget v0, Lcom/example/carcontroller/R$string;->res_locked:I

    goto :goto_0

    .line 199
    :pswitch_9
    sget v0, Lcom/example/carcontroller/R$string;->res_auth:I

    goto :goto_0

    .line 198
    :pswitch_a
    sget v0, Lcom/example/carcontroller/R$string;->res_connected:I

    .line 196
    :goto_0
    invoke-virtual {p0, v0}, Lcom/example/carcontroller/MainActivity;->getString(I)Ljava/lang/String;

    move-result-object v0

    const-string v1, "getString(...)"

    invoke-static {v0, v1}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    .line 210
    return-object v0

    :pswitch_data_0
    .packed-switch 0x1
        :pswitch_a
        :pswitch_9
        :pswitch_8
        :pswitch_7
        :pswitch_6
        :pswitch_5
        :pswitch_4
        :pswitch_3
        :pswitch_2
        :pswitch_1
        :pswitch_0
    .end packed-switch
.end method

.method private final handlePairingIntent(Landroid/content/Intent;)Z
    .locals 6
    .param p1, "i"    # Landroid/content/Intent;

    .line 319
    const/4 v0, 0x0

    if-eqz p1, :cond_4

    invoke-virtual {p1}, Landroid/content/Intent;->getAction()Ljava/lang/String;

    move-result-object v1

    const-string v2, "android.intent.action.VIEW"

    invoke-static {v1, v2}, Lkotlin/jvm/internal/Intrinsics;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v1

    if-nez v1, :cond_0

    goto :goto_0

    .line 320
    :cond_0
    invoke-virtual {p1}, Landroid/content/Intent;->getData()Landroid/net/Uri;

    move-result-object v1

    if-nez v1, :cond_1

    return v0

    .line 321
    .local v1, "data":Landroid/net/Uri;
    :cond_1
    const-string v2, "geelycar"

    invoke-virtual {v1}, Landroid/net/Uri;->getScheme()Ljava/lang/String;

    move-result-object v3

    const/4 v4, 0x1

    invoke-static {v2, v3, v4}, Lkotlin/text/StringsKt;->equals(Ljava/lang/String;Ljava/lang/String;Z)Z

    move-result v2

    if-nez v2, :cond_2

    return v0

    .line 322
    :cond_2
    sget-object v0, Lcom/example/carcontroller/PairingLink;->INSTANCE:Lcom/example/carcontroller/PairingLink;

    invoke-virtual {v1}, Landroid/net/Uri;->toString()Ljava/lang/String;

    move-result-object v2

    const-string v3, "toString(...)"

    invoke-static {v2, v3}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    invoke-virtual {v0, v2}, Lcom/example/carcontroller/PairingLink;->parse(Ljava/lang/String;)Lcom/example/carcontroller/PairingLink$Data;

    move-result-object v0

    .line 323
    .local v0, "pairing":Lcom/example/carcontroller/PairingLink$Data;
    if-nez v0, :cond_3

    .line 324
    sget v2, Lcom/example/carcontroller/R$string;->qr_invalid:I

    invoke-virtual {p0, v2}, Lcom/example/carcontroller/MainActivity;->getString(I)Ljava/lang/String;

    move-result-object v2

    const-string v3, "getString(...)"

    invoke-static {v2, v3}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    invoke-direct {p0, v2, v4}, Lcom/example/carcontroller/MainActivity;->toast(Ljava/lang/String;Z)V

    .line 325
    return v4

    .line 327
    :cond_3
    new-instance v2, Lcom/google/android/material/dialog/MaterialAlertDialogBuilder;

    move-object v3, p0

    check-cast v3, Landroid/content/Context;

    invoke-direct {v2, v3}, Lcom/google/android/material/dialog/MaterialAlertDialogBuilder;-><init>(Landroid/content/Context;)V

    .line 328
    sget v3, Lcom/example/carcontroller/R$string;->pair_dialog_title:I

    invoke-virtual {v2, v3}, Lcom/google/android/material/dialog/MaterialAlertDialogBuilder;->setTitle(I)Lcom/google/android/material/dialog/MaterialAlertDialogBuilder;

    move-result-object v2

    .line 329
    sget v3, Lcom/example/carcontroller/R$string;->pair_dialog_msg:I

    invoke-virtual {v0}, Lcom/example/carcontroller/PairingLink$Data;->getIps()Ljava/util/List;

    move-result-object v5

    invoke-static {v5}, Lkotlin/collections/CollectionsKt;->first(Ljava/util/List;)Ljava/lang/Object;

    move-result-object v5

    filled-new-array {v5}, [Ljava/lang/Object;

    move-result-object v5

    invoke-virtual {p0, v3, v5}, Lcom/example/carcontroller/MainActivity;->getString(I[Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v3

    check-cast v3, Ljava/lang/CharSequence;

    invoke-virtual {v2, v3}, Lcom/google/android/material/dialog/MaterialAlertDialogBuilder;->setMessage(Ljava/lang/CharSequence;)Lcom/google/android/material/dialog/MaterialAlertDialogBuilder;

    move-result-object v2

    .line 330
    sget v3, Lcom/example/carcontroller/R$string;->pair_yes:I

    new-instance v5, Lcom/example/carcontroller/MainActivity$$ExternalSyntheticLambda10;

    invoke-direct {v5, p0, v0}, Lcom/example/carcontroller/MainActivity$$ExternalSyntheticLambda10;-><init>(Lcom/example/carcontroller/MainActivity;Lcom/example/carcontroller/PairingLink$Data;)V

    invoke-virtual {v2, v3, v5}, Lcom/google/android/material/dialog/MaterialAlertDialogBuilder;->setPositiveButton(ILandroid/content/DialogInterface$OnClickListener;)Lcom/google/android/material/dialog/MaterialAlertDialogBuilder;

    move-result-object v2

    .line 331
    sget v3, Lcom/example/carcontroller/R$string;->cancel:I

    const/4 v5, 0x0

    invoke-virtual {v2, v3, v5}, Lcom/google/android/material/dialog/MaterialAlertDialogBuilder;->setNegativeButton(ILandroid/content/DialogInterface$OnClickListener;)Lcom/google/android/material/dialog/MaterialAlertDialogBuilder;

    move-result-object v2

    .line 332
    invoke-virtual {v2}, Lcom/google/android/material/dialog/MaterialAlertDialogBuilder;->show()Landroidx/appcompat/app/AlertDialog;

    .line 333
    return v4

    .line 319
    .end local v0    # "pairing":Lcom/example/carcontroller/PairingLink$Data;
    .end local v1    # "data":Landroid/net/Uri;
    :cond_4
    :goto_0
    return v0
.end method

.method private static final handlePairingIntent$lambda$11(Lcom/example/carcontroller/MainActivity;Lcom/example/carcontroller/PairingLink$Data;Landroid/content/DialogInterface;I)V
    .locals 0
    .param p0, "this$0"    # Lcom/example/carcontroller/MainActivity;
    .param p1, "$pairing"    # Lcom/example/carcontroller/PairingLink$Data;

    const-string p2, "this$0"

    invoke-static {p0, p2}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 330
    invoke-direct {p0, p1}, Lcom/example/carcontroller/MainActivity;->applyPairing(Lcom/example/carcontroller/PairingLink$Data;)V

    return-void
.end method

.method private final handleVoice(Ljava/util/List;)V
    .locals 6
    .param p1, "texts"    # Ljava/util/List;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/util/List<",
            "Ljava/lang/String;",
            ">;)V"
        }
    .end annotation

    .line 405
    invoke-interface {p1}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    move-result-object v0

    :goto_0
    invoke-interface {v0}, Ljava/util/Iterator;->hasNext()Z

    move-result v1

    if-eqz v1, :cond_1

    invoke-interface {v0}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Ljava/lang/String;

    .line 406
    .local v1, "text":Ljava/lang/String;
    sget-object v2, Lcom/example/carcontroller/VoiceCommandParser;->INSTANCE:Lcom/example/carcontroller/VoiceCommandParser;

    invoke-virtual {v2, v1}, Lcom/example/carcontroller/VoiceCommandParser;->parse(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v2

    if-nez v2, :cond_0

    goto :goto_0

    :cond_0
    move-object v0, v2

    .line 407
    .local v0, "cmd":Ljava/lang/String;
    sget v2, Lcom/example/carcontroller/R$string;->voice_heard:I

    filled-new-array {v1}, [Ljava/lang/Object;

    move-result-object v3

    invoke-virtual {p0, v2, v3}, Lcom/example/carcontroller/MainActivity;->getString(I[Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v2

    const-string v3, "getString(...)"

    invoke-static {v2, v3}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    const/4 v3, 0x2

    const/4 v4, 0x0

    const/4 v5, 0x0

    invoke-static {p0, v2, v5, v3, v4}, Lcom/example/carcontroller/MainActivity;->toast$default(Lcom/example/carcontroller/MainActivity;Ljava/lang/String;ZILjava/lang/Object;)V

    .line 408
    invoke-direct {p0, v0, v1}, Lcom/example/carcontroller/MainActivity;->send(Ljava/lang/String;Ljava/lang/String;)V

    .line 409
    return-void

    .line 411
    .end local v0    # "cmd":Ljava/lang/String;
    .end local v1    # "text":Ljava/lang/String;
    :cond_1
    nop

    .line 412
    invoke-interface {p1}, Ljava/util/List;->isEmpty()Z

    move-result v0

    if-eqz v0, :cond_2

    sget v0, Lcom/example/carcontroller/R$string;->voice_no_match:I

    invoke-virtual {p0, v0}, Lcom/example/carcontroller/MainActivity;->getString(I)Ljava/lang/String;

    move-result-object v0

    goto :goto_1

    .line 413
    :cond_2
    sget v0, Lcom/example/carcontroller/R$string;->voice_unknown:I

    invoke-static {p1}, Lkotlin/collections/CollectionsKt;->first(Ljava/util/List;)Ljava/lang/Object;

    move-result-object v1

    filled-new-array {v1}, [Ljava/lang/Object;

    move-result-object v1

    invoke-virtual {p0, v0, v1}, Lcom/example/carcontroller/MainActivity;->getString(I[Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v0

    .line 412
    :goto_1
    invoke-static {v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNull(Ljava/lang/Object;)V

    .line 414
    nop

    .line 411
    const/4 v1, 0x1

    invoke-direct {p0, v0, v1}, Lcom/example/carcontroller/MainActivity;->toast(Ljava/lang/String;Z)V

    .line 416
    return-void
.end method

.method private static final micPermission$lambda$0(Lcom/example/carcontroller/MainActivity;Ljava/lang/Boolean;)V
    .locals 2
    .param p0, "this$0"    # Lcom/example/carcontroller/MainActivity;
    .param p1, "granted"    # Ljava/lang/Boolean;

    const-string v0, "this$0"

    invoke-static {p0, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 49
    invoke-static {p1}, Lkotlin/jvm/internal/Intrinsics;->checkNotNull(Ljava/lang/Object;)V

    invoke-virtual {p1}, Ljava/lang/Boolean;->booleanValue()Z

    move-result v0

    if-eqz v0, :cond_0

    invoke-direct {p0}, Lcom/example/carcontroller/MainActivity;->startVoice()V

    goto :goto_0

    :cond_0
    sget v0, Lcom/example/carcontroller/R$string;->mic_denied:I

    invoke-virtual {p0, v0}, Lcom/example/carcontroller/MainActivity;->getString(I)Ljava/lang/String;

    move-result-object v0

    const-string v1, "getString(...)"

    invoke-static {v0, v1}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    const/4 v1, 0x1

    invoke-direct {p0, v0, v1}, Lcom/example/carcontroller/MainActivity;->toast(Ljava/lang/String;Z)V

    .line 50
    :goto_0
    return-void
.end method

.method private static final onCreate$lambda$3(Lcom/example/carcontroller/MainActivity;Landroid/view/View;)V
    .locals 1
    .param p0, "this$0"    # Lcom/example/carcontroller/MainActivity;
    .param p1, "it"    # Landroid/view/View;

    const-string v0, "this$0"

    invoke-static {p0, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 88
    invoke-direct {p0}, Lcom/example/carcontroller/MainActivity;->connectAndTest()V

    return-void
.end method

.method private static final onCreate$lambda$4(Lcom/example/carcontroller/MainActivity;Landroid/view/View;)V
    .locals 1
    .param p0, "this$0"    # Lcom/example/carcontroller/MainActivity;
    .param p1, "it"    # Landroid/view/View;

    const-string v0, "this$0"

    invoke-static {p0, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 89
    invoke-direct {p0}, Lcom/example/carcontroller/MainActivity;->scanQr()V

    return-void
.end method

.method private static final onCreate$lambda$5(Lcom/example/carcontroller/MainActivity;Landroid/view/View;)V
    .locals 1
    .param p0, "this$0"    # Lcom/example/carcontroller/MainActivity;
    .param p1, "it"    # Landroid/view/View;

    const-string v0, "this$0"

    invoke-static {p0, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 90
    invoke-direct {p0}, Lcom/example/carcontroller/MainActivity;->onVoiceClicked()V

    return-void
.end method

.method private static final onCreate$lambda$6(Lcom/example/carcontroller/MainActivity;Landroid/view/View;)V
    .locals 1
    .param p0, "this$0"    # Lcom/example/carcontroller/MainActivity;
    .param p1, "it"    # Landroid/view/View;

    const-string v0, "this$0"

    invoke-static {p0, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 91
    invoke-direct {p0}, Lcom/example/carcontroller/MainActivity;->confirmReboot()V

    return-void
.end method

.method private final onVoiceClicked()V
    .locals 2

    .line 367
    move-object v0, p0

    check-cast v0, Landroid/content/Context;

    const-string v1, "android.permission.RECORD_AUDIO"

    invoke-static {v0, v1}, Landroidx/core/content/ContextCompat;->checkSelfPermission(Landroid/content/Context;Ljava/lang/String;)I

    move-result v0

    if-eqz v0, :cond_0

    .line 370
    iget-object v0, p0, Lcom/example/carcontroller/MainActivity;->micPermission:Landroidx/activity/result/ActivityResultLauncher;

    invoke-virtual {v0, v1}, Landroidx/activity/result/ActivityResultLauncher;->launch(Ljava/lang/Object;)V

    .line 371
    return-void

    .line 373
    :cond_0
    invoke-direct {p0}, Lcom/example/carcontroller/MainActivity;->startVoice()V

    .line 374
    return-void
.end method

.method private static final qrScanner$lambda$2(Lcom/example/carcontroller/MainActivity;Lcom/journeyapps/barcodescanner/ScanIntentResult;)V
    .locals 4
    .param p0, "this$0"    # Lcom/example/carcontroller/MainActivity;
    .param p1, "result"    # Lcom/journeyapps/barcodescanner/ScanIntentResult;

    const-string v0, "this$0"

    invoke-static {p0, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 63
    invoke-virtual {p1}, Lcom/journeyapps/barcodescanner/ScanIntentResult;->getContents()Ljava/lang/String;

    move-result-object v0

    if-nez v0, :cond_0

    return-void

    .line 64
    .local v0, "text":Ljava/lang/String;
    :cond_0
    sget-object v1, Lcom/example/carcontroller/PairingLink;->INSTANCE:Lcom/example/carcontroller/PairingLink;

    invoke-virtual {v1, v0}, Lcom/example/carcontroller/PairingLink;->parse(Ljava/lang/String;)Lcom/example/carcontroller/PairingLink$Data;

    move-result-object v1

    .line 65
    .local v1, "pairing":Lcom/example/carcontroller/PairingLink$Data;
    if-nez v1, :cond_1

    sget v2, Lcom/example/carcontroller/R$string;->qr_invalid:I

    invoke-virtual {p0, v2}, Lcom/example/carcontroller/MainActivity;->getString(I)Ljava/lang/String;

    move-result-object v2

    const-string v3, "getString(...)"

    invoke-static {v2, v3}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    const/4 v3, 0x1

    invoke-direct {p0, v2, v3}, Lcom/example/carcontroller/MainActivity;->toast(Ljava/lang/String;Z)V

    goto :goto_0

    :cond_1
    invoke-direct {p0, v1}, Lcom/example/carcontroller/MainActivity;->applyPairing(Lcom/example/carcontroller/PairingLink$Data;)V

    .line 66
    :goto_0
    return-void
.end method

.method private final recognizerIntent()Landroid/content/Intent;
    .locals 5

    .line 377
    new-instance v0, Landroid/content/Intent;

    const-string v1, "android.speech.action.RECOGNIZE_SPEECH"

    invoke-direct {v0, v1}, Landroid/content/Intent;-><init>(Ljava/lang/String;)V

    move-object v1, v0

    .local v1, "$this$recognizerIntent_u24lambda_u2412":Landroid/content/Intent;
    const/4 v2, 0x0

    .line 378
    .local v2, "$i$a$-apply-MainActivity$recognizerIntent$1":I
    const-string v3, "android.speech.extra.LANGUAGE_MODEL"

    const-string v4, "free_form"

    invoke-virtual {v1, v3, v4}, Landroid/content/Intent;->putExtra(Ljava/lang/String;Ljava/lang/String;)Landroid/content/Intent;

    .line 379
    const-string v3, "android.speech.extra.LANGUAGE"

    const-string v4, "ar-SA"

    invoke-virtual {v1, v3, v4}, Landroid/content/Intent;->putExtra(Ljava/lang/String;Ljava/lang/String;)Landroid/content/Intent;

    .line 380
    const-string v3, "android.speech.extra.MAX_RESULTS"

    const/4 v4, 0x5

    invoke-virtual {v1, v3, v4}, Landroid/content/Intent;->putExtra(Ljava/lang/String;I)Landroid/content/Intent;

    .line 381
    nop

    .line 377
    .end local v1    # "$this$recognizerIntent_u24lambda_u2412":Landroid/content/Intent;
    .end local v2    # "$i$a$-apply-MainActivity$recognizerIntent$1":I
    nop

    .line 381
    return-object v0
.end method

.method private final requireConnection()Z
    .locals 4

    .line 233
    invoke-direct {p0}, Lcom/example/carcontroller/MainActivity;->currentIp()Ljava/lang/String;

    move-result-object v0

    check-cast v0, Ljava/lang/CharSequence;

    invoke-interface {v0}, Ljava/lang/CharSequence;->length()I

    move-result v0

    const/4 v1, 0x0

    const/4 v2, 0x1

    if-nez v0, :cond_0

    move v0, v2

    goto :goto_0

    :cond_0
    move v0, v1

    :goto_0
    const-string v3, "getString(...)"

    if-eqz v0, :cond_1

    .line 234
    sget v0, Lcom/example/carcontroller/R$string;->msg_need_ip:I

    invoke-virtual {p0, v0}, Lcom/example/carcontroller/MainActivity;->getString(I)Ljava/lang/String;

    move-result-object v0

    invoke-static {v0, v3}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    invoke-direct {p0, v0, v2}, Lcom/example/carcontroller/MainActivity;->toast(Ljava/lang/String;Z)V

    .line 235
    return v1

    .line 237
    :cond_1
    invoke-direct {p0}, Lcom/example/carcontroller/MainActivity;->currentPin()Ljava/lang/String;

    move-result-object v0

    check-cast v0, Ljava/lang/CharSequence;

    invoke-interface {v0}, Ljava/lang/CharSequence;->length()I

    move-result v0

    if-nez v0, :cond_2

    move v0, v2

    goto :goto_1

    :cond_2
    move v0, v1

    :goto_1
    if-eqz v0, :cond_3

    .line 238
    sget v0, Lcom/example/carcontroller/R$string;->msg_need_pin:I

    invoke-virtual {p0, v0}, Lcom/example/carcontroller/MainActivity;->getString(I)Ljava/lang/String;

    move-result-object v0

    invoke-static {v0, v3}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    invoke-direct {p0, v0, v2}, Lcom/example/carcontroller/MainActivity;->toast(Ljava/lang/String;Z)V

    .line 239
    return v1

    .line 241
    :cond_3
    return v2
.end method

.method private final save(Ljava/lang/String;Ljava/lang/String;)V
    .locals 2
    .param p1, "ip"    # Ljava/lang/String;
    .param p2, "pin"    # Ljava/lang/String;

    .line 228
    iget-object v0, p0, Lcom/example/carcontroller/MainActivity;->prefs:Landroid/content/SharedPreferences;

    if-nez v0, :cond_0

    const-string v0, "prefs"

    invoke-static {v0}, Lkotlin/jvm/internal/Intrinsics;->throwUninitializedPropertyAccessException(Ljava/lang/String;)V

    const/4 v0, 0x0

    :cond_0
    invoke-interface {v0}, Landroid/content/SharedPreferences;->edit()Landroid/content/SharedPreferences$Editor;

    move-result-object v0

    const-string v1, "CAR_IP"

    invoke-interface {v0, v1, p1}, Landroid/content/SharedPreferences$Editor;->putString(Ljava/lang/String;Ljava/lang/String;)Landroid/content/SharedPreferences$Editor;

    move-result-object v0

    const-string v1, "CAR_PIN"

    invoke-interface {v0, v1, p2}, Landroid/content/SharedPreferences$Editor;->putString(Ljava/lang/String;Ljava/lang/String;)Landroid/content/SharedPreferences$Editor;

    move-result-object v0

    invoke-interface {v0}, Landroid/content/SharedPreferences$Editor;->apply()V

    .line 229
    return-void
.end method

.method private final scanQr()V
    .locals 4

    .line 305
    new-instance v0, Lcom/journeyapps/barcodescanner/ScanOptions;

    invoke-direct {v0}, Lcom/journeyapps/barcodescanner/ScanOptions;-><init>()V

    .line 306
    const-string v1, "QR_CODE"

    filled-new-array {v1}, [Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v0, v1}, Lcom/journeyapps/barcodescanner/ScanOptions;->setDesiredBarcodeFormats([Ljava/lang/String;)Lcom/journeyapps/barcodescanner/ScanOptions;

    move-result-object v0

    .line 307
    sget v1, Lcom/example/carcontroller/R$string;->qr_prompt:I

    invoke-virtual {p0, v1}, Lcom/example/carcontroller/MainActivity;->getString(I)Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v0, v1}, Lcom/journeyapps/barcodescanner/ScanOptions;->setPrompt(Ljava/lang/String;)Lcom/journeyapps/barcodescanner/ScanOptions;

    move-result-object v0

    .line 308
    const/4 v1, 0x0

    invoke-virtual {v0, v1}, Lcom/journeyapps/barcodescanner/ScanOptions;->setBeepEnabled(Z)Lcom/journeyapps/barcodescanner/ScanOptions;

    move-result-object v0

    .line 309
    invoke-virtual {v0, v1}, Lcom/journeyapps/barcodescanner/ScanOptions;->setOrientationLocked(Z)Lcom/journeyapps/barcodescanner/ScanOptions;

    move-result-object v0

    .line 305
    nop

    .line 310
    .local v0, "options":Lcom/journeyapps/barcodescanner/ScanOptions;
    nop

    .line 311
    :try_start_0
    iget-object v1, p0, Lcom/example/carcontroller/MainActivity;->qrScanner:Landroidx/activity/result/ActivityResultLauncher;

    invoke-virtual {v1, v0}, Landroidx/activity/result/ActivityResultLauncher;->launch(Ljava/lang/Object;)V
    :try_end_0
    .catch Landroid/content/ActivityNotFoundException; {:try_start_0 .. :try_end_0} :catch_0

    goto :goto_0

    .line 312
    :catch_0
    move-exception v1

    .line 313
    .local v1, "e":Landroid/content/ActivityNotFoundException;
    sget v2, Lcom/example/carcontroller/R$string;->qr_scan_failed:I

    invoke-virtual {p0, v2}, Lcom/example/carcontroller/MainActivity;->getString(I)Ljava/lang/String;

    move-result-object v2

    const-string v3, "getString(...)"

    invoke-static {v2, v3}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    const/4 v3, 0x1

    invoke-direct {p0, v2, v3}, Lcom/example/carcontroller/MainActivity;->toast(Ljava/lang/String;Z)V

    .line 315
    .end local v1    # "e":Landroid/content/ActivityNotFoundException;
    :goto_0
    return-void
.end method

.method private final send(Ljava/lang/String;Ljava/lang/String;)V
    .locals 17
    .param p1, "cmd"    # Ljava/lang/String;
    .param p2, "label"    # Ljava/lang/String;

    .line 247
    move-object/from16 v6, p0

    invoke-direct/range {p0 .. p0}, Lcom/example/carcontroller/MainActivity;->requireConnection()Z

    move-result v0

    if-nez v0, :cond_0

    return-void

    .line 248
    :cond_0
    invoke-direct/range {p0 .. p0}, Lcom/example/carcontroller/MainActivity;->currentIp()Ljava/lang/String;

    move-result-object v7

    .line 249
    .local v7, "ip":Ljava/lang/String;
    invoke-direct/range {p0 .. p0}, Lcom/example/carcontroller/MainActivity;->currentPin()Ljava/lang/String;

    move-result-object v8

    .line 250
    .local v8, "pin":Ljava/lang/String;
    invoke-direct {v6, v7, v8}, Lcom/example/carcontroller/MainActivity;->save(Ljava/lang/String;Ljava/lang/String;)V

    .line 251
    sget-object v0, Lcom/example/carcontroller/MainActivity$State;->BUSY:Lcom/example/carcontroller/MainActivity$State;

    sget v1, Lcom/example/carcontroller/R$string;->status_sending:I

    invoke-virtual {v6, v1}, Lcom/example/carcontroller/MainActivity;->getString(I)Ljava/lang/String;

    move-result-object v1

    const-string v2, "getString(...)"

    invoke-static {v1, v2}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    invoke-direct {v6, v0, v1}, Lcom/example/carcontroller/MainActivity;->setStatus(Lcom/example/carcontroller/MainActivity$State;Ljava/lang/String;)V

    .line 252
    const/4 v9, 0x0

    const/4 v10, 0x0

    const/4 v11, 0x0

    const/4 v12, 0x0

    const/4 v13, 0x0

    new-instance v14, Lcom/example/carcontroller/MainActivity$send$1;

    move-object v0, v14

    move-object v1, v7

    move-object v2, v8

    move-object/from16 v3, p1

    move-object/from16 v4, p0

    move-object/from16 v5, p2

    invoke-direct/range {v0 .. v5}, Lcom/example/carcontroller/MainActivity$send$1;-><init>(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Lcom/example/carcontroller/MainActivity;Ljava/lang/String;)V

    check-cast v14, Lkotlin/jvm/functions/Function0;

    const/16 v15, 0x1f

    const/16 v16, 0x0

    invoke-static/range {v9 .. v16}, Lkotlin/concurrent/ThreadsKt;->thread$default(ZZLjava/lang/ClassLoader;Ljava/lang/String;ILkotlin/jvm/functions/Function0;ILjava/lang/Object;)Ljava/lang/Thread;

    .line 258
    return-void
.end method

.method private final setListening(Z)V
    .locals 2
    .param p1, "on"    # Z

    .line 400
    iget-object v0, p0, Lcom/example/carcontroller/MainActivity;->btnVoice:Lcom/google/android/material/button/MaterialButton;

    if-nez v0, :cond_0

    const-string v0, "btnVoice"

    invoke-static {v0}, Lkotlin/jvm/internal/Intrinsics;->throwUninitializedPropertyAccessException(Ljava/lang/String;)V

    const/4 v0, 0x0

    :cond_0
    if-eqz p1, :cond_1

    sget v1, Lcom/example/carcontroller/R$string;->voice_listening:I

    goto :goto_0

    :cond_1
    sget v1, Lcom/example/carcontroller/R$string;->btn_voice:I

    :goto_0
    invoke-virtual {v0, v1}, Lcom/google/android/material/button/MaterialButton;->setText(I)V

    .line 401
    return-void
.end method

.method private final setStatus(Lcom/example/carcontroller/MainActivity$State;Ljava/lang/String;)V
    .locals 3
    .param p1, "state"    # Lcom/example/carcontroller/MainActivity$State;
    .param p2, "text"    # Ljava/lang/String;

    .line 182
    iget-object v0, p0, Lcom/example/carcontroller/MainActivity;->tvStatus:Landroid/widget/TextView;

    const/4 v1, 0x0

    if-nez v0, :cond_0

    const-string v0, "tvStatus"

    invoke-static {v0}, Lkotlin/jvm/internal/Intrinsics;->throwUninitializedPropertyAccessException(Ljava/lang/String;)V

    move-object v0, v1

    :cond_0
    move-object v2, p2

    check-cast v2, Ljava/lang/CharSequence;

    invoke-virtual {v0, v2}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    .line 183
    sget-object v0, Lcom/example/carcontroller/MainActivity$WhenMappings;->$EnumSwitchMapping$0:[I

    invoke-virtual {p1}, Lcom/example/carcontroller/MainActivity$State;->ordinal()I

    move-result v2

    aget v0, v0, v2

    packed-switch v0, :pswitch_data_0

    .line 187
    new-instance v0, Lkotlin/NoWhenBranchMatchedException;

    invoke-direct {v0}, Lkotlin/NoWhenBranchMatchedException;-><init>()V

    throw v0

    :pswitch_0
    sget v0, Lcom/example/carcontroller/R$color;->danger:I

    goto :goto_0

    .line 186
    :pswitch_1
    sget v0, Lcom/example/carcontroller/R$color;->success:I

    goto :goto_0

    .line 185
    :pswitch_2
    sget v0, Lcom/example/carcontroller/R$color;->warning:I

    goto :goto_0

    .line 184
    :pswitch_3
    sget v0, Lcom/example/carcontroller/R$color;->idle:I

    .line 183
    :goto_0
    nop

    .line 189
    .local v0, "colorRes":I
    iget-object v2, p0, Lcom/example/carcontroller/MainActivity;->dotStatus:Landroid/view/View;

    if-nez v2, :cond_1

    const-string v2, "dotStatus"

    invoke-static {v2}, Lkotlin/jvm/internal/Intrinsics;->throwUninitializedPropertyAccessException(Ljava/lang/String;)V

    goto :goto_1

    :cond_1
    move-object v1, v2

    :goto_1
    move-object v2, p0

    check-cast v2, Landroid/content/Context;

    invoke-static {v2, v0}, Landroidx/core/content/ContextCompat;->getColor(Landroid/content/Context;I)I

    move-result v2

    invoke-static {v2}, Landroid/content/res/ColorStateList;->valueOf(I)Landroid/content/res/ColorStateList;

    move-result-object v2

    invoke-virtual {v1, v2}, Landroid/view/View;->setBackgroundTintList(Landroid/content/res/ColorStateList;)V

    .line 190
    return-void

    :pswitch_data_0
    .packed-switch 0x1
        :pswitch_3
        :pswitch_2
        :pswitch_1
        :pswitch_0
    .end packed-switch
.end method

.method private final showResult(Lcom/example/carcontroller/CarClient$Result;Ljava/lang/String;)V
    .locals 4
    .param p1, "r"    # Lcom/example/carcontroller/CarClient$Result;
    .param p2, "label"    # Ljava/lang/String;

    .line 213
    invoke-virtual {p1}, Lcom/example/carcontroller/CarClient$Result;->getOk()Z

    move-result v0

    if-eqz v0, :cond_0

    .line 214
    sget-object v0, Lcom/example/carcontroller/MainActivity$State;->OK:Lcom/example/carcontroller/MainActivity$State;

    sget v1, Lcom/example/carcontroller/R$string;->res_ok:I

    filled-new-array {p2}, [Ljava/lang/Object;

    move-result-object v2

    invoke-virtual {p0, v1, v2}, Lcom/example/carcontroller/MainActivity;->getString(I[Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v1

    const-string v2, "getString(...)"

    invoke-static {v1, v2}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    invoke-direct {p0, v0, v1}, Lcom/example/carcontroller/MainActivity;->setStatus(Lcom/example/carcontroller/MainActivity$State;Ljava/lang/String;)V

    .line 215
    return-void

    .line 217
    :cond_0
    invoke-direct {p0, p1}, Lcom/example/carcontroller/MainActivity;->describe(Lcom/example/carcontroller/CarClient$Result;)Ljava/lang/String;

    move-result-object v0

    .line 218
    .local v0, "message":Ljava/lang/String;
    sget-object v1, Lcom/example/carcontroller/MainActivity$State;->ERROR:Lcom/example/carcontroller/MainActivity$State;

    invoke-direct {p0, v1, v0}, Lcom/example/carcontroller/MainActivity;->setStatus(Lcom/example/carcontroller/MainActivity$State;Ljava/lang/String;)V

    .line 219
    invoke-virtual {p1}, Lcom/example/carcontroller/CarClient$Result;->getCode()Lcom/example/carcontroller/CarClient$Code;

    move-result-object v1

    sget-object v2, Lcom/example/carcontroller/CarClient$Code;->EXEC:Lcom/example/carcontroller/CarClient$Code;

    const/4 v3, 0x1

    if-ne v1, v2, :cond_2

    invoke-virtual {p1}, Lcom/example/carcontroller/CarClient$Result;->getDetail()Ljava/lang/String;

    move-result-object v1

    check-cast v1, Ljava/lang/CharSequence;

    invoke-interface {v1}, Ljava/lang/CharSequence;->length()I

    move-result v1

    if-lez v1, :cond_1

    move v1, v3

    goto :goto_0

    :cond_1
    const/4 v1, 0x0

    :goto_0
    if-eqz v1, :cond_2

    new-instance v1, Ljava/lang/StringBuilder;

    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v1, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    const/16 v2, 0xa

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(C)Ljava/lang/StringBuilder;

    move-result-object v1

    invoke-virtual {p1}, Lcom/example/carcontroller/CarClient$Result;->getDetail()Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    goto :goto_1

    :cond_2
    move-object v1, v0

    .line 220
    .local v1, "full":Ljava/lang/String;
    :goto_1
    invoke-direct {p0, v1, v3}, Lcom/example/carcontroller/MainActivity;->toast(Ljava/lang/String;Z)V

    .line 221
    return-void
.end method

.method private final sizeHero()V
    .locals 6

    .line 128
    invoke-virtual {p0}, Lcom/example/carcontroller/MainActivity;->getResources()Landroid/content/res/Resources;

    move-result-object v0

    invoke-virtual {v0}, Landroid/content/res/Resources;->getDisplayMetrics()Landroid/util/DisplayMetrics;

    move-result-object v0

    .line 129
    .local v0, "dm":Landroid/util/DisplayMetrics;
    iget v1, v0, Landroid/util/DisplayMetrics;->widthPixels:I

    int-to-float v1, v1

    const/high16 v2, 0x40400000    # 3.0f

    mul-float/2addr v1, v2

    const/high16 v2, 0x40800000    # 4.0f

    div-float/2addr v1, v2

    .line 131
    .local v1, "imageHeight":F
    const v2, 0x3f3d70a4    # 0.74f

    mul-float/2addr v2, v1

    iget v3, v0, Landroid/util/DisplayMetrics;->heightPixels:I

    int-to-float v3, v3

    const v4, 0x3e99999a    # 0.3f

    mul-float/2addr v3, v4

    invoke-static {v2, v3}, Ljava/lang/Math;->min(FF)F

    move-result v2

    .line 132
    .local v2, "wanted":F
    float-to-int v3, v2

    const/16 v4, 0x10

    int-to-float v4, v4

    iget v5, v0, Landroid/util/DisplayMetrics;->density:F

    mul-float/2addr v4, v5

    float-to-int v4, v4

    invoke-static {v3, v4}, Lkotlin/ranges/RangesKt;->coerceAtLeast(II)I

    move-result v3

    .line 133
    .local v3, "px":I
    sget v4, Lcom/example/carcontroller/R$id;->heroSpace:I

    invoke-virtual {p0, v4}, Lcom/example/carcontroller/MainActivity;->findViewById(I)Landroid/view/View;

    move-result-object v4

    .line 134
    .local v4, "spacer":Landroid/view/View;
    invoke-virtual {v4}, Landroid/view/View;->getLayoutParams()Landroid/view/ViewGroup$LayoutParams;

    move-result-object v5

    .line 135
    .local v5, "lp":Landroid/view/ViewGroup$LayoutParams;
    iput v3, v5, Landroid/view/ViewGroup$LayoutParams;->height:I

    .line 136
    invoke-virtual {v4, v5}, Landroid/view/View;->setLayoutParams(Landroid/view/ViewGroup$LayoutParams;)V

    .line 137
    return-void
.end method

.method private final startVoice()V
    .locals 4

    .line 384
    move-object v0, p0

    check-cast v0, Landroid/content/Context;

    invoke-static {v0}, Landroid/speech/SpeechRecognizer;->isRecognitionAvailable(Landroid/content/Context;)Z

    move-result v0

    if-eqz v0, :cond_1

    .line 385
    iget-object v0, p0, Lcom/example/carcontroller/MainActivity;->recognizer:Landroid/speech/SpeechRecognizer;

    if-nez v0, :cond_0

    move-object v0, p0

    check-cast v0, Landroid/content/Context;

    invoke-static {v0}, Landroid/speech/SpeechRecognizer;->createSpeechRecognizer(Landroid/content/Context;)Landroid/speech/SpeechRecognizer;

    move-result-object v0

    move-object v1, v0

    .local v1, "it":Landroid/speech/SpeechRecognizer;
    const/4 v2, 0x0

    .line 386
    .local v2, "$i$a$-also-MainActivity$startVoice$sr$1":I
    iget-object v3, p0, Lcom/example/carcontroller/MainActivity;->listener:Lcom/example/carcontroller/MainActivity$listener$1;

    check-cast v3, Landroid/speech/RecognitionListener;

    invoke-virtual {v1, v3}, Landroid/speech/SpeechRecognizer;->setRecognitionListener(Landroid/speech/RecognitionListener;)V

    .line 387
    iput-object v1, p0, Lcom/example/carcontroller/MainActivity;->recognizer:Landroid/speech/SpeechRecognizer;

    .line 388
    nop

    .line 385
    .end local v1    # "it":Landroid/speech/SpeechRecognizer;
    .end local v2    # "$i$a$-also-MainActivity$startVoice$sr$1":I
    nop

    .line 389
    .local v0, "sr":Landroid/speech/SpeechRecognizer;
    :cond_0
    invoke-direct {p0}, Lcom/example/carcontroller/MainActivity;->recognizerIntent()Landroid/content/Intent;

    move-result-object v1

    invoke-virtual {v0, v1}, Landroid/speech/SpeechRecognizer;->startListening(Landroid/content/Intent;)V

    .end local v0    # "sr":Landroid/speech/SpeechRecognizer;
    goto :goto_0

    .line 391
    :cond_1
    nop

    .line 392
    :try_start_0
    iget-object v0, p0, Lcom/example/carcontroller/MainActivity;->systemVoice:Landroidx/activity/result/ActivityResultLauncher;

    invoke-direct {p0}, Lcom/example/carcontroller/MainActivity;->recognizerIntent()Landroid/content/Intent;

    move-result-object v1

    invoke-virtual {v0, v1}, Landroidx/activity/result/ActivityResultLauncher;->launch(Ljava/lang/Object;)V
    :try_end_0
    .catch Landroid/content/ActivityNotFoundException; {:try_start_0 .. :try_end_0} :catch_0

    goto :goto_0

    .line 393
    :catch_0
    move-exception v0

    .line 394
    .local v0, "e":Landroid/content/ActivityNotFoundException;
    sget v1, Lcom/example/carcontroller/R$string;->voice_unavailable:I

    invoke-virtual {p0, v1}, Lcom/example/carcontroller/MainActivity;->getString(I)Ljava/lang/String;

    move-result-object v1

    const-string v2, "getString(...)"

    invoke-static {v1, v2}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    const/4 v2, 0x1

    invoke-direct {p0, v1, v2}, Lcom/example/carcontroller/MainActivity;->toast(Ljava/lang/String;Z)V

    .line 397
    .end local v0    # "e":Landroid/content/ActivityNotFoundException;
    :goto_0
    return-void
.end method

.method private static final systemVoice$lambda$1(Lcom/example/carcontroller/MainActivity;Landroidx/activity/result/ActivityResult;)V
    .locals 2
    .param p0, "this$0"    # Lcom/example/carcontroller/MainActivity;
    .param p1, "result"    # Landroidx/activity/result/ActivityResult;

    const-string v0, "this$0"

    invoke-static {p0, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 55
    invoke-virtual {p1}, Landroidx/activity/result/ActivityResult;->getResultCode()I

    move-result v0

    const/4 v1, -0x1

    if-ne v0, v1, :cond_2

    .line 56
    invoke-virtual {p1}, Landroidx/activity/result/ActivityResult;->getData()Landroid/content/Intent;

    move-result-object v0

    if-eqz v0, :cond_0

    const-string v1, "android.speech.extra.RESULTS"

    invoke-virtual {v0, v1}, Landroid/content/Intent;->getStringArrayListExtra(Ljava/lang/String;)Ljava/util/ArrayList;

    move-result-object v0

    goto :goto_0

    :cond_0
    const/4 v0, 0x0

    :goto_0
    check-cast v0, Ljava/util/List;

    if-nez v0, :cond_1

    invoke-static {}, Lkotlin/collections/CollectionsKt;->emptyList()Ljava/util/List;

    move-result-object v0

    :cond_1
    invoke-direct {p0, v0}, Lcom/example/carcontroller/MainActivity;->handleVoice(Ljava/util/List;)V

    .line 58
    :cond_2
    return-void
.end method

.method private final toast(Ljava/lang/String;Z)V
    .locals 2
    .param p1, "message"    # Ljava/lang/String;
    .param p2, "long"    # Z

    .line 193
    move-object v0, p0

    check-cast v0, Landroid/content/Context;

    move-object v1, p1

    check-cast v1, Ljava/lang/CharSequence;

    invoke-static {v0, v1, p2}, Landroid/widget/Toast;->makeText(Landroid/content/Context;Ljava/lang/CharSequence;I)Landroid/widget/Toast;

    move-result-object v0

    invoke-virtual {v0}, Landroid/widget/Toast;->show()V

    .line 194
    return-void
.end method

.method static synthetic toast$default(Lcom/example/carcontroller/MainActivity;Ljava/lang/String;ZILjava/lang/Object;)V
    .locals 0

    .line 192
    and-int/lit8 p3, p3, 0x2

    if-eqz p3, :cond_0

    const/4 p2, 0x0

    :cond_0
    invoke-direct {p0, p1, p2}, Lcom/example/carcontroller/MainActivity;->toast(Ljava/lang/String;Z)V

    return-void
.end method


# virtual methods
.method protected onCreate(Landroid/os/Bundle;)V
    .locals 6
    .param p1, "savedInstanceState"    # Landroid/os/Bundle;

    .line 69
    invoke-super {p0, p1}, Landroidx/appcompat/app/AppCompatActivity;->onCreate(Landroid/os/Bundle;)V

    .line 70
    invoke-virtual {p0}, Lcom/example/carcontroller/MainActivity;->getWindow()Landroid/view/Window;

    move-result-object v0

    const/4 v1, 0x0

    invoke-static {v0, v1}, Landroidx/core/view/WindowCompat;->setDecorFitsSystemWindows(Landroid/view/Window;Z)V

    .line 71
    sget v0, Lcom/example/carcontroller/R$layout;->activity_main:I

    invoke-virtual {p0, v0}, Lcom/example/carcontroller/MainActivity;->setContentView(I)V

    .line 73
    const-string v0, "CarConfig"

    invoke-virtual {p0, v0, v1}, Lcom/example/carcontroller/MainActivity;->getSharedPreferences(Ljava/lang/String;I)Landroid/content/SharedPreferences;

    move-result-object v0

    const-string v1, "getSharedPreferences(...)"

    invoke-static {v0, v1}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    iput-object v0, p0, Lcom/example/carcontroller/MainActivity;->prefs:Landroid/content/SharedPreferences;

    .line 74
    sget v0, Lcom/example/carcontroller/R$id;->etCarIp:I

    invoke-virtual {p0, v0}, Lcom/example/carcontroller/MainActivity;->findViewById(I)Landroid/view/View;

    move-result-object v0

    const-string v1, "findViewById(...)"

    invoke-static {v0, v1}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    check-cast v0, Lcom/google/android/material/textfield/TextInputEditText;

    iput-object v0, p0, Lcom/example/carcontroller/MainActivity;->etIp:Lcom/google/android/material/textfield/TextInputEditText;

    .line 75
    sget v0, Lcom/example/carcontroller/R$id;->etPin:I

    invoke-virtual {p0, v0}, Lcom/example/carcontroller/MainActivity;->findViewById(I)Landroid/view/View;

    move-result-object v0

    invoke-static {v0, v1}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    check-cast v0, Lcom/google/android/material/textfield/TextInputEditText;

    iput-object v0, p0, Lcom/example/carcontroller/MainActivity;->etPin:Lcom/google/android/material/textfield/TextInputEditText;

    .line 76
    sget v0, Lcom/example/carcontroller/R$id;->tvStatus:I

    invoke-virtual {p0, v0}, Lcom/example/carcontroller/MainActivity;->findViewById(I)Landroid/view/View;

    move-result-object v0

    invoke-static {v0, v1}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    check-cast v0, Landroid/widget/TextView;

    iput-object v0, p0, Lcom/example/carcontroller/MainActivity;->tvStatus:Landroid/widget/TextView;

    .line 77
    sget v0, Lcom/example/carcontroller/R$id;->dotStatus:I

    invoke-virtual {p0, v0}, Lcom/example/carcontroller/MainActivity;->findViewById(I)Landroid/view/View;

    move-result-object v0

    invoke-static {v0, v1}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    iput-object v0, p0, Lcom/example/carcontroller/MainActivity;->dotStatus:Landroid/view/View;

    .line 78
    sget v0, Lcom/example/carcontroller/R$id;->btnVoiceCommand:I

    invoke-virtual {p0, v0}, Lcom/example/carcontroller/MainActivity;->findViewById(I)Landroid/view/View;

    move-result-object v0

    invoke-static {v0, v1}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    check-cast v0, Lcom/google/android/material/button/MaterialButton;

    iput-object v0, p0, Lcom/example/carcontroller/MainActivity;->btnVoice:Lcom/google/android/material/button/MaterialButton;

    .line 80
    invoke-direct {p0}, Lcom/example/carcontroller/MainActivity;->applyInsets()V

    .line 81
    invoke-direct {p0}, Lcom/example/carcontroller/MainActivity;->sizeHero()V

    .line 82
    invoke-direct {p0}, Lcom/example/carcontroller/MainActivity;->buildSections()V

    .line 84
    iget-object v0, p0, Lcom/example/carcontroller/MainActivity;->etIp:Lcom/google/android/material/textfield/TextInputEditText;

    const/4 v1, 0x0

    if-nez v0, :cond_0

    const-string v0, "etIp"

    invoke-static {v0}, Lkotlin/jvm/internal/Intrinsics;->throwUninitializedPropertyAccessException(Ljava/lang/String;)V

    move-object v0, v1

    :cond_0
    iget-object v2, p0, Lcom/example/carcontroller/MainActivity;->prefs:Landroid/content/SharedPreferences;

    const-string v3, "prefs"

    if-nez v2, :cond_1

    invoke-static {v3}, Lkotlin/jvm/internal/Intrinsics;->throwUninitializedPropertyAccessException(Ljava/lang/String;)V

    move-object v2, v1

    :cond_1
    const-string v4, "CAR_IP"

    const-string v5, ""

    invoke-interface {v2, v4, v5}, Landroid/content/SharedPreferences;->getString(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v2

    if-nez v2, :cond_2

    move-object v2, v5

    :cond_2
    check-cast v2, Ljava/lang/CharSequence;

    invoke-virtual {v0, v2}, Lcom/google/android/material/textfield/TextInputEditText;->setText(Ljava/lang/CharSequence;)V

    .line 85
    iget-object v0, p0, Lcom/example/carcontroller/MainActivity;->etPin:Lcom/google/android/material/textfield/TextInputEditText;

    if-nez v0, :cond_3

    const-string v0, "etPin"

    invoke-static {v0}, Lkotlin/jvm/internal/Intrinsics;->throwUninitializedPropertyAccessException(Ljava/lang/String;)V

    move-object v0, v1

    :cond_3
    iget-object v2, p0, Lcom/example/carcontroller/MainActivity;->prefs:Landroid/content/SharedPreferences;

    if-nez v2, :cond_4

    invoke-static {v3}, Lkotlin/jvm/internal/Intrinsics;->throwUninitializedPropertyAccessException(Ljava/lang/String;)V

    move-object v2, v1

    :cond_4
    const-string v3, "CAR_PIN"

    invoke-interface {v2, v3, v5}, Landroid/content/SharedPreferences;->getString(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v2

    if-nez v2, :cond_5

    goto :goto_0

    :cond_5
    move-object v5, v2

    :goto_0
    check-cast v5, Ljava/lang/CharSequence;

    invoke-virtual {v0, v5}, Lcom/google/android/material/textfield/TextInputEditText;->setText(Ljava/lang/CharSequence;)V

    .line 86
    sget-object v0, Lcom/example/carcontroller/MainActivity$State;->IDLE:Lcom/example/carcontroller/MainActivity$State;

    sget v2, Lcom/example/carcontroller/R$string;->status_disconnected:I

    invoke-virtual {p0, v2}, Lcom/example/carcontroller/MainActivity;->getString(I)Ljava/lang/String;

    move-result-object v2

    const-string v3, "getString(...)"

    invoke-static {v2, v3}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    invoke-direct {p0, v0, v2}, Lcom/example/carcontroller/MainActivity;->setStatus(Lcom/example/carcontroller/MainActivity$State;Ljava/lang/String;)V

    .line 88
    sget v0, Lcom/example/carcontroller/R$id;->btnConnect:I

    invoke-virtual {p0, v0}, Lcom/example/carcontroller/MainActivity;->findViewById(I)Landroid/view/View;

    move-result-object v0

    check-cast v0, Lcom/google/android/material/button/MaterialButton;

    new-instance v2, Lcom/example/carcontroller/MainActivity$$ExternalSyntheticLambda3;

    invoke-direct {v2, p0}, Lcom/example/carcontroller/MainActivity$$ExternalSyntheticLambda3;-><init>(Lcom/example/carcontroller/MainActivity;)V

    invoke-virtual {v0, v2}, Lcom/google/android/material/button/MaterialButton;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    .line 89
    sget v0, Lcom/example/carcontroller/R$id;->btnScan:I

    invoke-virtual {p0, v0}, Lcom/example/carcontroller/MainActivity;->findViewById(I)Landroid/view/View;

    move-result-object v0

    check-cast v0, Lcom/google/android/material/button/MaterialButton;

    new-instance v2, Lcom/example/carcontroller/MainActivity$$ExternalSyntheticLambda4;

    invoke-direct {v2, p0}, Lcom/example/carcontroller/MainActivity$$ExternalSyntheticLambda4;-><init>(Lcom/example/carcontroller/MainActivity;)V

    invoke-virtual {v0, v2}, Lcom/google/android/material/button/MaterialButton;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    .line 90
    iget-object v0, p0, Lcom/example/carcontroller/MainActivity;->btnVoice:Lcom/google/android/material/button/MaterialButton;

    if-nez v0, :cond_6

    const-string v0, "btnVoice"

    invoke-static {v0}, Lkotlin/jvm/internal/Intrinsics;->throwUninitializedPropertyAccessException(Ljava/lang/String;)V

    goto :goto_1

    :cond_6
    move-object v1, v0

    :goto_1
    new-instance v0, Lcom/example/carcontroller/MainActivity$$ExternalSyntheticLambda5;

    invoke-direct {v0, p0}, Lcom/example/carcontroller/MainActivity$$ExternalSyntheticLambda5;-><init>(Lcom/example/carcontroller/MainActivity;)V

    invoke-virtual {v1, v0}, Lcom/google/android/material/button/MaterialButton;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    .line 91
    sget v0, Lcom/example/carcontroller/R$id;->btnReboot:I

    invoke-virtual {p0, v0}, Lcom/example/carcontroller/MainActivity;->findViewById(I)Landroid/view/View;

    move-result-object v0

    check-cast v0, Lcom/google/android/material/button/MaterialButton;

    new-instance v1, Lcom/example/carcontroller/MainActivity$$ExternalSyntheticLambda6;

    invoke-direct {v1, p0}, Lcom/example/carcontroller/MainActivity$$ExternalSyntheticLambda6;-><init>(Lcom/example/carcontroller/MainActivity;)V

    invoke-virtual {v0, v1}, Lcom/google/android/material/button/MaterialButton;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    .line 93
    if-nez p1, :cond_7

    .line 94
    invoke-virtual {p0}, Lcom/example/carcontroller/MainActivity;->getIntent()Landroid/content/Intent;

    move-result-object v0

    invoke-direct {p0, v0}, Lcom/example/carcontroller/MainActivity;->handlePairingIntent(Landroid/content/Intent;)Z

    move-result v0

    if-nez v0, :cond_7

    invoke-direct {p0}, Lcom/example/carcontroller/MainActivity;->autoPing()V

    .line 96
    :cond_7
    return-void
.end method

.method protected onDestroy()V
    .locals 1

    .line 105
    invoke-super {p0}, Landroidx/appcompat/app/AppCompatActivity;->onDestroy()V

    .line 106
    iget-object v0, p0, Lcom/example/carcontroller/MainActivity;->recognizer:Landroid/speech/SpeechRecognizer;

    if-eqz v0, :cond_0

    invoke-virtual {v0}, Landroid/speech/SpeechRecognizer;->destroy()V

    .line 107
    :cond_0
    const/4 v0, 0x0

    iput-object v0, p0, Lcom/example/carcontroller/MainActivity;->recognizer:Landroid/speech/SpeechRecognizer;

    .line 108
    return-void
.end method

.method protected onNewIntent(Landroid/content/Intent;)V
    .locals 1
    .param p1, "intent"    # Landroid/content/Intent;

    const-string v0, "intent"

    invoke-static {p1, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 99
    invoke-super {p0, p1}, Landroidx/appcompat/app/AppCompatActivity;->onNewIntent(Landroid/content/Intent;)V

    .line 100
    invoke-virtual {p0, p1}, Lcom/example/carcontroller/MainActivity;->setIntent(Landroid/content/Intent;)V

    .line 101
    invoke-direct {p0, p1}, Lcom/example/carcontroller/MainActivity;->handlePairingIntent(Landroid/content/Intent;)Z

    .line 102
    return-void
.end method
