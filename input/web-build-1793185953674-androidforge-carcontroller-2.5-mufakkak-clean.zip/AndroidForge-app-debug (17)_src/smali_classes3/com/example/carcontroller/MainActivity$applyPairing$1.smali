.class final Lcom/example/carcontroller/MainActivity$applyPairing$1;
.super Lkotlin/jvm/internal/Lambda;
.source "MainActivity.kt"

# interfaces
.implements Lkotlin/jvm/functions/Function0;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lcom/example/carcontroller/MainActivity;->applyPairing(Lcom/example/carcontroller/PairingLink$Data;)V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x18
    name = null
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "Lkotlin/jvm/internal/Lambda;",
        "Lkotlin/jvm/functions/Function0<",
        "Lkotlin/Unit;",
        ">;"
    }
.end annotation

.annotation runtime Lkotlin/Metadata;
    d1 = {
        "\u0000\u0008\n\u0000\n\u0002\u0010\u0002\n\u0000\u0010\u0000\u001a\u00020\u0001H\n\u00a2\u0006\u0002\u0008\u0002"
    }
    d2 = {
        "<anonymous>",
        "",
        "invoke"
    }
    k = 0x3
    mv = {
        0x1,
        0x9,
        0x0
    }
    xi = 0x30
.end annotation


# instance fields
.field final synthetic $p:Lcom/example/carcontroller/PairingLink$Data;

.field final synthetic this$0:Lcom/example/carcontroller/MainActivity;


# direct methods
.method public static synthetic $r8$lambda$FWrt3RkOejGtIVq7hJ2n3bbm8Lo(Lcom/example/carcontroller/MainActivity;Ljava/lang/String;Lcom/example/carcontroller/PairingLink$Data;Lkotlin/jvm/internal/Ref$ObjectRef;)V
    .locals 0

    invoke-static {p0, p1, p2, p3}, Lcom/example/carcontroller/MainActivity$applyPairing$1;->invoke$lambda$0(Lcom/example/carcontroller/MainActivity;Ljava/lang/String;Lcom/example/carcontroller/PairingLink$Data;Lkotlin/jvm/internal/Ref$ObjectRef;)V

    return-void
.end method

.method constructor <init>(Lcom/example/carcontroller/PairingLink$Data;Lcom/example/carcontroller/MainActivity;)V
    .locals 1

    iput-object p1, p0, Lcom/example/carcontroller/MainActivity$applyPairing$1;->$p:Lcom/example/carcontroller/PairingLink$Data;

    iput-object p2, p0, Lcom/example/carcontroller/MainActivity$applyPairing$1;->this$0:Lcom/example/carcontroller/MainActivity;

    const/4 v0, 0x0

    invoke-direct {p0, v0}, Lkotlin/jvm/internal/Lambda;-><init>(I)V

    return-void
.end method

.method private static final invoke$lambda$0(Lcom/example/carcontroller/MainActivity;Ljava/lang/String;Lcom/example/carcontroller/PairingLink$Data;Lkotlin/jvm/internal/Ref$ObjectRef;)V
    .locals 4
    .param p0, "this$0"    # Lcom/example/carcontroller/MainActivity;
    .param p1, "$chosen"    # Ljava/lang/String;
    .param p2, "$p"    # Lcom/example/carcontroller/PairingLink$Data;
    .param p3, "$reachable"    # Lkotlin/jvm/internal/Ref$ObjectRef;

    const-string v0, "this$0"

    invoke-static {p0, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    const-string v0, "$chosen"

    invoke-static {p1, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    const-string v0, "$p"

    invoke-static {p2, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    const-string v0, "$reachable"

    invoke-static {p3, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 349
    invoke-virtual {p0}, Lcom/example/carcontroller/MainActivity;->isFinishing()Z

    move-result v0

    if-nez v0, :cond_4

    invoke-virtual {p0}, Lcom/example/carcontroller/MainActivity;->isDestroyed()Z

    move-result v0

    if-eqz v0, :cond_0

    goto :goto_1

    .line 350
    :cond_0
    invoke-static {p0}, Lcom/example/carcontroller/MainActivity;->access$getEtIp$p(Lcom/example/carcontroller/MainActivity;)Lcom/google/android/material/textfield/TextInputEditText;

    move-result-object v0

    const/4 v1, 0x0

    if-nez v0, :cond_1

    const-string v0, "etIp"

    invoke-static {v0}, Lkotlin/jvm/internal/Intrinsics;->throwUninitializedPropertyAccessException(Ljava/lang/String;)V

    move-object v0, v1

    :cond_1
    move-object v2, p1

    check-cast v2, Ljava/lang/CharSequence;

    invoke-virtual {v0, v2}, Lcom/google/android/material/textfield/TextInputEditText;->setText(Ljava/lang/CharSequence;)V

    .line 351
    invoke-static {p0}, Lcom/example/carcontroller/MainActivity;->access$getEtPin$p(Lcom/example/carcontroller/MainActivity;)Lcom/google/android/material/textfield/TextInputEditText;

    move-result-object v0

    if-nez v0, :cond_2

    const-string v0, "etPin"

    invoke-static {v0}, Lkotlin/jvm/internal/Intrinsics;->throwUninitializedPropertyAccessException(Ljava/lang/String;)V

    move-object v0, v1

    :cond_2
    invoke-virtual {p2}, Lcom/example/carcontroller/PairingLink$Data;->getPin()Ljava/lang/String;

    move-result-object v2

    check-cast v2, Ljava/lang/CharSequence;

    invoke-virtual {v0, v2}, Lcom/google/android/material/textfield/TextInputEditText;->setText(Ljava/lang/CharSequence;)V

    .line 352
    invoke-virtual {p2}, Lcom/example/carcontroller/PairingLink$Data;->getPin()Ljava/lang/String;

    move-result-object v0

    invoke-static {p0, p1, v0}, Lcom/example/carcontroller/MainActivity;->access$save(Lcom/example/carcontroller/MainActivity;Ljava/lang/String;Ljava/lang/String;)V

    .line 353
    iget-object v0, p3, Lkotlin/jvm/internal/Ref$ObjectRef;->element:Ljava/lang/Object;

    const-string v2, "getString(...)"

    if-eqz v0, :cond_3

    .line 354
    sget-object v0, Lcom/example/carcontroller/MainActivity$State;->OK:Lcom/example/carcontroller/MainActivity$State;

    sget v3, Lcom/example/carcontroller/R$string;->status_connected:I

    invoke-virtual {p0, v3}, Lcom/example/carcontroller/MainActivity;->getString(I)Ljava/lang/String;

    move-result-object v3

    invoke-static {v3, v2}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    invoke-static {p0, v0, v3}, Lcom/example/carcontroller/MainActivity;->access$setStatus(Lcom/example/carcontroller/MainActivity;Lcom/example/carcontroller/MainActivity$State;Ljava/lang/String;)V

    .line 355
    sget v0, Lcom/example/carcontroller/R$string;->qr_paired:I

    filled-new-array {p1}, [Ljava/lang/Object;

    move-result-object v3

    invoke-virtual {p0, v0, v3}, Lcom/example/carcontroller/MainActivity;->getString(I[Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v0

    invoke-static {v0, v2}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    const/4 v2, 0x0

    const/4 v3, 0x2

    invoke-static {p0, v0, v2, v3, v1}, Lcom/example/carcontroller/MainActivity;->toast$default(Lcom/example/carcontroller/MainActivity;Ljava/lang/String;ZILjava/lang/Object;)V

    goto :goto_0

    .line 357
    :cond_3
    sget-object v0, Lcom/example/carcontroller/MainActivity$State;->ERROR:Lcom/example/carcontroller/MainActivity$State;

    sget v1, Lcom/example/carcontroller/R$string;->res_unreachable:I

    invoke-virtual {p0, v1}, Lcom/example/carcontroller/MainActivity;->getString(I)Ljava/lang/String;

    move-result-object v1

    invoke-static {v1, v2}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    invoke-static {p0, v0, v1}, Lcom/example/carcontroller/MainActivity;->access$setStatus(Lcom/example/carcontroller/MainActivity;Lcom/example/carcontroller/MainActivity$State;Ljava/lang/String;)V

    .line 358
    sget v0, Lcom/example/carcontroller/R$string;->qr_paired_unverified:I

    invoke-virtual {p0, v0}, Lcom/example/carcontroller/MainActivity;->getString(I)Ljava/lang/String;

    move-result-object v0

    invoke-static {v0, v2}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    const/4 v1, 0x1

    invoke-static {p0, v0, v1}, Lcom/example/carcontroller/MainActivity;->access$toast(Lcom/example/carcontroller/MainActivity;Ljava/lang/String;Z)V

    .line 360
    :goto_0
    return-void

    .line 349
    :cond_4
    :goto_1
    return-void
.end method


# virtual methods
.method public bridge synthetic invoke()Ljava/lang/Object;
    .locals 1

    .line 339
    invoke-virtual {p0}, Lcom/example/carcontroller/MainActivity$applyPairing$1;->invoke()V

    sget-object v0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    return-object v0
.end method

.method public final invoke()V
    .locals 10

    .line 340
    new-instance v0, Lkotlin/jvm/internal/Ref$ObjectRef;

    invoke-direct {v0}, Lkotlin/jvm/internal/Ref$ObjectRef;-><init>()V

    .line 341
    .local v0, "reachable":Lkotlin/jvm/internal/Ref$ObjectRef;
    iget-object v1, p0, Lcom/example/carcontroller/MainActivity$applyPairing$1;->$p:Lcom/example/carcontroller/PairingLink$Data;

    invoke-virtual {v1}, Lcom/example/carcontroller/PairingLink$Data;->getIps()Ljava/util/List;

    move-result-object v1

    invoke-interface {v1}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    move-result-object v1

    :cond_0
    invoke-interface {v1}, Ljava/util/Iterator;->hasNext()Z

    move-result v2

    if-eqz v2, :cond_1

    invoke-interface {v1}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v2

    check-cast v2, Ljava/lang/String;

    .line 342
    .local v2, "ip":Ljava/lang/String;
    new-instance v9, Lcom/example/carcontroller/CarClient;

    iget-object v3, p0, Lcom/example/carcontroller/MainActivity$applyPairing$1;->$p:Lcom/example/carcontroller/PairingLink$Data;

    invoke-virtual {v3}, Lcom/example/carcontroller/PairingLink$Data;->getPin()Ljava/lang/String;

    move-result-object v5

    const/4 v6, 0x0

    const/4 v7, 0x4

    const/4 v8, 0x0

    move-object v3, v9

    move-object v4, v2

    invoke-direct/range {v3 .. v8}, Lcom/example/carcontroller/CarClient;-><init>(Ljava/lang/String;Ljava/lang/String;IILkotlin/jvm/internal/DefaultConstructorMarker;)V

    invoke-virtual {v9}, Lcom/example/carcontroller/CarClient;->ping()Lcom/example/carcontroller/CarClient$Result;

    move-result-object v3

    invoke-virtual {v3}, Lcom/example/carcontroller/CarClient$Result;->getOk()Z

    move-result v3

    if-eqz v3, :cond_0

    .line 343
    iput-object v2, v0, Lkotlin/jvm/internal/Ref$ObjectRef;->element:Ljava/lang/Object;

    .line 344
    nop

    .line 347
    .end local v2    # "ip":Ljava/lang/String;
    :cond_1
    iget-object v1, v0, Lkotlin/jvm/internal/Ref$ObjectRef;->element:Ljava/lang/Object;

    check-cast v1, Ljava/lang/String;

    if-nez v1, :cond_2

    iget-object v1, p0, Lcom/example/carcontroller/MainActivity$applyPairing$1;->$p:Lcom/example/carcontroller/PairingLink$Data;

    invoke-virtual {v1}, Lcom/example/carcontroller/PairingLink$Data;->getIps()Ljava/util/List;

    move-result-object v1

    invoke-static {v1}, Lkotlin/collections/CollectionsKt;->first(Ljava/util/List;)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Ljava/lang/String;

    .line 348
    .local v1, "chosen":Ljava/lang/String;
    :cond_2
    iget-object v2, p0, Lcom/example/carcontroller/MainActivity$applyPairing$1;->this$0:Lcom/example/carcontroller/MainActivity;

    iget-object v3, p0, Lcom/example/carcontroller/MainActivity$applyPairing$1;->$p:Lcom/example/carcontroller/PairingLink$Data;

    new-instance v4, Lcom/example/carcontroller/MainActivity$applyPairing$1$$ExternalSyntheticLambda0;

    invoke-direct {v4, v2, v1, v3, v0}, Lcom/example/carcontroller/MainActivity$applyPairing$1$$ExternalSyntheticLambda0;-><init>(Lcom/example/carcontroller/MainActivity;Ljava/lang/String;Lcom/example/carcontroller/PairingLink$Data;Lkotlin/jvm/internal/Ref$ObjectRef;)V

    invoke-virtual {v2, v4}, Lcom/example/carcontroller/MainActivity;->runOnUiThread(Ljava/lang/Runnable;)V

    .line 361
    return-void
.end method
