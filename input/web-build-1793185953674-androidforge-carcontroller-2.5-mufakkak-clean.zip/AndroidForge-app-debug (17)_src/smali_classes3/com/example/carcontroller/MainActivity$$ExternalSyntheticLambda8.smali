.class public final synthetic Lcom/example/carcontroller/MainActivity$$ExternalSyntheticLambda8;
.super Ljava/lang/Object;
.source "D8$$SyntheticClass"

# interfaces
.implements Landroid/view/View$OnClickListener;


# instance fields
.field public final synthetic f$0:Lcom/example/carcontroller/MainActivity;

.field public final synthetic f$1:Lcom/example/carcontroller/Control;


# direct methods
.method public synthetic constructor <init>(Lcom/example/carcontroller/MainActivity;Lcom/example/carcontroller/Control;)V
    .locals 0

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Lcom/example/carcontroller/MainActivity$$ExternalSyntheticLambda8;->f$0:Lcom/example/carcontroller/MainActivity;

    iput-object p2, p0, Lcom/example/carcontroller/MainActivity$$ExternalSyntheticLambda8;->f$1:Lcom/example/carcontroller/Control;

    return-void
.end method


# virtual methods
.method public final onClick(Landroid/view/View;)V
    .locals 2

    iget-object v0, p0, Lcom/example/carcontroller/MainActivity$$ExternalSyntheticLambda8;->f$0:Lcom/example/carcontroller/MainActivity;

    iget-object v1, p0, Lcom/example/carcontroller/MainActivity$$ExternalSyntheticLambda8;->f$1:Lcom/example/carcontroller/Control;

    invoke-static {v0, v1, p1}, Lcom/example/carcontroller/MainActivity;->$r8$lambda$UuzjDZW5vZChflqxjYVX1hekApA(Lcom/example/carcontroller/MainActivity;Lcom/example/carcontroller/Control;Landroid/view/View;)V

    return-void
.end method
