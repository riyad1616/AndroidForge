.class public final Lcom/example/carcontroller/MainActivity$listener$1;
.super Ljava/lang/Object;
.source "MainActivity.kt"

# interfaces
.implements Landroid/speech/RecognitionListener;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lcom/example/carcontroller/MainActivity;-><init>()V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x19
    name = null
.end annotation

.annotation runtime Lkotlin/Metadata;
    d1 = {
        "\u00001\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u0002\n\u0002\u0008\u0002\n\u0002\u0010\u0012\n\u0002\u0008\u0003\n\u0002\u0010\u0008\n\u0002\u0008\u0003\n\u0002\u0018\u0002\n\u0002\u0008\u0007\n\u0002\u0010\u0007\n\u0000*\u0001\u0000\u0008\n\u0018\u00002\u00020\u0001J\u0008\u0010\u0002\u001a\u00020\u0003H\u0016J\u0012\u0010\u0004\u001a\u00020\u00032\u0008\u0010\u0005\u001a\u0004\u0018\u00010\u0006H\u0016J\u0008\u0010\u0007\u001a\u00020\u0003H\u0016J\u0010\u0010\u0008\u001a\u00020\u00032\u0006\u0010\t\u001a\u00020\nH\u0016J\u001a\u0010\u000b\u001a\u00020\u00032\u0006\u0010\u000c\u001a\u00020\n2\u0008\u0010\r\u001a\u0004\u0018\u00010\u000eH\u0016J\u0012\u0010\u000f\u001a\u00020\u00032\u0008\u0010\u0010\u001a\u0004\u0018\u00010\u000eH\u0016J\u0012\u0010\u0011\u001a\u00020\u00032\u0008\u0010\r\u001a\u0004\u0018\u00010\u000eH\u0016J\u0010\u0010\u0012\u001a\u00020\u00032\u0006\u0010\u0013\u001a\u00020\u000eH\u0016J\u0010\u0010\u0014\u001a\u00020\u00032\u0006\u0010\u0015\u001a\u00020\u0016H\u0016\u00a8\u0006\u0017"
    }
    d2 = {
        "com/example/carcontroller/MainActivity$listener$1",
        "Landroid/speech/RecognitionListener;",
        "onBeginningOfSpeech",
        "",
        "onBufferReceived",
        "buffer",
        "",
        "onEndOfSpeech",
        "onError",
        "error",
        "",
        "onEvent",
        "eventType",
        "params",
        "Landroid/os/Bundle;",
        "onPartialResults",
        "partialResults",
        "onReadyForSpeech",
        "onResults",
        "results",
        "onRmsChanged",
        "rmsdB",
        "",
        "app_debug"
    }
    k = 0x1
    mv = {
        0x1,
        0x9,
        0x0
    }
    xi = 0x30
.end annotation


# instance fields
.field final synthetic this$0:Lcom/example/carcontroller/MainActivity;


# direct methods
.method constructor <init>(Lcom/example/carcontroller/MainActivity;)V
    .locals 0
    .param p1, "$receiver"    # Lcom/example/carcontroller/MainActivity;

    iput-object p1, p0, Lcom/example/carcontroller/MainActivity$listener$1;->this$0:Lcom/example/carcontroller/MainActivity;

    .line 418
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public onBeginningOfSpeech()V
    .locals 0

    .line 423
    return-void
.end method

.method public onBufferReceived([B)V
    .locals 0
    .param p1, "buffer"    # [B

    .line 425
    return-void
.end method

.method public onEndOfSpeech()V
    .locals 2

    .line 427
    iget-object v0, p0, Lcom/example/carcontroller/MainActivity$listener$1;->this$0:Lcom/example/carcontroller/MainActivity;

    const/4 v1, 0x0

    invoke-static {v0, v1}, Lcom/example/carcontroller/MainActivity;->access$setListening(Lcom/example/carcontroller/MainActivity;Z)V

    .line 428
    return-void
.end method

.method public onError(I)V
    .locals 5
    .param p1, "error"    # I

    .line 431
    iget-object v0, p0, Lcom/example/carcontroller/MainActivity$listener$1;->this$0:Lcom/example/carcontroller/MainActivity;

    const/4 v1, 0x0

    invoke-static {v0, v1}, Lcom/example/carcontroller/MainActivity;->access$setListening(Lcom/example/carcontroller/MainActivity;Z)V

    .line 432
    const/4 v0, 0x1

    const-string v2, "getString(...)"

    packed-switch p1, :pswitch_data_0

    .line 437
    :pswitch_0
    iget-object v1, p0, Lcom/example/carcontroller/MainActivity$listener$1;->this$0:Lcom/example/carcontroller/MainActivity;

    sget v3, Lcom/example/carcontroller/R$string;->voice_error:I

    invoke-static {p1}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v4

    filled-new-array {v4}, [Ljava/lang/Object;

    move-result-object v4

    invoke-virtual {v1, v3, v4}, Lcom/example/carcontroller/MainActivity;->getString(I[Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v3

    invoke-static {v3, v2}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    invoke-static {v1, v3, v0}, Lcom/example/carcontroller/MainActivity;->access$toast(Lcom/example/carcontroller/MainActivity;Ljava/lang/String;Z)V

    goto :goto_0

    .line 436
    :pswitch_1
    iget-object v1, p0, Lcom/example/carcontroller/MainActivity$listener$1;->this$0:Lcom/example/carcontroller/MainActivity;

    sget v3, Lcom/example/carcontroller/R$string;->mic_denied:I

    invoke-virtual {v1, v3}, Lcom/example/carcontroller/MainActivity;->getString(I)Ljava/lang/String;

    move-result-object v3

    invoke-static {v3, v2}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    invoke-static {v1, v3, v0}, Lcom/example/carcontroller/MainActivity;->access$toast(Lcom/example/carcontroller/MainActivity;Ljava/lang/String;Z)V

    goto :goto_0

    .line 434
    :pswitch_2
    iget-object v0, p0, Lcom/example/carcontroller/MainActivity$listener$1;->this$0:Lcom/example/carcontroller/MainActivity;

    sget v3, Lcom/example/carcontroller/R$string;->voice_no_match:I

    invoke-virtual {v0, v3}, Lcom/example/carcontroller/MainActivity;->getString(I)Ljava/lang/String;

    move-result-object v3

    invoke-static {v3, v2}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    const/4 v2, 0x2

    const/4 v4, 0x0

    invoke-static {v0, v3, v1, v2, v4}, Lcom/example/carcontroller/MainActivity;->toast$default(Lcom/example/carcontroller/MainActivity;Ljava/lang/String;ZILjava/lang/Object;)V

    .line 439
    :goto_0
    return-void

    nop

    :pswitch_data_0
    .packed-switch 0x6
        :pswitch_2
        :pswitch_2
        :pswitch_0
        :pswitch_1
    .end packed-switch
.end method

.method public onEvent(ILandroid/os/Bundle;)V
    .locals 0
    .param p1, "eventType"    # I
    .param p2, "params"    # Landroid/os/Bundle;

    .line 447
    return-void
.end method

.method public onPartialResults(Landroid/os/Bundle;)V
    .locals 0
    .param p1, "partialResults"    # Landroid/os/Bundle;

    .line 446
    return-void
.end method

.method public onReadyForSpeech(Landroid/os/Bundle;)V
    .locals 2
    .param p1, "params"    # Landroid/os/Bundle;

    .line 420
    iget-object v0, p0, Lcom/example/carcontroller/MainActivity$listener$1;->this$0:Lcom/example/carcontroller/MainActivity;

    const/4 v1, 0x1

    invoke-static {v0, v1}, Lcom/example/carcontroller/MainActivity;->access$setListening(Lcom/example/carcontroller/MainActivity;Z)V

    .line 421
    return-void
.end method

.method public onResults(Landroid/os/Bundle;)V
    .locals 2
    .param p1, "results"    # Landroid/os/Bundle;

    const-string v0, "results"

    invoke-static {p1, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 442
    iget-object v0, p0, Lcom/example/carcontroller/MainActivity$listener$1;->this$0:Lcom/example/carcontroller/MainActivity;

    const/4 v1, 0x0

    invoke-static {v0, v1}, Lcom/example/carcontroller/MainActivity;->access$setListening(Lcom/example/carcontroller/MainActivity;Z)V

    .line 443
    iget-object v0, p0, Lcom/example/carcontroller/MainActivity$listener$1;->this$0:Lcom/example/carcontroller/MainActivity;

    const-string v1, "results_recognition"

    invoke-virtual {p1, v1}, Landroid/os/Bundle;->getStringArrayList(Ljava/lang/String;)Ljava/util/ArrayList;

    move-result-object v1

    check-cast v1, Ljava/util/List;

    if-nez v1, :cond_0

    invoke-static {}, Lkotlin/collections/CollectionsKt;->emptyList()Ljava/util/List;

    move-result-object v1

    :cond_0
    invoke-static {v0, v1}, Lcom/example/carcontroller/MainActivity;->access$handleVoice(Lcom/example/carcontroller/MainActivity;Ljava/util/List;)V

    .line 444
    return-void
.end method

.method public onRmsChanged(F)V
    .locals 0
    .param p1, "rmsdB"    # F

    .line 424
    return-void
.end method
