.class public final synthetic Lcom/example/carcontroller/MainActivity$$ExternalSyntheticLambda1;
.super Ljava/lang/Object;
.source "D8$$SyntheticClass"

# interfaces
.implements Landroidx/activity/result/ActivityResultCallback;


# instance fields
.field public final synthetic f$0:Lcom/example/carcontroller/MainActivity;


# direct methods
.method public synthetic constructor <init>(Lcom/example/carcontroller/MainActivity;)V
    .locals 0

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Lcom/example/carcontroller/MainActivity$$ExternalSyntheticLambda1;->f$0:Lcom/example/carcontroller/MainActivity;

    return-void
.end method


# virtual methods
.method public final onActivityResult(Ljava/lang/Object;)V
    .locals 1

    iget-object v0, p0, Lcom/example/carcontroller/MainActivity$$ExternalSyntheticLambda1;->f$0:Lcom/example/carcontroller/MainActivity;

    check-cast p1, Landroidx/activity/result/ActivityResult;

    invoke-static {v0, p1}, Lcom/example/carcontroller/MainActivity;->$r8$lambda$JB7w35urldXJ6-znvSb1F1PneEY(Lcom/example/carcontroller/MainActivity;Landroidx/activity/result/ActivityResult;)V

    return-void
.end method
