.class public final Lcom/example/carcontroller/CarClient$Companion;
.super Ljava/lang/Object;
.source "CarClient.kt"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/example/carcontroller/CarClient;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x19
    name = "Companion"
.end annotation

.annotation runtime Lkotlin/Metadata;
    d1 = {
        "\u0000 \n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0002\u0008\u0002\n\u0002\u0010\u0008\n\u0002\u0008\u0003\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u000e\n\u0000\u0008\u0086\u0003\u0018\u00002\u00020\u0001B\u0007\u0008\u0002\u00a2\u0006\u0002\u0010\u0002J\u000e\u0010\u0007\u001a\u00020\u00082\u0006\u0010\t\u001a\u00020\nR\u000e\u0010\u0003\u001a\u00020\u0004X\u0086T\u00a2\u0006\u0002\n\u0000R\u000e\u0010\u0005\u001a\u00020\u0004X\u0086T\u00a2\u0006\u0002\n\u0000R\u000e\u0010\u0006\u001a\u00020\u0004X\u0086T\u00a2\u0006\u0002\n\u0000\u00a8\u0006\u000b"
    }
    d2 = {
        "Lcom/example/carcontroller/CarClient$Companion;",
        "",
        "()V",
        "CONNECT_TIMEOUT_MS",
        "",
        "DEFAULT_PORT",
        "READ_TIMEOUT_MS",
        "parseReply",
        "Lcom/example/carcontroller/CarClient$Result;",
        "line",
        "",
        "app_debug"
    }
    k = 0x1
    mv = {
        0x1,
        0x9,
        0x0
    }
    xi = 0x30
.end annotation


# direct methods
.method private constructor <init>()V
    .locals 0

    .line 70
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method

.method public synthetic constructor <init>(Lkotlin/jvm/internal/DefaultConstructorMarker;)V
    .locals 0

    invoke-direct {p0}, Lcom/example/carcontroller/CarClient$Companion;-><init>()V

    return-void
.end method


# virtual methods
.method public final parseReply(Ljava/lang/String;)Lcom/example/carcontroller/CarClient$Result;
    .locals 4
    .param p1, "line"    # Ljava/lang/String;

    const-string v0, "line"

    invoke-static {p1, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 75
    nop

    .line 76
    const-string v0, "OK"

    invoke-static {p1, v0}, Lkotlin/jvm/internal/Intrinsics;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v0

    const/4 v1, 0x2

    const/4 v2, 0x0

    if-eqz v0, :cond_0

    new-instance v0, Lcom/example/carcontroller/CarClient$Result;

    sget-object v3, Lcom/example/carcontroller/CarClient$Code;->OK:Lcom/example/carcontroller/CarClient$Code;

    invoke-direct {v0, v3, v2, v1, v2}, Lcom/example/carcontroller/CarClient$Result;-><init>(Lcom/example/carcontroller/CarClient$Code;Ljava/lang/String;ILkotlin/jvm/internal/DefaultConstructorMarker;)V

    goto :goto_0

    .line 77
    :cond_0
    const-string v0, "ERR_AUTH"

    invoke-static {p1, v0}, Lkotlin/jvm/internal/Intrinsics;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_1

    new-instance v0, Lcom/example/carcontroller/CarClient$Result;

    sget-object v3, Lcom/example/carcontroller/CarClient$Code;->AUTH:Lcom/example/carcontroller/CarClient$Code;

    invoke-direct {v0, v3, v2, v1, v2}, Lcom/example/carcontroller/CarClient$Result;-><init>(Lcom/example/carcontroller/CarClient$Code;Ljava/lang/String;ILkotlin/jvm/internal/DefaultConstructorMarker;)V

    goto :goto_0

    .line 78
    :cond_1
    const-string v0, "ERR_LOCKED"

    invoke-static {p1, v0}, Lkotlin/jvm/internal/Intrinsics;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_2

    new-instance v0, Lcom/example/carcontroller/CarClient$Result;

    sget-object v3, Lcom/example/carcontroller/CarClient$Code;->LOCKED:Lcom/example/carcontroller/CarClient$Code;

    invoke-direct {v0, v3, v2, v1, v2}, Lcom/example/carcontroller/CarClient$Result;-><init>(Lcom/example/carcontroller/CarClient$Code;Ljava/lang/String;ILkotlin/jvm/internal/DefaultConstructorMarker;)V

    goto :goto_0

    .line 79
    :cond_2
    const-string v0, "ERR_UNKNOWN"

    invoke-static {p1, v0}, Lkotlin/jvm/internal/Intrinsics;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_3

    new-instance v0, Lcom/example/carcontroller/CarClient$Result;

    sget-object v3, Lcom/example/carcontroller/CarClient$Code;->UNKNOWN:Lcom/example/carcontroller/CarClient$Code;

    invoke-direct {v0, v3, v2, v1, v2}, Lcom/example/carcontroller/CarClient$Result;-><init>(Lcom/example/carcontroller/CarClient$Code;Ljava/lang/String;ILkotlin/jvm/internal/DefaultConstructorMarker;)V

    goto :goto_0

    .line 80
    :cond_3
    const-string v0, "ERR_FORMAT"

    invoke-static {p1, v0}, Lkotlin/jvm/internal/Intrinsics;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_4

    new-instance v0, Lcom/example/carcontroller/CarClient$Result;

    sget-object v3, Lcom/example/carcontroller/CarClient$Code;->FORMAT:Lcom/example/carcontroller/CarClient$Code;

    invoke-direct {v0, v3, v2, v1, v2}, Lcom/example/carcontroller/CarClient$Result;-><init>(Lcom/example/carcontroller/CarClient$Code;Ljava/lang/String;ILkotlin/jvm/internal/DefaultConstructorMarker;)V

    goto :goto_0

    .line 81
    :cond_4
    const/4 v0, 0x0

    const-string v3, "ERR_EXEC"

    invoke-static {p1, v3, v0, v1, v2}, Lkotlin/text/StringsKt;->startsWith$default(Ljava/lang/String;Ljava/lang/String;ZILjava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_5

    new-instance v0, Lcom/example/carcontroller/CarClient$Result;

    sget-object v1, Lcom/example/carcontroller/CarClient$Code;->EXEC:Lcom/example/carcontroller/CarClient$Code;

    check-cast v3, Ljava/lang/CharSequence;

    invoke-static {p1, v3}, Lkotlin/text/StringsKt;->removePrefix(Ljava/lang/String;Ljava/lang/CharSequence;)Ljava/lang/String;

    move-result-object v2

    check-cast v2, Ljava/lang/CharSequence;

    invoke-static {v2}, Lkotlin/text/StringsKt;->trim(Ljava/lang/CharSequence;)Ljava/lang/CharSequence;

    move-result-object v2

    invoke-virtual {v2}, Ljava/lang/Object;->toString()Ljava/lang/String;

    move-result-object v2

    invoke-direct {v0, v1, v2}, Lcom/example/carcontroller/CarClient$Result;-><init>(Lcom/example/carcontroller/CarClient$Code;Ljava/lang/String;)V

    goto :goto_0

    .line 82
    :cond_5
    new-instance v0, Lcom/example/carcontroller/CarClient$Result;

    sget-object v1, Lcom/example/carcontroller/CarClient$Code;->NO_REPLY:Lcom/example/carcontroller/CarClient$Code;

    invoke-direct {v0, v1, p1}, Lcom/example/carcontroller/CarClient$Result;-><init>(Lcom/example/carcontroller/CarClient$Code;Ljava/lang/String;)V

    .line 83
    :goto_0
    return-object v0
.end method
