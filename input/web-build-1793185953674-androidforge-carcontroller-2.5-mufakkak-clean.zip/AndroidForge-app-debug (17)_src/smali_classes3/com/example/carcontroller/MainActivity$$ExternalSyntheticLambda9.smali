.class public final synthetic Lcom/example/carcontroller/MainActivity$$ExternalSyntheticLambda9;
.super Ljava/lang/Object;
.source "D8$$SyntheticClass"

# interfaces
.implements Landroid/view/View$OnClickListener;


# instance fields
.field public final synthetic f$0:Lcom/example/carcontroller/MainActivity;

.field public final synthetic f$1:Ljava/lang/String;

.field public final synthetic f$2:Lcom/example/carcontroller/Control;

.field public final synthetic f$3:Ljava/lang/Integer;


# direct methods
.method public synthetic constructor <init>(Lcom/example/carcontroller/MainActivity;Ljava/lang/String;Lcom/example/carcontroller/Control;Ljava/lang/Integer;)V
    .locals 0

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Lcom/example/carcontroller/MainActivity$$ExternalSyntheticLambda9;->f$0:Lcom/example/carcontroller/MainActivity;

    iput-object p2, p0, Lcom/example/carcontroller/MainActivity$$ExternalSyntheticLambda9;->f$1:Ljava/lang/String;

    iput-object p3, p0, Lcom/example/carcontroller/MainActivity$$ExternalSyntheticLambda9;->f$2:Lcom/example/carcontroller/Control;

    iput-object p4, p0, Lcom/example/carcontroller/MainActivity$$ExternalSyntheticLambda9;->f$3:Ljava/lang/Integer;

    return-void
.end method


# virtual methods
.method public final onClick(Landroid/view/View;)V
    .locals 4

    iget-object v0, p0, Lcom/example/carcontroller/MainActivity$$ExternalSyntheticLambda9;->f$0:Lcom/example/carcontroller/MainActivity;

    iget-object v1, p0, Lcom/example/carcontroller/MainActivity$$ExternalSyntheticLambda9;->f$1:Ljava/lang/String;

    iget-object v2, p0, Lcom/example/carcontroller/MainActivity$$ExternalSyntheticLambda9;->f$2:Lcom/example/carcontroller/Control;

    iget-object v3, p0, Lcom/example/carcontroller/MainActivity$$ExternalSyntheticLambda9;->f$3:Ljava/lang/Integer;

    invoke-static {v0, v1, v2, v3, p1}, Lcom/example/carcontroller/MainActivity;->$r8$lambda$YhpC8PtvEtB9dgpMQWuyuso_pCA(Lcom/example/carcontroller/MainActivity;Ljava/lang/String;Lcom/example/carcontroller/Control;Ljava/lang/Integer;Landroid/view/View;)V

    return-void
.end method
