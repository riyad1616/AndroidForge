.class public final synthetic Lcom/example/carcontroller/MainActivity$$ExternalSyntheticLambda0;
.super Ljava/lang/Object;
.source "D8$$SyntheticClass"

# interfaces
.implements Landroidx/core/view/OnApplyWindowInsetsListener;


# instance fields
.field public final synthetic f$0:Landroid/view/View;

.field public final synthetic f$1:I

.field public final synthetic f$2:Landroid/view/View;

.field public final synthetic f$3:I


# direct methods
.method public synthetic constructor <init>(Landroid/view/View;ILandroid/view/View;I)V
    .locals 0

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Lcom/example/carcontroller/MainActivity$$ExternalSyntheticLambda0;->f$0:Landroid/view/View;

    iput p2, p0, Lcom/example/carcontroller/MainActivity$$ExternalSyntheticLambda0;->f$1:I

    iput-object p3, p0, Lcom/example/carcontroller/MainActivity$$ExternalSyntheticLambda0;->f$2:Landroid/view/View;

    iput p4, p0, Lcom/example/carcontroller/MainActivity$$ExternalSyntheticLambda0;->f$3:I

    return-void
.end method


# virtual methods
.method public final onApplyWindowInsets(Landroid/view/View;Landroidx/core/view/WindowInsetsCompat;)Landroidx/core/view/WindowInsetsCompat;
    .locals 6

    iget-object v0, p0, Lcom/example/carcontroller/MainActivity$$ExternalSyntheticLambda0;->f$0:Landroid/view/View;

    iget v1, p0, Lcom/example/carcontroller/MainActivity$$ExternalSyntheticLambda0;->f$1:I

    iget-object v2, p0, Lcom/example/carcontroller/MainActivity$$ExternalSyntheticLambda0;->f$2:Landroid/view/View;

    iget v3, p0, Lcom/example/carcontroller/MainActivity$$ExternalSyntheticLambda0;->f$3:I

    move-object v4, p1

    move-object v5, p2

    invoke-static/range {v0 .. v5}, Lcom/example/carcontroller/MainActivity;->$r8$lambda$5cDgd-2bDRHQxX8U80P0rcr-wzo(Landroid/view/View;ILandroid/view/View;ILandroid/view/View;Landroidx/core/view/WindowInsetsCompat;)Landroidx/core/view/WindowInsetsCompat;

    move-result-object p1

    return-object p1
.end method
