.class public final synthetic Lcom/example/carcontroller/MainActivity$$ExternalSyntheticLambda10;
.super Ljava/lang/Object;
.source "D8$$SyntheticClass"

# interfaces
.implements Landroid/content/DialogInterface$OnClickListener;


# instance fields
.field public final synthetic f$0:Lcom/example/carcontroller/MainActivity;

.field public final synthetic f$1:Lcom/example/carcontroller/PairingLink$Data;


# direct methods
.method public synthetic constructor <init>(Lcom/example/carcontroller/MainActivity;Lcom/example/carcontroller/PairingLink$Data;)V
    .locals 0

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Lcom/example/carcontroller/MainActivity$$ExternalSyntheticLambda10;->f$0:Lcom/example/carcontroller/MainActivity;

    iput-object p2, p0, Lcom/example/carcontroller/MainActivity$$ExternalSyntheticLambda10;->f$1:Lcom/example/carcontroller/PairingLink$Data;

    return-void
.end method


# virtual methods
.method public final onClick(Landroid/content/DialogInterface;I)V
    .locals 2

    iget-object v0, p0, Lcom/example/carcontroller/MainActivity$$ExternalSyntheticLambda10;->f$0:Lcom/example/carcontroller/MainActivity;

    iget-object v1, p0, Lcom/example/carcontroller/MainActivity$$ExternalSyntheticLambda10;->f$1:Lcom/example/carcontroller/PairingLink$Data;

    invoke-static {v0, v1, p1, p2}, Lcom/example/carcontroller/MainActivity;->$r8$lambda$zQ46SAyN-qmJIB6Wnh8faEIYO-8(Lcom/example/carcontroller/MainActivity;Lcom/example/carcontroller/PairingLink$Data;Landroid/content/DialogInterface;I)V

    return-void
.end method
