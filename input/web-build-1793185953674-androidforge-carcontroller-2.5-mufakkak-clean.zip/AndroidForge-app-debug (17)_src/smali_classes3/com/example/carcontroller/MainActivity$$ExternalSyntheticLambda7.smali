.class public final synthetic Lcom/example/carcontroller/MainActivity$$ExternalSyntheticLambda7;
.super Ljava/lang/Object;
.source "D8$$SyntheticClass"

# interfaces
.implements Landroid/content/DialogInterface$OnClickListener;


# instance fields
.field public final synthetic f$0:Lcom/example/carcontroller/MainActivity;


# direct methods
.method public synthetic constructor <init>(Lcom/example/carcontroller/MainActivity;)V
    .locals 0

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Lcom/example/carcontroller/MainActivity$$ExternalSyntheticLambda7;->f$0:Lcom/example/carcontroller/MainActivity;

    return-void
.end method


# virtual methods
.method public final onClick(Landroid/content/DialogInterface;I)V
    .locals 1

    iget-object v0, p0, Lcom/example/carcontroller/MainActivity$$ExternalSyntheticLambda7;->f$0:Lcom/example/carcontroller/MainActivity;

    invoke-static {v0, p1, p2}, Lcom/example/carcontroller/MainActivity;->$r8$lambda$G74EyzD3O-pS4yEPIDNflujjj4U(Lcom/example/carcontroller/MainActivity;Landroid/content/DialogInterface;I)V

    return-void
.end method
