package com.riyad.geely.launcher;

import android.content.ComponentName;
import android.content.Context;
import android.content.ServiceConnection;
import android.os.IBinder;
import android.util.Log;

import java.lang.reflect.InvocationHandler;
import java.lang.reflect.Method;
import java.lang.reflect.Proxy;

/**
 * يقرأ سرعة السيارة من خدمة android.car الموجودة في نظام الشاشة.
 *
 * مكتبة android.car غير موجودة في Android SDK العادي، وبالتالي الاستيراد المباشر
 * (import android.car.Car) يكسر البناء على GitHub Actions / Android Forge.
 * لذلك نصل إليها بالـ Reflection: يبنى المشروع في أي مكان، ويعمل على الشاشة
 * إذا كانت المكتبة موجودة، وإلا يكتفي بتسجيل تحذير في Logcat دون أن ينهار التطبيق.
 */
final class CarSpeedReader {

    interface Listener {
        /** تُستدعى على خيط غير الخيط الرئيسي، فاستعمل runOnUiThread للتحديث. */
        void onSpeedKmh(int kmh);
    }

    private static final String TAG = "CarSpeedReader";

    /** VehiclePropertyIds.PERF_VEHICLE_SPEED (متر/ثانية). غيّر الرقم إذا كانت شاشتك تستعمل رقما خاصا بالشركة. */
    static final int PROPERTY_SPEED = 291504647;
    private static final float SAMPLE_RATE_HZ = 10.0f;

    private final Context context;
    private final Listener listener;

    private Class<?> carClass;
    private Class<?> managerClass;
    private Class<?> callbackClass;
    private Object car;
    private Object propertyManager;
    private Object callback;

    private final ServiceConnection serviceConnection = new ServiceConnection() {
        @Override
        public void onServiceConnected(ComponentName name, IBinder service) {
            registerSpeedCallback();
        }

        @Override
        public void onServiceDisconnected(ComponentName name) {
            propertyManager = null;
            callback = null;
        }
    };

    CarSpeedReader(Context context, Listener listener) {
        this.context = context.getApplicationContext() != null ? context.getApplicationContext() : context;
        this.listener = listener;
    }

    /** يتصل بخدمة السيارة ويبدأ استقبال السرعة. آمن للاستدعاء أكثر من مرة. */
    void start() {
        if (car != null) {
            return;
        }
        try {
            carClass = Class.forName("android.car.Car");
            Method createWithConnection = findMethod(carClass, "createCar", Context.class, ServiceConnection.class);
            if (createWithConnection != null) {
                car = createWithConnection.invoke(null, context, serviceConnection);
                carClass.getMethod("connect").invoke(car);
            } else {
                // نسخ أحدث من النظام: createCar(Context) تعيد خدمة متصلة مباشرة
                car = carClass.getMethod("createCar", Context.class).invoke(null, context);
                registerSpeedCallback();
            }
        } catch (ClassNotFoundException e) {
            Log.w(TAG, "android.car غير موجودة على هذا الجهاز، لن تظهر السرعة");
        } catch (ReflectiveOperationException | RuntimeException e) {
            Log.e(TAG, "فشل الاتصال بخدمة السيارة", e);
            car = null;
        }
    }

    /** يوقف استقبال السرعة ويقطع الاتصال بخدمة السيارة. */
    void stop() {
        try {
            if (propertyManager != null && callback != null && managerClass != null && callbackClass != null) {
                managerClass.getMethod("unregisterCallback", callbackClass).invoke(propertyManager, callback);
            }
        } catch (ReflectiveOperationException | RuntimeException e) {
            Log.w(TAG, "تعذر إلغاء تسجيل مستمع السرعة", e);
        }
        try {
            if (car != null && carClass != null) {
                carClass.getMethod("disconnect").invoke(car);
            }
        } catch (ReflectiveOperationException | RuntimeException e) {
            Log.w(TAG, "تعذر قطع الاتصال بخدمة السيارة", e);
        }
        propertyManager = null;
        callback = null;
        car = null;
    }

    private void registerSpeedCallback() {
        try {
            // Car.PROPERTY_SERVICE = "property"
            propertyManager = carClass.getMethod("getCarManager", String.class).invoke(car, "property");
            if (propertyManager == null) {
                Log.w(TAG, "خدمة property غير متوفرة");
                return;
            }
            managerClass = Class.forName("android.car.hardware.property.CarPropertyManager");
            callbackClass = Class.forName(
                    "android.car.hardware.property.CarPropertyManager$CarPropertyEventCallback");

            callback = Proxy.newProxyInstance(
                    CarSpeedReader.class.getClassLoader(),
                    new Class<?>[]{callbackClass},
                    new InvocationHandler() {
                        @Override
                        public Object invoke(Object proxy, Method method, Object[] args) {
                            String name = method.getName();
                            if ("onChangeEvent".equals(name) && args != null && args.length == 1) {
                                handlePropertyValue(args[0]);
                            } else if ("hashCode".equals(name)) {
                                return System.identityHashCode(proxy);
                            } else if ("equals".equals(name)) {
                                return args != null && args.length == 1 && proxy == args[0];
                            } else if ("toString".equals(name)) {
                                return "CarSpeedCallback";
                            }
                            return null;
                        }
                    });

            managerClass.getMethod("registerCallback", callbackClass, int.class, float.class)
                    .invoke(propertyManager, callback, PROPERTY_SPEED, SAMPLE_RATE_HZ);
        } catch (ReflectiveOperationException | RuntimeException e) {
            // مثلا SecurityException إذا لم تُمنح صلاحية CAR_SPEED
            Log.e(TAG, "فشل تسجيل مستمع السرعة", e);
        }
    }

    private void handlePropertyValue(Object carPropertyValue) {
        try {
            Class<?> valueClass = carPropertyValue.getClass();
            Object id = valueClass.getMethod("getPropertyId").invoke(carPropertyValue);
            if (!(id instanceof Integer) || (Integer) id != PROPERTY_SPEED) {
                return;
            }
            Object value = valueClass.getMethod("getValue").invoke(carPropertyValue);
            if (value instanceof Number) {
                float metersPerSecond = ((Number) value).floatValue();
                listener.onSpeedKmh(Math.round(metersPerSecond * 3.6f));
            }
        } catch (ReflectiveOperationException | RuntimeException e) {
            Log.w(TAG, "تعذر قراءة قيمة السرعة", e);
        }
    }

    private static Method findMethod(Class<?> cls, String name, Class<?>... parameterTypes) {
        try {
            return cls.getMethod(name, parameterTypes);
        } catch (NoSuchMethodException e) {
            return null;
        }
    }
}
