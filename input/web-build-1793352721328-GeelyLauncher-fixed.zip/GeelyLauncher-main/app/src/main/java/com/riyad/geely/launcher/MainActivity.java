package com.riyad.geely.launcher;

import android.content.pm.PackageManager;
import android.os.Bundle;
import android.view.MotionEvent;
import android.view.View;
import android.view.WindowManager;
import android.widget.LinearLayout;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;
import androidx.viewpager2.widget.ViewPager2;

public class MainActivity extends AppCompatActivity {

    private static final String PERMISSION_CAR_SPEED = "android.car.permission.CAR_SPEED";
    private static final int REQUEST_CAR_SPEED = 1001;

    // أقل وأكثر نسبة يمكن أن تأخذها الجهة اليسرى عند سحب المقبض
    private static final float MIN_LEFT_PERCENT = 30f;
    private static final float MAX_LEFT_PERCENT = 70f;

    private ViewPager2 leftViewPager;
    private View dragDivider;
    private View rightContainer;
    private LinearLayout splitMainLayout;
    private TextView speedDisplay;

    private CarSpeedReader speedReader;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        // السماح بلمسين متزامنين في نافذتين (كان الرقم 0x00800000 مكتوبا مباشرة)
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_SPLIT_TOUCH);
        setContentView(R.layout.activity_main);

        splitMainLayout = findViewById(R.id.splitMainLayout);
        leftViewPager = findViewById(R.id.leftContainerViewPager);
        dragDivider = findViewById(R.id.dragDivider);
        rightContainer = findViewById(R.id.rightMapsContainer);
        speedDisplay = findViewById(R.id.speedDisplay);

        // TODO: leftViewPager.setAdapter(...) لإضافة صفحات الجهة اليسرى
        // TODO: وضع شاشة الخرائط داخل rightContainer

        setupInteractiveDivider();

        speedReader = new CarSpeedReader(this, kmh -> runOnUiThread(() -> showSpeed(kmh)));
        requestCarSpeedPermissionIfNeeded();
    }

    private void showSpeed(int kmh) {
        if (speedDisplay != null) {
            speedDisplay.setText(kmh + " " + getString(R.string.speed_unit));
        }
    }

    private void requestCarSpeedPermissionIfNeeded() {
        if (checkSelfPermission(PERMISSION_CAR_SPEED) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[]{PERMISSION_CAR_SPEED}, REQUEST_CAR_SPEED);
        }
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == REQUEST_CAR_SPEED
                && grantResults.length > 0
                && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
            // أعد الاتصال بعد منح الصلاحية
            speedReader.stop();
            speedReader.start();
        }
    }

    private void setupInteractiveDivider() {
        dragDivider.setOnTouchListener(new View.OnTouchListener() {
            @Override
            public boolean onTouch(View v, MotionEvent event) {
                switch (event.getActionMasked()) {
                    case MotionEvent.ACTION_MOVE:
                        updateSplit(event.getRawX());
                        break;
                    case MotionEvent.ACTION_UP:
                        v.performClick();
                        break;
                    default:
                        break;
                }
                return true;
            }
        });
    }

    /** rawX: موضع الإصبع على الشاشة بالبكسل. */
    private void updateSplit(float rawX) {
        int[] location = new int[2];
        splitMainLayout.getLocationOnScreen(location);

        float dividerWidth = dragDivider.getWidth();
        float usableWidth = splitMainLayout.getWidth() - dividerWidth;
        if (usableWidth <= 0) {
            return;
        }

        // مركز المقبض يتبع الإصبع، والنسبة تحسب من العرض الفعلي الذي تتقاسمه الجهتان
        float leftPercent = (rawX - location[0] - dividerWidth / 2f) / usableWidth * 100f;
        leftPercent = Math.max(MIN_LEFT_PERCENT, Math.min(MAX_LEFT_PERCENT, leftPercent));
        float rightPercent = 100f - leftPercent;

        LinearLayout.LayoutParams leftParams = (LinearLayout.LayoutParams) leftViewPager.getLayoutParams();
        leftParams.weight = leftPercent;
        leftViewPager.setLayoutParams(leftParams);

        LinearLayout.LayoutParams rightParams = (LinearLayout.LayoutParams) rightContainer.getLayoutParams();
        rightParams.weight = rightPercent;
        rightContainer.setLayoutParams(rightParams);
    }

    @Override
    protected void onStart() {
        super.onStart();
        speedReader.start();
    }

    @Override
    protected void onStop() {
        super.onStop();
        speedReader.stop();
    }
}
